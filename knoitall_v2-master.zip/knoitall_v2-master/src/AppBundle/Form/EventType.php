<?php

namespace AppBundle\Form;

use AppBundle\Entity\Age;
use AppBundle\Entity\Event;
use AppBundle\Entity\EventFormat;
use AppBundle\Entity\ScheduleSession;
use AppBundle\Form\DataTransformer\DateTransformer;
use AppBundle\Form\Type\DatePickerType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Ivory\CKEditorBundle\Form\Type\CKEditorType;
use AppBundle\Entity\Taxonomy;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Vich\UploaderBundle\Form\Type\VichImageType;

class EventType extends AbstractType
{
    public function configureOptions( OptionsResolver $resolver )
    {
        $resolver->setDefaults([
            'data_class' => 'AppBundle\Entity\Event',
            'eventFormatSection' => null,
            'eventFormats' => [],
        ]);
    }

    public function buildForm( FormBuilderInterface $builder, array $options )
    {
        /** @var \AppBundle\Entity\Event $event */
        $event = $builder->getData();

        /*
         * fields common for all event types:
         */

        $eventFormatSection = $options['eventFormatSection'];
        $eventFormats = $options['eventFormats'];

        $choices = [];
        /** @var \AppBundle\Entity\EventFormat $eventFormat */
        foreach( $options['eventFormats'] as $eventFormat ) {
            $choices[$eventFormat->getDescription()] = $eventFormat->getId();
        }

        $builder->add( 'eventFormat', EntityType::class, [
            'class' => 'AppBundle\Entity\EventFormat',
            'choices' => $eventFormats,
        ] );

        $builder->add('eventFormatSection', HiddenType::class, [
            'data' => $eventFormatSection,
        ] );

        $builder
            ->add('title', TextType::class, [
                'label' => 'event_form.title.label',
            ] )
            /*
             * try to customize this ckeditor input here:
             * TODO: it might be better to customize the ckeditor appearance in the template
             * rather than here but I have been unable to make it work
             */
            ->add('description', CKEditorType::class, [
                'label' => 'event_form.description.label',
                'config_name' => 'custom',
                'config' => [
                    'uiColor' => '#ffe0c0',
                    ////'width' => 448,
                    'filebrowserBrowseRoute' => 'elfinder',
                    'filebrowserBrowseRouteParameters' => ['instance' => 'event', 'homeFolder' => $event->getHash()],
                    'filebrowserUploadRoute' => 'knoitall_admin_fileupload_upload_media',
                    'filebrowserUploadRouteParameters' => ['entity' => 'event', 'hash' => $event->getHash()],
                ],
                'required' => true,
            ])
            ->add('learningOutcomes', CKEditorType::class, [
                'label' => 'event_form.learning_outcomes.label',
                'config_name' => 'minimal',
                'config' => [
                    'uiColor' => '#ffe0c0',
                    ////'width' => 448
                ],
            ])
            ->add('requirements', CKEditorType::class, [
                'label' => 'event_form.requirements.label',
                'config_name' => 'minimal',
                'config' => [
                    'uiColor' => '#ffe0c0',
                    ////'width' => 224
                ],
            ])
            ->add('taxonomies', EntityType::class, [
                'attr' => ['class' => 'select2'],
                'label' => 'event_form.taxonomies.label',
                'class' => Taxonomy::class,
                'multiple' => true,
            ])
            ->add('ages', EntityType::class, [
                'attr' => ['class' => 'select2'],
                'label' => 'event_form.ages.label',
                'class' => Age::class,
                'multiple' => true,
            ] )
            ->add('postingDate', DatePickerType::class, [
                'label' => 'event_form.posting_date.label',
                'required' => false,
                'widget' => 'single_text',
                'format' => 'yyyy-M-d',
                'attr' => ['field_type' => 'datetime', 'placeholder' => 'event_form.posting_date.placeholder', 'class' => 'datepicker form-control']
            ])
            ->add('expirationDate', DatePickerType::class, [
                'label' => 'event_form.expiration_date.label',
                'required' => false,
                'widget' => 'single_text',
                'format' => 'yyyy-M-d',
                'attr' => ['field_type' => 'datetime', 'placeholder' => 'event_form.expiration_date.placeholder', 'class' => 'datepicker form-control']
            ])
            ->add('imageFile', VichImageType::class, [
                'label' => 'event_form.image.label',
//                'data' => '????', // TODO: can we use this field rather than the image property to render a preview in the listing pages?
                'required' => false,
            ])
            ->add('advisor')
            ->add('published', CheckboxType::class, [
                'label' => 'event_form.published.label',
            ] )
            ->add('hash', HiddenType::class)
            ->add('save', SubmitType::class, [
                'label' => 'event_form.save.label',
            ] )
        ;

        /*
         * add event-type-specific fields using a listener:
         */
        $builder->addEventListener( FormEvents::PRE_SET_DATA, function (FormEvent $formEvent) {

            /** @var \AppBundle\Entity\Event $event */
            $event = $formEvent->getData();
            $form = $formEvent->getForm();

            $eventFormatSection = $form->get('eventFormatSection')->getData();

             if( $eventFormatSection == 'Generic' or $eventFormatSection == 'Other' ) {
                $form
                    ->add('numberOfSeats')
                    ->add('price')
                    ->add('startDate')
                    ->add('endDate')
                    ->add('startTime')
                    ->add('endTime')
                    ->add('location')
                    ->add('externalLink')
                    ->add('registrationLink')
                    ->add('specialInstructions', CKEditorType::class, [
                        'config_name' => 'minimal',
                        'config' => [
                            'uiColor' => '#ffe0c0',
                            ////'width' => 224
                        ],
                    ])
                    ->add('scheduleSessions', CollectionType::class, [
                        'entry_type' => ScheduleSessionType::class,
                        'allow_add' => true,
                        'allow_delete' => true,
                    ])
                ;
            }

            /* Use EventPostType Instead
            if( $eventFormatSection == 'Post' ) {
                $form
                    ->add('externalLink')
                    ->add('specialInstructions', CKEditorType::class, [
                        'config_name' => 'minimal',
                        'config' => [
                            'uiColor' => '#ffe0c0',
                            ////'width' => 224
                        ],
                    ] )
                ;
            }*/

            if( $eventFormatSection == 'Free Resource' ) { // Free Resource (Video, Article, Pod Cast or Other)
                $form
                    ->add('externalLink', TextType::class, [
                        'label' => 'event_form.external_link.label',
                        'attr' => [
                            'placeholder' => 'event_form.external_link.placeholder'
                        ],
                    ] )
                ;
            }

            if( $eventFormatSection == 'Self-Directed' ) { // Resource For Sale (Video, Article, Pod Cast or Other)
                $form
                    ->add('numberOfSeats')
                    ->add('price')
                ;
            }

            /*
             * class/seminar/webinar with fixed schedule
             */
            if( $eventFormatSection == 'Class' ) {
                $form
                    ->add('numberOfSeats')
                    ->add('price')
                    ->add('startDate')
                    ->add('endDate')
                    ->add('startTime')
                    ->add('endTime')
                    ->add('location')
                    ->add('specialInstructions', CKEditorType::class, [
                        'config_name' => 'minimal',
                        'config' => [
                            'uiColor' => '#ffe0c0',
                            ////'width' => 224
                        ],
                    ])
                    ->add('scheduleSessions', CollectionType::class, [
                        'entry_type' => ScheduleSessionType::class,
                        'allow_add' => true,
                        'allow_delete' => true,
                    ])
                ;
            }

            /*
             * tutoring/advising/ongoing - more or less the same as the above 'Class' but without a fixed schedule
             */
            if( $eventFormatSection == 'Lessons' ) {
                $form
                    ->add('numberOfSeats')
                    ->add('price')
                    ->add('location')
                    ->add('specialInstructions', CKEditorType::class, [
                        'config_name' => 'minimal',
                        'config' => [
                            'uiColor' => '#ffe0c0',
                            ////'width' => 224
                        ],
                    ])
                ;
            }

            /*
             * product that must be shipped
             */
            if( $eventFormatSection == 'Product' ) {
                $form
                    ->add('numberOfSeats')
                    ->add('price')
                    ->add('specialInstructions', CKEditorType::class, [
                        'config_name' => 'minimal',
                        'config' => [
                            'uiColor' => '#ffe0c0',
                            ////'width' => 224
                        ],
                    ])
                ;
            }

            /*
             * certificate/degree program
             */
            if( $eventFormatSection == 'Certificate' ) {
                $form
                    ->add('numberOfSeats')
                    ->add('price')
                    ->add('registrationLink')
                    ->add('location')
                    ->add('specialInstructions', CKEditorType::class, [
                        'config_name' => 'minimal',
                        'config' => [
                            'uiColor' => '#ffe0c0',
                            ////'width' => 224
                        ],
                    ])
                ;
            }

        } );

    }
}

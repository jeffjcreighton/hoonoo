<?php

namespace AppBundle\Form;

use AppBundle\Entity\Age;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Vich\UploaderBundle\Form\Type\VichImageType;
use Ivory\CKEditorBundle\Form\Type\CKEditorType;
use AppBundle\Entity\Taxonomy;

class EventPostType extends AbstractType
{
    public function configureOptions( OptionsResolver $resolver )
    {
        $resolver->setDefaults([
            'data_class' => 'AppBundle\Entity\Event',
            'eventFormatSection' => null,
            'eventFormats' => [],
        ]);
    }

    public function buildForm( FormBuilderInterface $builder, array $options )
    {
        /** @var \AppBundle\Entity\Event $event */
        $event = $builder->getData();

        /*
         * fields common for all event types:
         */

        $eventFormatSection = $options['eventFormatSection'];
        $eventFormats = $options['eventFormats'];

        $choices = [];
        /** @var \AppBundle\Entity\EventFormat $eventFormat */
        foreach( $options['eventFormats'] as $eventFormat ) {
            $choices[$eventFormat->getDescription()] = $eventFormat->getId();
        }

        $builder->add( 'eventFormat', EntityType::class, [
            'class' => 'AppBundle\Entity\EventFormat',
            'choices' => $eventFormats,
        ] );

        $builder->add('eventFormatSection', HiddenType::class, [
            'data' => $eventFormatSection,
        ] );

        $builder
            ->add('title', TextType::class, [
                'label' => 'event_form.title.label',
                'attr' => [
                    'placeholder' => 'event_form.title.placeholder',
                ]
            ] )
            ->add('learningOutcomes', TextareaType::class, [
                'label' => 'event_form.learning_outcomes.label',
                'attr' => [
                    'placeholder' => 'event_form.learning_outcomes.placeholder',
                ],
            ] )
            /*
             * try to customize this ckeditor input here:
             * TODO: it might be better to customize the ckeditor appearance in the template
             * rather than here but I have been unable to make it work
             */
            ->add('description', CKEditorType::class, [
                'label' => 'event_form.description.label',
                'config_name' => 'custom',
                'config' => [
                    'uiColor' => '#ffe0c0',
                    ////'width' => 448,
                    'filebrowserBrowseRoute' => 'elfinder',
                    'filebrowserBrowseRouteParameters' => ['instance' => 'event', 'homeFolder' => $event->getHash()],
                    'filebrowserUploadRoute' => 'knoitall_admin_fileupload_upload_media',
                    'filebrowserUploadRouteParameters' => ['entity' => 'event', 'hash' => $event->getHash()],
                ],
                'required' => true,
            ])
            /*->add('description', CKEditorType::class, array(
                'label' => 'event_form.description.label',
                'config_name' => 'custom',
                'attr' => array('placeholder' => 'Type Post'),*/
                /*'config' => array(
                    'uiColor' => '#ffe0c0',
                    'filebrowserBrowseRoute' => 'elfinder',
                    'filebrowserBrowseRouteParameters' => array('instance' => 'event', 'homeFolder' => $event->getHash()),
                    'filebrowserUploadRoute' => 'knoitall_admin_fileupload_upload_media',
                    'filebrowserUploadRouteParameters' => array('entity' => 'event', 'hash' => $event->getHash()),
                    'extraPlugins' => 'confighelper',
                    'placeholder' => 'Type Post',
                ),*/
                /*'required' => false,
            ))*/
            /*->add('description', CKEditorType::class, [
                'label' => 'event_form.description.label',
                'config_name' => 'custom',
                'config' => [
                    'uiColor' => '#ffe0c0',
                    'filebrowserBrowseRoute' => 'elfinder',
                    'filebrowserBrowseRouteParameters' => ['instance' => 'event', 'homeFolder' => $event->getHash()],
                    'filebrowserUploadRoute' => 'knoitall_admin_fileupload_upload_media',
                    'filebrowserUploadRouteParameters' => ['entity' => 'event', 'hash' => $event->getHash()],
                    'extraPlugins' => 'confighelper',
                    'placeholder' => 'Type Post',
                ],
                'required' => false,
            ])*/
            ->add('externalLink', TextType::class, [
                'label' => 'event_form.external_link.label',
                'attr' => [
                    'placeholder' => 'event_form.external_link.placeholder'
                ],
                'required' => false,
            ] )
            ->add('taxonomies', EntityType::class, [
                'attr' => ['class' => 'select2'],
                'label' => 'event_form.taxonomies.label',
                'class' => Taxonomy::class,
                'multiple' => true,
                'required' => false,
            ])
            ->add('ages', EntityType::class, [
                'attr' => ['class' => 'select2'],
                'label' => 'event_form.ages.label',
                'class' => Age::class,
                'multiple' => true,
                'required' => false,
            ] )
            ->add('imageFile', VichImageType::class, [
                'label' => 'event_form.image.label',
//                'data' => '????', // TODO: can we use this field rather than the image property to render a preview in the listing pages?
                'required' => false,
            ])
            ->add('specialInstructions', CKEditorType::class, [
                        'config_name' => 'minimal',
                        'config' => [
                            'uiColor' => '#ffe0c0',
                            ////'width' => 224
                        ],
                    ] )
            ->add('published')
            ->add('hash', HiddenType::class)
            ->add('save', SubmitType::class, [
                'label' => 'event_form.save.label',
            ] )
        ;
    }
}

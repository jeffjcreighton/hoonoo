<?php

namespace AppBundle\Form;

use AppBundle\Entity\StripeAccount;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class StripeAccountType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('publishableKey')
            ->add('stripeUserId')
            ->add('refreshToken')
            ->add('accessToken')
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults( [
            'data_class' => StripeAccount::class,
        ] );
    }
}

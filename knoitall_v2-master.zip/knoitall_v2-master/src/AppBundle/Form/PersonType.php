<?php

namespace AppBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use AppBundle\Entity\Person;
use AppBundle\Entity\StripeAccount;

class PersonType extends AbstractType
{
    public function configureOptions( OptionsResolver $resolver )
    {
        $resolver->setDefaults( [
            'data_class' => Person::class,
        ] );
    }

    public function buildForm( FormBuilderInterface $builder, array $options )
    {
        $builder
            ->add('firstName')
            ->add('lastName')
            ->add('street')
            ->add('city')
            ->add('state')
            ->add('postalcode')
            ->add('stripeAccounts', CollectionType::class, [
                    'entry_type' => StripeAccountType::class,
            ] )
        ;
    }
}

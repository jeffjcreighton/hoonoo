<?php

namespace AppBundle\Form;

use AppBundle\Entity\Age;
use AppBundle\Entity\Event;
use AppBundle\Entity\EventFormat;
use AppBundle\Entity\ScheduleSession;
use AppBundle\Form\DataTransformer\DateTransformer;
use AppBundle\Form\Type\DatePickerType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Ivory\CKEditorBundle\Form\Type\CKEditorType;
use AppBundle\Entity\Taxonomy;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Vich\UploaderBundle\Form\Type\VichImageType;

class EventTypeForPost extends AbstractType
{
    public function configureOptions( OptionsResolver $resolver )
    {
        $resolver->setDefaults([
            'data_class' => 'AppBundle\Entity\Event',
            'eventFormatSection' => null,
            'eventFormats' => [],
        ]);
    }

    public function buildForm( FormBuilderInterface $builder, array $options )
    {
        /** @var \AppBundle\Entity\Event $event */
        $event = $builder->getData();

        /*
         * fields common for all event types:
         */

        $eventFormatSection = $options['eventFormatSection'];
        $eventFormats = $options['eventFormats'];

        $choices = [];
        /** @var \AppBundle\Entity\EventFormat $eventFormat */
        foreach( $options['eventFormats'] as $eventFormat ) {
            $choices[$eventFormat->getDescription()] = $eventFormat->getId();
        }

        $builder->add( 'eventFormat', EntityType::class, [
            'class' => 'AppBundle\Entity\EventFormat',
            'choices' => $eventFormats,
        ] );

        $builder->add('eventFormatSection', HiddenType::class, [
            'data' => $eventFormatSection,
        ] );

        $builder
            ->add('title', TextType::class, [
                'label' => 'event_form.title.label',
                'attr' => [
                    'placeholder' => 'event_form.title.placeholder',
                    /* Need - bootstrap_3_add_helpbloc.html.twig */
                    // 'data-help' => 'event_form.title.placeholder', 
                ],
            ])
            /*
             * try to customize this ckeditor input here:
             * TODO: it might be better to customize the ckeditor appearance in the template
             * rather than here but I have been unable to make it work
             */
            ->add('description', TextareaType::class, [
                'label' => 'event_form.description.post_label',
                /*'config_name' => 'custom',
                'config' => [
                    'uiColor' => '#ffe0c0',
                    'disableNativeSpellChecker' => false,
                    'extraPlugins' => 'confighelper',
                    'placeholder' => 'Teach me or describe the item you are linking to',
                    ////'width' => 448,
                    'filebrowserBrowseRoute' => 'elfinder',
                    'filebrowserBrowseRouteParameters' => ['instance' => 'event', 'homeFolder' => $event->getHash()],
                    'filebrowserUploadRoute' => 'knoitall_admin_fileupload_upload_media',
                    'filebrowserUploadRouteParameters' => ['entity' => 'event', 'hash' => $event->getHash()],
                ],
                'plugins' => [
                    'confighelper' => [
                        'path' => '/bundles/confighelper/',
                        'filename' => 'plugin.js',
                    ]
                ],*/
                'required' => true,
            ])
            ->add('learningOutcomes', TextareaType::class, [
                'label' => 'event_form.learning_outcomes.label',
                /*'config_name' => 'minimal',
                'config' => [
                    'uiColor' => '#ffe0c0',                    
                    'disableNativeSpellChecker' => false,
                    'extraPlugins' => 'confighelper',
                    'placeholder' => 'Learn how to...',
                ],
                'plugins' => [
                    'confighelper' => [
                        'path' => '/bundles/confighelper/',
                        'filename' => 'plugin.js',
                    ]
                ],*/
                'required' => true,
            ])
            ->add('taxonomies', EntityType::class, [
                'attr' => ['class' => 'select2'],
                'label' => 'event_form.taxonomies.label',
                'class' => Taxonomy::class,
                'multiple' => true,
            ])
            ->add('ages', EntityType::class, [
                'attr' => ['class' => 'select2'],
                'label' => 'event_form.ages.label',
                'class' => Age::class,
                'multiple' => true,
            ] )            
            ->add('externalLink', TextType::class, [
                'label' => 'event_form.external_link.label',
                'required' => false,
                'attr' => [
                    'placeholder' => 'event_form.external_link.placeholder',
                ],
            ])
            ->add('imageFile', VichImageType::class, [
                'label' => 'event_form.image.label',
                'download_link' => false,
//                'data' => '????', // TODO: can we use this field rather than the image property to render a preview in the listing pages?
                'required' => false,
            ])
            ->add('specialInstructions', TextareaType::class, [
                'label' => 'event_form.special_instructions.label',
                /*'config_name' => 'minimal',
                'config' => [
                    'uiColor' => '#ffe0c0',
                    'disableNativeSpellChecker' => false,
                    'extraPlugins' => 'confighelper',
                    'placeholder' => 'ex. I will follow up with you after your purchase to schedule your first session',
                ],
                'plugins' => [
                    'confighelper' => [
                        'path' => '/bundles/confighelper/',
                        'filename' => 'plugin.js',
                    ]
                ],*/
                'required' => false,
            ])
            ->add('published', CheckboxType::class, [
                'label' => 'event_form.published.label',
            ] )
            ->add('hash', HiddenType::class)
            ->add('save', SubmitType::class, [
                'label' => 'event_form.save.label',
            ] )
        ;

        /*
         * add event-type-specific fields using a listener:
         */
        $builder->addEventListener( FormEvents::PRE_SET_DATA, function (FormEvent $formEvent) {

            /** @var \AppBundle\Entity\Event $event */
            $event = $formEvent->getData();
            $form = $formEvent->getForm();
        } );
    }
}

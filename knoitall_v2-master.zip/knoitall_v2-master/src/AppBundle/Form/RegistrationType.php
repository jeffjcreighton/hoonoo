<?php

namespace AppBundle\Form;

use AppBundle\Entity\User;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class RegistrationType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('firstName', TextType::class, [
                'label' => 'First name',
                'attr' => [
                    'placeholder' => 'Enter your first name',
                    'class' => 'form-control input-lg',
                ],
                'label_attr' => [
                    'class' => 'control-label',
                ],
            ] )
            ->add('lastName', TextType::class, [
                'label' => 'Last name',
                'attr' => [
                    'placeholder' => 'Enter your last name',
                    'class' => 'form-control input-lg',
                ],
                'label_attr' => [
                    'class' => 'control-label',
                ],
            ] )
            /*->add('nickname', TextType::class, [
                'label' => 'Name your classroom',
                'attr' => [
                    'placeholder' => 'Classroom name (or Business name)',
                    'title' => 'Your Classroom',
                    'class' => 'form-control input-lg',
                ],
                'label_attr' => [
                    'class' => 'control-label',
                ],
            ] )*/
            ->add('email', EmailType::class, [
                'label' => 'Email address',
                'attr' => [
                    'placeholder' => 'Your email address',
                    'class' => 'form-control input-lg',
                ],
                'label_attr' => [
                    'class' => 'control-label',
                ],
            ] )
            ->add('plainPassword', RepeatedType::class, [
                'type' => PasswordType::class,
                'label' => 'Password',
                'first_options' => [
                    'label' => 'Password',
                    'attr' => [
                        'placeholder' => 'Create a password',
                        'class' => 'form-control input-lg',
                    ],
                    'label_attr' => [
                        'class' => 'control-label',
                    ],
                ],
                'second_options' => [
                    'label' => 'Repeat password',
                    'attr' => [
                        'placeholder' => 'Type your password again',
                        'class' => 'form-control input-lg',
                    ],
                    'label_attr' => [
                        'class' => 'control-label',
                    ],
                ],
            ] )
        ;

//        $builder->add('title');
//        $builder->add('personTitle');
//        $builder->add('age');
//        $builder->add('taxonomies');

        /*
         * remove username field, which is somehow automatically added:
         */
        $builder->remove('username');

        /*
         * validating e-mail format, password, and check if e-mail already registerd using a listener:
         */

        /** @var \AppBundle\Entity\User $user */
        //$user = $builder->getData();
        //$userRepository = $this->getDoctrine()->getRepository('AppBundle:User');
              
        $builder->addEventListener( FormEvents::PRE_SUBMIT, //POST_SET_DATA,
            function (FormEvent $formEvent) {
                global $kernel;
                $userManager = $kernel->getContainer()->get('fos_user.user_manager');
                $data = $formEvent->getData();
                $form = $formEvent->getForm();           
                //$emailAddress = $form->get('email')->getData();     
                $emailAddress = $data['email'];                
                $Password = $data['plainPassword'];
                if ($Password['first'] != $Password['second']) {
                    ?> <script> alert('Password must be the same.'); </script> <?php }
                //echo('Password:' . implode(",",array_keys($Password)));
                //$data['email']='';
                //$userRepo = $this->getDoctrine()->getRepository('AppBundle:User');
                //$userRepo = $userManager->getRepository('User');
                if ($userManager->findUserBy(['email' => $emailAddress])) {
                    $form->addError(new FormError('Email already registered')); }


                //$form->addError(new FormError('User already exists'));
            }
        );
    }

    public function getParent()
    {
        return 'FOS\UserBundle\Form\Type\RegistrationFormType';
    }

    public function getBlockPrefix()
    {
        return 'app_user_registration';
    }

    // For Symfony 2.x
    public function getName()
    {
        return $this->getBlockPrefix();
    }
}
<?php

namespace AppBundle\Form;

use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Ivory\CKEditorBundle\Form\Type\CKEditorType;
use AppBundle\Entity\Taxonomy;
use Vich\UploaderBundle\Form\Type\VichImageType;

class AdvisorType extends AbstractType
{
    public function configureOptions( OptionsResolver $resolver )
    {
        $resolver->setDefaults([
            'data_class' => 'AppBundle\Entity\Advisor',
        ]);
    }

    public function buildForm( FormBuilderInterface $builder, array $options )
    {
        $builder
            ->add('title', TextType::class, [
                'label' => 'advisor_form.title.label',
            ] )
            ->add('nickname', TextType::class, [
                'label' => 'advisor_form.nickname.label'
            ] )
            ->add('profile', CKEditorType::class, [
                'label' => 'advisor_form.profile.label',
                'config' => ['uiColor' => '#ffe0c0'],
            ] )
            ->add('additionalInformation', CKEditorType::class, [
                'label' => 'advisor_form.additionalInformation.label',
                'config_name' => 'minimal',
                //'config' => ['width' => 512],
            ] )
            ->add('taxonomies', EntityType::class, [
                'attr' => ['class' => 'select2'],
                'label' => 'advisor_form.taxonomies.label',
                'class' => Taxonomy::class,
                'multiple' => true,
            ] )
            ->add('imageFile', VichImageType::class, [
                'label' => 'advisor_form.image.label',
//                'data' => '????', // TODO: can we use this field rather than the image property to render a preview in the listing pages?
                'required' => false,
            ] )
            ->add('published', CheckboxType::class, [
                'label' => 'advisor_form.published.label'
            ] )
            ->add('hash', HiddenType::class)
            ->add('save', SubmitType::class, [
                'label' => 'advisor_form.save.label'
            ] )
        ;
    }
}

<?php

namespace AppBundle\Form;

use AppBundle\Entity\Pathway;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Vich\UploaderBundle\Form\Type\VichImageType;
use AppBundle\Entity\Taxonomy;

class PathwayType extends AbstractType
{
    public function configureOptions( OptionsResolver $resolver )
    {
        $resolver->setDefaults([
            'data_class' => 'AppBundle\Entity\Pathway',
        ]);
    }

    public function buildForm( FormBuilderInterface $builder, array $options )
    {
        $builder
            ->add('name', TextType::class, [
                'label' => 'pathway_form.name.label',
                'attr' => ['placeholder' => 'pathway_form.name.placeholder'],                
            ] )
            ->add('description', TextareaType::class, [
                'label' => 'pathway_form.description.label',
                'attr' => ['placeholder' => 'pathway_form.description.placeholder'],
                'required' => false,
            ] )            
            ->add('taxonomies', EntityType::class, [
                'attr' => ['class' => 'select2'],
                'label' => 'pathway_form.taxonomies.label',
                'class' => Taxonomy::class,
                'multiple' => true,
            ])
            ->add('imageFile', VichImageType::class, [
                'label' => 'pathway_form.image.label',
                'download_link' => false,
//                'data' => '????', // TODO: can we use this field rather than the image property to render a preview in the listing pages?
                'required' => false,
            ])
            ->add('published', CheckboxType::class, [
                'label' => 'pathway_form.published.label',
            ] )
            ->add('hash', HiddenType::class)
            ->add('save', SubmitType::class, [
                'label' => 'pathway_form.save.label',
            ] )
        ;        
    }
}
<?php

namespace AppBundle\Form;

use AppBundle\Entity\Learner;
use AppBundle\Entity\Provider;
use AppBundle\Repository\TaxonomyRepository;
use Doctrine\ORM\EntityRepository;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Ivory\CKEditorBundle\Form\Type\CKEditorType;
use Vich\UploaderBundle\Form\Type\VichImageType;
use AppBundle\Entity\Age;
use AppBundle\Entity\Goal;
use AppBundle\Entity\Taxonomy;

class LearnerProfileWizardStep2Type extends AbstractType
{
    public function configureOptions( OptionsResolver $resolver )
    {
        $resolver->setDefaults([
            'data_class' => 'AppBundle\Entity\Learner',
        ]);
    }

    public function buildForm( FormBuilderInterface $builder, array $options )
    {
        $builder
            ->add('followees', EntityType::class, [
                'class' => Provider::class,
                'query_builder' => function (EntityRepository $er) {
                    return $er->createQueryBuilder('p')->where('p.published = 1');
                },
                'attr' => ['class' => 'select2'],
                'label' => 'learner_form.followees.label',
                'multiple' => true,
            ] )
            ->add('save', SubmitType::class, [
                'label' => 'Continue',
                'attr' => ['class' => 'save_btn'],
            ] )
        ;
    }
}

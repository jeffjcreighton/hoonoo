<?php

namespace AppBundle\Form;

use AppBundle\Entity\Learner;
use AppBundle\Repository\TaxonomyRepository;
use Doctrine\ORM\EntityRepository;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Ivory\CKEditorBundle\Form\Type\CKEditorType;
use Vich\UploaderBundle\Form\Type\VichImageType;
use AppBundle\Entity\Age;
use AppBundle\Entity\Goal;
use AppBundle\Entity\Taxonomy;

class LearnerProfileWizardStep1Type extends AbstractType
{
    public function configureOptions( OptionsResolver $resolver )
    {
        $resolver->setDefaults([
            'data_class' => 'AppBundle\Entity\Learner',
        ]);
    }

    public function buildForm( FormBuilderInterface $builder, array $options )
    {
        $builder
            /*
             * do not include nickname here since it is in the registration form
             */
//            ->add('nickname', TextType::class, [
//                'label' => 'learner_form.nickname.label',
//            ] )
            ->add('title', TextType::class, [
                'label' => 'Name',
                'attr' => [
                    'placeholder' => 'Your complete name',
                    'title' => 'Name',
                    'class' => 'form-control input-lg',
                ],
                'label_attr' => [
                    'class' => 'control-label',
                ],
                'required' => true,
            ] )
            /* ->add('title', TextType::class, [
                'label' => 'learner_form.title.label',
                'attr' => [
                    'placeholder' => 'Your complete name',
                ],
                'required' => true,
            ] ) */
            ->add('imageFile', VichImageType::class, [
                'label' => 'learner_form.image.label',
                'download_link' => false,
                'required' => false,
            ] )
            /* ->add('goals', EntityType::class, [
                'class' => Goal::class,
                'label' => 'learner_form.goals.label',
                'choice_label' => 'description',
                'multiple' => true,
                'expanded' => true,
            ] ) */
            ->add('ages', EntityType::class, [
                'attr' => ['class' => 'select2'],
                'label' => 'learner_form.ages.label',
                'class' => Age::class,
                'multiple' => true,
            ] )
            ->add('taxonomies', EntityType::class, [
                'attr' => ['class' => 'select2'],
                'label' => 'learner_form.taxonomies.label',
                'class' => Taxonomy::class,
                'multiple' => true,
            ] )
            ->add('taxonomies', EntityType::class, [
                'class' => Taxonomy::class,
                'query_builder' => function (EntityRepository $er) {
                    return $er->createQueryBuilder('t')->where('t.inShortList=1');
                },
                'attr' => ['class' => 'select2'],
                'label' => 'learner_form.taxonomies.label',
                'multiple' => true,
            ] )
            ->add('save', SubmitType::class, [
                'label' => 'Continue',
                'attr' => ['class' => 'save_btn'],
            ] )
        ;
    }
}

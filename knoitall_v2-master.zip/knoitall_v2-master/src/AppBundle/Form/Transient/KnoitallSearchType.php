<?php

namespace AppBundle\Form\Transient;

use Symfony\Component\Form\AbstractType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use AppBundle\Entity\Taxonomy;
use AppBundle\Entity\Tag;

class KnoitallSearchType extends AbstractType
{
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => 'AppBundle\Entity\Transient\KnoitallSearch',
            ////'translation_domain' => 'forms',
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('taxonomy', EntityType::class, [
                'attr' => ['class' => 'select2'],
                'class' => Taxonomy::class,
                'multiple' => false,
                'required' => false,
                'label' => 'search_form.taxonomy.label',
                'placeholder' => 'search_form.taxonomy.placeholder'
            ] )
            ->add('tag', EntityType::class, [
                'attr' => ['class' => 'select2'],
                'class' => Tag::class,
                'multiple' => false,
                'required' => false,
                'label' => 'search_form.tag.label',
                'placeholder' => 'search_form.tag.placeholder',
            ] )
            ->add('zip', TextType::class, [
                'attr' => ['placeholder' => 'search_form.zip.placeholder'],
                'required' => false,
                'label' => 'search_form.zip.label',
            ])
            ->add('submit', SubmitType::class, [
                'label' => 'search_form.submit.label',
            ] )
        ;
    }
}

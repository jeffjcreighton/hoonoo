<?php

namespace AppBundle\Form;

use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Ivory\CKEditorBundle\Form\Type\CKEditorType;
use AppBundle\Entity\Taxonomy;
use Vich\UploaderBundle\Form\Type\VichImageType;

class ProviderType extends AbstractType
{
    public function configureOptions( OptionsResolver $resolver )
    {
        $resolver->setDefaults([
            'data_class' => 'AppBundle\Entity\Provider',
        ]);
    }

    public function buildForm( FormBuilderInterface $builder, array $options )
    {
        $builder
            ->add('title', TextType::class, [
                'label' => 'provider_form.title.label',
                'attr' => [
                    'placeholder' => 'Classroom name (or Business name)',
                ],
                'required' => true,
            ] )
            ->add('nickname', TextType::class, [
                'label' => 'provider_form.nickname.label',
                'attr' => [
                    'placeholder' => 'Your classroom unique screen name',
                ],
                'required' => true,
            ] )
            ->add('profile', TextareaType::class, [
                'label' => 'provider_form.profile.label',
                /*'config' => ['uiColor' => '#ffe0c0',
                'extraPlugins' => 'confighelper',
                'placeholder' => 'What learning topics are covered? What are you selling?',
                ],
                'plugins' => [
                    'confighelper' => [
                        'path' => '/bundles/confighelper/',
                        'filename' => 'plugin.js',
                    ]
                ],*/
                'required' => false,
            ])
            ->add('additionalInformation', TextareaType::class, [
                'label' => 'provider_form.additionalInformation.label',
                //'config' => ['uiColor' => '#ffe0c0'],
                //'config_name' => 'minimal',
                //'config' => ['width' => 512],
                'required' => false,
            ])
            ->add('taxonomies', EntityType::class, [
                'attr' => ['class' => 'select2'],
                'label' => 'provider_form.taxonomies.label',
                'class' => Taxonomy::class,
                'multiple' => true,
            ])
            ->add('imageFile', VichImageType::class, [
                'label' => 'provider_form.image.label',
                'download_link' => false,
//                'data' => '????', // TODO: can we use this field rather than the image property to render a preview in the listing pages?
                'required' => false,
            ])
            ->add('published', CheckboxType::class, [
                'label' => 'provider_form.published.label',
            ] )
            ->add('hash', HiddenType::class)
            ->add('save', SubmitType::class, [
                'label' => 'provider_form.save.label',
            ] )
        ;
    }
}

<?php

namespace AppBundle\Form;

use AppBundle\Entity\State;
use AppBundle\Entity\Location;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\TimeType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class LocationType extends AbstractType
{
    public function configureOptions( OptionsResolver $resolver )
    {
        $resolver->setDefaults([
            'data_class' => 'AppBundle\Entity\Location',
        ]);
    }

    public function buildForm( FormBuilderInterface $builder, array $options )
    {
        $builder
            ->add('name', TextType::class, [
                'label' => 'location_form.name.label',
                'attr' => ['placeholder' => 'location_form.name.placeholder'],                
            ] )
            ->add('description', TextareaType::class, [
                'label' => 'location_form.description.label',
                'attr' => ['placeholder' => 'location_form.description.placeholder'],
                'required' => false,
            ] )
            ->add( 'locationType', EntityType::class, [
                'label' => 'location_form.location_type.label',
                'class' => 'AppBundle\Entity\LocationType',
            ] )
            ->add('street', TextType::class, [
                'label' => 'location_form.street.label',
                'attr' => ['placeholder' => 'location_form.street.placeholder'],
            ] )
            ->add('city', TextType::class, [
                'label' => 'location_form.city.label',
                'attr' => ['placeholder' => 'location_form.city.placeholder'],
            ] )
            ->add( 'state', EntityType::class, [
                'label' => 'location_form.state.label',
                'class' => 'AppBundle\Entity\State',
            ] )
            ->add('zip', TextType::class, [
                'label' => 'location_form.zip.label',
                'attr' => ['placeholder' => 'location_form.zip.placeholder'],
            ] )
            ->add('published', CheckboxType::class, [
                'label' => ' ',
                'required' => false,
            ] )
            ->add('latitude', NumberType::class, [
                'scale' => 6,
                'attr' => [
                    'min' => '-90',
                    'max' => '90',
                    'step' => '0.000001',
                ],                
            ] )
            ->add('longitude', NumberType::class, [
                'scale' => 6,
                'attr' => [
                    'min' => '-180',
                    'max' => '180',
                    'step' => '0.000001',
                ],                
            ] )
            ->add('hash', HiddenType::class)
            ->add('save', SubmitType::class, [
                'label' => 'location_form.save.label',
            ] )
        ;        
    }
}
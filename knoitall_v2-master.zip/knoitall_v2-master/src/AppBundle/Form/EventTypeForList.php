<?php

namespace AppBundle\Form;

use AppBundle\Entity\Age;
use AppBundle\Entity\Event;
use AppBundle\Entity\Location;
use AppBundle\Entity\EventFormat;
use AppBundle\Entity\ScheduleSession;
use AppBundle\Form\DataTransformer\DateTransformer;
use AppBundle\Form\Type\DatePickerType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\TimeType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Ivory\CKEditorBundle\Form\Type\CKEditorType;
use AppBundle\Entity\Taxonomy;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Vich\UploaderBundle\Form\Type\VichImageType;

class EventTypeForList extends AbstractType
{
    public function configureOptions( OptionsResolver $resolver )
    {
        $resolver->setDefaults([
            'data_class' => 'AppBundle\Entity\Event',
            'eventFormatSection' => null,
            'eventFormats' => [],
            'locations' => [],
        ]);
    }

    public function buildForm( FormBuilderInterface $builder, array $options )
    {
        /** @var \AppBundle\Entity\Event $event */
        $event = $builder->getData();

        /*
         * fields common for all event types:
         */

        $eventFormatSection = $options['eventFormatSection'];
        $eventFormats = $options['eventFormats'];
        $locations = $options['locations'];

        $choices = [];
        /** @var \AppBundle\Entity\EventFormat $eventFormat */
        foreach( $options['eventFormats'] as $eventFormat ) {
            $choices[$eventFormat->getDescription()] = $eventFormat->getId();
        }

        $builder->add( 'eventFormat', EntityType::class, [
            'class' => 'AppBundle\Entity\EventFormat',
            'choices' => $eventFormats,
        ] );

        $builder->add('eventFormatSection', HiddenType::class, [
            'data' => $eventFormatSection,
        ] );

        $builder->add( 'location', EntityType::class, [
            'class' => 'AppBundle\Entity\Location',
            'choices' => $locations,
            'required' => false,
        ] );

        $builder
            ->add('title', TextType::class, [
                'label' => 'event_form.title.label',
                'attr' => ['placeholder' => 'event_form.title.placeholder'],
            ] )
            /*
             * try to customize this ckeditor input here:
             * TODO: it might be better to customize the ckeditor appearance in the template
             * rather than here but I have been unable to make it work
             */
            ->add('description', TextareaType::class, [
                'label' => 'event_form.description.label',
                /*'config_name' => 'custom',
                'config' => [
                    'uiColor' => '#ffe0c0',
                    'disableNativeSpellChecker' => false,
                    'extraPlugins' => 'confighelper',
                    'placeholder' => 'Description of your item or event',
                    ////'width' => 448,
                    'filebrowserBrowseRoute' => 'elfinder',
                    'filebrowserBrowseRouteParameters' => ['instance' => 'event', 'homeFolder' => $event->getHash()],
                    'filebrowserUploadRoute' => 'knoitall_admin_fileupload_upload_media',
                    'filebrowserUploadRouteParameters' => ['entity' => 'event', 'hash' => $event->getHash()],
                ],                
                'plugins' => [
                    'confighelper' => [
                        'path' => '/bundles/confighelper/',
                        'filename' => 'plugin.js',
                    ]
                ],*/
                'required' => true,
            ])
            ->add('learningOutcomes', TextareaType::class, [
                'label' => 'event_form.learning_outcomes.label',
                /*'config_name' => 'minimal',
                'config' => [
                    'uiColor' => '#ffe0c0',
                    'disableNativeSpellChecker' => false,
                    'extraPlugins' => 'confighelper',
                    'placeholder' => 'Learn how to...',
                ],
                'plugins' => [
                    'confighelper' => [
                        'path' => '/bundles/confighelper/',
                        'filename' => 'plugin.js',
                    ]
                ],*/
                'required' => true,
            ])
            ->add('requirements', TextareaType::class, [
                'label' => 'event_form.requirements.label',
                /*'config_name' => 'minimal',
                'config' => [
                    'uiColor' => '#ffe0c0',
                    'disableNativeSpellChecker' => false,
                    'extraPlugins' => 'confighelper',
                    'placeholder' => 'Requirements or Required Items',
                ],
                'plugins' => [
                    'confighelper' => [
                        'path' => '/bundles/confighelper/',
                        'filename' => 'plugin.js',
                    ]
                ],*/
                'required' => false,
            ])
            ->add('taxonomies', EntityType::class, [
                'attr' => ['class' => 'select2'],
                'label' => 'event_form.taxonomies.label',
                'class' => Taxonomy::class,
                'multiple' => true,
            ])
            ->add('ages', EntityType::class, [
                'attr' => ['class' => 'select2'],
                'label' => 'event_form.ages.label',
                'class' => Age::class,
                'multiple' => true,
            ] )            
            ->add('postingDate', DateType::class, [
                'label' => 'event_form.posting_date.label',
                'widget' => 'single_text',
                'required' => false,
                'format' => 'yyyy-mm-dd',  //'MM dd, yy',
                'html5' => false,
                'attr' => ['class' => 'js-datepicker', 'placeholder' => 'event_form.posting_date.placeholder'],
            ])
            ->add('expirationDate', DateType::class, [
                'label' => 'event_form.expiration_date.label',
                'widget' => 'single_text',
                'required' => false,
                'format' => 'yyyy-mm-dd',  //'MM dd, yy',
                'html5' => false,
                'attr' => ['class' => 'js-datepicker', 'placeholder' => 'event_form.expiration_date.placeholder'],
            ])
            ->add('startDate', DateType::class, [
                'widget' => 'single_text',
                'required' => false,
                'format' => 'yyyy-mm-dd',  //'MM dd, yy',
                'html5' => false,
                'attr' => ['class' => 'js-datepicker'],
            ])
            ->add('endDate', DateType::class, [
                'widget' => 'single_text',
                'required' => false,
                'format' => 'yyyy-mm-dd',  //'MM dd, yy',
                'html5' => false,
                'attr' => ['class' => 'js-datepicker'],
            ])
            ->add('startTime', TimeType::class, [
                'input'  => 'datetime',
                'required' => false,
                'widget' => 'single_text',                 
            ])
            ->add('endTime', TimeType::class, [
                'input'  => 'datetime',
                'required' => false,
                'widget' => 'single_text',                
            ])
            ->add('monday', CheckboxType::class, [
                //'label' => 'event_form.dow.mon_label',
                'label' => ' ',
                'required' => false,
            ])
            ->add('tuesday', CheckboxType::class, [
                //'label' => 'event_form.dow.tue_label',
                'label' => ' ',
                'required' => false,
            ])
            ->add('wednesday', CheckboxType::class, [
                //'label' => 'event_form.dow.wed_label',
                'label' => ' ',
                'required' => false,
            ])
            ->add('thursday', CheckboxType::class, [
                //'label' => 'event_form.dow.thu_label',
                'label' => ' ',
                'required' => false,
            ])
            ->add('friday', CheckboxType::class, [
                //'label' => 'event_form.dow.fri_label',
                'label' => ' ',
                'required' => false,
            ])
            ->add('saturday', CheckboxType::class, [
                //'label' => 'event_form.dow.sat_label',
                'label' => ' ',
                'required' => false,
            ])
            ->add('sunday', CheckboxType::class, [
                //'label' => 'event_form.dow.sun_label',
                'label' => ' ',
                'required' => false,
            ])
            ->add('specialInstructions', TextareaType::class, [
                'label' => 'event_form.scheduling_instructions.label',
                'attr' => ['placeholder' => 'event_form.scheduling_instructions.placeholder'],
                'required' => false,
            ] )
            ->add('imageFile', VichImageType::class, [
                'label' => 'event_form.image.label',
                'download_link' => false,
                /* 'data' => '????', /* TODO: can we use this field rather than the image property to render a preview in the listing pages? */
                'required' => false,
            ])            
            ->add('price')
            ->add('numberOfSeats')
            ->add('numberOfSessions')
            ->add('durationTimeUnit')
            ->add('durationAmount', IntegerType::class)
            //->add('location')
            ->add('published', CheckboxType::class, [
                'label' => 'event_form.published.label',
            ] )
            ->add('hash', HiddenType::class)
            ->add('save', SubmitType::class, [
                'label' => 'event_form.save.label',
            ] )
        ;

        /*
         * add event-type-specific fields using a listener:
         */
        $builder->addEventListener( FormEvents::PRE_SET_DATA, function (FormEvent $formEvent) {

            /** @var \AppBundle\Entity\Event $event */
            $event = $formEvent->getData();
            $form = $formEvent->getForm();
        } );

        $builder->addEventListener( FormEvents::PRE_SUBMIT, //POST_SET_DATA,
            function (FormEvent $formEvent) {
                global $kernel;
                $userManager = $kernel->getContainer()->get('fos_user.user_manager');
                $data = $formEvent->getData();
                $form = $formEvent->getForm();           
                $location = $data['location'];
                /*echo '<script type="text/javascript">',
                     'alert("Location: ' . $location . '");',                     
                     '</script>';*/
                //$location = $form->get('location')->getData();
                if ($location == "") {
                    ?> <script> alert('Location is not defined'); </script> <?php 
                    $form->get('location')->setData(null);
                    $data['location'] = null;
                    $formEvent->setData($data);
                    //$formEvent->setForm($form);                    
                }
            }
        );

    }
}

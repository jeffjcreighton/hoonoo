<?php

namespace AppBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TimeType;

class TimePickerType extends AbstractType
{
    public function setDefaultOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'widget' => 'single_text',
            'date_format' => 'Y-m-d',
            'format' => 'H:mm:ss',
            'attr' => [
                'class' => 'timepicker'
            ],
        ]);
    }

    public function getParent()
    {
        return TimeType::class;
    }

    public function getName()
    {
        return 'timepicker';
    }
}

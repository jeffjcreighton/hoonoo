<?php

namespace AppBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;

class DateTimePickerType extends AbstractType
{
    public function setDefaultOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'widget' => 'single_text',
            'date_format' => 'Y-m-d',
            'format' => 'yyyy-M-d H:mm',
            'attr' => [
                'class' => 'datetimepicker'
            ],
        ]);
    }

    public function getParent()
    {
        return DateTimeType::class;
    }

    public function getName()
    {
        return 'datetimepicker';
    }
}

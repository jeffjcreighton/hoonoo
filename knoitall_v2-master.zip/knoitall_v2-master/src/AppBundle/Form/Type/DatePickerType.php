<?php

namespace AppBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\DateType;

class DatePickerType extends AbstractType
{
    public function setDefaultOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'widget' => 'single_text',
            'date_format' => 'd.m.Y',
            'format' => 'd.M.yyyy',
            'attr' => [
                'class' => 'datepicker'
            ],
        ]);
    }

    public function getParent()
    {
        return DateType::class;
    }

    public function getName()
    {
        return 'datepicker';
    }
}

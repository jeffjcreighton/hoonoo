<?php

namespace AppBundle\Form;

use AppBundle\Entity\Learner;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Ivory\CKEditorBundle\Form\Type\CKEditorType;
use Vich\UploaderBundle\Form\Type\VichImageType;
use AppBundle\Entity\Age;
use AppBundle\Entity\Goal;
use AppBundle\Entity\Taxonomy;

class LearnerType extends AbstractType
{
    public function configureOptions( OptionsResolver $resolver )
    {
        $resolver->setDefaults([
            'data_class' => 'AppBundle\Entity\Learner',
        ]);
    }

    public function buildForm( FormBuilderInterface $builder, array $options )
    {
        $builder
            ->add('title', TextType::class, [
                'label' => 'learner_form.title.label',
                'attr' => [
                    'placeholder' => 'Your complete name',
                ],
                'required' => true,
            ] )
            ->add('nickname', TextType::class, [
                'label' => 'learner_form.nickname.label',
                'attr' => [
                    'placeholder' => 'Your learner unique screen name',
                ],
                'required' => true,
            ] )
            ->add('profile', TextareaType::class, [
                'label' => 'learner_form.profile.label',
                /*'config' => ['uiColor' => '#ffe0c0',
                'extraPlugins' => 'confighelper',
                'placeholder' => 'What are you passionate about? What can you teach others?',
                ],
                'plugins' => [
                    'confighelper' => [
                        'path' => '/bundles/confighelper/',
                        'filename' => 'plugin.js',
                    ]
                ],*/
                'required' => false,
            ])
            ->add('specialNeeds', TextareaType::class, [
                'label' => 'learner_form.special_needs.label',
                /*'config' => ['uiColor' => '#ffe0c0',
                //'config_name' => 'minimal',
                //'config' => ['width' => 512],
                'extraPlugins' => 'confighelper',
                'placeholder' => 'Ex. I have a peanut allergy',
                ],
                'plugins' => [
                    'confighelper' => [
                        'path' => '/bundles/confighelper/',
                        'filename' => 'plugin.js',
                    ]
                ],*/
                'required' => false,
            ] )
            ->add('goals', EntityType::class, [
                'class' => Goal::class,
                'label' => 'learner_form.goals.label',
                'choice_label' => 'description',
                'multiple' => true,
                'expanded' => true,
            ] )
            ->add('goalsOther', CKEditorType::class, [
                'label' => 'learner_form.goals_other.label',
                'config' => ['uiColor' => '#ffe0c0'],
                //'config_name' => 'minimal',
                //'config' => ['width' => 512],
            ] )
            ->add('ages', EntityType::class, [
                'attr' => ['class' => 'select2'],
                'label' => 'learner_form.ages.label',
                'class' => Age::class,
                'multiple' => true,
            ] )
            /*->add('ages', EntityType::class, [
                'class' => Age::class,
                'label' => 'learner_form.ages.label',
                'choice_label' => 'description',
                'multiple' => true,
                'expanded' => true,
            ] )*/
            ->add('taxonomies', EntityType::class, [
                'attr' => ['class' => 'select2'],
                'label' => 'learner_form.taxonomies.label',
                'class' => Taxonomy::class,
                'multiple' => true,
            ] )
            ->add('imageFile', VichImageType::class, [
                'label' => 'learner_form.image.label',
                'download_link' => false,
//                'data' => '????', // TODO: can we use this field rather than the image property to render a preview in the listing pages?
                'required' => false,
            ] )
            ->add('published', CheckboxType::class, [
                'label' => 'learner_form.published.label'
            ] )
            ->add('hash', HiddenType::class)
            ->add('save', SubmitType::class, [
                'label' => 'learner_form.save.label'
            ] )
        ;
    }
}

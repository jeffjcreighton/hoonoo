<?php

namespace AppBundle\Form;

use AppBundle\Entity\TimeSlot;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class TimeSlotType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('slotType')
            ->add('startDate')
            ->add('finishDate')
            ->add('startTime')
            ->add('finishTime')
            ->add('repeatDailyN')
            ->add('repeatWeeklyN')
            ->add('repeatMonthlyN')
            ->add('repeatYearlyN')
            ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults( [
            'data_class' => TimeSlot::class,
        ]);
    }
}

<?php

namespace AppBundle\DataFixtures\ORM;

use AppBundle\Entity\Taxonomy;
use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\DataFixtures\OrderedFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;

class DefineTaxonomyShortList extends AbstractFixture implements OrderedFixtureInterface
{
    public function load(ObjectManager $manager)
    {
        $taxonomyRepository = $manager->getRepository(Taxonomy::class);

        /*
         * TODO: this list contains many entries which are not in the current taxonomy and need to be sorted out
         */
        $shortListTaxonomies = [
            //
            // Arts & Crafts:
            //
            ['level1' => 'Arts & Crafts', 'level2' => null],
            ['level1' => 'Arts & Crafts', 'level2' => 'Animation & Visual Effects'],
            ['level1' => 'Arts & Crafts', 'level2' => 'Antiques'],
            ['level1' => 'Arts & Crafts', 'level2' => 'Architecture, Landscape & Drafting'],
            ['level1' => 'Arts & Crafts', 'level2' => 'Art History & Gallery Management'],
            ['level1' => 'Arts & Crafts', 'level2' => 'Beading, Glass & Jewelry'],
            ['level1' => 'Arts & Crafts', 'level2' => 'Calligraphy & Lettering'],
            ['level1' => 'Arts & Crafts', 'level2' => 'Candle Making'],
            ['level1' => 'Arts & Crafts', 'level2' => 'Ceramics, Pottery & Sculpture'],
            ['level1' => 'Arts & Crafts', 'level2' => 'Clothing Design'], // category added for v2
            ['level1' => 'Arts & Crafts', 'level2' => 'Coloring'],
            ['level1' => 'Arts & Crafts', 'level2' => 'Drawing'],
            ['level1' => 'Arts & Crafts', 'level2' => 'Floral or Flower Arranging'],
            ['level1' => 'Arts & Crafts', 'level2' => 'Graphic Design & Digital Arts'],
            ['level1' => 'Arts & Crafts', 'level2' => 'Holiday Crafts'],
            ['level1' => 'Arts & Crafts', 'level2' => 'Knitting & Sewing'],
            ['level1' => 'Arts & Crafts', 'level2' => 'Metallurgy & Welding'],
            ['level1' => 'Arts & Crafts', 'level2' => 'Painting'],
            ['level1' => 'Arts & Crafts', 'level2' => 'Photography'],
            ['level1' => 'Arts & Crafts', 'level2' => 'Scrapbooking'],
            ['level1' => 'Arts & Crafts', 'level2' => 'Woodworking & Carpentry'],
            //
            // Business:
            //
            ['level1' => 'Business', 'level2' => null],
            ['level1' => 'Business', 'level2' => 'Accounting, Bookkeeping & Payroll'],
            ['level1' => 'Business', 'level2' => 'Administration'],
            ['level1' => 'Business', 'level2' => 'Career Planning, Coaching & Mentoring'],
            ['level1' => 'Business', 'level2' => 'Communications, Public Speaking & Public Relations'],
            ['level1' => 'Business', 'level2' => 'Compliance'],
            ['level1' => 'Business', 'level2' => 'Critical & Analytical Thinking'],
            ['level1' => 'Business', 'level2' => 'Diversity & Intercultural Competency'],
            ['level1' => 'Business', 'level2' => 'eCommerce'],
            ['level1' => 'Business', 'level2' => 'Small Business & Entrepreneurship'],
            ['level1' => 'Business', 'level2' => 'Ethics'],
            ['level1' => 'Business', 'level2' => 'Finance, Financial Management & Budgets'],
            ['level1' => 'Business', 'level2' => 'Human Resources & Benefits Administration'],
            ['level1' => 'Business', 'level2' => 'Information Technology'],
            ['level1' => 'Business', 'level2' => 'International Business & Globalization'],
            ['level1' => 'Business', 'level2' => 'Investing & Wealth Creation'],
            ['level1' => 'Business', 'level2' => 'Logistics & Supply Chain'], // category added for v2
            ['level1' => 'Business', 'level2' => 'Management & Leadership'],
            ['level1' => 'Business', 'level2' => 'Marketing, Social Media & Advertising'],
            ['level1' => 'Business', 'level2' => 'Organization Development'],
            ['level1' => 'Business', 'level2' => 'Productivity & Time Management'],
            ['level1' => 'Business', 'level2' => 'Project Management'],
            ['level1' => 'Business', 'level2' => 'Real Estate, Appraisal & Property'],
            ['level1' => 'Business', 'level2' => 'Sales & Selling'],
            //
            // Computers & Software:
            //
            ['level1' => 'Computers & Software', 'level2' => null],
            ['level1' => 'Computers & Software', 'level2' => 'Adobe Illustrator'],
            ['level1' => 'Computers & Software', 'level2' => 'Adobe InDesign'],
            ['level1' => 'Computers & Software', 'level2' => 'Adobe Photoshop'],
            ['level1' => 'Computers & Software', 'level2' => 'Adobe Acrobat'],
            ['level1' => 'Computers & Software', 'level2' => 'Adobe Flash'],
            ['level1' => 'Computers & Software', 'level2' => 'Adobe After Effects'],
            ['level1' => 'Computers & Software', 'level2' => 'Algorithms'],
            ['level1' => 'Computers & Software', 'level2' => 'Analytics & Data Management'],
            ['level1' => 'Computers & Software', 'level2' => 'Apple iOS'],
            ['level1' => 'Computers & Software', 'level2' => 'Apple IPhone & iPad'],
            ['level1' => 'Computers & Software', 'level2' => 'Apple Macintosh'],
            ['level1' => 'Computers & Software', 'level2' => 'Apple Swift'],
            ['level1' => 'Computers & Software', 'level2' => 'Artificial Intelligence'],
            ['level1' => 'Computers & Software', 'level2' => 'Cloud Computing'], // category added for v2
            ['level1' => 'Computers & Software', 'level2' => 'Databases'],
            ['level1' => 'Computers & Software', 'level2' => 'Growth Hacking'],
            ['level1' => 'Computers & Software', 'level2' => 'Microsoft Front Page'],
            ['level1' => 'Computers & Software', 'level2' => 'Microsoft Visio'],
            ['level1' => 'Computers & Software', 'level2' => 'Microsoft Project'],
            ['level1' => 'Computers & Software', 'level2' => 'Microsoft Internet Explorer'],
            ['level1' => 'Computers & Software', 'level2' => 'Microsoft Office'],
            ['level1' => 'Computers & Software', 'level2' => 'Microsoft Excel'],
            ['level1' => 'Computers & Software', 'level2' => 'Microsoft Word'],
            ['level1' => 'Computers & Software', 'level2' => 'Microsoft PowerPoint'],
            ['level1' => 'Computers & Software', 'level2' => 'Microsoft Outlook'],
            ['level1' => 'Computers & Software', 'level2' => 'Microsoft Access'],
            ['level1' => 'Computers & Software', 'level2' => 'Microsoft Windows'],
            ['level1' => 'Computers & Software', 'level2' => 'Programming Languages'], // TODO: should we add this category?
            ['level1' => 'Computers & Software', 'level2' => 'Ajax Programming'],
            ['level1' => 'Computers & Software', 'level2' => 'Android Programming'],
            ['level1' => 'Computers & Software', 'level2' => 'C Programming'],
            ['level1' => 'Computers & Software', 'level2' => 'Drupal Programming'],
            ['level1' => 'Computers & Software', 'level2' => '.Net Programming'],
            ['level1' => 'Computers & Software', 'level2' => 'PHP Programming'],
            ['level1' => 'Computers & Software', 'level2' => 'Python Programming'],
            ['level1' => 'Computers & Software', 'level2' => 'Ruby Programming'],
            ['level1' => 'Computers & Software', 'level2' => 'Social Media'], // category added for v2
            ['level1' => 'Computers & Software', 'level2' => 'Security & Cybersecurity'],
            ['level1' => 'Computers & Software', 'level2' => 'Search Engine Optimization & SEO'],
            ['level1' => 'Computers & Software', 'level2' => 'Web Development'],
            //
            // Cooking & Beverage:
            //
            ['level1' => 'Cooking & Beverage', 'level2' => null],
            ['level1' => 'Cooking & Beverage', 'level2' => 'Appetizers'], // category added for v2
            ['level1' => 'Cooking & Beverage', 'level2' => 'Barbecue'],
            ['level1' => 'Cooking & Beverage', 'level2' => 'Breakfasts'], // category added for v2
            ['level1' => 'Cooking & Beverage', 'level2' => 'Catering & Food Management'],
            ['level1' => 'Cooking & Beverage', 'level2' => 'Coffee & Tea'],
            ['level1' => 'Cooking & Beverage', 'level2' => 'Desserts'], // category added for v2
            ['level1' => 'Cooking & Beverage', 'level2' => 'Ethnic Foods'], // category added for v2
            ['level1' => 'Cooking & Beverage', 'level2' => 'Gluten Free'], // TODO: this should maybe be "Gluten Free & Paleo"
            ['level1' => 'Cooking & Beverage', 'level2' => 'Holiday Meals'], // category added for v2
            ['level1' => 'Cooking & Beverage', 'level2' => 'Mixology'], // category added for v2
            ['level1' => 'Cooking & Beverage', 'level2' => 'Soups & Salads'], // category added for v2
            ['level1' => 'Cooking & Beverage', 'level2' => 'Vegetarian & Vegan'], // category added for v2
            ['level1' => 'Cooking & Beverage', 'level2' => 'Wine & Beer'],
            //
            // Dance, Drama & Music:
            //
            ['level1' => 'Dance, Drama & Music', 'level2' => null],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Acting & Drama'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Audio & Recording'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Ballet'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Band'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Banjo & Fiddle'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Bugle, Coronet & Flugelhorn'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Choreography'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Directing'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Drums & Percussion'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'French Horn, Trumpet & Tuba'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Guitar & Bass Guitar'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Hip Hop & Modern Dance'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Jazz'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Music History & Theory'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Musicals'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Opera'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Piano & Keyboard'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Saxophone'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Singing & Vocals'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Song Writing'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Stage & Sound Design'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Swing & Square Dancing'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Violin, Viola & Cello'],
            ['level1' => 'Dance, Drama & Music', 'level2' => 'Woodwinds'], // category added for v2
            //
            // Education:
            //
            ['level1' => 'Education', 'level2' => null],
            ['level1' => 'Education', 'level2' => 'Administration & Leadership'],
            ['level1' => 'Education', 'level2' => 'College Readiness'],
            ['level1' => 'Education', 'level2' => 'Common Core Standards'],
            ['level1' => 'Education', 'level2' => 'Counseling'],
            ['level1' => 'Education', 'level2' => 'Credential'],
            ['level1' => 'Education', 'level2' => 'Curriculum & Teaching'],
            ['level1' => 'Education', 'level2' => 'Early Childhood'],
            ['level1' => 'Education', 'level2' => 'GED'],
            ['level1' => 'Education', 'level2' => 'Home Schooling'],
            ['level1' => 'Education', 'level2' => 'Instructional Design'],
            ['level1' => 'Education', 'level2' => 'Special Ed'],
            ['level1' => 'Education', 'level2' => 'Technology'],
            ['level1' => 'Education', 'level2' => 'Vocational'],
            //
            // Engineering:
            //
            ['level1' => 'Engineering', 'level2' => null],
            ['level1' => 'Engineering', 'level2' => 'Aerospace'],
            ['level1' => 'Engineering', 'level2' => 'Biomedical'],
            ['level1' => 'Engineering', 'level2' => 'chemical'],
            ['level1' => 'Engineering', 'level2' => 'Civil'],
            ['level1' => 'Engineering', 'level2' => 'Computer'],
            ['level1' => 'Engineering', 'level2' => 'Electrical'],
            ['level1' => 'Engineering', 'level2' => 'Engineering & Technology Management'],
            ['level1' => 'Engineering', 'level2' => 'Environmental Engineering'],
            ['level1' => 'Engineering', 'level2' => 'Health & Safety Engineering'],
            ['level1' => 'Engineering', 'level2' => 'Industrial'],
            ['level1' => 'Engineering', 'level2' => 'Manufacturing & Materials'],
            ['level1' => 'Engineering', 'level2' => 'Mechanical'],
            ['level1' => 'Engineering', 'level2' => 'Software'],
            ['level1' => 'Engineering', 'level2' => 'Systems Engineering & Systems Architecture'],
            //
            // English, Literature & Writing:
            //
            ['level1' => 'English, Literature & Writing', 'level2' => null],
            ['level1' => 'English, Literature & Writing', 'level2' => 'Editing'],
            ['level1' => 'English, Literature & Writing', 'level2' => 'Fiction'],
            ['level1' => 'English, Literature & Writing', 'level2' => 'Grammar & Vocabulary'],
            ['level1' => 'English, Literature & Writing', 'level2' => 'Non Fiction'],
            ['level1' => 'English, Literature & Writing', 'level2' => 'Poetry'],
            ['level1' => 'English, Literature & Writing', 'level2' => 'Reading & Comprehension'],
            ['level1' => 'English, Literature & Writing', 'level2' => 'Spelling'],
            ['level1' => 'English, Literature & Writing', 'level2' => 'Writing, Blogging, Journaling & Getting Published'],
//            ['level1' => 'English, Literature & Writing', 'level2' => 'Health & Safety'], // TODO: this is probably erroneous
            //
            // Health & Health Care:
            //
            ['level1' => 'Health & Health Care', 'level2' => null],
            ['level1' => 'Health & Health Care', 'level2' => 'Acupressure'],
            ['level1' => 'Health & Health Care', 'level2' => 'ADD, ADHD & Attention Deficit'],
            ['level1' => 'Health & Health Care', 'level2' => 'Alcohol & Drugs'],
            ['level1' => 'Health & Health Care', 'level2' => 'Alternative Medicine & Healing'],
            ['level1' => 'Health & Health Care', 'level2' => 'Anesthesiology'],
            ['level1' => 'Health & Health Care', 'level2' => 'Autism & Neurodevelopment Disorders'],
            ['level1' => 'Health & Health Care', 'level2' => 'Birth, Lamaze & Ultrasound'],
            ['level1' => 'Health & Health Care', 'level2' => 'Cancer'],
            ['level1' => 'Health & Health Care', 'level2' => 'Cardiology'],
            ['level1' => 'Health & Health Care', 'level2' => 'Certification & Licensure'],
            ['level1' => 'Health & Health Care', 'level2' => 'Child Health'],
            ['level1' => 'Health & Health Care', 'level2' => 'Cosmetic Surgery'],
            ['level1' => 'Health & Health Care', 'level2' => 'Death & Grief'],
            ['level1' => 'Health & Health Care', 'level2' => 'Dentistry & Periodontics'],
            ['level1' => 'Health & Health Care', 'level2' => 'Dermatology'],
            ['level1' => 'Health & Health Care', 'level2' => 'Disorders & Diseases'],
            ['level1' => 'Health & Health Care', 'level2' => 'Endocrinology'],
            ['level1' => 'Health & Health Care', 'level2' => 'Epidemiology'],
            ['level1' => 'Health & Health Care', 'level2' => 'Firefighting, Paramedic & Emergency'],
            ['level1' => 'Health & Health Care', 'level2' => 'Gerontology'],
            ['level1' => 'Health & Health Care', 'level2' => 'Gynecology'],
            ['level1' => 'Health & Health Care', 'level2' => 'Health Administration'],
            ['level1' => 'Health & Health Care', 'level2' => 'Infertility'],
            ['level1' => 'Health & Health Care', 'level2' => 'Internal Medicine'],
            ['level1' => 'Health & Health Care', 'level2' => 'Massage'],
            ['level1' => 'Health & Health Care', 'level2' => 'Meditation'],
            ['level1' => 'Health & Health Care', 'level2' => 'Menopause'],
            ['level1' => 'Health & Health Care', 'level2' => 'Neurology'],
            ['level1' => 'Health & Health Care', 'level2' => 'Nursing'],
            ['level1' => 'Health & Health Care', 'level2' => 'Opthalmology'],
            ['level1' => 'Health & Health Care', 'level2' => 'Optometry'],
            ['level1' => 'Health & Health Care', 'level2' => 'Orthodontics'],
            ['level1' => 'Health & Health Care', 'level2' => 'Pain'],
            ['level1' => 'Health & Health Care', 'level2' => 'Pathology'],
            ['level1' => 'Health & Health Care', 'level2' => 'Pharmacology'],
            ['level1' => 'Health & Health Care', 'level2' => 'Prosthodontics'],
            ['level1' => 'Health & Health Care', 'level2' => 'Psychiatry & Mental Health'],
            ['level1' => 'Health & Health Care', 'level2' => 'Sanitation'],
            ['level1' => 'Health & Health Care', 'level2' => 'Sex'],
            ['level1' => 'Health & Health Care', 'level2' => 'Sleep & Dreams'],
            ['level1' => 'Health & Health Care', 'level2' => 'Urology'],
            ['level1' => 'Health & Health Care', 'level2' => 'Veterinarian'],
            ['level1' => 'Health & Health Care', 'level2' => 'Wellness, Fitness, Nutrition & Weight Loss'],
            //
            // History:
            //
            ['level1' => 'History', 'level2' => null],
            ['level1' => 'History', 'level2' => 'Colonialism'], // category added for v2
            ['level1' => 'History', 'level2' => 'Cultural History'], // category added for v2
            ['level1' => 'History', 'level2' => 'China'],
            ['level1' => 'History', 'level2' => 'Europe'],
            ['level1' => 'History', 'level2' => 'Jewish'],
            ['level1' => 'History', 'level2' => 'Medieval History'], // category added for v2
            ['level1' => 'History', 'level2' => 'Military & War'],
            ['level1' => 'History', 'level2' => 'Native American History'], // category added for v2
            ['level1' => 'History', 'level2' => 'Technology'], // category added for v2
            ['level1' => 'History', 'level2' => 'World & Ancient'],
            //
            // Hobbies & Games:
            //
            ['level1' => 'Hobbies & Games', 'level2' => null],
            ['level1' => 'Hobbies & Games', 'level2' => 'Backgammon'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Bee Keeping'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Billiards'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Bingo'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Bird Watching'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Black Jack'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Bridge'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Checkers'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Chess'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Coins & Currency'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Craps'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Cribbage'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Dinnerware & Silverware'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Dog training'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Dolls'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Film'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Genealogy'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Glassware'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Joomba'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Magic'], // category added for v2
            ['level1' => 'Hobbies & Games', 'level2' => 'Mah Jongg'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Poker'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Puzzles'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Records'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Rockets & Drones'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Rocks & Gems'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Senet'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Shogi'],
            ['level1' => 'Hobbies & Games', 'level2' => 'Stamps'],
            //
            // Home & Garden:
            //
            ['level1' => 'Home & Garden', 'level2' => null],
            ['level1' => 'Home & Garden', 'level2' => 'Appliances'],
            ['level1' => 'Home & Garden', 'level2' => 'Cabinetry'],
            ['level1' => 'Home & Garden', 'level2' => 'Concrete'],
            ['level1' => 'Home & Garden', 'level2' => 'Electrical'],
            ['level1' => 'Home & Garden', 'level2' => 'Gardening'],
            ['level1' => 'Home & Garden', 'level2' => 'Interior Decorating'],
            ['level1' => 'Home & Garden', 'level2' => 'Painting'],
            ['level1' => 'Home & Garden', 'level2' => 'Plumbing'],
            ['level1' => 'Home & Garden', 'level2' => 'Roofing'],
            ['level1' => 'Home & Garden', 'level2' => 'Tile'], // category added for v2
            //
            // Languages:
            //
            ['level1' => 'Languages', 'level2' => null],
            ['level1' => 'Languages', 'level2' => 'American Sign Language'],
            ['level1' => 'Languages', 'level2' => 'Chinese'],
            ['level1' => 'Languages', 'level2' => 'English'],
            ['level1' => 'Languages', 'level2' => 'French'],
            ['level1' => 'Languages', 'level2' => 'German'],
            ['level1' => 'Languages', 'level2' => 'Italian'],
            ['level1' => 'Languages', 'level2' => 'Japanese'],
            ['level1' => 'Languages', 'level2' => 'Korean'],
            ['level1' => 'Languages', 'level2' => 'Linguistics'],
            ['level1' => 'Languages', 'level2' => 'Russian'],
            ['level1' => 'Languages', 'level2' => 'Spanish'],
            //
            // Legal Studies:
            //
            ['level1' => 'Legal Studies', 'level2' => null],
            ['level1' => 'Legal Studies', 'level2' => 'Business Law'],
            ['level1' => 'Legal Studies', 'level2' => 'Civil Law'],
            ['level1' => 'Legal Studies', 'level2' => 'Compliance'],
            ['level1' => 'Legal Studies', 'level2' => 'Constitution'],
            ['level1' => 'Legal Studies', 'level2' => 'Construction Law'],
            ['level1' => 'Legal Studies', 'level2' => 'Corporate Law'],
            ['level1' => 'Legal Studies', 'level2' => 'Criminal Justice & Criminal Law'],
            ['level1' => 'Legal Studies', 'level2' => 'Entertainment Law'],
            ['level1' => 'Legal Studies', 'level2' => 'Environmental Law'],
            ['level1' => 'Legal Studies', 'level2' => 'Estates, Wills & Trusts'],
            ['level1' => 'Legal Studies', 'level2' => 'Family Law'],
            ['level1' => 'Legal Studies', 'level2' => 'Government Law'],
            ['level1' => 'Legal Studies', 'level2' => 'Intellectual Property'],
            ['level1' => 'Legal Studies', 'level2' => 'Labor & Employment Law'],
            ['level1' => 'Legal Studies', 'level2' => 'Legal Assistant & Paralegal'],
            ['level1' => 'Legal Studies', 'level2' => 'Real Property Law'],
            ['level1' => 'Legal Studies', 'level2' => 'Taxation Law'],
            ['level1' => 'Legal Studies', 'level2' => 'Torts & Contracts'],
            //
            // Parenting:
            //
            ['level1' => 'Parenting', 'level2' => null],
            ['level1' => 'Parenting', 'level2' => 'Adolescence'],
            ['level1' => 'Parenting', 'level2' => 'Adoption'],
            ['level1' => 'Parenting', 'level2' => 'Artificial Insemination'],
            ['level1' => 'Parenting', 'level2' => 'Baby Massage'],
            ['level1' => 'Parenting', 'level2' => 'Babysitting'],
            ['level1' => 'Parenting', 'level2' => 'Bedwetting'],
            ['level1' => 'Parenting', 'level2' => 'Breast Feeding'],
            ['level1' => 'Parenting', 'level2' => 'Child Care'],
            ['level1' => 'Parenting', 'level2' => 'Discipline'],
            ['level1' => 'Parenting', 'level2' => 'Divorce'],
            ['level1' => 'Parenting', 'level2' => 'Family Network Security'], // category added for v2
            ['level1' => 'Parenting', 'level2' => 'Foster Care'],
            ['level1' => 'Parenting', 'level2' => 'Home Schooling'],
            ['level1' => 'Parenting', 'level2' => 'Mid-Wifery'],
            ['level1' => 'Parenting', 'level2' => 'Single Parent'],
            ['level1' => 'Parenting', 'level2' => 'Special Needs Parenting'],
            ['level1' => 'Parenting', 'level2' => 'Substance Abuse'],
            //
            // Philosophy:
            //
            ['level1' => 'Philosophy', 'level2' => null],
            ['level1' => 'Philosophy', 'level2' => 'Ethics'],
            ['level1' => 'Philosophy', 'level2' => 'Knowledge & Pragmatism'],
            ['level1' => 'Philosophy', 'level2' => 'Logic'],
            //
            // Religion:
            //
            ['level1' => 'Religion', 'level2' => null],
            ['level1' => 'Religion', 'level2' => 'African Religions'],
            ['level1' => 'Religion', 'level2' => 'Buddhism'],
            ['level1' => 'Religion', 'level2' => 'Jesus & Christianity'],
            ['level1' => 'Religion', 'level2' => 'Cults & Witchcraft'],
            ['level1' => 'Religion', 'level2' => 'Family Ministry'],
            ['level1' => 'Religion', 'level2' => 'Hinduism'],
            ['level1' => 'Religion', 'level2' => 'Islam'],
            ['level1' => 'Religion', 'level2' => 'Judaism & Old Testament'],
            ['level1' => 'Religion', 'level2' => 'Mormonism'],
            ['level1' => 'Religion', 'level2' => 'Mythology'],
            ['level1' => 'Religion', 'level2' => 'Pastoral Ministry'],
            ['level1' => 'Religion', 'level2' => 'Rastafari'],
            ['level1' => 'Religion', 'level2' => 'Taoism'],
            ['level1' => 'Religion', 'level2' => 'Tenrikyo'],
            ['level1' => 'Religion', 'level2' => 'Wicca'],
            ['level1' => 'Religion', 'level2' => 'Youth Ministry'],
            //
            // Science & Math:
            //
            ['level1' => 'Science & Math', 'level2' => null],
            ['level1' => 'Science & Math', 'level2' => 'Addition, Subtraction, Multiplication & Division'],
            ['level1' => 'Science & Math', 'level2' => 'Algebra'],
            ['level1' => 'Science & Math', 'level2' => 'Anatomy'],
            ['level1' => 'Science & Math', 'level2' => 'Anthropology'],
            ['level1' => 'Science & Math', 'level2' => 'Archaeology'],
            ['level1' => 'Science & Math', 'level2' => 'Astrobiology'],
            ['level1' => 'Science & Math', 'level2' => 'Astronomy & Space'],
            ['level1' => 'Science & Math', 'level2' => 'Biochemistry'],
            ['level1' => 'Science & Math', 'level2' => 'Bioinformatics'],
            ['level1' => 'Science & Math', 'level2' => 'Biology'],
            ['level1' => 'Science & Math', 'level2' => 'Biomedical science'],
            ['level1' => 'Science & Math', 'level2' => 'Biotechnology'],
            ['level1' => 'Science & Math', 'level2' => 'Botany'],
            ['level1' => 'Science & Math', 'level2' => 'Calculus'],
            ['level1' => 'Science & Math', 'level2' => 'Chemistry'],
            ['level1' => 'Science & Math', 'level2' => 'Earth & Environment'],
            ['level1' => 'Science & Math', 'level2' => 'Ecology'],
            ['level1' => 'Science & Math', 'level2' => 'Game Theory'],
            ['level1' => 'Science & Math', 'level2' => 'Geneology'],
            ['level1' => 'Science & Math', 'level2' => 'Geology'],
            ['level1' => 'Science & Math', 'level2' => 'Geometry'],
            ['level1' => 'Science & Math', 'level2' => 'Horticulture'],
            ['level1' => 'Science & Math', 'level2' => 'Paleontology'],
            ['level1' => 'Science & Math', 'level2' => 'Physics'],
            ['level1' => 'Science & Math', 'level2' => 'Political Science'],
            ['level1' => 'Science & Math', 'level2' => 'Psychology'],
            ['level1' => 'Science & Math', 'level2' => 'Sociology & Social Work'],
            ['level1' => 'Science & Math', 'level2' => 'Statistics & Probability'],
            ['level1' => 'Science & Math', 'level2' => 'Trigonometry'],
            ['level1' => 'Science & Math', 'level2' => 'Zoology'],
            //
            // Sports & Leisure:
            //
            ['level1' => 'Sports & Leisure', 'level2' => null],
            ['level1' => 'Sports & Leisure', 'level2' => 'Aerobics, Pilates & Spinning'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Auto & GoKart Racing'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Badminton'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Baseball'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Basketball'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Bodybuilding'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Bowling'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Boxing & Kick Boxing'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Canoe, Kayak & Stand Up Paddleboarding'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Cricket'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Croquet'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Curling'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Cycling & Mountain Biking'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Driver\'s Ed & Traffic School'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Equestrian & Horseback riding'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Fencing'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Fishing'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Flying'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Football'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Golf'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Gymnastics & Tumbling'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Handball'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Hiking & Backpacking'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Hockey'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Hunting'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Ice Skating & Speed Skating'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Jousting'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Ju Jutsu, Judo & Kenpo'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Karate'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Kite Flying'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Krav Maga'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Kung Fu'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Lacrosse'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Motorcycles'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Mountain & Rock Climbing'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Paddle Tennis & Pickle Ball'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Parasailing'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Polo'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Racquetball & Squash'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Rodeo, Bull Riding & Roping'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Roller Skating'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Rowing & Crew'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Rugby'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Running, Cross Country & Marathon Training'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Sae Bo, Tae Kwon Do & Tai Chi Chuan'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Sailing, Boat Racing & Yachting'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Skateboard'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Skiing & Snowboarding'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Skydiving & Parachuting'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Snorkeling & Scuba Diving'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Soccer'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Softball'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Surfing'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Survival Skills'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Swimming'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Table Tennis & Ping Pong'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Tennis'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Track & Field'], // category added for v2
            ['level1' => 'Sports & Leisure', 'level2' => 'Triathlon'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Volleyball'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Water Polo'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Water Skiing'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Wind Surfing'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Wrestling'],
            ['level1' => 'Sports & Leisure', 'level2' => 'Yoga'],
        ];

        $countShortListTaxonomies = 0;
        foreach( $shortListTaxonomies as $shortListTaxonomy ) {
            $level1 = $shortListTaxonomy['level1'];
            $level2 = $shortListTaxonomy['level2'];
            $taxonomy = $taxonomyRepository->findOneBy(['level1' => $level1, 'level2' => $level2]);
            if( $taxonomy ) {
                $taxonomy->setInShortList(true);
                $manager->persist($taxonomy);
                ++$countShortListTaxonomies;
            } else {
                echo "ERROR: could not find taxonomy with level1='$level1', level2='$level2'\n";
            }
        }
        $manager->flush();
        echo "INFO: successfully set $countShortListTaxonomies short list taxonomies\n";
    }

    public function getOrder()
    {
        return 4;
    }
}

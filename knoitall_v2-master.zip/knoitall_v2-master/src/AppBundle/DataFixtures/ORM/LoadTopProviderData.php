<?php

namespace AppBundle\DataFixtures\ORM;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\DataFixtures\OrderedFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use AppBundle\Entity\Provider;
use AppBundle\Entity\TopProvider;

class LoadTopProviderData extends AbstractFixture implements OrderedFixtureInterface
{
    public function load(ObjectManager $manager)
    {
        $srcDir = __DIR__ . "/../Data";
        $providerRepository = $manager->getRepository(Provider::class);

        $topProvider1 = new TopProvider();
        $topProvider1->setProvider($providerRepository->findOneBy(['title' => 'Bike Commuting Resource Center', 'nickname' => 'bikecommuting']));
        $topProvider1->setDescription('John Zappa: Bike Commuting');
        $destDir = __DIR__ . "/../../../../web/media/top-provider/" . $topProvider1->getHash();
        $filename = 'zappa.jpg';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topProvider1->setImage($filename);
        $manager->persist($topProvider1);

        $topProvider2 = new TopProvider();
        $topProvider2->setProvider($providerRepository->findOneBy(['title' => 'Kleiner Perkins Caufield Byers', 'nickname' => 'Kleiner_Perkins_Caufield_Byers']));
        $topProvider2->setDescription('Kleiner Perkins: New Venture Creation');
        $destDir = __DIR__ . "/../../../../web/media/top-provider/" . $topProvider2->getHash();
        $filename = 'KPCB.jpg';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topProvider2->setImage($filename);
        $manager->persist($topProvider2);

        $topProvider3 = new TopProvider();
        $topProvider3->setProvider($providerRepository->findOneBy(['title' => 'Grilling, Barbecue and Southern Foods Expert', 'nickname' => 'grilling-barbecue-and-southern-foods-expert']));
        $topProvider3->setDescription('Elizabeth Karmel: Grilling & Barbecue');
        $destDir = __DIR__ . "/../../../../web/media/top-provider/" . $topProvider3->getHash();
        $filename = 'elizabeth.jpg';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topProvider3->setImage($filename);
        $manager->persist($topProvider3);

        $topProvider4 = new TopProvider();
        $topProvider4->setProvider($providerRepository->findOneBy(['title' => 'Dax Ross', 'nickname' => 'dax-ross']));
        $topProvider4->setDescription('Dax Ross: Ultra Marathoner');
        $destDir = __DIR__ . "/../../../../web/media/top-provider/" . $topProvider4->getHash();
        $filename = 'Dax_Running.JPG';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topProvider4->setImage($filename);
        $manager->persist($topProvider4);

        $topProvider5 = new TopProvider();
        $topProvider5->setProvider($providerRepository->findOneBy(['title' => 'The Enchanting Lawyer', 'nickname' => 'The_Enchanting_Lawyer']));
        $topProvider5->setDescription('The Enchanting Lawyer: Social Media');
        $destDir = __DIR__ . "/../../../../web/media/top-provider/" . $topProvider5->getHash();
        $filename = 'the_enchanting_lawyer.png';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topProvider5->setImage($filename);
        $manager->persist($topProvider5);

        $topProvider6 = new TopProvider();
        $topProvider6->setProvider($providerRepository->findOneBy(['title' => 'French LSA', 'nickname' => 'French_LSA']));
        $topProvider6->setDescription('Christine Bilange: French Language & Travel');
        $destDir = __DIR__ . "/../../../../web/media/top-provider/" . $topProvider6->getHash();
        $filename = 'christine.jpg';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topProvider6->setImage($filename);
        $manager->persist($topProvider6);

        $topProvider7 = new TopProvider();
        $topProvider7->setProvider($providerRepository->findOneBy(['title' => 'Berkshire Hathaway HomeServices / INDRA Group', 'nickname' => 'RealEstate']));
        $topProvider7->setDescription('Indra Real Estate: Home Flipping & Appraisal');
        $destDir = __DIR__ . "/../../../../web/media/top-provider/" . $topProvider7->getHash();
        $filename = 'Melia_Indra_Profile_Pic.jpg';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topProvider7->setImage($filename);
        $manager->persist($topProvider7);

        $topProvider8 = new TopProvider();
        $topProvider8->setProvider($providerRepository->findOneBy(['title' => 'Kristy Abbott', 'nickname' => 'Kristy-Abbott']));
        $topProvider8->setDescription('Kristy Abbott: Getting Published');
        $destDir = __DIR__ . "/../../../../web/media/top-provider/" . $topProvider8->getHash();
        $filename = 'kristy.jpg';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topProvider8->setImage($filename);
        $manager->persist($topProvider8);

        $topProvider9 = new TopProvider();
        $topProvider9->setProvider($providerRepository->findOneBy(['title' => 'USC Viterbi School of Engineering', 'nickname' => 'USC_Viterbi_School_of_Engineering']));
        $topProvider9->setDescription('USC Engineering: Advanced Degrees');
        $destDir = __DIR__ . "/../../../../web/media/top-provider/" . $topProvider9->getHash();
        $filename = 'usc.jpg';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topProvider9->setImage($filename);
        $manager->persist($topProvider9);

        $topProvider10 = new TopProvider();
        $topProvider10->setProvider($providerRepository->findOneBy(['title' => 'Craftsy', 'nickname' => 'Craftsy']));
        $topProvider10->setDescription('Craftsy: All types of Crafts');
        $destDir = __DIR__ . "/../../../../web/media/top-provider/" . $topProvider10->getHash();
        $filename = 'craftsy1.png';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topProvider10->setImage($filename);
        $manager->persist($topProvider10);

        $topProvider11 = new TopProvider();
        $topProvider11->setProvider($providerRepository->findOneBy(['title' => 'REI', 'nickname' => 'REI_Outdoor']));
        $topProvider11->setDescription('REI: Outdoor Activities');
        $destDir = __DIR__ . "/../../../../web/media/top-provider/" . $topProvider11->getHash();
        $filename = 'rei_logo_detail.png';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topProvider11->setImage($filename);
        $manager->persist($topProvider11);

        $topProvider12 = new TopProvider();
        $topProvider12->setProvider($providerRepository->findOneBy(['title' => 'Vado', 'nickname' => 'Vado-Learning']));
        $topProvider12->setDescription('Vado Learning: Management & Compliance');
        $destDir = __DIR__ . "/../../../../web/media/top-provider/" . $topProvider12->getHash();
        $filename = 'vado.png';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topProvider12->setImage($filename);
        $manager->persist($topProvider12);

        $topProvider13 = new TopProvider();
        $topProvider13->setProvider($providerRepository->findOneBy(['title' => 'Sea World San Diego', 'nickname' => 'Sea_World_San_Diego']));
        $topProvider13->setDescription('Sea World: Oceanography');
        $destDir = __DIR__ . "/../../../../web/media/top-provider/" . $topProvider13->getHash();
        $filename = 'Seaworld_logo.png';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topProvider13->setImage($filename);
        $manager->persist($topProvider13);

        $topProvider14 = new TopProvider();
        $topProvider14->setProvider($providerRepository->findOneBy(['title' => 'Deborah Ferber', 'nickname' => 'Deborah_Ferber']));
        $topProvider14->setDescription('Deborah Ferber: Innovation & Diversity');
        $destDir = __DIR__ . "/../../../../web/media/top-provider/" . $topProvider14->getHash();
        $filename = 'deborah.jpg';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topProvider14->setImage($filename);
        $manager->persist($topProvider14);

        $topProvider15 = new TopProvider();
        $topProvider15->setProvider($providerRepository->findOneBy(['title' => 'Adobe', 'nickname' => 'adobe']));
        $topProvider15->setDescription('Adobe: Graphic Design');
        $destDir = __DIR__ . "/../../../../web/media/top-provider/" . $topProvider15->getHash();
        $filename = 'adobe.png';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topProvider15->setImage($filename);
        $manager->persist($topProvider15);

        $topProvider16 = new TopProvider();
        $topProvider16->setProvider($providerRepository->findOneBy(['title' => 'Knoitall, Inc.', 'nickname' => 'knoitall']));
        $topProvider16->setDescription('Knoitall: About Us');
        $destDir = __DIR__ . "/../../../../web/media/top-provider/" . $topProvider16->getHash();
        $filename = 'knoitall favicon 128x128_0002_orange.jpg';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topProvider16->setImage($filename);
        $manager->persist($topProvider16);

        $topProvider17 = new TopProvider();
        $topProvider17->setProvider($providerRepository->findOneBy(['title' => 'Brad Feld', 'nickname' => 'brad-feld']));
        $topProvider17->setDescription('Brad Feld: Technology Investing');
        $destDir = __DIR__ . "/../../../../web/media/top-provider/" . $topProvider17->getHash();
        $filename = 'brad.png';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topProvider17->setImage($filename);
        $manager->persist($topProvider17);

        $topProvider18 = new TopProvider();
        $topProvider18->setProvider($providerRepository->findOneBy(['title' => 'UC Berkeley Extension Programs for Corporate and Professional Training', 'nickname' => 'UC_Berkeley_Extension_Programs_for_Corporate_and_Professional_Training']));
        $topProvider18->setDescription('UC Berkeley: Extension Programs');
        $destDir = __DIR__ . "/../../../../web/media/top-provider/" . $topProvider18->getHash();
        $filename = 'ucberkeley.jpg';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topProvider18->setImage($filename);
        $manager->persist($topProvider18);

        $manager->flush();

        $this->addReference('topprovider-1', $topProvider1);
        $this->addReference('topprovider-2', $topProvider2);
        $this->addReference('topprovider-3', $topProvider3);
        $this->addReference('topprovider-4', $topProvider4);
        $this->addReference('topprovider-5', $topProvider5);
        $this->addReference('topprovider-6', $topProvider6);
        $this->addReference('topprovider-7', $topProvider7);
        $this->addReference('topprovider-8', $topProvider8);
        $this->addReference('topprovider-9', $topProvider9);
        $this->addReference('topprovider-10', $topProvider10);
        $this->addReference('topprovider-11', $topProvider11);
        $this->addReference('topprovider-12', $topProvider12);
        $this->addReference('topprovider-13', $topProvider13);
        $this->addReference('topprovider-14', $topProvider14);
        $this->addReference('topprovider-15', $topProvider15);
        $this->addReference('topprovider-16', $topProvider16);
        $this->addReference('topprovider-17', $topProvider17);
        $this->addReference('topprovider-18', $topProvider18);
    }

    public function getOrder()
    {
        return 3;
    }
}

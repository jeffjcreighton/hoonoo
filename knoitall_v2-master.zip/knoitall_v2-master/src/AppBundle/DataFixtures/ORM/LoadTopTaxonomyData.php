<?php

namespace AppBundle\DataFixtures\ORM;

use AppBundle\Entity\Taxonomy;
use AppBundle\Entity\TopTaxonomy;
use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\DataFixtures\OrderedFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;

class LoadTopTaxonomyData extends AbstractFixture implements OrderedFixtureInterface
{
    public function load(ObjectManager $manager)
    {
        $taxonomyRepository = $manager->getRepository(Taxonomy::class);
        $srcDir = __DIR__ . "/../../../../web/images/classes";

        $topTaxonomy1 = new TopTaxonomy();
        $taxonomy = $taxonomyRepository->findOneBy(['level1' => 'Education', 'level2' => 'Curriculum & Teaching']);
        $topTaxonomy1->setTaxonomy($taxonomy);
        $topTaxonomy1->setDescription('Education: Teaching classes, certifications and degrees');
        $id = $topTaxonomy1->getId();
        $destDir = __DIR__ . "/../../../../web/media/top-taxonomy/" . $topTaxonomy1->getHash();
        $filename = 'knoitall_0014_education.jpg';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topTaxonomy1->setImage($filename);
        $manager->persist($topTaxonomy1);

        $topTaxonomy2 = new TopTaxonomy();
        $taxonomy = $taxonomyRepository->findOneBy(['level1' => 'Business', 'level2' => 'Strategy & Risk']);
        $topTaxonomy2->setTaxonomy($taxonomy);
        $topTaxonomy2->setDescription('Business: Strategy & Risk');
        $destDir = __DIR__ . "/../../../../web/media/top-taxonomy/" . $topTaxonomy2->getHash();
        $filename = 'knoitall_0017_business.jpg';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topTaxonomy2->setImage($filename);
        $manager->persist($topTaxonomy2);

        $topTaxonomy3 = new TopTaxonomy();
        $taxonomy = $taxonomyRepository->findOneBy(['level1' => 'Computers & Software', 'level2' => 'Microsoft Excel']);
        $topTaxonomy3->setTaxonomy($taxonomy);
        $topTaxonomy3->setDescription('Computers & Software: Introduction to Microsoft Excel');
        $destDir = __DIR__ . "/../../../../web/media/top-taxonomy/" . $topTaxonomy3->getHash();
        $filename = 'knoitall_0016_computers_software.jpg';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topTaxonomy3->setImage($filename);
        $manager->persist($topTaxonomy3);

        $topTaxonomy4 = new TopTaxonomy();
        $taxonomy = $taxonomyRepository->findOneBy(['level1' => 'Arts & Crafts', 'level2' => 'Beading, Glass & Jewelry']);
        $topTaxonomy4->setTaxonomy($taxonomy);
        $topTaxonomy4->setDescription('Art, Drama & Music: Beading, Glass & Jewelry');
        $destDir = __DIR__ . "/../../../../web/media/top-taxonomy/" . $topTaxonomy4->getHash();
        $filename = 'knoitall_0018_art_drama_music.jpg';
        mkdir($destDir, 0755, true);
        copy("$srcDir/$filename", "$destDir/$filename");
        $topTaxonomy4->setImage($filename);
        $manager->persist($topTaxonomy4);

        $manager->flush();

        $this->addReference('toptaxonomy-1', $topTaxonomy1);
        $this->addReference('toptaxonomy-2', $topTaxonomy2);
        $this->addReference('toptaxonomy-3', $topTaxonomy3);
        $this->addReference('toptaxonomy-4', $topTaxonomy3);
    }

    public function getOrder()
    {
        return 2;
    }
}

<?php

namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;
use Doctrine\Common\Collections\ArrayCollection;
use AppBundle\Entity\Taxonomy;

class AdvisorRepository extends EntityRepository
{
    /**
     * @var $taxonomy \AppBundle\Entity\Taxonomy
     *
     * @return ArrayCollection
     */
    public function findAllHavingTaxonomy( Taxonomy $taxonomy )
    {
        $query = $this
            ->createQueryBuilder('a')
            ->select('a')
            ->join('a.taxonomies', 't')
            ->where('a.published = true')
            ->andWhere('t = :taxonomy')
            ->setParameter('taxonomy', $taxonomy)
            ->getQuery()
        ;

        return $query->getResult();
    }
}

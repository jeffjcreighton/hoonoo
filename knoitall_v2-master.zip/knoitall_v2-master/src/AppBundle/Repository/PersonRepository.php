<?php

namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;

class PersonRepository extends EntityRepository
{
    public function findOneByFullName( $fullName )
    {
        $nameParts = explode( ' ', $fullName );
        if( count($nameParts) == 2 ) {
            return $this->findOneBy( [
                'firstName' => $nameParts[0],
                'lastName' => $nameParts[1],
            ] );
        } else {
            return null;
        }
    }
}

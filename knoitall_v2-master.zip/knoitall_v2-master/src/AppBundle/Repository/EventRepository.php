<?php

namespace AppBundle\Repository;

use AppBundle\Entity\EventFormatSection;
use Doctrine\ORM\EntityRepository;
use AppBundle\Entity\Taxonomy;
use AppBundle\Entity\Provider;

class EventRepository extends EntityRepository
{
    /**
     * @param Taxonomy $taxonomy
     * @return array
     */
    public function findAllHavingTaxonomy( Taxonomy $taxonomy )
    {
        $query = $this
            ->createQueryBuilder('e')
            ->select('e')
            ->join('e.taxonomies', 't')
            ->where('e.published = true')
            ->andWhere('t = :taxonomy')
            ->setParameter('taxonomy', $taxonomy)
            ->getQuery()
        ;

        return $query->getResult();
    }

    /**
     * @param Provider $provider
     * @return \Doctrine\ORM\Query
     */
    public function findAllHavingProviderQuery( Provider $provider, EventFormatSection $eventFormatSection = null )
    {
        $query = $this
            ->createQueryBuilder('e')
            ->join('e.eventFormat', 'ef')
            ->where('e.provider = :provider')
            ->setParameter('provider', $provider)
        ;

        if( $eventFormatSection ) {
            $query
                ->andWhere('ef.eventFormatSection = :section')
                ->setParameter('section', $eventFormatSection)
            ;
        }

        $query
            ->orderBy('e.id', 'ASC')
            ->getQuery();

        return $query;
    }
}

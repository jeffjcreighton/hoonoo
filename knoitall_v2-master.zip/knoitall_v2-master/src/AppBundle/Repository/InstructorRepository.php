<?php

namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;
use Doctrine\Common\Collections\ArrayCollection;
use AppBundle\Entity\Taxonomy;

class InstructorRepository extends EntityRepository
{
    /**
     * @var $taxonomy \AppBundle\Entity\Taxonomy
     *
     * @return ArrayCollection
     */
    public function findAllHavingTaxonomy( Taxonomy $taxonomy )
    {
        $query = $this
            ->createQueryBuilder('i')
            ->select('i')
            ->join('i.taxonomies', 't')
            ->where('i.published = true')
            ->andWhere('t = :taxonomy')
            ->setParameter('taxonomy', $taxonomy)
            ->getQuery()
        ;

        return $query->getResult();
    }
}

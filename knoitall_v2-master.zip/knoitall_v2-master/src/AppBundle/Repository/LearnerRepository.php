<?php

namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;
use Doctrine\Common\Collections\ArrayCollection;
use AppBundle\Entity\Taxonomy;

class LearnerRepository extends EntityRepository
{
    /**
     * @var $taxonomy \AppBundle\Entity\Taxonomy
     *
     * @return ArrayCollection
     */
    public function findAllHavingTaxonomy( Taxonomy $taxonomy )
    {
        $query = $this
            ->createQueryBuilder('l')
            ->select('l')
            ->join('l.taxonomies', 't')
            ->where('l.published = true')
            ->andWhere('t = :taxonomy')
            ->setParameter('taxonomy', $taxonomy)
            ->getQuery()
        ;

        return $query->getResult();
    }
}

<?php

namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;
use Doctrine\Common\Collections\ArrayCollection;
use AppBundle\Entity\Taxonomy;

class LocationRepository extends EntityRepository
{
}

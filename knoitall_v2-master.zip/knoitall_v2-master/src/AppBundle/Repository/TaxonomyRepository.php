<?php

namespace AppBundle\Repository;

use AppBundle\Entity\Taxonomy;
use Doctrine\ORM\EntityRepository;

class TaxonomyRepository extends EntityRepository
{
    private function normalizeDescription($desc)
    {
        $x = $desc;
        $x = preg_replace("/&/", ' ', $x);
        $x = preg_replace("/,/", ' ', $x);
        $x = preg_replace("/-/", ' ', $x);
        $x = preg_replace("/\s+/", ' ', $x);
        $x = preg_replace("/^\s+/", '', $x);
        $x = preg_replace("/\s+$/", '', $x);
        $x = strtolower($x);

        return $x;
    }

    /**
     * @param $level1
     * @param $level2
     * @param $level3
     * @return Taxonomy
     */
    public function findFuzzy($level1 = null, $level2 = null, $level3 = null)
    {
        $level1Normalized = ( $level1 ? $this->normalizeDescription($level1) : null );
        $level2Normalized = ( $level2 ? $this->normalizeDescription($level2) : null );
        $level3Normalized = ( $level3 ? $this->normalizeDescription($level3) : null );

        $query = $this
            ->createQueryBuilder('t')
            ->select('t')
            ->getQuery()
        ;
        $candidates = $query->getResult();

        /** @var Taxonomy $candidate */
        foreach( $candidates as $candidate ) {

            if( $level1 and ! $candidate->getLevel1() ) continue;
            if( ! $level1 and $candidate->getLevel1() ) continue;
            if( $level1 and $candidate->getLevel1() and $this->normalizeDescription($candidate->getLevel1()) != $level1Normalized ) continue;

            if( $level2 and ! $candidate->getLevel2() ) continue;
            if( ! $level2 and $candidate->getLevel2() ) continue;
            if( $level2 and $candidate->getLevel2() and $this->normalizeDescription($candidate->getLevel2()) != $level2Normalized ) continue;

            if( $level3 and ! $candidate->getLevel3() ) continue;
            if( ! $level3 and $candidate->getLevel3() ) continue;
            if( $level3 and $candidate->getLevel3() and $this->normalizeDescription($candidate->getLevel3()) != $level3Normalized ) continue;

            return $candidate;
        }

        return null;
    }
}

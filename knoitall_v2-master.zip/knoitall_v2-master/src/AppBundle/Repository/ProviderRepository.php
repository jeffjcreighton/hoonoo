<?php

namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;
use AppBundle\Entity\Person;
use AppBundle\Entity\Provider;
use AppBundle\Entity\Taxonomy;

class ProviderRepository extends EntityRepository
{
    public function findOneBelongingTo( Person $person )
    {
        /*
         * TODO: implement this properly
         */
        $providers = $this->findAll();
        /** @var Provider $provider */
        foreach( $providers as $provider ) {
            if( in_array($person,$provider->getPersons()->toArray()) ) {
                return $provider;
            }
        }
        return null;
    }

    /**
     * @var $taxonomy \AppBundle\Entity\Taxonomy
     *
     * @return array
     */
    public function findAllHavingTaxonomy( Taxonomy $taxonomy )
    {
        $query = $this
            ->createQueryBuilder('p')
            ->select('p')
            ->join('p.taxonomies', 't')
            ->where('p.published = true')
            ->andWhere('t = :taxonomy')
            ->setParameter('taxonomy', $taxonomy)
            ->getQuery()
        ;

        return $query->getResult();
    }
}

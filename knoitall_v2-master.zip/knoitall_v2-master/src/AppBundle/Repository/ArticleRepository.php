<?php

namespace AppBundle\Repository;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\EntityRepository;
use AppBundle\Entity\Taxonomy;

class ArticleRepository extends EntityRepository
{
    /*
     * TODO: implement the actual findLatest() method
     */
    public function findLatest()
    {
        return $this->findBy( ['published' => 1] );
    }

    /**
     * @var $taxonomy \AppBundle\Entity\Taxonomy
     *
     * @return ArrayCollection
     */
    public function findAllHavingTaxonomy( Taxonomy $taxonomy )
    {
        $query = $this
            ->createQueryBuilder('a')
            ->select('a')
            ->join('a.taxonomies', 't')
            ->where('a.published = true')
            ->andWhere('t = :taxonomy')
            ->setParameter('taxonomy', $taxonomy)
            ->getQuery()
        ;

        return $query->getResult();
    }
}

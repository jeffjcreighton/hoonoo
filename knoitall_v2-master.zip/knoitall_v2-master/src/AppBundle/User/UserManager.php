<?php

namespace AppBundle\User;

use AppBundle\Entity\User;
use AppBundle\Entity\Person;
use FOS\UserBundle\Doctrine\UserManager as BaseUserManager;

class UserManager extends BaseUserManager
{
    public function createUser()
    {
        $person = new Person();

        $class = $this->getClass();
        /** @var User $user */
        $user = new $class;
        $user->setPerson( $person );

        $this->objectManager->persist($person);
        $this->objectManager->persist($user);

        return $user;
    }
}
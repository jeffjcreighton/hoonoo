<?php

namespace AppBundle\User;

use Doctrine\ORM\EntityManager;
use FOS\UserBundle\Event\FilterUserResponseEvent;
use FOS\UserBundle\Event\GetResponseUserEvent;
use FOS\UserBundle\Event\UserEvent;
use FOS\UserBundle\Event\FormEvent;
use FOS\UserBundle\FOSUserEvents;
use Symfony\Bundle\FrameworkBundle\Routing\Router;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;

class RegistrationListener implements EventSubscriberInterface
{
    /**
     * Entity manager
     *
     * @var EntityManager;
     */
    private $em;

    private $mailer;

    private $templating;

    /**
     * @var Router
     */
    private $router;

    /**
     * RegistrationListener constructor.
     *
     * @param \Doctrine\ORM\EntityManager $entityManager
     */
    public function __construct(EntityManager $entityManager, $mailer, $templating, $router)
    {
        $this->em = $entityManager;
        $this->mailer = $mailer;
        $this->templating = $templating;
        $this->router = $router;
    }

    /**
     * @return array
     */
    public static function getSubscribedEvents()
    {
        return array(
            FOSUserEvents::REGISTRATION_INITIALIZE => 'onRegistrationInitialize',
            FOSUserEvents::REGISTRATION_SUCCESS => 'onRegistrationSuccess',
            FOSUserEvents::REGISTRATION_COMPLETED => 'onRegistrationCompleted',
            FOSUserEvents::REGISTRATION_CONFIRM => 'onRegistrationConfirm',
        );
    }

    /**
     * @param \FOS\UserBundle\Event\UserEvent $userEvent
     */
    public function onRegistrationInitialize(UserEvent $userEvent)
    {
        /*
         * In the case that usernames are not used during registration, we can set the username to be a unique random string:
         */
        $user = $userEvent->getUser();
        $user->setUsername( uniqid() );
    }

    /**
     * @param \FOS\UserBundle\Event\FormEvent $formEvent
     */
    public function onRegistrationSuccess(FormEvent $formEvent)
    {     
        $url = $this->router->generate('knoitall_provider_profile_wizard');
        // $url = $this->router->generate('knoitall_learner_profile_wizard_step_1');

        $formEvent->setResponse(new RedirectResponse($url));
    }

    /**
     * @param \FOS\UserBundle\Event\FilterUserResponseEvent $event
     */
    public function onRegistrationCompleted(FilterUserResponseEvent $event)
    {
        /*
         * In the case that usernames are not used during registration, we can set the username to be identical to the email:
         */
        $user = $event->getUser();
        $user->setUsername( $user->getEmail() );
        $person = $user->getPerson();

        /*
         * Sw
         * We do not require a confirmation email, but still send out an informational email:
         */

        /**
         * Swift_Message $message
         */
        $email = strtolower($user->getEmail());
        $name = $person->getFirstName() . " " . $person->getLastName();
        $message = \Swift_Message::newInstance()
            ->setSubject('Knoitall registration')
            ->setFrom(['registration@knoitall.com' => 'Knoitall'])
            ->setTo([$email => $name]) 
            ->setBody(
                $this->templating->render('email/registration.html.twig', ['name' => $name]),'text/html'
            );
        $this->mailer->send($message);
    }

    public function onRegistrationConfirm(GetResponseUserEvent $event)
    {
    }
}

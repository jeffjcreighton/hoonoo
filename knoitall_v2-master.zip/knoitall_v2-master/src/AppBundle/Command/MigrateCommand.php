<?php

namespace AppBundle\Command;

use AppBundle\Entity\EventFormatSection;
use AppBundle\Entity\Location;
use AppBundle\Entity\TimeUnit;
use AppBundle\Repository\EventFormatSectionRepository;
use Doctrine\DBAL\Driver\PDOException;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use AppBundle\Entity\Advisor;
use AppBundle\Entity\Age;
use AppBundle\Entity\EventFormat;
use AppBundle\Entity\Goal;
use AppBundle\Entity\Instructor;
use AppBundle\Entity\Learner;
use AppBundle\Entity\Person;
use AppBundle\Entity\PersonTitle;
use AppBundle\Entity\Provider;
use AppBundle\Entity\Tag;
use AppBundle\Entity\User;
use AppBundle\Entity\LocationType;
use AppBundle\Entity\Postalcode;
use AppBundle\Entity\Taxonomy;
use AppBundle\Entity\Country;
use AppBundle\Entity\State;
use AppBundle\Entity\Event;

class MigrateCommand extends ContainerAwareCommand
{
    private $knoitall_v1_host   = 'localhost';
    private $knoitall_v1_userid = 'knoitalluser';
    private $knoitall_v1_passwd = 'knoitallpass';
    private $knoitall_v1_db     = 'knoitall_v1';

    private $eventFormatMap = [
        null                                  => 'Other',
        ''                                    => 'Other',
        'Face-to-Face - Advising'             => 'Face-to-Face - Advising',
        'Face-to-Face - Certificate'          => 'Face-to-Face - Certificate',
        'Face-to-Face - Class'                => 'Face-to-Face - Class or Seminar',
        'Face-to-Face - Graduate Degree'      => 'Face-to-Face - Graduate Degree',
        'Face-to-Face - Ongoing'              => 'Face-to-Face - Ongoing',
        'Face-to-Face - Self Directed'        => 'Face-to-Face - Self-Directed',
        'Face-to-Face - Tutoring'             => 'Face-to-Face - Tutoring or Individual Lessons',
        'Face-to-Face - Undergraduate Degree' => 'Face-to-Face - Undergraduate Degree',
        'Face-to-Face'                        => 'Face-to-Face - Other',
        'Free Resource'                       => 'Free Resource (Video, Article, Pod Cast or Other)',
        'Media'                               => 'Media',
        'Online - Advising'                   => 'Online - Advising',
        'Online - Certificate'                => 'Online - Certificate',
        'Online - Class'                      => 'Online - Class or Webinar',
        'Online - Graduate Degree'            => 'Online - Graduate Degree',
        'Online - Ongoing'                    => 'Online - Ongoing',
        'Online - Self Directed'              => 'Online - Self-Directed',
        'Online - Tutoring'                   => 'Online - Tutoring or Individual Lessons',
        'Online - Undergraduate Degree'       => 'Online - Undergraduate Degree',
        'Online'                              => 'Online - Other',
        'online'                              => 'Online - Other', // some events have 'online' (with a lower-case 'o')
        'Product'                             => 'Product That Must Be Shipped (CD, DVD, Book or Other)',
        'Supplemental Product'                => 'Supplemental Product',
        /*
         * TODO: examine these cases more closely:
         * e.g. provider 'Azusa Pacific University School of Education' has a program called 'Accelerated Teaching Degree'
         * which is classified as 'Undergraduate Degree' without specifying Face-to-Face or Online
         */
        'Certificate'                         => 'Face-to-Face - Certificate',
        'Undergraduate Degree'                => 'Face-to-Face - Undergraduate Degree',
        'Graduate Degree'                     => 'Face-to-Face - Graduate Degree',
    ];

    private $ageMap = [
        'Infant' => 'Infant',
        'Toddler' => 'Toddler',
        'Child' => 'Child',
        'Preteen' => 'Pre-teen', // this is the only one that changes from v1 to v2
        'Teen' => 'Teen',
        'Adult' => 'Adult',
        'Senior' => 'Senior',
    ];

    private $taxonomyRemap = [
        /*
         * level-1 category 'Art, Drama & Music' has been split into 'Arts & Crafts' and 'Dance, Drama & Music':
         */
        [ 'v1' => ['Art, Drama & Music','Acting & Drama'],                     'v2' => ['Dance, Drama & Music','Acting & Drama']                  ],
        [ 'v1' => ['Art, Drama & Music','After Effects'],                      'v2' => ['Arts & Crafts','After Effects']                          ],
        [ 'v1' => ['Art, Drama & Music','Airbrushing'],                        'v2' => ['Arts & Crafts','Airbrushing']                            ],
        [ 'v1' => ['Art, Drama & Music','Animation & Visual Effects'],         'v2' => ['Arts & Crafts','Animation & Visual Effects']             ],
        [ 'v1' => ['Art, Drama & Music','Antiques'],                           'v2' => ['Arts & Crafts','Antiques']                               ],
        [ 'v1' => ['Art, Drama & Music','Architecture, Landscape & Drafting'], 'v2' => ['Arts & Crafts','Architecture, Landscape & Drafting']     ],
        [ 'v1' => ['Art, Drama & Music','Art History & Gallery Management'],   'v2' => ['Arts & Crafts','Art History & Gallery Management']       ],
        [ 'v1' => ['Art, Drama & Music','Audio & Recording'],                  'v2' => ['Dance, Drama & Music','Audio & Recording']               ],
        [ 'v1' => ['Art, Drama & Music','Bach, Beethoven & Mozart'],           'v2' => ['Dance, Drama & Music','Bach, Beethoven & Mozart']        ],
        [ 'v1' => ['Art, Drama & Music','Ballet'],                             'v2' => ['Dance, Drama & Music','Ballet']                          ],
        [ 'v1' => ['Art, Drama & Music','Band'],                               'v2' => ['Dance, Drama & Music','Band']                            ],
        [ 'v1' => ['Art, Drama & Music','Banjo & Fiddle'],                     'v2' => ['Dance, Drama & Music','Banjo & Fiddle']                  ],
        [ 'v1' => ['Art, Drama & Music','Basketry & Weaving'],                 'v2' => ['Arts & Crafts','Basketry & Weaving']                     ],
        [ 'v1' => ['Art, Drama & Music','Beading, Glass & Jewelry'],           'v2' => ['Arts & Crafts','Beading, Glass & Jewelry']               ],
        [ 'v1' => ['Art, Drama & Music','Bugle, Coronet & Flugelhorn'],        'v2' => ['Dance, Drama & Music','Bugle, Coronet & Flugelhorn']     ],
        [ 'v1' => ['Art, Drama & Music','Calligraphy & Lettering'],            'v2' => ['Arts & Crafts','Calligraphy & Lettering']                ],
        [ 'v1' => ['Art, Drama & Music','Candle making'],                      'v2' => ['Arts & Crafts','Candle Making']                          ], // also 'making' was capitalized
        [ 'v1' => ['Art, Drama & Music','Ceramics, Pottery & Sculpture'],      'v2' => ['Arts & Crafts','Ceramics, Pottery & Sculpture']          ],
        [ 'v1' => ['Art, Drama & Music','Choreography'],                       'v2' => ['Dance, Drama & Music','Choreography']                    ],
        [ 'v1' => ['Art, Drama & Music','Clarinet'],                           'v2' => ['Dance, Drama & Music','Clarinet']                        ],
        [ 'v1' => ['Art, Drama & Music','Coloring'],                           'v2' => ['Arts & Crafts','Coloring']                               ],
        [ 'v1' => ['Art, Drama & Music','Dance-Other'],                        'v2' => ['Dance, Drama & Music','Dance - Other']                   ], // also space was added around the '-' for consistency
        [ 'v1' => ['Art, Drama & Music','Directing'],                          'v2' => ['Dance, Drama & Music','Directing']                       ],
        [ 'v1' => ['Art, Drama & Music','Drawing'],                            'v2' => ['Arts & Crafts','Drawing']                                ],
        [ 'v1' => ['Art, Drama & Music','Dress Making'],                       'v2' => ['Arts & Crafts','Dress Making']                           ],
        [ 'v1' => ['Art, Drama & Music','Drums & Percussion'],                 'v2' => ['Dance, Drama & Music','Drums & Percussion']              ],
        [ 'v1' => ['Art, Drama & Music','Embroidery & Engraving'],             'v2' => ['Arts & Crafts','Embroidery & Engraving']                 ],
        [ 'v1' => ['Art, Drama & Music','Fashion Design & Merchandising'],     'v2' => ['Arts & Crafts','Fashion Design & Merchandising']         ],
        [ 'v1' => ['Art, Drama & Music','Film Development & Movie Theory'],    'v2' => ['Dance, Drama & Music','Film Development & Movie Theory'] ],
        [ 'v1' => ['Art, Drama & Music','Floral or Flower Arranging'],         'v2' => ['Arts & Crafts','Floral or Flower Arranging']             ],
        [ 'v1' => ['Art, Drama & Music','Flute & Piccolo'],                    'v2' => ['Dance, Drama & Music','Flute & Piccolo']                 ],
        [ 'v1' => ['Art, Drama & Music','French Horn, Trumpet & Tuba'],        'v2' => ['Dance, Drama & Music','French Horn, Trumpet & Tuba']     ],
        [ 'v1' => ['Art, Drama & Music','Graphic Design & Digital Arts'],      'v2' => ['Arts & Crafts','Graphic Design & Digital Arts']          ],
        [ 'v1' => ['Art, Drama & Music','Guitar & Bass Guitar'],               'v2' => ['Dance, Drama & Music','Guitar & Bass Guitar']            ],
        [ 'v1' => ['Art, Drama & Music','Harmonica'],                          'v2' => ['Dance, Drama & Music','Harmonica']                       ],
        [ 'v1' => ['Art, Drama & Music','Hip Hop & Modern Dance'],             'v2' => ['Dance, Drama & Music','Hip Hop & Modern Dance']          ],
        [ 'v1' => ['Art, Drama & Music','Holiday Crafts'],                     'v2' => ['Arts & Crafts','Holiday Crafts']                         ],
        [ 'v1' => ['Art, Drama & Music','Impressionism'],                      'v2' => ['Arts & Crafts','Impressionism']                          ],
        [ 'v1' => ['Art, Drama & Music','Jazz'],                               'v2' => ['Dance, Drama & Music','Jazz']                            ],
        [ 'v1' => ['Art, Drama & Music','Jazz & Tap Dance'],                   'v2' => ['Dance, Drama & Music','Jazz & Tap Dance']                ],
        [ 'v1' => ['Art, Drama & Music','Knitting & Sewing'],                  'v2' => ['Arts & Crafts','Knitting & Sewing']                      ],
        [ 'v1' => ['Art, Drama & Music','Leather'],                            'v2' => ['Arts & Crafts','Leather']                                ],
        [ 'v1' => ['Art, Drama & Music','Liberal & General Studies'],          'v2' => ['Arts & Crafts','Liberal & General Studies']              ],
        [ 'v1' => ['Art, Drama & Music','Metallurgy & Welding'],               'v2' => ['Arts & Crafts','Metallurgy & Welding']                   ],
        [ 'v1' => ['Art, Drama & Music','Music History & Theory'],             'v2' => ['Dance, Drama & Music','Music History & Theory']          ],
        [ 'v1' => ['Art, Drama & Music','Musicals'],                           'v2' => ['Dance, Drama & Music','Musicals']                        ],
        [ 'v1' => ['Art, Drama & Music','Oboe & Bassoon'],                     'v2' => ['Dance, Drama & Music','Oboe & Bassoon']                  ],
        [ 'v1' => ['Art, Drama & Music','Opera'],                              'v2' => ['Dance, Drama & Music','Opera']                           ],
        [ 'v1' => ['Art, Drama & Music','Orchestra'],                          'v2' => ['Dance, Drama & Music','Orchestra']                       ],
        [ 'v1' => ['Art, Drama & Music','Origami & Paper Mache'],              'v2' => ['Arts & Crafts','Origami & Paper Mache']                  ],
        [ 'v1' => ['Art, Drama & Music','Painting'],                           'v2' => ['Arts & Crafts','Painting']                               ],
        [ 'v1' => ['Art, Drama & Music','Painting-Acrylics'],                  'v2' => ['Arts & Crafts','Painting - Acrylics']                    ], // also space was added around the '-' for consistency
        [ 'v1' => ['Art, Drama & Music','Painting-Guache'],                    'v2' => ['Arts & Crafts','Painting - Guache']                      ], // also space was added around the '-' for consistency
        [ 'v1' => ['Art, Drama & Music','Painting-Oils'],                      'v2' => ['Arts & Crafts','Painting - Oils']                        ], // also space was added around the '-' for consistency
        [ 'v1' => ['Art, Drama & Music','Painting-Water Color'],               'v2' => ['Arts & Crafts','Painting - Water Color']                 ], // also space was added around the '-' for consistency
        [ 'v1' => ['Art, Drama & Music','Photography'],                        'v2' => ['Arts & Crafts','Photography']                            ],
        [ 'v1' => ['Art, Drama & Music','Piano & Keyboard'],                   'v2' => ['Dance, Drama & Music','Piano & Keyboard']                ],
        [ 'v1' => ['Art, Drama & Music','Post Production'],                    'v2' => ['Arts & Crafts','Post Production']                        ],
        [ 'v1' => ['Art, Drama & Music','Saxophone'],                          'v2' => ['Dance, Drama & Music','Saxophone']                       ],
        [ 'v1' => ['Art, Drama & Music','Scrapbooking'],                       'v2' => ['Arts & Crafts','Scrapbooking']                           ],
        [ 'v1' => ['Art, Drama & Music','Singing & Vocals'],                   'v2' => ['Dance, Drama & Music','Singing & Vocals']                ],
        [ 'v1' => ['Art, Drama & Music','Song Writing'],                       'v2' => ['Dance, Drama & Music','Song Writing']                    ],
        [ 'v1' => ['Art, Drama & Music','Stage & Sound Design'],               'v2' => ['Dance, Drama & Music','Stage & Sound Design']            ],
        [ 'v1' => ['Art, Drama & Music','Swing & Square Dancing'],             'v2' => ['Dance, Drama & Music','Swing & Square Dancing']          ],
        [ 'v1' => ['Art, Drama & Music','Symphony, Concertos & Sonatas'],      'v2' => ['Dance, Drama & Music','Symphony, Concertos & Sonatas']   ],
        [ 'v1' => ['Art, Drama & Music','Trombone'],                           'v2' => ['Dance, Drama & Music','Trombone']                        ],
        [ 'v1' => ['Art, Drama & Music','Ukulele'],                            'v2' => ['Dance, Drama & Music','Ukulele']                         ],
        [ 'v1' => ['Art, Drama & Music','Videography'],                        'v2' => ['Arts & Crafts','Videography']                            ],
        [ 'v1' => ['Art, Drama & Music','Violin, Viola & Cello'],              'v2' => ['Dance, Drama & Music','Violin, Viola & Cello']           ],
        [ 'v1' => ['Art, Drama & Music','Woodworking & Carpentry'],            'v2' => ['Arts & Crafts','Woodworking & Carpentry']                ],
        [ 'v1' => ['Art, Drama & Music','Zumba'],                              'v2' => ['Dance, Drama & Music','Zumba']                           ],
        /*
         * other fixes (typos and inconsistencies):
         */
        [ 'v1' => ['Science & Math','paleongology'],                                   'v2' => ['Science & Math','Paleontology'] ], // fixed typo
        [ 'v1' => ['Sports & Leisure','triathlon'],                                    'v2' => ['Sports & Leisure','Triathlon'] ], // fixed capitalization
        [ 'v1' => ['Sports & Leisure','Cycling Road Biking'],                          'v2' => ['Sports & Leisure','Cycling & Mountain Biking'] ], // categories combined into one
        [ 'v1' => ['Sports & Leisure','Mountain Biking'],                              'v2' => ['Sports & Leisure','Cycling & Mountain Biking'] ], // categories combined into one
        [ 'v1' => ['Sports & Leisure','Running, Cross Country and Marathon Training'], 'v2' => ['Sports & Leisure','Running, Cross Country & Marathon Training'] ], // 'and' changed to '&' for consistency
        [ 'v1' => ['History','Military and War'],                                      'v2' => ['History','Military & War'] ], // 'and' changed to '&' for consistency
        [ 'v1' => ['Business','Compliance - Drug and Alcohol Testing'],                'v2' => ['Business','Compliance - Drug & Alcohol Testing'] ], // 'and' changed to '&' for consistency
        [ 'v1' => ['Business','Compliance - Health and Safety-OSHA'],                  'v2' => ['Business','Compliance - Health & Safety - OSHA'] ], // 'and' changed to '&' for consistency; also space was added around the '-' for consistency
        [ 'v1' => ['Business','Compliance - Health and Safety (OSHA)'],                'v2' => ['Business','Compliance - Health & Safety - OSHA'] ], // 'and' changed to '&' for consistency; removed parentheses
        [ 'v1' => ['Computers & Software','Chrome, Safari and Firefox'],               'v2' => ['Computers & Software','Chrome, Safari & Firefox'] ], // 'and' changed to '&' for consistency
        [ 'v1' => ['Computers & Software','Corel Draw and Corel Paint'],               'v2' => ['Computers & Software','Corel Draw & Corel Paint'] ], // 'and' changed to '&' for consistency
        [ 'v1' => ['Health & Health Care','Allergies and Asthma'],                     'v2' => ['Health & Health Care','Allergies & Asthma'] ], // 'and' changed to '&' for consistency
        [ 'v1' => ['Health & Health Care','Neonatal and Pediatric Care'],              'v2' => ['Health & Health Care','Neonatal & Pediatric Care'] ], // 'and' changed to '&' for consistency
        [ 'v1' => ['Home & Garden','Indoor and Outdoor Plants'],                       'v2' => ['Home & Garden','Indoor & Outdoor Plants'] ], // 'and' changed to '&' for consistency
        /*
         * still more fixes (changes for better consistency):
         */
        [ 'v1' => ['Computers & Software','Microsoft Excel-Charts'],                           'v2' => ['Computers & Software','Microsoft Excel - Charts'] ], // add space around '-'
        [ 'v1' => ['Computers & Software','Microsoft Excel-Conditional Formatting'],           'v2' => ['Computers & Software','Microsoft Excel - Conditional Formatting'] ], // add space around '-'
        [ 'v1' => ['Computers & Software','Microsoft Excel-Formatting'],                       'v2' => ['Computers & Software','Microsoft Excel - Formatting'] ], // add space around '-'
        [ 'v1' => ['Computers & Software','Microsoft Excel-Formulas & Functions'],             'v2' => ['Computers & Software','Microsoft Excel - Formulas & Functions'] ], // add space around '-'
        [ 'v1' => ['Computers & Software','Microsoft Excel-If Statements'],                    'v2' => ['Computers & Software','Microsoft Excel - If Statements'] ], // add space around '-'
        [ 'v1' => ['Computers & Software','Microsoft Excel-Lookups'],                          'v2' => ['Computers & Software','Microsoft Excel - Lookups'] ], // add space around '-'
        [ 'v1' => ['Computers & Software','Microsoft Excel-Navigation & Views'],               'v2' => ['Computers & Software','Microsoft Excel - Navigation & Views'] ], // add space around '-'
        [ 'v1' => ['Computers & Software','Microsoft Excel-Pivot Tables'],                     'v2' => ['Computers & Software','Microsoft Excel - Pivot Tables'] ], // add space around '-'
        [ 'v1' => ['Computers & Software','Microsoft Excel-Working with Multiple Worksheets'], 'v2' => ['Computers & Software','Microsoft Excel - Working with Multiple Worksheets'] ], // add space around '-'
        [ 'v1' => ['Computers & Software','Operating systems'],                                'v2' => ['Computers & Software','Operating Systems'] ], // fixed capitalization
        [ 'v1' => ['History','18th, 19th & 20th centuries'],                                   'v2' => ['History','18th, 19th & 20th Centuries'] ], // fixed capitalization
        [ 'v1' => ['Hobbies & Games','Dog training'],                                          'v2' => ['Hobbies & Games','Dog Training'] ], // fixed capitalization
        [ 'v1' => ['Science & Math','Biomedical science'],                                     'v2' => ['Science & Math','Biomedical Science'] ], // fixed capitalization
        [ 'v1' => ['Science & Math','Cognitive neuroscience'],                                 'v2' => ['Science & Math','Cognitive Neuroscience'] ], // fixed capitalization
        [ 'v1' => ['Science & Math','Computational neuroscience'],                             'v2' => ['Science & Math','Computational Neuroscience'] ], // fixed capitalization
        [ 'v1' => ['Sports & Leisure','Equestrian & Horseback riding'],                        'v2' => ['Sports & Leisure','Equestrian & Horseback Riding'] ], // fixed capitalization
        /*
         * more fixes (from events/providers which contain references to non-existent categories):
         */
        [ 'v1' => ['Art, Drama & Music','Art History'],                               'v2' => ['Arts & Crafts','Art History & Gallery Management'] ],
        [ 'v1' => ['Art, Drama & Music', 'Bach, Beehtoven & Mozart'],                 'v2' => ['Dance, Drama & Music','Bach, Beethoven & Mozart'] ], // [sic] "Beehtoven" in v1 rather than "Beethoven"
        [ 'v1' => ['Business','Careers'],                                             'v2' => ['Business','Career Planning, Coaching & Mentoring'] ],
        [ 'v1' => ['Business','Communications & PR'],                                 'v2' => ['Business','Communications, Public Speaking & Public Relations'] ],
        [ 'v1' => ['Business','Communications, Public Speaking & Public Relatio'],    'v2' => ['Business','Communications, Public Speaking & Public Relations'] ], // [sic] 'Relatio' somehow got truncated in v1
        [ 'v1' => ['Business','Finance'],                                             'v2' => ['Business','Finance, Financial Management & Budgets'] ],
        [ 'v1' => ['Business','Investing'],                                           'v2' => ['Business','Investing & Wealth Creation'] ],
        [ 'v1' => ['Cooking & Beverage','Food Management'],                           'v2' => ['Cooking & Beverage','Catering & Food Management'] ],
        [ 'v1' => ['Cooking & Beverage','Other'],                                     'v2' => ['Cooking & Beverage'] ], // TODO: we could do this in other places too: Instead of taxonomy 'x:Other', simply use the single-level taxonomy 'x'
        [ 'v1' => ['Cooking Wine',''],                                                'v2' => ['Cooking & Beverage','Wine & Beer'] ],
        [ 'v1' => ['Education','Administration'],                                     'v2' => ['Education','Administration & Leadership'] ],
        [ 'v1' => ['Education','Vocational Education'],                               'v2' => ['Education','Vocational'] ],
        [ 'v1' => ['Engineering','Systems Engineering'],                              'v2' => ['Engineering','Systems Engineering & Systems Architecture'] ],
        [ 'v1' => ['English, Literature & Writing','Reading World Literature'],       'v2' => ['English, Literature & Writing','World Literature'] ],
        [ 'v1' => ['Health & Health Care','Compliance - Health Information (HIPPA)'], 'v2' => ['Health & Health Care','Compliance - HIPPA'] ],
        [ 'v1' => ['Health & Health Care','Dental'],                                  'v2' => ['Health & Health Care','Dentistry & Orthodontics'] ],
        [ 'v1' => ['Health & Health Care','Nutrition & Fitness'],                     'v2' => ['Health & Health Care','Wellness, Fitness, Nutrition & Weight Loss'] ],
        [ 'v1' => ['Health & Health Care','Pharmacy'],                                'v2' => ['Health & Health Care','Pharmacology'] ],
        [ 'v1' => ['History','World Ancient History'],                                'v2' => ['History','World & Ancient'] ],
        [ 'v1' => ['Science & Math','Arithmetic'],                                    'v2' => ['Science & Math','Arithmetic & Mathematics'] ],
        [ 'v1' => ['Science & Math','Outer Space'],                                   'v2' => ['Science & Math','Astronomy & Space'] ],
        [ 'v1' => ['Science & Math','Social Sciences'],                               'v2' => ['Science & Math','Sociology & Social Work'] ],
    ];

    /*
     * explicit taxonomy for certain provider (which can not be easily migrated otherwise):
     */
    private $providerTaxonomy = [
//        'Lifelong Learning Institute' => [
//            ['Business','Administration'],
//            ['Business','Career Planning, Coaching & Mentoring'],
//            ['Business','Communications, Public Speaking & Public Relations'],
//            ['Business','Compensation & Benefits'],
//            ['Business','Creativity & Innovation'],
//            ['Business','Critical & Analytical Thinking'],
//            ['Business','Problem Solving'],
//            ['Business','Discipline & Termination'],
//            ['Business','Diversity & Intercultural Competency'],
//            ['Business','Emotional Intelligence'],
//            ['Business','Finance, Financial Management & Budgets'],
//            ['Business','Interviewing, Recruiting & Retention'],
//            ['Business','Organization Development'],
//        ],
    ];

    /*
     * explicit taxonomy for certain events (which can not be easily migrated otherwise):
     */
    private $eventTaxonomy = [
        'Case-Based Introduction to Biostatistics' => [
            ['Science & Math','Statistics & Probability'],
        ],
        'Biostatistics for Medical Product Regulation' => [
            ['Science & Math','Statistics & Probability'],
        ],
        'Computational Methods' => [
            ['Science & Math','Computational Methods'],
        ],
    ];

    /*
     * extra categories to added to the taxonomy, beyond those migrated from v1:
     */
    private $taxonomyExtraCategories = [
        ['Arts & Crafts', 'Clothing Design'],
        ['Business', 'Logistics & Supply Chain'],
        ['Computers & Software', 'Cloud Computing'],
        ['Computers & Software', 'Programming Languages'],
        ['Computers & Software', 'Social Media'],
        ['Cooking & Beverage', 'Appetizers'],
        ['Cooking & Beverage', 'Breakfasts'],
        ['Cooking & Beverage', 'Desserts'],
        ['Cooking & Beverage', 'Ethnic Foods'],
        ['Cooking & Beverage', 'Holiday Meals'],
        ['Cooking & Beverage', 'Mixology'],
        ['Cooking & Beverage', 'Soups & Salads'],
        ['Cooking & Beverage', 'Vegetarian & Vegan'],
        ['Dance, Drama & Music', 'Woodwinds'],
        ['Health & Health Care','Dentistry & Orthodontics'],
        ['History', 'Colonialism'],
        ['History', 'Cultural History'],
        ['History', 'Medieval History'],
        ['History', 'Native American History'],
        ['History', 'Technology'],
        ['Hobbies & Games', 'Magic'],
        ['Home & Garden', 'Tile'],
        ['Parenting', 'Family Network Security'],
        ['Science & Math','Computational Methods'],
        ['Sports & Leisure', 'Track & Field'],
    ];

    /*
     * explicit overrides for slugs (otherwise created automatically) for the taxonommy:
     */
    private $taxonomySlugs = [
        [ ['Computers & Software','C# Programming'], 'computers-software-c-sharp-programming' ], // otherwise we'd have "computers-software-c-programming-1" because of "C Programming"
    ];

    private $excludedProviders = [
        1488965304 => ['Record_Key' => 1488965304, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-71'],
        1488664775 => ['Record_Key' => 1488664775, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-59'],
        1481239878 => ['Record_Key' => 1481239878, 'Entered_By_Email' => null, 'Provider' => '557558', 'Nickname' => '557558'],
        1491051634 => ['Record_Key' => 1491051634, 'Entered_By_Email' => null, 'Provider' => '730450', 'Nickname' => '730450'],
        1484533004 => ['Record_Key' => 1484533004, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-15'],
        1488664748 => ['Record_Key' => 1488664748, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-55'],
        1488965247 => ['Record_Key' => 1488965247, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-68'],
        1478434992 => ['Record_Key' => 1478434992, 'Entered_By_Email' => null, 'Provider' => 'turquoise21', 'Nickname' => 'turquoise21'],
        1486685396 => ['Record_Key' => 1486685396, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-46'],
        1445886301 => ['Record_Key' => 1445886301, 'Entered_By_Email' => 'jeff@knoitall.com', 'Provider' => null, 'Nickname' => 'Jeff'],
        1486685413 => ['Record_Key' => 1486685413, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-48'],
        1483948885 => ['Record_Key' => 1483948885, 'Entered_By_Email' => null, 'Provider' => '10540', 'Nickname' => '10540'],
        1482403807 => ['Record_Key' => 1482403807, 'Entered_By_Email' => null, 'Provider' => 'H3Z 2Y7', 'Nickname' => 'h3z-2y7'],
        1472851762 => ['Record_Key' => 1472851762, 'Entered_By_Email' => null, 'Provider' => 'YungM3tro', 'Nickname' => 'YungM3tro'],
        1471981704 => ['Record_Key' => 1471981704, 'Entered_By_Email' => null, 'Provider' => 'jay69', 'Nickname' => 'jay69'],
        1487505150 => ['Record_Key' => 1487505150, 'Entered_By_Email' => null, 'Provider' => '9040', 'Nickname' => '9040'],
        1486685370 => ['Record_Key' => 1486685370, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-43'],
        1481260426 => ['Record_Key' => 1481260426, 'Entered_By_Email' => null, 'Provider' => '640141', 'Nickname' => '640141'],
        1490383565 => ['Record_Key' => 1490383565, 'Entered_By_Email' => null, 'Provider' => null, 'Nickname' => null],
        1490726102 => ['Record_Key' => 1490726102, 'Entered_By_Email' => null, 'Provider' => null, 'Nickname' => null],
        1485146558 => ['Record_Key' => 1485146558, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-31'],
        1486685362 => ['Record_Key' => 1486685362, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-42'],
        1483651763 => ['Record_Key' => 1483651763, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-6'],
        1483651908 => ['Record_Key' => 1483651908, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-8'],
        1480839146 => ['Record_Key' => 1480839146, 'Entered_By_Email' => null, 'Provider' => 'None', 'Nickname' => 'none-2'],
        1484532890 => ['Record_Key' => 1484532890, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-13'],
        1488027463 => ['Record_Key' => 1488027463, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-52'],
        1483651605 => ['Record_Key' => 1483651605, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-3'],
        1473467231 => ['Record_Key' => 1473467231, 'Entered_By_Email' => null, 'Provider' => 'Baby talk', 'Nickname' => 'Baby_talk-2'],
        1418684849 => ['Record_Key' => 1418684849, 'Entered_By_Email' => 'jeff@knoitall.com', 'Provider' => null, 'Nickname' => 'jeffjcreighton'],
        1488964006 => ['Record_Key' => 1488964006, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-63'],
        1485146642 => ['Record_Key' => 1485146642, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-37'],
        1482548350 => ['Record_Key' => 1482548350, 'Entered_By_Email' => null, 'Provider' => null, 'Nickname' => null],
        1484533089 => ['Record_Key' => 1484533089, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-17'],
        1487008546 => ['Record_Key' => 1487008546, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-51'],
        1472225440 => ['Record_Key' => 1472225440, 'Entered_By_Email' => null, 'Provider' => 'Pebbles072', 'Nickname' => 'Pebbles072'],
        1483651973 => ['Record_Key' => 1483651973, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-9'],
        1486685387 => ['Record_Key' => 1486685387, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-45'],
        1475505394 => ['Record_Key' => 1475505394, 'Entered_By_Email' => null, 'Provider' => 'None', 'Nickname' => 'None'],
        1470918812 => ['Record_Key' => 1470918812, 'Entered_By_Email' => null, 'Provider' => 'tester', 'Nickname' => 'tester'],
        1488664782 => ['Record_Key' => 1488664782, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-60'],
        1485146527 => ['Record_Key' => 1485146527, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-29'],
        1491027440 => ['Record_Key' => 1491027440, 'Entered_By_Email' => null, 'Provider' => '9450', 'Nickname' => '9450'],
        1483651837 => ['Record_Key' => 1483651837, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-7'],
        0 => ['Record_Key' => 0, 'Entered_By_Email' => 'Provider', 'Provider' => null, 'Nickname' => null],
        1485146585 => ['Record_Key' => 1485146585, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-33'],
        1486685421 => ['Record_Key' => 1486685421, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-49'],
        1463459386 => ['Record_Key' => 1463459386, 'Entered_By_Email' => 'prajwalpasdrvce@gmail.com', 'Provider' => 'prajwalpasdrvce', 'Nickname' => 'prajwalpasdrvce'],
        1488965349 => ['Record_Key' => 1488965349, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-73'],
        1478059352 => ['Record_Key' => 1478059352, 'Entered_By_Email' => null, 'Provider' => 'dDSyHhBAHcRWJ', 'Nickname' => 'dDSyHhBAHcRWJ'],
        1488965328 => ['Record_Key' => 1488965328, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-72'],
        1488664734 => ['Record_Key' => 1488664734, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-53'],
        1484532933 => ['Record_Key' => 1484532933, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-14'],
        1488965212 => ['Record_Key' => 1488965212, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-66'],
        1483976681 => ['Record_Key' => 1483976681, 'Entered_By_Email' => null, 'Provider' => '49161', 'Nickname' => '49161'],
        1490123983 => ['Record_Key' => 1490123983, 'Entered_By_Email' => null, 'Provider' => null, 'Nickname' => null],
        1480555459 => ['Record_Key' => 1480555459, 'Entered_By_Email' => null, 'Provider' => '8485', 'Nickname' => '8485'],
        1485146348 => ['Record_Key' => 1485146348, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-21'],
        1483925040 => ['Record_Key' => 1483925040, 'Entered_By_Email' => null, 'Provider' => '3418', 'Nickname' => '3418'],
        1473167659 => ['Record_Key' => 1473167659, 'Entered_By_Email' => null, 'Provider' => 'Mzpeaches', 'Nickname' => 'Mzpeaches'],
        1358051731 => ['Record_Key' => 1358051731, 'Entered_By_Email' => 'computertutoring123@gmail.com', 'Provider' => 'Computer Tutoring', 'Nickname' => null],
        1490761242 => ['Record_Key' => 1490761242, 'Entered_By_Email' => null, 'Provider' => null, 'Nickname' => null],
        1485146365 => ['Record_Key' => 1485146365, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-22'],
        1484533024 => ['Record_Key' => 1484533024, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-16'],
        1472681406 => ['Record_Key' => 1472681406, 'Entered_By_Email' => null, 'Provider' => 'mysite3', 'Nickname' => 'mysite3'],
        1488664797 => ['Record_Key' => 1488664797, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-62'],
        1482582312 => ['Record_Key' => 1482582312, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180'],
        1490574424 => ['Record_Key' => 1490574424, 'Entered_By_Email' => null, 'Provider' => null, 'Nickname' => null],
        1488965264 => ['Record_Key' => 1488965264, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-69'],
        1485146478 => ['Record_Key' => 1485146478, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-26'],
        1488664790 => ['Record_Key' => 1488664790, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-61'],
        1483651704 => ['Record_Key' => 1483651704, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-5'],
        1490799449 => ['Record_Key' => 1490799449, 'Entered_By_Email' => null, 'Provider' => null, 'Nickname' => null],
        1483655099 => ['Record_Key' => 1483655099, 'Entered_By_Email' => null, 'Provider' => 'N/A', 'Nickname' => 'n/a'],
        1490831090 => ['Record_Key' => 1490831090, 'Entered_By_Email' => null, 'Provider' => null, 'Nickname' => null],
        1324223522 => ['Record_Key' => 1324223522, 'Entered_By_Email' => 'Jeff@inquisic.com', 'Provider' => 'Zimbazee', 'Nickname' => null],
        1484533115 => ['Record_Key' => 1484533115, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-18'],
        1472941789 => ['Record_Key' => 1472941789, 'Entered_By_Email' => null, 'Provider' => 'CAshleygrow72', 'Nickname' => 'CAshleygrow72'],
        1483906240 => ['Record_Key' => 1483906240, 'Entered_By_Email' => null, 'Provider' => '95077', 'Nickname' => '95077'],
        1485146512 => ['Record_Key' => 1485146512, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-28'],
        1485146663 => ['Record_Key' => 1485146663, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-38'],
        1488664762 => ['Record_Key' => 1488664762, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-57'],
        1473094660 => ['Record_Key' => 1473094660, 'Entered_By_Email' => null, 'Provider' => 'MelMel721', 'Nickname' => 'MelMel721'],
        1490690378 => ['Record_Key' => 1490690378, 'Entered_By_Email' => null, 'Provider' => null, 'Nickname' => null],
        1491064165 => ['Record_Key' => 1491064165, 'Entered_By_Email' => null, 'Provider' => '82685', 'Nickname' => '82685'],
        1488965184 => ['Record_Key' => 1488965184, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-64'],
        1488965231 => ['Record_Key' => 1488965231, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-67'],
        1470791541 => ['Record_Key' => 1470791541, 'Entered_By_Email' => null, 'Provider' => 'erictest', 'Nickname' => 'erictest'],
        1490801025 => ['Record_Key' => 1490801025, 'Entered_By_Email' => null, 'Provider' => null, 'Nickname' => null],
        1485146613 => ['Record_Key' => 1485146613, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-35'],
        1483651880 => ['Record_Key' => 1483651880, 'Entered_By_Email' => null, 'Provider' => null, 'Nickname' => null],
        1379328131 => ['Record_Key' => 1379328131, 'Entered_By_Email' => 'tom@highefficiencyskills.com', 'Provider' => 'High Efficiency Skills', 'Nickname' => null],
        1484687120 => ['Record_Key' => 1484687120, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-20'],
        1470790848 => ['Record_Key' => 1470790848, 'Entered_By_Email' => null, 'Provider' => 'test2a', 'Nickname' => 'test2a'],
        1486685344 => ['Record_Key' => 1486685344, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-40'],
        1483652080 => ['Record_Key' => 1483652080, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-11'],
        1484533171 => ['Record_Key' => 1484533171, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-19'],
        1481124948 => ['Record_Key' => 1481124948, 'Entered_By_Email' => null, 'Provider' => '98011', 'Nickname' => '98011'],
        1472942200 => ['Record_Key' => 1472942200, 'Entered_By_Email' => null, 'Provider' => 'CAshleygrow72', 'Nickname' => 'CAshleygrow72-2'],
        1485146540 => ['Record_Key' => 1485146540, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-30'],
        1485146406 => ['Record_Key' => 1485146406, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-23'],
        1485146599 => ['Record_Key' => 1485146599, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-34'],
        1482768734 => ['Record_Key' => 1482768734, 'Entered_By_Email' => null, 'Provider' => 'Renaissance Learners of New England', 'Nickname' => 'renaissance-learners-of-new-england-2'],
        1476675015 => ['Record_Key' => 1476675015, 'Entered_By_Email' => null, 'Provider' => 'tdavis2789', 'Nickname' => 'tdavis2789'],
        1485146442 => ['Record_Key' => 1485146442, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-25'],
        1446657233 => ['Record_Key' => 1446657233, 'Entered_By_Email' => 'jeff@knoitall.com', 'Provider' => null, 'Nickname' => null],
        1486685404 => ['Record_Key' => 1486685404, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-47'],
        1474356194 => ['Record_Key' => 1474356194, 'Entered_By_Email' => null, 'Provider' => 'Art', 'Nickname' => 'Art'],
        1488664769 => ['Record_Key' => 1488664769, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-58'],
        1488965281 => ['Record_Key' => 1488965281, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-70'],
        1470852832 => ['Record_Key' => 1470852832, 'Entered_By_Email' => null, 'Provider' => 'Emily', 'Nickname' => 'Emily'],
        1483933257 => ['Record_Key' => 1483933257, 'Entered_By_Email' => null, 'Provider' => '21862', 'Nickname' => '21862'],
        1463127778 => ['Record_Key' => 1463127778, 'Entered_By_Email' => 'hnurin_husnina@yahoo.com', 'Provider' => 'NRNHUSNINA', 'Nickname' => 'NRNHUSNINA'],
        1488965199 => ['Record_Key' => 1488965199, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-65'],
        1484533137 => ['Record_Key' => 1484533137, 'Entered_By_Email' => null, 'Provider' => null, 'Nickname' => null],
        1462481778 => ['Record_Key' => 1462481778, 'Entered_By_Email' => 'deerpath@knoitall.com', 'Provider' => 'Deerpath', 'Nickname' => 'Deerpath-2'],
        1483651627 => ['Record_Key' => 1483651627, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-4'],
        1490612486 => ['Record_Key' => 1490612486, 'Entered_By_Email' => null, 'Provider' => null, 'Nickname' => null],
        1481821898 => ['Record_Key' => 1481821898, 'Entered_By_Email' => null, 'Provider' => '26676', 'Nickname' => '26676'],
        1486685354 => ['Record_Key' => 1486685354, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-41'],
        1485146495 => ['Record_Key' => 1485146495, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-27'],
        1485146572 => ['Record_Key' => 1485146572, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-32'],
        1367882915 => ['Record_Key' => 1367882915, 'Entered_By_Email' => 'clariece@cox.net', 'Provider' => 'Document Solutions', 'Nickname' => null],
        1475863158 => ['Record_Key' => 1475863158, 'Entered_By_Email' => null, 'Provider' => 'd2rams@gmail.com', 'Nickname' => 'd2rams@gmail.com'],
        1487008514 => ['Record_Key' => 1487008514, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-50'],
        1488664755 => ['Record_Key' => 1488664755, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-56'],
        1483651552 => ['Record_Key' => 1483651552, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-2'],
        1483491428 => ['Record_Key' => 1483491428, 'Entered_By_Email' => null, 'Provider' => 'Alexa', 'Nickname' => 'alexa'],
        1488664741 => ['Record_Key' => 1488664741, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-54'],
        1484016527 => ['Record_Key' => 1484016527, 'Entered_By_Email' => null, 'Provider' => '4802', 'Nickname' => '4802'],
        1483652184 => ['Record_Key' => 1483652184, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-12'],
        1481199088 => ['Record_Key' => 1481199088, 'Entered_By_Email' => null, 'Provider' => '1905', 'Nickname' => '1905'],
        1491072276 => ['Record_Key' => 1491072276, 'Entered_By_Email' => null, 'Provider' => '30951', 'Nickname' => '30951'],
        1482704728 => ['Record_Key' => 1482704728, 'Entered_By_Email' => null, 'Provider' => null, 'Nickname' => null],
        1483652006 => ['Record_Key' => 1483652006, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-10'],
        1480126465 => ['Record_Key' => 1480126465, 'Entered_By_Email' => null, 'Provider' => 'Non', 'Nickname' => 'non'],
        1486685379 => ['Record_Key' => 1486685379, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-44'],
        1490845192 => ['Record_Key' => 1490845192, 'Entered_By_Email' => null, 'Provider' => null, 'Nickname' => null],
        1491013613 => ['Record_Key' => 1491013613, 'Entered_By_Email' => null, 'Provider' => null, 'Nickname' => null],
        1481811211 => ['Record_Key' => 1481811211, 'Entered_By_Email' => null, 'Provider' => '77966', 'Nickname' => '77966'],
        1485146627 => ['Record_Key' => 1485146627, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-36'],
        1485146424 => ['Record_Key' => 1485146424, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-24'],
        1490714176 => ['Record_Key' => 1490714176, 'Entered_By_Email' => null, 'Provider' => null, 'Nickname' => null],
        1473202156 => ['Record_Key' => 1473202156, 'Entered_By_Email' => null, 'Provider' => 'Nez2936', 'Nickname' => 'Nez2936'],
        1474303380 => ['Record_Key' => 1474303380, 'Entered_By_Email' => null, 'Provider' => 'US federal government', 'Nickname' => 'US_federal_government'],
        1485588227 => ['Record_Key' => 1485588227, 'Entered_By_Email' => null, 'Provider' => '180', 'Nickname' => '180-39'],
    ];

    /*
     * TODO: add these back for final migration (temporarily exclude them to save time during trial migration):
     */
    private $excludeEventsByProvider = [
        //'LearnSmart', // learnsmart@knoitall.com // 101 events
        //'GCF Learn Free', // gcflearnfree@knoitall.com // 145 events
        //'Khan Academy', // khanacademy@knoitall.com // 164 events
        //'UCLA Extension', // uclaextension@knoitall.com // 191 events
        //'Wikipedia', // wikipedia@knoitall.com // 237 events
        'Nest Learning', // nfaffiliate@nestfamily.com // 313 events
        'FTeacher Express', // ftexpress@knoitall.com // 356 events
        'Ed2Go', // ed2go@knoitall.com // 357 events
        'Chefs Catalog', // chefscatalog@knoitall.com // 389 events
        'CME Info', // cmeinfo@knoitall.com // 413 events
        'Lynda.com', // lynda@knoitall.com // 561 events
        'CCMS, Inc.', // tschear@ccmsinc.net // 642 events
        'Great Courses', // greatcourses@knoitall.com // 705 events
        'Totally Guitars', // totallyguitars@knoitall.com // 797 events
        'Pimsleur', // pimsleur@knoitall.com // 942 events
        'MIT OpenCourseWare', // mit1@knoitall.com //  1656 events
        'FT Press', // ftpress@knoitall.com //  1744 events
        'Free Tech Services', // freetechservices@knoitall.com // 1938 events
        //'Craftsy', // craftsy@knoitall.com // 2211 events
        'Peachpit', // peachpit@knoitall.com // 2699 events
        'Pluralsight', // pluralsight@knoitall.com // 3597 events
        'livingsocial', // livingsocial@knoitall.com // 3859 events
        'Skillsoft', // elizabeth_teixeira@skillsoft.com // 4163 events
        'Udemy', // udemy@knoitall.com // 9038 events
        'Wyzant', // wyzant@knoitall.com // 20935 events
        'Informit', // informit@knoitall.com // 22146 events
        'Blick Art Supplies', // p.paul@dickblick.com // 46843 events
    ];

    private $eventTitleRemap = [
        'Law as...": Theory and Method in Legal History Conference' => '"Law as...": Theory and Method in Legal History Conference', // first double-quote was missing
    ];

    private function normalizeDescription($desc)
    {
        $x = $desc;
        $x = preg_replace("/&/", ' ', $x);
        $x = preg_replace("/,/", ' ', $x);
        $x = preg_replace("/-/", ' ', $x);
        $x = preg_replace("/\s+/", ' ', $x);
        $x = preg_replace("/^\s+/", '', $x);
        $x = preg_replace("/\s+$/", '', $x);
        $x = strtolower($x);

        return $x;
    }

    /**
     * remap v1 taxonomy to v2 taxonomy:
     *
     * e.g. "Art, Drama & Music:Oboe Bassoon" should be remapped to "Dance, Drama & Music:Oboe & Bassoon"
     */
    private function remapCategories( $level1=null, $level2=null, $level3=null )
    {
        foreach( $this->taxonomyRemap as $remapping ) {
            if(
                $this->normalizeDescription($remapping['v1'][0]) == $this->normalizeDescription($level1) &&
                (
                    ( !isset($remapping['v1'][1]) && !isset($level2) ) ||
                    isset($remapping['v1'][1]) && isset($level2) && $this->normalizeDescription($remapping['v1'][1]) == $this->normalizeDescription($level2)
                )
            ) {
                $level1 = ( isset($remapping['v2'][0]) ? $remapping['v2'][0] : null );
                $level2 = ( isset($remapping['v2'][1]) ? $remapping['v2'][1] : null );
                $level3 = ( isset($remapping['v2'][2]) ? $remapping['v2'][2] : null );
            }
        }

        return array($level1,$level2,$level3);
    }

    protected function configure()
    {
        $this
            ->setName('migrate:entities')
            ->setDescription("Migrate data from Knoitall-v1 to Knoitall-v2")
            ->addArgument(
                'entities',
                InputArgument::IS_ARRAY,
                "Which entities do you want to migrate (separate names with a space)?"
            )
            ->addOption(
                'count',
                null,
                InputOption::VALUE_REQUIRED,
                'How many entries do you want to migrate?',
                null
            )
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $output->writeln( "Migrating entities..." );

        $entities = $input->getArgument( 'entities' );
        if( in_array('all',$entities) ) {
            $entities = [
                'taxonomy',
                'locationtype',
                'TimeUnit',
                'goal',
                'age',
                'PersonTitle',
                'country',
                'state',
                'postalcode',
                'EventFormatSection',
                'EventFormat',
                'person',
                'user',
                'learner',
                'provider',
                'advisor',
                'instructor',
                'location',
                'Event',
            ];
        }
        $output->writeln( "DEBUG: migrating entitites: " . implode(', ',$entities), OutputInterface::VERBOSITY_DEBUG );
        $count = $input->getOption( 'count' );
        $output->writeln( "DEBUG: count = " . (isset($count) ? $count : 'null'), OutputInterface::VERBOSITY_DEBUG );

        try {
            $dsn = sprintf( "mysql:dbname=%s;host=%s", $this->knoitall_v1_db, $this->knoitall_v1_host );
            $dbh = new \PDO( $dsn, $this->knoitall_v1_userid, $this->knoitall_v1_passwd );
            $output->writeln( "INFO: successfully connected to database $this->knoitall_v1_db" );
        } catch( PDOException $e ) {
            $output->writeln( 'Connection failed: ' . $e->getMessage() );
            exit( -1 );
        }

        $em = $this->getContainer()->get('doctrine')->getManager();
        $personRepository = $em->getRepository(Person::class);
        $userRepository = $em->getRepository(User::class);
        $postalcodeRepository = $em->getRepository(Postalcode::class);
        $stateRepository = $em->getRepository(State::class);
        $countryRepository = $em->getRepository(Country::class);
        $goalRepository = $em->getRepository(Goal::class);
        $ageRepository = $em->getRepository(Age::class);
        $tagRepository = $em->getRepository(Tag::class);
        $taxonomyRepository = $em->getRepository(Taxonomy::class);
        $learnerRepository = $em->getRepository(Learner::class);
        $advisorRepository = $em->getRepository(Advisor::class);
        $instructorRepository = $em->getRepository(Instructor::class);
        $providerRepository = $em->getRepository(Provider::class);
        $eventRepository = $em->getRepository(Event::class);
        $eventFormatRepository = $em->getRepository(EventFormat::class);
        $eventFormatSectionRepository = $em->getRepository(EventFormatSection::class);
        $timeUnitRepository = $em->getRepository(TimeUnit::class);
        $locationTypeRepository = $em->getRepository(LocationType::class);

        if( in_array('TimeUnit',$entities) ) {
            $output->writeln("INFO: migrating TimeUnit...");

            $timeUnitDesriptions = [
                'Seconds',
                'Minutes',
                'Hours',
                'Days',
                'Weeks',
                'Months',
                'Years',
            ];

            foreach( $timeUnitDesriptions as $timeUnitDesription ) {
                $timeUnit = new TimeUnit();
                $timeUnit->setDescription($timeUnitDesription);
                $em->persist( $timeUnit );
            }
            $em->flush();
            $output->writeln( "INFO: successfully migrated TimeUnit." );
        }

        if( in_array('taxonomy',$entities) ) {
            $output->writeln( "INFO: migrating taxonomy..." );

            $query = "SELECT * FROM knoitall_taxonomy ORDER BY Record_Key";
            if( $count ) {
                $query .= " LIMIT $count";
            }
            $stmt = $dbh->query( $query  );
            $data = $stmt->fetchAll( \PDO::FETCH_ASSOC );

            $countTaxonomies = 0;
            foreach( $data as $row ) {
                $level1   = ( $row['Level_1'] != '' ? $row['Level_1'] : null );
                $level2   = ( $row['Level_2'] != '' ? $row['Level_2'] : null );
                $level3   = ( $row['Level_3'] != '' ? $row['Level_3'] : null );
                $keywords = $row['Keywords'];
                $output->writeln( "DEBUG: processing level1='$level1', level2='$level2', level3='$level3'", OutputInterface::VERBOSITY_DEBUG );

                list($level1,$level2) = $this->remapCategories($level1,$level2);

                if( preg_match("/ [a-z]/", $level1) ) {
                    $output->writeln("WARNING: level1='$level1 (possible bad capitalization)");
                }
                if( preg_match("/ [a-z]/", $level2) ) {
                    $output->writeln("WARNING: level2='$level2 (possible bad capitalization)");
                }

                if( $taxonomyRepository->findOneBy(['level1' => $level1, 'level2' => $level2, 'level3' => $level3]) ) {
                    $output->writeln("WARNING: category ['$level1','$level2','$level3'] already exists, skipping");
                    continue;
                }

                /** @var Taxonomy $taxonomy */
                $taxonomy = new Taxonomy();
                if( $level1 ) {
                    $taxonomy->setLevel1( $level1 );
                }
                if( $level2 ) {
                    $taxonomy->setLevel2( $level2 );
                }
                if( $level3 ) {
                    $taxonomy->setLevel3( $level3 );
                }

                foreach( $this->taxonomySlugs as $taxonomySlug ) {
                    if( $taxonomySlug[0][0] == $level1 && $taxonomySlug[0][1] == $level2 ) {
                        $taxonomy->setSlug($taxonomySlug[1]);
                    }
                }

                foreach( explode(',',$keywords) as $keyword ) {
                    $keyword = trim($keyword);
                    if( $keyword == '' ) continue;
                    $output->writeln( "DEBUG: processing keyword='$keyword'", OutputInterface::VERBOSITY_DEBUG );
                    if( !($tag = $tagRepository->findOneBy(['keyword' => $keyword])) ) {
                        $output->writeln( "DEBUG: keyword='$keyword' not found: creating", OutputInterface::VERBOSITY_DEBUG );
                        $tag = new Tag();
                        $tag->setKeyword( $keyword );
                        $em->persist( $tag );
                        $em->flush();
                    }
                    /*
                     * before adding the taxonomy-tag association, check if they're already associated
                     * (could happen if the given keyword is erroneously specified more than once)
                     */
                    if( ! $taxonomy->getTags()->contains($tag) ) {
                        $output->writeln( "DEBUG: not associated: adding", OutputInterface::VERBOSITY_DEBUG );
                        $taxonomy->addTag( $tag );
                    }
                }

                $taxonomy->setInShortList(false);

                $em->persist( $taxonomy );
                $em->flush();

                ++$countTaxonomies;

            }
            $output->writeln("INFO: successfully migrated $countTaxonomies taxonomies");

            /*
             * add extra categories not present in v1:
             */
            $countExtraTaxonomies = 0;
            foreach( $this->taxonomyExtraCategories as $extraCategory ) {

                $level1 = ( isset($extraCategory[0]) ? $extraCategory[0] : null );
                $level2 = ( isset($extraCategory[1]) ? $extraCategory[1] : null );
                $level3 = ( isset($extraCategory[2]) ? $extraCategory[2] : null );

                if( $taxonomyRepository->findOneBy(['level1' => $level1, 'level2' => $level2, 'level3' => $level3]) ) {
                    $output->writeln("WARNING: category ['$level1','$level2','$level3'] already exists, skipping");
                    continue;
                }

                $taxonomy = new Taxonomy();
                if( $level1 ) {
                    $taxonomy->setLevel1($level1);
                }
                if( $level2 ) {
                    $taxonomy->setLevel2($level2);
                }
                if( $level3 ) {
                    $taxonomy->setLevel3($level3);
                }
                $taxonomy->setInShortList(false);
                $em->persist( $taxonomy );
                $em->flush();
                ++$countExtraTaxonomies;
            }
            $output->writeln("INFO: $countExtraTaxonomies extra taxonomies added");

            /*
             * add and set parent taxonomies:
             *
             * NOTE: this would not work properly if we had 3rd level categories (we would not thus generate the parents' parents)
             * but for our purposes it's OK
             */
            $output->writeln("INFO: adding and setting parent taxonomies...");
            $taxonomies = $taxonomyRepository->findAll();
            $countNewParentTaxonomies = 0;
            $countSetParentTaxonomy = 0;
            /** @var Taxonomy $taxonomy */
            foreach( $taxonomies as $taxonomy ) {
                $level1 = $taxonomy->getLevel1();
                $level2 = $taxonomy->getLevel2();
                $level3 = $taxonomy->getLevel3();
                if( $level3  ) {
                    $level3 = null;
                } elseif( $level2  ) {
                    $level2 = null;
                } elseif( $level1  ) {
                    $level1 = null;
                }
                $parentTaxonomy = $taxonomyRepository->findOneBy(['level1' => $level1, 'level2' => $level2, 'level3' => $level3]);
                if( ! $parentTaxonomy ) {
                    $parentTaxonomy = new Taxonomy();
                    $parentTaxonomy
                        ->setLevel1($level1)
                        ->setLevel2($level2)
                        ->setLevel3($level3)
                        ->setInShortList(false)
                    ;
                    $em->persist($parentTaxonomy);
                    $em->flush();
                    ++$countNewParentTaxonomies;
                }
                $taxonomy->setParent($parentTaxonomy);
                $em->persist($taxonomy);

                ++$countSetParentTaxonomy;
            }
            $output->writeln("INFO: successfully added $countNewParentTaxonomies parent taxonomies");
            $output->writeln("INFO: successfully set $countSetParentTaxonomy parent taxonomies");

            $em->flush();
            $output->writeln( "INFO: successfully migrated taxonomy." );
        }

        if( in_array('locationtype',$entities) ) {
            $output->writeln( "INFO: migrating locationtype..." );

            $locationsTypeDescriptions = [
                'Business',
                'College',
                'Residence',
                'Hospital',
                'Community Center',
                'Library',
                'Online',
                'Other',
            ];

            foreach( $locationsTypeDescriptions as $locationsTypeDescription ) {
                $locationType = new LocationType();
                $locationType->setDescription( $locationsTypeDescription );
                $em->persist( $locationType );
            }
            $em->flush();
            $output->writeln( "INFO: successfully migrated locationtype." );
        }

        if( in_array('goal',$entities) ) {
            $output->writeln( "INFO: migrating goal..." );

            $descriptions = [
                'Lifelong learning; want to know more',
                'Augmenting or enhancing my skills',
                'Keeping my certification(s) current',
                'Gaining new credentials to make a career change',
                'Finding learning opportunities for my family',
            ];

            foreach( $descriptions as $description ) {
                $goal = new Goal();
                $goal->setDescription( $description );
                $em->persist( $goal );
            }
            $em->flush();
            $output->writeln( "INFO: successfully migrated goal." );
        }

        if( in_array('age',$entities) ) {
            $output->writeln( "INFO: migrating age..." );

            $descriptions = [
                'Infant',
                'Toddler',
                'Preschooler',
                'Child',
                'Pre-teen',
                'Teen',
                'Adult',
                'Senior',
            ];

            foreach( $descriptions as $description ) {
                $age = new Age();
                $age->setDescription( $description );
                $em->persist( $age );
            }
            $em->flush();
            $output->writeln( "INFO: successfully migrated age." );
        }

        if( in_array('PersonTitle',$entities) ) {
            $output->writeln( "INFO: migrating PersonTitle..." );

            $descriptions = [
                'Mr.',
                'Mrs.',
                'Ms.',
                'Dr.',
            ];

            foreach( $descriptions as $description ) {
                $personTitle = new PersonTitle();
                $personTitle->setDescription( $description );
                $em->persist( $personTitle );
            }
            $em->flush();
            $output->writeln( "INFO: successfully migrated PersonTitle." );
        }

        if( in_array('EventFormatSection',$entities) ) {
            $output->writeln( "INFO: migrating EventFormatSection..." );

            $data = [
                ['description' => 'Resources'],
                ['description' => 'Classes'],
                ['description' => 'Tutoring'],
                ['description' => 'Group Lessons'],
                ['description' => 'Certificates'],
                ['description' => 'Degrees'],
                ['description' => 'Learning Products'],
                ['description' => 'Supplies'],
                ['description' => 'Other'],
            ];

            foreach( $data as $row ) {
                $eventFormatSection = new EventFormatSection();
                $eventFormatSection->setDescription( $row['description'] );
                $em->persist( $eventFormatSection );
            }
            $em->flush();
            $output->writeln( "INFO: successfully migrated EventFormatSection." );
        }

        if( in_array('EventFormat',$entities) ) {
            $output->writeln( "INFO: migrating EventFormat..." );

            $data = [
                ['description' => 'Free Resource (Video, Article, Pod Cast or Other)', 'section' => 'Resources'],
                ['description' => 'Resource For Sale (Video, Article, Pod Cast or Other)', 'section' => 'Resources'],
                ['description' => 'Product That Must Be Shipped (CD, DVD, Book or Other)', 'section' => 'Learning Products'],
                ['description' => 'Supplemental Product', 'section' => 'Learning Products'],
                ['description' => 'Media', 'section' => 'Learning Products'],
                ['description' => 'Face-to-Face - Class or Seminar', 'section' => 'Classes'],
                ['description' => 'Face-to-Face - Advising', 'section' => 'Group Lessons'],
                ['description' => 'Face-to-Face - Tutoring or Individual Lessons', 'section' => 'Group Lessons'],
                ['description' => 'Face-to-Face - Ongoing', 'section' => 'Group Lessons'],
                ['description' => 'Face-to-Face - Self-Directed', 'section' => 'Resources'], // TODO: is this not a contradiction in terms?
                // Face-to-Face - Group Lessons // TODO: is this the same as 'Ongoing'?
                ['description' => 'Face-to-Face - Certificate', 'section' => 'Certificates'],
                ['description' => 'Face-to-Face - Undergraduate Degree', 'section' => 'Degrees'],
                ['description' => 'Face-to-Face - Graduate Degree', 'section' => 'Degrees'],
                ['description' => 'Face-to-Face - Other', 'section' => 'Other'],
                ['description' => 'Online - Class or Webinar', 'section' => 'Classes'],
                ['description' => 'Online - Advising', 'section' => 'Tutoring'],
                ['description' => 'Online - Tutoring or Individual Lessons', 'section' => 'Tutoring'],
                ['description' => 'Online - Ongoing', 'section' => 'Tutoring'],
                ['description' => 'Online - Self-Directed', 'section' => 'Resources'], // TODO: I think this is the same as 'Resource For Sale'
                ['description' => 'Online - Certificate', 'section' => 'Certificates'],
                ['description' => 'Online - Undergraduate Degree', 'section' => 'Degrees'],
                ['description' => 'Online - Graduate Degree', 'section' => 'Degrees'],
                ['description' => 'Online - Other', 'section' => 'Other'],
                ['description' => 'Other', 'section' => 'Other'],
                //['description' => 'Certificate', 'section' => 'Certificate'], // TODO: is this necessary since we have face-to-face and on-line versons?
                //['description' => 'Undergraduate Degree', 'section' => 'Certificate'], // TODO: is this necessary since we have face-to-face and on-line versons?
                //['description' => 'Graduate Degree', 'section' => 'Certificate'], // TODO: is this necessary since we have face-to-face and on-line versons?
            ];

            foreach( $data as $row ) {
                /** @var EventFormat $eventFormat */
                $eventFormat = new EventFormat;
                $eventFormat->setDescription( $row['description'] );

                /** @var EventFormatSection $eventFormatSection */
                $eventFormatSection = $eventFormatSectionRepository->findOneBy(['description' => $row['section']]);
                if( $eventFormatSection ) {
                    $eventFormat->setEventFormatSection( $eventFormatSection );
                } else {
                    $output->writeln("WARNING: couldn't find EventFormatSection='" . $row['section'] . "'");
                }

                $em->persist( $eventFormat );
            }
            $em->flush();
            $output->writeln( "INFO: successfully migrated EventFormat." );
        }

        if( in_array('country',$entities) ) {
            $output->writeln( "INFO: migrating country..." );

            $data = [
                [ 'name' => "Afghanistan", 'alpha2Code' => 'AF', 'alpha3Code' => 'AFG', 'numericCode' => '004' ],
                [ 'name' => "Åland Islands", 'alpha2Code' => 'AX', 'alpha3Code' => 'ALA', 'numericCode' => '248' ],
                [ 'name' => "Albania", 'alpha2Code' => 'AL', 'alpha3Code' => 'ALB', 'numericCode' => '008' ],
                [ 'name' => "Algeria", 'alpha2Code' => 'DZ', 'alpha3Code' => 'DZA', 'numericCode' => '012' ],
                [ 'name' => "American Samoa", 'alpha2Code' => 'AS', 'alpha3Code' => 'ASM', 'numericCode' => '016' ],
                [ 'name' => "Andorra", 'alpha2Code' => 'AD', 'alpha3Code' => 'AND', 'numericCode' => '020' ],
                [ 'name' => "Angola", 'alpha2Code' => 'AO', 'alpha3Code' => 'AGO', 'numericCode' => '024' ],
                [ 'name' => "Anguilla", 'alpha2Code' => 'AI', 'alpha3Code' => 'AIA', 'numericCode' => '660' ],
                [ 'name' => "Antarctica", 'alpha2Code' => 'AQ', 'alpha3Code' => 'ATA', 'numericCode' => '010' ],
                [ 'name' => "Antigua and Barbuda", 'alpha2Code' => 'AG', 'alpha3Code' => 'ATG', 'numericCode' => '028' ],
                [ 'name' => "Argentina", 'alpha2Code' => 'AR', 'alpha3Code' => 'ARG', 'numericCode' => '032' ],
                [ 'name' => "Armenia", 'alpha2Code' => 'AM', 'alpha3Code' => 'ARM', 'numericCode' => '051' ],
                [ 'name' => "Aruba", 'alpha2Code' => 'AW', 'alpha3Code' => 'ABW', 'numericCode' => '533' ],
                [ 'name' => "Australia", 'alpha2Code' => 'AU', 'alpha3Code' => 'AUS', 'numericCode' => '036' ],
                [ 'name' => "Austria", 'alpha2Code' => 'AT', 'alpha3Code' => 'AUT', 'numericCode' => '040' ],
                [ 'name' => "Azerbaijan", 'alpha2Code' => 'AZ', 'alpha3Code' => 'AZE', 'numericCode' => '031' ],
                [ 'name' => "Bahamas", 'alpha2Code' => 'BS', 'alpha3Code' => 'BHS', 'numericCode' => '044' ],
                [ 'name' => "Bahrain", 'alpha2Code' => 'BH', 'alpha3Code' => 'BHR', 'numericCode' => '048' ],
                [ 'name' => "Bangladesh", 'alpha2Code' => 'BD', 'alpha3Code' => 'BGD', 'numericCode' => '050' ],
                [ 'name' => "Barbados", 'alpha2Code' => 'BB', 'alpha3Code' => 'BRB', 'numericCode' => '052' ],
                [ 'name' => "Belarus", 'alpha2Code' => 'BY', 'alpha3Code' => 'BLR', 'numericCode' => '112' ],
                [ 'name' => "Belgium", 'alpha2Code' => 'BE', 'alpha3Code' => 'BEL', 'numericCode' => '056' ],
                [ 'name' => "Belize", 'alpha2Code' => 'BZ', 'alpha3Code' => 'BLZ', 'numericCode' => '084' ],
                [ 'name' => "Benin", 'alpha2Code' => 'BJ', 'alpha3Code' => 'BEN', 'numericCode' => '204' ],
                [ 'name' => "Bermuda", 'alpha2Code' => 'BM', 'alpha3Code' => 'BMU', 'numericCode' => '060' ],
                [ 'name' => "Bhutan", 'alpha2Code' => 'BT', 'alpha3Code' => 'BTN', 'numericCode' => '064' ],
                [ 'name' => "Bolivia (Plurinational State of)", 'alpha2Code' => 'BO', 'alpha3Code' => 'BOL', 'numericCode' => '068' ],
                [ 'name' => "Bonaire, Sint Eustatius and Saba", 'alpha2Code' => 'BQ', 'alpha3Code' => 'BES', 'numericCode' => '535' ],
                [ 'name' => "Bosnia and Herzegovina", 'alpha2Code' => 'BA', 'alpha3Code' => 'BIH', 'numericCode' => '070' ],
                [ 'name' => "Botswana", 'alpha2Code' => 'BW', 'alpha3Code' => 'BWA', 'numericCode' => '072' ],
                [ 'name' => "Bouvet Island", 'alpha2Code' => 'BV', 'alpha3Code' => 'BVT', 'numericCode' => '074' ],
                [ 'name' => "Brazil", 'alpha2Code' => 'BR', 'alpha3Code' => 'BRA', 'numericCode' => '076' ],
                [ 'name' => "British Indian Ocean Territory", 'alpha2Code' => 'IO', 'alpha3Code' => 'IOT', 'numericCode' => '086' ],
                [ 'name' => "Brunei Darussalam", 'alpha2Code' => 'BN', 'alpha3Code' => 'BRN', 'numericCode' => '096' ],
                [ 'name' => "Bulgaria", 'alpha2Code' => 'BG', 'alpha3Code' => 'BGR', 'numericCode' => '100' ],
                [ 'name' => "Burkina Faso", 'alpha2Code' => 'BF', 'alpha3Code' => 'BFA', 'numericCode' => '854' ],
                [ 'name' => "Burundi", 'alpha2Code' => 'BI', 'alpha3Code' => 'BDI', 'numericCode' => '108' ],
                [ 'name' => "Cabo Verde", 'alpha2Code' => 'CV', 'alpha3Code' => 'CPV', 'numericCode' => '132' ],
                [ 'name' => "Cambodia", 'alpha2Code' => 'KH', 'alpha3Code' => 'KHM', 'numericCode' => '116' ],
                [ 'name' => "Cameroon", 'alpha2Code' => 'CM', 'alpha3Code' => 'CMR', 'numericCode' => '120' ],
                [ 'name' => "Canada", 'alpha2Code' => 'CA', 'alpha3Code' => 'CAN', 'numericCode' => '124' ],
                [ 'name' => "Cayman Islands", 'alpha2Code' => 'KY', 'alpha3Code' => 'CYM', 'numericCode' => '136' ],
                [ 'name' => "Central African Republic", 'alpha2Code' => 'CF', 'alpha3Code' => 'CAF', 'numericCode' => '140' ],
                [ 'name' => "Chad", 'alpha2Code' => 'TD', 'alpha3Code' => 'TCD', 'numericCode' => '148' ],
                [ 'name' => "Chile", 'alpha2Code' => 'CL', 'alpha3Code' => 'CHL', 'numericCode' => '152' ],
                [ 'name' => "China", 'alpha2Code' => 'CN', 'alpha3Code' => 'CHN', 'numericCode' => '156' ],
                [ 'name' => "Christmas Island", 'alpha2Code' => 'CX', 'alpha3Code' => 'CXR', 'numericCode' => '162' ],
                [ 'name' => "Cocos (Keeling) Islands", 'alpha2Code' => 'CC', 'alpha3Code' => 'CCK', 'numericCode' => '166' ],
                [ 'name' => "Colombia", 'alpha2Code' => 'CO', 'alpha3Code' => 'COL', 'numericCode' => '170' ],
                [ 'name' => "Comoros", 'alpha2Code' => 'KM', 'alpha3Code' => 'COM', 'numericCode' => '174' ],
                [ 'name' => "Congo", 'alpha2Code' => 'CG', 'alpha3Code' => 'COG', 'numericCode' => '178' ],
                [ 'name' => "Congo (Democratic Republic of the)", 'alpha2Code' => 'CD', 'alpha3Code' => 'COD', 'numericCode' => '180' ],
                [ 'name' => "Cook Islands", 'alpha2Code' => 'CK', 'alpha3Code' => 'COK', 'numericCode' => '184' ],
                [ 'name' => "Costa Rica", 'alpha2Code' => 'CR', 'alpha3Code' => 'CRI', 'numericCode' => '188' ],
                [ 'name' => "Côte d'Ivoire", 'alpha2Code' => 'CI', 'alpha3Code' => 'CIV', 'numericCode' => '384' ],
                [ 'name' => "Croatia", 'alpha2Code' => 'HR', 'alpha3Code' => 'HRV', 'numericCode' => '191' ],
                [ 'name' => "Cuba", 'alpha2Code' => 'CU', 'alpha3Code' => 'CUB', 'numericCode' => '192' ],
                [ 'name' => "Curaçao", 'alpha2Code' => 'CW', 'alpha3Code' => 'CUW', 'numericCode' => '531' ],
                [ 'name' => "Cyprus", 'alpha2Code' => 'CY', 'alpha3Code' => 'CYP', 'numericCode' => '196' ],
                [ 'name' => "Czech Republic", 'alpha2Code' => 'CZ', 'alpha3Code' => 'CZE', 'numericCode' => '203' ],
                [ 'name' => "Denmark", 'alpha2Code' => 'DK', 'alpha3Code' => 'DNK', 'numericCode' => '208' ],
                [ 'name' => "Djibouti", 'alpha2Code' => 'DJ', 'alpha3Code' => 'DJI', 'numericCode' => '262' ],
                [ 'name' => "Dominica", 'alpha2Code' => 'DM', 'alpha3Code' => 'DMA', 'numericCode' => '212' ],
                [ 'name' => "Dominican Republic", 'alpha2Code' => 'DO', 'alpha3Code' => 'DOM', 'numericCode' => '214' ],
                [ 'name' => "Ecuador", 'alpha2Code' => 'EC', 'alpha3Code' => 'ECU', 'numericCode' => '218' ],
                [ 'name' => "Egypt", 'alpha2Code' => 'EG', 'alpha3Code' => 'EGY', 'numericCode' => '818' ],
                [ 'name' => "El Salvador", 'alpha2Code' => 'SV', 'alpha3Code' => 'SLV', 'numericCode' => '222' ],
                [ 'name' => "Equatorial Guinea", 'alpha2Code' => 'GQ', 'alpha3Code' => 'GNQ', 'numericCode' => '226' ],
                [ 'name' => "Eritrea", 'alpha2Code' => 'ER', 'alpha3Code' => 'ERI', 'numericCode' => '232' ],
                [ 'name' => "Estonia", 'alpha2Code' => 'EE', 'alpha3Code' => 'EST', 'numericCode' => '233' ],
                [ 'name' => "Ethiopia", 'alpha2Code' => 'ET', 'alpha3Code' => 'ETH', 'numericCode' => '231' ],
                [ 'name' => "Falkland Islands (Malvinas)", 'alpha2Code' => 'FK', 'alpha3Code' => 'FLK', 'numericCode' => '238' ],
                [ 'name' => "Faroe Islands", 'alpha2Code' => 'FO', 'alpha3Code' => 'FRO', 'numericCode' => '234' ],
                [ 'name' => "Fiji", 'alpha2Code' => 'FJ', 'alpha3Code' => 'FJI', 'numericCode' => '242' ],
                [ 'name' => "Finland", 'alpha2Code' => 'FI', 'alpha3Code' => 'FIN', 'numericCode' => '246' ],
                [ 'name' => "France", 'alpha2Code' => 'FR', 'alpha3Code' => 'FRA', 'numericCode' => '250' ],
                [ 'name' => "French Guiana", 'alpha2Code' => 'GF', 'alpha3Code' => 'GUF', 'numericCode' => '254' ],
                [ 'name' => "French Polynesia", 'alpha2Code' => 'PF', 'alpha3Code' => 'PYF', 'numericCode' => '258' ],
                [ 'name' => "French Southern Territories", 'alpha2Code' => 'TF', 'alpha3Code' => 'ATF', 'numericCode' => '260' ],
                [ 'name' => "Gabon", 'alpha2Code' => 'GA', 'alpha3Code' => 'GAB', 'numericCode' => '266' ],
                [ 'name' => "Gambia", 'alpha2Code' => 'GM', 'alpha3Code' => 'GMB', 'numericCode' => '270' ],
                [ 'name' => "Georgia", 'alpha2Code' => 'GE', 'alpha3Code' => 'GEO', 'numericCode' => '268' ],
                [ 'name' => "Germany", 'alpha2Code' => 'DE', 'alpha3Code' => 'DEU', 'numericCode' => '276' ],
                [ 'name' => "Ghana", 'alpha2Code' => 'GH', 'alpha3Code' => 'GHA', 'numericCode' => '288' ],
                [ 'name' => "Gibraltar", 'alpha2Code' => 'GI', 'alpha3Code' => 'GIB', 'numericCode' => '292' ],
                [ 'name' => "Greece", 'alpha2Code' => 'GR', 'alpha3Code' => 'GRC', 'numericCode' => '300' ],
                [ 'name' => "Greenland", 'alpha2Code' => 'GL', 'alpha3Code' => 'GRL', 'numericCode' => '304' ],
                [ 'name' => "Grenada", 'alpha2Code' => 'GD', 'alpha3Code' => 'GRD', 'numericCode' => '308' ],
                [ 'name' => "Guadeloupe", 'alpha2Code' => 'GP', 'alpha3Code' => 'GLP', 'numericCode' => '312' ],
                [ 'name' => "Guam", 'alpha2Code' => 'GU', 'alpha3Code' => 'GUM', 'numericCode' => '316' ],
                [ 'name' => "Guatemala", 'alpha2Code' => 'GT', 'alpha3Code' => 'GTM', 'numericCode' => '320' ],
                [ 'name' => "Guernsey", 'alpha2Code' => 'GG', 'alpha3Code' => 'GGY', 'numericCode' => '831' ],
                [ 'name' => "Guinea", 'alpha2Code' => 'GN', 'alpha3Code' => 'GIN', 'numericCode' => '324' ],
                [ 'name' => "Guinea-Bissau", 'alpha2Code' => 'GW', 'alpha3Code' => 'GNB', 'numericCode' => '624' ],
                [ 'name' => "Guyana", 'alpha2Code' => 'GY', 'alpha3Code' => 'GUY', 'numericCode' => '328' ],
                [ 'name' => "Haiti", 'alpha2Code' => 'HT', 'alpha3Code' => 'HTI', 'numericCode' => '332' ],
                [ 'name' => "Heard Island and McDonald Islands", 'alpha2Code' => 'HM', 'alpha3Code' => 'HMD', 'numericCode' => '334' ],
                [ 'name' => "Holy See", 'alpha2Code' => 'VA', 'alpha3Code' => 'VAT', 'numericCode' => '336' ],
                [ 'name' => "Honduras", 'alpha2Code' => 'HN', 'alpha3Code' => 'HND', 'numericCode' => '340' ],
                [ 'name' => "Hong Kong", 'alpha2Code' => 'HK', 'alpha3Code' => 'HKG', 'numericCode' => '344' ],
                [ 'name' => "Hungary", 'alpha2Code' => 'HU', 'alpha3Code' => 'HUN', 'numericCode' => '348' ],
                [ 'name' => "Iceland", 'alpha2Code' => 'IS', 'alpha3Code' => 'ISL', 'numericCode' => '352' ],
                [ 'name' => "India", 'alpha2Code' => 'IN', 'alpha3Code' => 'IND', 'numericCode' => '356' ],
                [ 'name' => "Indonesia", 'alpha2Code' => 'ID', 'alpha3Code' => 'IDN', 'numericCode' => '360' ],
                [ 'name' => "Iran (Islamic Republic of)", 'alpha2Code' => 'IR', 'alpha3Code' => 'IRN', 'numericCode' => '364' ],
                [ 'name' => "Iraq", 'alpha2Code' => 'IQ', 'alpha3Code' => 'IRQ', 'numericCode' => '368' ],
                [ 'name' => "Ireland", 'alpha2Code' => 'IE', 'alpha3Code' => 'IRL', 'numericCode' => '372' ],
                [ 'name' => "Isle of Man", 'alpha2Code' => 'IM', 'alpha3Code' => 'IMN', 'numericCode' => '833' ],
                [ 'name' => "Israel", 'alpha2Code' => 'IL', 'alpha3Code' => 'ISR', 'numericCode' => '376' ],
                [ 'name' => "Italy", 'alpha2Code' => 'IT', 'alpha3Code' => 'ITA', 'numericCode' => '380' ],
                [ 'name' => "Jamaica", 'alpha2Code' => 'JM', 'alpha3Code' => 'JAM', 'numericCode' => '388' ],
                [ 'name' => "Japan", 'alpha2Code' => 'JP', 'alpha3Code' => 'JPN', 'numericCode' => '392' ],
                [ 'name' => "Jersey", 'alpha2Code' => 'JE', 'alpha3Code' => 'JEY', 'numericCode' => '832' ],
                [ 'name' => "Jordan", 'alpha2Code' => 'JO', 'alpha3Code' => 'JOR', 'numericCode' => '400' ],
                [ 'name' => "Kazakhstan", 'alpha2Code' => 'KZ', 'alpha3Code' => 'KAZ', 'numericCode' => '398' ],
                [ 'name' => "Kenya", 'alpha2Code' => 'KE', 'alpha3Code' => 'KEN', 'numericCode' => '404' ],
                [ 'name' => "Kiribati", 'alpha2Code' => 'KI', 'alpha3Code' => 'KIR', 'numericCode' => '296' ],
                [ 'name' => "Korea (Democratic People's Republic of)", 'alpha2Code' => 'KP', 'alpha3Code' => 'PRK', 'numericCode' => '408' ],
                [ 'name' => "Korea (Republic of)", 'alpha2Code' => 'KR', 'alpha3Code' => 'KOR', 'numericCode' => '410' ],
                [ 'name' => "Kuwait", 'alpha2Code' => 'KW', 'alpha3Code' => 'KWT', 'numericCode' => '414' ],
                [ 'name' => "Kyrgyzstan", 'alpha2Code' => 'KG', 'alpha3Code' => 'KGZ', 'numericCode' => '417' ],
                [ 'name' => "Lao People's Democratic Republic", 'alpha2Code' => 'LA', 'alpha3Code' => 'LAO', 'numericCode' => '418' ],
                [ 'name' => "Latvia", 'alpha2Code' => 'LV', 'alpha3Code' => 'LVA', 'numericCode' => '428' ],
                [ 'name' => "Lebanon", 'alpha2Code' => 'LB', 'alpha3Code' => 'LBN', 'numericCode' => '422' ],
                [ 'name' => "Lesotho", 'alpha2Code' => 'LS', 'alpha3Code' => 'LSO', 'numericCode' => '426' ],
                [ 'name' => "Liberia", 'alpha2Code' => 'LR', 'alpha3Code' => 'LBR', 'numericCode' => '430' ],
                [ 'name' => "Libya", 'alpha2Code' => 'LY', 'alpha3Code' => 'LBY', 'numericCode' => '434' ],
                [ 'name' => "Liechtenstein", 'alpha2Code' => 'LI', 'alpha3Code' => 'LIE', 'numericCode' => '438' ],
                [ 'name' => "Lithuania", 'alpha2Code' => 'LT', 'alpha3Code' => 'LTU', 'numericCode' => '440' ],
                [ 'name' => "Luxembourg", 'alpha2Code' => 'LU', 'alpha3Code' => 'LUX', 'numericCode' => '442' ],
                [ 'name' => "Macao", 'alpha2Code' => 'MO', 'alpha3Code' => 'MAC', 'numericCode' => '446' ],
                [ 'name' => "Macedonia (the former Yugoslav Republic of)", 'alpha2Code' => 'MK', 'alpha3Code' => 'MKD', 'numericCode' => '807' ],
                [ 'name' => "Madagascar", 'alpha2Code' => 'MG', 'alpha3Code' => 'MDG', 'numericCode' => '450' ],
                [ 'name' => "Malawi", 'alpha2Code' => 'MW', 'alpha3Code' => 'MWI', 'numericCode' => '454' ],
                [ 'name' => "Malaysia", 'alpha2Code' => 'MY', 'alpha3Code' => 'MYS', 'numericCode' => '458' ],
                [ 'name' => "Maldives", 'alpha2Code' => 'MV', 'alpha3Code' => 'MDV', 'numericCode' => '462' ],
                [ 'name' => "Mali", 'alpha2Code' => 'ML', 'alpha3Code' => 'MLI', 'numericCode' => '466' ],
                [ 'name' => "Malta", 'alpha2Code' => 'MT', 'alpha3Code' => 'MLT', 'numericCode' => '470' ],
                [ 'name' => "Marshall Islands", 'alpha2Code' => 'MH', 'alpha3Code' => 'MHL', 'numericCode' => '584' ],
                [ 'name' => "Martinique", 'alpha2Code' => 'MQ', 'alpha3Code' => 'MTQ', 'numericCode' => '474' ],
                [ 'name' => "Mauritania", 'alpha2Code' => 'MR', 'alpha3Code' => 'MRT', 'numericCode' => '478' ],
                [ 'name' => "Mauritius", 'alpha2Code' => 'MU', 'alpha3Code' => 'MUS', 'numericCode' => '480' ],
                [ 'name' => "Mayotte", 'alpha2Code' => 'YT', 'alpha3Code' => 'MYT', 'numericCode' => '175' ],
                [ 'name' => "Mexico", 'alpha2Code' => 'MX', 'alpha3Code' => 'MEX', 'numericCode' => '484' ],
                [ 'name' => "Micronesia (Federated States of)", 'alpha2Code' => 'FM', 'alpha3Code' => 'FSM', 'numericCode' => '583' ],
                [ 'name' => "Moldova (Republic of)", 'alpha2Code' => 'MD', 'alpha3Code' => 'MDA', 'numericCode' => '498' ],
                [ 'name' => "Monaco", 'alpha2Code' => 'MC', 'alpha3Code' => 'MCO', 'numericCode' => '492' ],
                [ 'name' => "Mongolia", 'alpha2Code' => 'MN', 'alpha3Code' => 'MNG', 'numericCode' => '496' ],
                [ 'name' => "Montenegro", 'alpha2Code' => 'ME', 'alpha3Code' => 'MNE', 'numericCode' => '499' ],
                [ 'name' => "Montserrat", 'alpha2Code' => 'MS', 'alpha3Code' => 'MSR', 'numericCode' => '500' ],
                [ 'name' => "Morocco", 'alpha2Code' => 'MA', 'alpha3Code' => 'MAR', 'numericCode' => '504' ],
                [ 'name' => "Mozambique", 'alpha2Code' => 'MZ', 'alpha3Code' => 'MOZ', 'numericCode' => '508' ],
                [ 'name' => "Myanmar", 'alpha2Code' => 'MM', 'alpha3Code' => 'MMR', 'numericCode' => '104' ],
                [ 'name' => "Namibia", 'alpha2Code' => 'NA', 'alpha3Code' => 'NAM', 'numericCode' => '516' ],
                [ 'name' => "Nauru", 'alpha2Code' => 'NR', 'alpha3Code' => 'NRU', 'numericCode' => '520' ],
                [ 'name' => "Nepal", 'alpha2Code' => 'NP', 'alpha3Code' => 'NPL', 'numericCode' => '524' ],
                [ 'name' => "Netherlands", 'alpha2Code' => 'NL', 'alpha3Code' => 'NLD', 'numericCode' => '528' ],
                [ 'name' => "New Caledonia", 'alpha2Code' => 'NC', 'alpha3Code' => 'NCL', 'numericCode' => '540' ],
                [ 'name' => "New Zealand", 'alpha2Code' => 'NZ', 'alpha3Code' => 'NZL', 'numericCode' => '554' ],
                [ 'name' => "Nicaragua", 'alpha2Code' => 'NI', 'alpha3Code' => 'NIC', 'numericCode' => '558' ],
                [ 'name' => "Niger", 'alpha2Code' => 'NE', 'alpha3Code' => 'NER', 'numericCode' => '562' ],
                [ 'name' => "Nigeria", 'alpha2Code' => 'NG', 'alpha3Code' => 'NGA', 'numericCode' => '566' ],
                [ 'name' => "Niue", 'alpha2Code' => 'NU', 'alpha3Code' => 'NIU', 'numericCode' => '570' ],
                [ 'name' => "Norfolk Island", 'alpha2Code' => 'NF', 'alpha3Code' => 'NFK', 'numericCode' => '574' ],
                [ 'name' => "Northern Mariana Islands", 'alpha2Code' => 'MP', 'alpha3Code' => 'MNP', 'numericCode' => '580' ],
                [ 'name' => "Norway", 'alpha2Code' => 'NO', 'alpha3Code' => 'NOR', 'numericCode' => '578' ],
                [ 'name' => "Oman", 'alpha2Code' => 'OM', 'alpha3Code' => 'OMN', 'numericCode' => '512' ],
                [ 'name' => "Pakistan", 'alpha2Code' => 'PK', 'alpha3Code' => 'PAK', 'numericCode' => '586' ],
                [ 'name' => "Palau", 'alpha2Code' => 'PW', 'alpha3Code' => 'PLW', 'numericCode' => '585' ],
                [ 'name' => "Palestine, State of", 'alpha2Code' => 'PS', 'alpha3Code' => 'PSE', 'numericCode' => '275' ],
                [ 'name' => "Panama", 'alpha2Code' => 'PA', 'alpha3Code' => 'PAN', 'numericCode' => '591' ],
                [ 'name' => "Papua New Guinea", 'alpha2Code' => 'PG', 'alpha3Code' => 'PNG', 'numericCode' => '598' ],
                [ 'name' => "Paraguay", 'alpha2Code' => 'PY', 'alpha3Code' => 'PRY', 'numericCode' => '600' ],
                [ 'name' => "Peru", 'alpha2Code' => 'PE', 'alpha3Code' => 'PER', 'numericCode' => '604' ],
                [ 'name' => "Philippines", 'alpha2Code' => 'PH', 'alpha3Code' => 'PHL', 'numericCode' => '608' ],
                [ 'name' => "Pitcairn", 'alpha2Code' => 'PN', 'alpha3Code' => 'PCN', 'numericCode' => '612' ],
                [ 'name' => "Poland", 'alpha2Code' => 'PL', 'alpha3Code' => 'POL', 'numericCode' => '616' ],
                [ 'name' => "Portugal", 'alpha2Code' => 'PT', 'alpha3Code' => 'PRT', 'numericCode' => '620' ],
                [ 'name' => "Puerto Rico", 'alpha2Code' => 'PR', 'alpha3Code' => 'PRI', 'numericCode' => '630' ],
                [ 'name' => "Qatar", 'alpha2Code' => 'QA', 'alpha3Code' => 'QAT', 'numericCode' => '634' ],
                [ 'name' => "Réunion", 'alpha2Code' => 'RE', 'alpha3Code' => 'REU', 'numericCode' => '638' ],
                [ 'name' => "Romania", 'alpha2Code' => 'RO', 'alpha3Code' => 'ROU', 'numericCode' => '642' ],
                [ 'name' => "Russian Federation", 'alpha2Code' => 'RU', 'alpha3Code' => 'RUS', 'numericCode' => '643' ],
                [ 'name' => "Rwanda", 'alpha2Code' => 'RW', 'alpha3Code' => 'RWA', 'numericCode' => '646' ],
                [ 'name' => "Saint Barthélemy", 'alpha2Code' => 'BL', 'alpha3Code' => 'BLM', 'numericCode' => '652' ],
                [ 'name' => "Saint Helena, Ascension and Tristan da Cunha", 'alpha2Code' => 'SH', 'alpha3Code' => 'SHN', 'numericCode' => '654' ],
                [ 'name' => "Saint Kitts and Nevis", 'alpha2Code' => 'KN', 'alpha3Code' => 'KNA', 'numericCode' => '659' ],
                [ 'name' => "Saint Lucia", 'alpha2Code' => 'LC', 'alpha3Code' => 'LCA', 'numericCode' => '662' ],
                [ 'name' => "Saint Martin (French part)", 'alpha2Code' => 'MF', 'alpha3Code' => 'MAF', 'numericCode' => '663' ],
                [ 'name' => "Saint Pierre and Miquelon", 'alpha2Code' => 'PM', 'alpha3Code' => 'SPM', 'numericCode' => '666' ],
                [ 'name' => "Saint Vincent and the Grenadines", 'alpha2Code' => 'VC', 'alpha3Code' => 'VCT', 'numericCode' => '670' ],
                [ 'name' => "Samoa", 'alpha2Code' => 'WS', 'alpha3Code' => 'WSM', 'numericCode' => '882' ],
                [ 'name' => "San Marino", 'alpha2Code' => 'SM', 'alpha3Code' => 'SMR', 'numericCode' => '674' ],
                [ 'name' => "Sao Tome and Principe", 'alpha2Code' => 'ST', 'alpha3Code' => 'STP', 'numericCode' => '678' ],
                [ 'name' => "Saudi Arabia", 'alpha2Code' => 'SA', 'alpha3Code' => 'SAU', 'numericCode' => '682' ],
                [ 'name' => "Senegal", 'alpha2Code' => 'SN', 'alpha3Code' => 'SEN', 'numericCode' => '686' ],
                [ 'name' => "Serbia", 'alpha2Code' => 'RS', 'alpha3Code' => 'SRB', 'numericCode' => '688' ],
                [ 'name' => "Seychelles", 'alpha2Code' => 'SC', 'alpha3Code' => 'SYC', 'numericCode' => '690' ],
                [ 'name' => "Sierra Leone", 'alpha2Code' => 'SL', 'alpha3Code' => 'SLE', 'numericCode' => '694' ],
                [ 'name' => "Singapore", 'alpha2Code' => 'SG', 'alpha3Code' => 'SGP', 'numericCode' => '702' ],
                [ 'name' => "Sint Maarten (Dutch part)", 'alpha2Code' => 'SX', 'alpha3Code' => 'SXM', 'numericCode' => '534' ],
                [ 'name' => "Slovakia", 'alpha2Code' => 'SK', 'alpha3Code' => 'SVK', 'numericCode' => '703' ],
                [ 'name' => "Slovenia", 'alpha2Code' => 'SI', 'alpha3Code' => 'SVN', 'numericCode' => '705' ],
                [ 'name' => "Solomon Islands", 'alpha2Code' => 'SB', 'alpha3Code' => 'SLB', 'numericCode' => '090' ],
                [ 'name' => "Somalia", 'alpha2Code' => 'SO', 'alpha3Code' => 'SOM', 'numericCode' => '706' ],
                [ 'name' => "South Africa", 'alpha2Code' => 'ZA', 'alpha3Code' => 'ZAF', 'numericCode' => '710' ],
                [ 'name' => "South Georgia and the South Sandwich Islands", 'alpha2Code' => 'GS', 'alpha3Code' => 'SGS', 'numericCode' => '239' ],
                [ 'name' => "South Sudan", 'alpha2Code' => 'SS', 'alpha3Code' => 'SSD', 'numericCode' => '728' ],
                [ 'name' => "Spain", 'alpha2Code' => 'ES', 'alpha3Code' => 'ESP', 'numericCode' => '724' ],
                [ 'name' => "Sri Lanka", 'alpha2Code' => 'LK', 'alpha3Code' => 'LKA', 'numericCode' => '144' ],
                [ 'name' => "Sudan", 'alpha2Code' => 'SD', 'alpha3Code' => 'SDN', 'numericCode' => '729' ],
                [ 'name' => "Suriname", 'alpha2Code' => 'SR', 'alpha3Code' => 'SUR', 'numericCode' => '740' ],
                [ 'name' => "Svalbard and Jan Mayen", 'alpha2Code' => 'SJ', 'alpha3Code' => 'SJM', 'numericCode' => '744' ],
                [ 'name' => "Swaziland", 'alpha2Code' => 'SZ', 'alpha3Code' => 'SWZ', 'numericCode' => '748' ],
                [ 'name' => "Sweden", 'alpha2Code' => 'SE', 'alpha3Code' => 'SWE', 'numericCode' => '752' ],
                [ 'name' => "Switzerland", 'alpha2Code' => 'CH', 'alpha3Code' => 'CHE', 'numericCode' => '756' ],
                [ 'name' => "Syrian Arab Republic", 'alpha2Code' => 'SY', 'alpha3Code' => 'SYR', 'numericCode' => '760' ],
                [ 'name' => "Taiwan, Province of China[a]", 'alpha2Code' => 'TW', 'alpha3Code' => 'TWN', 'numericCode' => '158' ],
                [ 'name' => "Tajikistan", 'alpha2Code' => 'TJ', 'alpha3Code' => 'TJK', 'numericCode' => '762' ],
                [ 'name' => "Tanzania, United Republic of", 'alpha2Code' => 'TZ', 'alpha3Code' => 'TZA', 'numericCode' => '834' ],
                [ 'name' => "Thailand", 'alpha2Code' => 'TH', 'alpha3Code' => 'THA', 'numericCode' => '764' ],
                [ 'name' => "Timor-Leste", 'alpha2Code' => 'TL', 'alpha3Code' => 'TLS', 'numericCode' => '626' ],
                [ 'name' => "Togo", 'alpha2Code' => 'TG', 'alpha3Code' => 'TGO', 'numericCode' => '768' ],
                [ 'name' => "Tokelau", 'alpha2Code' => 'TK', 'alpha3Code' => 'TKL', 'numericCode' => '772' ],
                [ 'name' => "Tonga", 'alpha2Code' => 'TO', 'alpha3Code' => 'TON', 'numericCode' => '776' ],
                [ 'name' => "Trinidad and Tobago", 'alpha2Code' => 'TT', 'alpha3Code' => 'TTO', 'numericCode' => '780' ],
                [ 'name' => "Tunisia", 'alpha2Code' => 'TN', 'alpha3Code' => 'TUN', 'numericCode' => '788' ],
                [ 'name' => "Turkey", 'alpha2Code' => 'TR', 'alpha3Code' => 'TUR', 'numericCode' => '792' ],
                [ 'name' => "Turkmenistan", 'alpha2Code' => 'TM', 'alpha3Code' => 'TKM', 'numericCode' => '795' ],
                [ 'name' => "Turks and Caicos Islands", 'alpha2Code' => 'TC', 'alpha3Code' => 'TCA', 'numericCode' => '796' ],
                [ 'name' => "Tuvalu", 'alpha2Code' => 'TV', 'alpha3Code' => 'TUV', 'numericCode' => '798' ],
                [ 'name' => "Uganda", 'alpha2Code' => 'UG', 'alpha3Code' => 'UGA', 'numericCode' => '800' ],
                [ 'name' => "Ukraine", 'alpha2Code' => 'UA', 'alpha3Code' => 'UKR', 'numericCode' => '804' ],
                [ 'name' => "United Arab Emirates", 'alpha2Code' => 'AE', 'alpha3Code' => 'ARE', 'numericCode' => '784' ],
                [ 'name' => "United Kingdom of Great Britain and Northern Ireland", 'alpha2Code' => 'GB', 'alpha3Code' => 'GBR', 'numericCode' => '826' ],
                [ 'name' => "United States of America", 'alpha2Code' => 'US', 'alpha3Code' => 'USA', 'numericCode' => '840' ],
                [ 'name' => "United States Minor Outlying Islands", 'alpha2Code' => 'UM', 'alpha3Code' => 'UMI', 'numericCode' => '581' ],
                [ 'name' => "Uruguay", 'alpha2Code' => 'UY', 'alpha3Code' => 'URY', 'numericCode' => '858' ],
                [ 'name' => "Uzbekistan", 'alpha2Code' => 'UZ', 'alpha3Code' => 'UZB', 'numericCode' => '860' ],
                [ 'name' => "Vanuatu", 'alpha2Code' => 'VU', 'alpha3Code' => 'VUT', 'numericCode' => '548' ],
                [ 'name' => "Venezuela (Bolivarian Republic of)", 'alpha2Code' => 'VE', 'alpha3Code' => 'VEN', 'numericCode' => '862' ],
                [ 'name' => "Viet Nam", 'alpha2Code' => 'VN', 'alpha3Code' => 'VNM', 'numericCode' => '704' ],
                [ 'name' => "Virgin Islands (British)", 'alpha2Code' => 'VG', 'alpha3Code' => 'VGB', 'numericCode' => '092' ],
                [ 'name' => "Virgin Islands (U.S.)", 'alpha2Code' => 'VI', 'alpha3Code' => 'VIR', 'numericCode' => '850' ],
                [ 'name' => "Wallis and Futuna", 'alpha2Code' => 'WF', 'alpha3Code' => 'WLF', 'numericCode' => '876' ],
                [ 'name' => "Western Sahara", 'alpha2Code' => 'EH', 'alpha3Code' => 'ESH', 'numericCode' => '732' ],
                [ 'name' => "Yemen", 'alpha2Code' => 'YE', 'alpha3Code' => 'YEM', 'numericCode' => '887' ],
                [ 'name' => "Zambia", 'alpha2Code' => 'ZM', 'alpha3Code' => 'ZMB', 'numericCode' => '894' ],
                [ 'name' => "Zimbabwe", 'alpha2Code' => 'ZW', 'alpha3Code' => 'ZWE', 'numericCode' => '716' ],
            ];

            foreach( $data as $row ) {
                $country = new Country();
                $country->setName( $row['name'] );
                $country->setAlpha2Code( $row['alpha2Code'] );
                $country->setAlpha3Code( $row['alpha3Code'] );
                $country->setNumericCode( $row['numericCode'] );
                $em->persist( $country );
            }
            $em->flush();
            $output->writeln( "INFO: successfully migrated country." );
        }

        if( in_array('state',$entities) ) {
            $output->writeln( "INFO: migrating states..." );

            $data = [
                [ 'name' => 'Alabama', 'alpha2Code' => 'AL', 'country' => 'USA' ],
                [ 'name' => 'Alaska', 'alpha2Code' => 'AK', 'country' => 'USA' ],
                [ 'name' => 'Arizona', 'alpha2Code' => 'AZ', 'country' => 'USA' ],
                [ 'name' => 'Arkansas', 'alpha2Code' => 'AR', 'country' => 'USA' ],
                [ 'name' => 'California', 'alpha2Code' => 'CA', 'country' => 'USA' ],
                [ 'name' => 'Colorado', 'alpha2Code' => 'CO', 'country' => 'USA' ],
                [ 'name' => 'Connecticut', 'alpha2Code' => 'CT', 'country' => 'USA' ],
                [ 'name' => 'Delaware', 'alpha2Code' => 'DE', 'country' => 'USA' ],
                [ 'name' => 'Florida', 'alpha2Code' => 'FL', 'country' => 'USA' ],
                [ 'name' => 'Georgia', 'alpha2Code' => 'GA', 'country' => 'USA' ],
                [ 'name' => 'Hawaii', 'alpha2Code' => 'HI', 'country' => 'USA' ],
                [ 'name' => 'Idaho', 'alpha2Code' => 'ID', 'country' => 'USA' ],
                [ 'name' => 'Illinois', 'alpha2Code' => 'IL', 'country' => 'USA' ],
                [ 'name' => 'Indiana', 'alpha2Code' => 'IN', 'country' => 'USA' ],
                [ 'name' => 'Iowa', 'alpha2Code' => 'IA', 'country' => 'USA' ],
                [ 'name' => 'Kansas', 'alpha2Code' => 'KS', 'country' => 'USA' ],
                [ 'name' => 'Kentucky', 'alpha2Code' => 'KY', 'country' => 'USA' ],
                [ 'name' => 'Louisiana', 'alpha2Code' => 'LA', 'country' => 'USA' ],
                [ 'name' => 'Maine', 'alpha2Code' => 'ME', 'country' => 'USA' ],
                [ 'name' => 'Maryland', 'alpha2Code' => 'MD', 'country' => 'USA' ],
                [ 'name' => 'Massachusetts', 'alpha2Code' => 'MA', 'country' => 'USA' ],
                [ 'name' => 'Michigan', 'alpha2Code' => 'MI', 'country' => 'USA' ],
                [ 'name' => 'Minnesota', 'alpha2Code' => 'MN', 'country' => 'USA' ],
                [ 'name' => 'Mississippi', 'alpha2Code' => 'MS', 'country' => 'USA' ],
                [ 'name' => 'Missouri', 'alpha2Code' => 'MO', 'country' => 'USA' ],
                [ 'name' => 'Montana', 'alpha2Code' => 'MT', 'country' => 'USA' ],
                [ 'name' => 'Nebraska', 'alpha2Code' => 'NE', 'country' => 'USA' ],
                [ 'name' => 'Nevada', 'alpha2Code' => 'NV', 'country' => 'USA' ],
                [ 'name' => 'New Hampshire', 'alpha2Code' => 'NH', 'country' => 'USA' ],
                [ 'name' => 'New Jersey', 'alpha2Code' => 'NJ', 'country' => 'USA' ],
                [ 'name' => 'New Mexico', 'alpha2Code' => 'NM', 'country' => 'USA' ],
                [ 'name' => 'New York', 'alpha2Code' => 'NY', 'country' => 'USA' ],
                [ 'name' => 'North Carolina', 'alpha2Code' => 'NC', 'country' => 'USA' ],
                [ 'name' => 'North Dakota', 'alpha2Code' => 'ND', 'country' => 'USA' ],
                [ 'name' => 'Ohio', 'alpha2Code' => 'OH', 'country' => 'USA' ],
                [ 'name' => 'Oklahoma', 'alpha2Code' => 'OK', 'country' => 'USA' ],
                [ 'name' => 'Oregon', 'alpha2Code' => 'OR', 'country' => 'USA' ],
                [ 'name' => 'Pennsylvania', 'alpha2Code' => 'PA', 'country' => 'USA' ],
                [ 'name' => 'Rhode Island', 'alpha2Code' => 'RI', 'country' => 'USA' ],
                [ 'name' => 'South Carolina', 'alpha2Code' => 'SC', 'country' => 'USA' ],
                [ 'name' => 'South Dakota', 'alpha2Code' => 'SD', 'country' => 'USA' ],
                [ 'name' => 'Tennessee', 'alpha2Code' => 'TN', 'country' => 'USA' ],
                [ 'name' => 'Texas', 'alpha2Code' => 'TX', 'country' => 'USA' ],
                [ 'name' => 'Utah', 'alpha2Code' => 'UT', 'country' => 'USA' ],
                [ 'name' => 'Vermont', 'alpha2Code' => 'VT', 'country' => 'USA' ],
                [ 'name' => 'Virginia', 'alpha2Code' => 'VA', 'country' => 'USA' ],
                [ 'name' => 'Washington', 'alpha2Code' => 'WA', 'country' => 'USA' ],
                [ 'name' => 'West Virginia', 'alpha2Code' => 'WV', 'country' => 'USA' ],
                [ 'name' => 'Wisconsin', 'alpha2Code' => 'WI', 'country' => 'USA' ],
                [ 'name' => 'Wyoming', 'alpha2Code' => 'WY', 'country' => 'USA' ],
                [ 'name' => 'District of Columbia', 'alpha2Code' => 'DC', 'country' => 'USA' ],
                [ 'name' => 'Puerto Rico', 'alpha2Code' => 'PR', 'country' => 'USA' ],
                [ 'name' => 'Guam', 'alpha2Code' => 'GU', 'country' => 'USA' ],
                [ 'name' => 'Northern Mariana Islands', 'alpha2Code' => 'MP', 'country' => 'USA' ],
                [ 'name' => 'U.S. Virgin Islands', 'alpha2Code' => 'VI', 'country' => 'USA' ],
                [ 'name' => 'American Samoa', 'alpha2Code' => 'AS', 'country' => 'USA' ],
                [ 'name' => 'Alberta', 'alpha2Code' => 'AB', 'country' => 'CAN' ],
                [ 'name' => 'British Columbia', 'alpha2Code' => 'BC', 'country' => 'CAN' ],
                [ 'name' => 'Manitoba', 'alpha2Code' => 'MB', 'country' => 'CAN' ],
                [ 'name' => 'New Brunswick', 'alpha2Code' => 'NB', 'country' => 'CAN' ],
                [ 'name' => 'Newfoundland and Labrador', 'alpha2Code' => 'NL', 'country' => 'CAN' ],
                [ 'name' => 'Northwest Territories', 'alpha2Code' => 'NT', 'country' => 'CAN' ],
                [ 'name' => 'Nova Scotia', 'alpha2Code' => 'NS', 'country' => 'CAN' ],
                [ 'name' => 'Nunavut', 'alpha2Code' => 'NU', 'country' => 'CAN' ],
                [ 'name' => 'Ontario', 'alpha2Code' => 'ON', 'country' => 'CAN' ],
                [ 'name' => 'Prince Edward Island', 'alpha2Code' => 'PE', 'country' => 'CAN' ],
                [ 'name' => 'Quebec', 'alpha2Code' => 'QC', 'country' => 'CAN' ],
                [ 'name' => 'Saskatchewan', 'alpha2Code' => 'SK', 'country' => 'CAN' ],
                [ 'name' => 'Yukon', 'alpha2Code' => 'YT', 'country' => 'CAN' ],
                [ 'name' => 'Jihočeský kraj (South Bohemia)', 'alpha2Code' => 'JC', 'country' => 'CZE' ],
                [ 'name' => 'Jihomoravský kraj (South Moravia)', 'alpha2Code' => 'JM', 'country' => 'CZE' ],
                [ 'name' => 'Karlovarský kraj (Karlovy Vary)', 'alpha2Code' => 'KA', 'country' => 'CZE' ],
                [ 'name' => 'Královéhradecký kraj (Hradec Králové)', 'alpha2Code' => 'KR', 'country' => 'CZE' ],
                [ 'name' => 'Liberecký kraj (Liberec)', 'alpha2Code' => 'LI', 'country' => 'CZE' ],
                [ 'name' => 'Moravskoslezský kraj (Moravia-Silesia)', 'alpha2Code' => 'MO', 'country' => 'CZE' ],
                [ 'name' => 'Olomoucký kraj (Olomouc)', 'alpha2Code' => 'OL', 'country' => 'CZE' ],
                [ 'name' => 'Pardubický kraj (Pardubice)', 'alpha2Code' => 'PA', 'country' => 'CZE' ],
                [ 'name' => 'Plzeňský kraj (Plzeň)', 'alpha2Code' => 'PL', 'country' => 'CZE' ],
                [ 'name' => 'Praha, hlavní město (Prague)', 'alpha2Code' => 'PR', 'country' => 'CZE' ],
                [ 'name' => 'Středočeský kraj (Central Bohemia)', 'alpha2Code' => 'ST', 'country' => 'CZE' ],
                [ 'name' => 'Ústecký kraj (Ústí nad Labem)', 'alpha2Code' => 'US', 'country' => 'CZE' ],
                [ 'name' => 'Vysočina (Vysočina)', 'alpha2Code' => 'VY', 'country' => 'CZE' ],
                [ 'name' => 'Zlínský kraj (Zlín)', 'alpha2Code' => 'ZL', 'country' => 'CZE' ],
                [ 'name' => 'Not Applicable', 'alpha2Code' => 'NA' ],
            ];

            foreach( $data as $row ) {
                $name = $row['name'];
                $alpha2Code = $row['alpha2Code'];

                $state = new State();
                $state->setName( $name );
                $state->setAlpha2Code( $alpha2Code );

                if( isset($row['country']) ) {
                    if( $country = $countryRepository->findOneBy(['alpha3Code' => $row['country']]) ) {
                        $state->setCountry( $country );
                    }
                }

                $em->persist( $state );
            }
            $em->flush();
            $output->writeln( "INFO: successfully migrated states." );
        }

        if( in_array('postalcode',$entities) ) {
            $output->writeln( "INFO: migrating postalcode..." );

            $query = "SELECT * FROM knoitall_postalcodes ORDER BY Record_Key";
            if( $count ) {
                $query .= " LIMIT $count";
            }
            $stmt = $dbh->query( $query  );
            $data = $stmt->fetchAll( \PDO::FETCH_ASSOC );

            foreach( $data as $row ) {
                $postalcode = new Postalcode();
                if( $row['Postal_Code'] ) {
                    $postalcode->setZip( $row['Postal_Code'] );
                }
                if( $row['City'] ) {
                    $postalcode->setCity( $row['City'] );
                }
                if( $row['State'] ) {
                    if( $stateObject = $stateRepository->findOneBy(['alpha2Code' => $row['State']]) ) {
                        $postalcode->setState( $stateObject );
                    }
                }
                if( $row['Latitude'] ) {
                    $postalcode->setLatitude( $row['Latitude'] );
                }
                if( $row['Longitude'] ) {
                    $postalcode->setLongitude( $row['Longitude'] );
                }
                $em->persist( $postalcode );
            }
            $em->flush();
            $output->writeln( "INFO: successfully migrated postalcode." );
        }

        if( in_array('person',$entities) ) {
            $output->writeln( "INFO: migrating Person..." );

            $query = "SELECT * FROM knoitall_users ORDER BY Record_Key";
            if( $count ) {
                $query .= " LIMIT $count";
            }
            $stmt = $dbh->query( $query  );
            $data = $stmt->fetchAll( \PDO::FETCH_ASSOC );

            foreach( $data as $row ) {
                $output->writeln( "----------------------------------------------------------------------" );
                $output->writeln( sprintf("DEBUG: First_Name='%s', Last_Name='%s', Your_Email='%s', Password='%s'",
                    $row['First_Name'],
                    $row['Last_Name'],
                    $row['Your_Email'],
                    $row['Password']), OutputInterface::VERBOSITY_DEBUG );

                /*
                 * Check if we have everything we need to proceed:
                 */
                if( ! $row['First_Name'] and ! $row['Last_Name'] and ! $row['Your_Email'] ) {
                    $output->writeln( "WARNING: data missing, skipping." );
                    continue;
                }

                /*
                 * Check for corrupt/missing/unusual data:
                 */
                if( $row['Retype_Email'] != $row['Your_Email'] ) {
                    $msg = sprintf( "DISCREPANCY: Your_Email='%s', Retype_Email='%s'", $row['Your_Email'], $row['Retype_Email'] );
                    $output->writeln( $msg );
                }
                if( $row['Password2'] != $row['Password'] ) {
                    $msg = sprintf( "DISCREPANCY: Password='%s', Password2='%s'", $row['Password'], $row['Password2'] );
                    $output->writeln( $msg );
                }

                /*
                 * Check if this email already exists in the Person class:
                 */
                if( $person = $personRepository->findOneBy(['email' => $row['Your_Email']]) ) {
                    $output->writeln( sprintf("WARNING: email='%s' already exists, skipping",$row['Your_Email']) );
                    continue;
                }
                /*
                 * Check if this firstname/lastname combination already exists in the Person class:
                 */
                if( $person = $personRepository->findOneBy(['firstName' => $row['First_Name'], 'lastName' => $row['Last_Name']]) ) {
                    $output->writeln( sprintf("WARNING: firstName='%s', lastName='%s' already exist, skipping",$row['First_Name'],$row['Last_Name']) );
                    continue;
                }

                $output->writeln( sprintf("DEBUG: Address='%s', Address2='%s'", $row['Address'], $row['Address2']) );

                $postalcode = null;
                $state = null;
                $country = null;
                if( $row['Postal_Code'] ) {
                    $postalcode = $postalcodeRepository->findOneBy(['zip' => $row['Postal_Code']]);
                }
                if( $row['State'] ) {
                    $state = $stateRepository->findOneBy(['alpha2Code' => $row['State']]);
                    if( $state ) {
                        $country = $state->getCountry();
                    }
                }

                $output->writeln( "INFO: creating new Person entity" );
                $person = new Person();
                $person->setFirstName( $row['First_Name'] );
                $person->setLastName( $row['Last_Name'] );
                $person->setStreet( $row['Address'] . (($row['Address2'] != '') ? (', ' . $row['Address2']) : '') );
                $person->setCity( $row['City'] );
                $person->setState( $state );
                $person->setPostalcode( $postalcode );
                $person->setCountry( $country );
                $person->setPhone( $row['Phone'] );
                $person->setEmail( $row['Your_Email']);
                $em->persist( $person );

                /*
                 * flush early so that we can pick up duplicates:
                 */
                $em->flush();
            }
            $output->writeln( "----------------------------------------------------------------------");
            $em->flush();
            $output->writeln( "INFO: successfully migrated Person." );
        }

        if( in_array('user',$entities) ){
            $output->writeln( "INFO: migrating User..." );

            $query = "SELECT * FROM knoitall_users ORDER BY Record_Key";
            if( $count ) {
                $query .= " LIMIT $count";
            }
            $stmt = $dbh->query( $query  );
            $data = $stmt->fetchAll( \PDO::FETCH_ASSOC );

            foreach( $data as $row ) {
                $output->writeln( "----------------------------------------------------------------------" );
                $output->writeln( sprintf("DEBUG: First_Name='%s', Last_Name='%s', Your_Email='%s', Password='%s'",
                    $row['First_Name'],
                    $row['Last_Name'],
                    $row['Your_Email'],
                    $row['Password']), OutputInterface::VERBOSITY_DEBUG );

                /*
                 * Check if we have everything we need to proceed:
                 */
                if( ! $row['First_Name'] and ! $row['Last_Name'] and ! $row['Your_Email'] ) {
                    $output->writeln( "WARNING: data missing, skipping." );
                    continue;
                }

                if( $user = $userRepository->findOneBy(['emailCanonical' => strtolower($row['Your_Email']) ]) ) {
                    $output->writeln( "WARNING: using existing User entity" );
                } else {
                    $user = new User();
                    $user->setEmail( $row['Your_Email'] );
                    $user->setUsername( $row['Your_Email'] ); // username field is required by FOSUserBundle
                }
                if( $row['Password'] == '' ) {
                    $user->setPlainPassword('##TODO##');
                    $user->setEnabled( false );
                    $user->setLocked( true );
                } else {
                    $user->setPlainPassword( $row['Password'] );
                    $user->setEnabled( true );
                    $user->setLocked( false );
                }

                if( $person = $personRepository->findOneBy(['email' => $row['Your_Email'], 'firstName' => $row['First_Name'], 'lastName' => $row['Last_Name']]) ) {
                    $output->writeln( "INFO: found" );
                    $user->setPerson($person);
                } elseif( $person = $personRepository->findOneBy(['firstName' => $row['First_Name'], 'lastName' => $row['Last_Name']]) ) {
                    $output->writeln( "WARNING: probably found" );
                    $user->setPerson($person);
                } else {
                    $output->writeln( "ERROR: could not find relevant Person" );
                }

                if( in_array($row['Your_Email'],['d@vidm.cc','jeff@knoitall.com']) ) {
                    $user->addRole('ROLE_ADMIN');
                }
                $em->persist( $user );
                /*
                 * flush early to pick up duplicates:
                 */
                $em->flush();
            }
            $output->writeln( "----------------------------------------------------------------------" );
            $em->flush();
            $output->writeln( "INFO: successfully migrated User." );
        }

        if( in_array('learner',$entities) ) {
            $output->writeln( "INFO: migrating Learner..." );

            if(
                $row['User_Type'] == 'Consumer' or
                $row['Consumer_Profile'] or
                $row['Special_Needs'] or
                $row['Learning_Goals'] or
                $row['Learning_Goals_Other'] or
                $row['Age']
            ) {
                $output->writeln( "INFO: creating Learner entity..." );
                $learner = new Learner();
                $learner->setPerson( $person );
                $learner->setProfile( $row['Consumer_Profile'] );
                $learner->setSpecialNeeds( $row['Special_Needs'] );
                if( $row['Learning_Goals'] ) {
                    foreach( explode('|',$row['Learning_Goals']) as $goalText ) {
                        if( $goal = $goalRepository->findOneBy(['description' => $goalText]) ) {
                            $learner->addGoal( $goal );
                        } else {
                            if( $goalText != 'Other' ) {
                                $row['Learning_Goals_Other'] = $goalText . ($row['Learning_Goals_Other'] ?: (', ' . $row['Learning_Goals_Other']) );
                            }
                        }
                    }
                }
                $learner->setGoalsOther( $row['Learning_Goals_Other'] );

                if( $row['Age'] ) {
                    if( preg_match("/\|/",$row['Age']) ) {
                        $ageTexts = explode( '|', $row['Age'] );
                    } else {
                        $ageTexts = explode( ',', $row['Age'] );
                    }
                    foreach( $ageTexts as $ageText ) {
                        if( $age = $ageRepository->findOneBy(['description' => $ageText]) ) {
                            $learner->addAge( $age );
                        } else {
                            $output->writeln( "WARNING: count not find ageText='$ageText', skipping" );
                        }
                    }
                }

                $learner->setNickname( $row['Nickname'] );
                $em->persist( $learner );
            }
            $em->flush();
            $output->writeln( "INFO: successfully migrated Learner." );
        }

        if( in_array('provider',$entities) ) {
            $output->writeln( "INFO: migrating Provider..." );

            $query = <<<END
    SELECT
        Record_Key,
        Entered_Date,
        Entered_Time,
        CASE WHEN trim(Entered_By_Email) = '' THEN NULL ELSE trim(Entered_By_Email) END AS Entered_By_Email,
        CASE WHEN trim(Entered_By_First_Name) = '' THEN NULL ELSE trim(Entered_By_First_Name) END AS Entered_By_First_Name,
        CASE WHEN trim(Entered_By_Last_Name) = '' THEN NULL ELSE trim(Entered_By_Last_Name) END AS Entered_By_Last_Name,
        CASE WHEN trim(Entered_By_Organization) = '' THEN NULL ELSE trim(Entered_By_Organization) END AS Entered_By_Organization,
        CASE WHEN trim(Provider) = '' THEN NULL ELSE trim(Provider) END AS Provider,
        CASE WHEN trim(Description_Of_Services) = '' THEN NULL ELSE trim(Description_Of_Services) END AS Description_Of_Services,
        CASE WHEN trim(Nickname) = '' THEN NULL ELSE trim(Nickname) END AS Nickname,
		Art_Drama_Music,
		Business,
		Camps_Travel,
		Computers_Software,
		Cooking_Beverage,
		Education,
		Engineering,
		English_Literature_Writing,
		Health_Health_Care,
		History,
		Hobbies_Games,
		Home_Garden,
		Languages,
		Legal_Studies,
		Parenting,
		Philosophy,
		Religion,
		Science_Math,
		Sport_Leisure,
		Testing_Test_Prep,
		trim(Provider_List) AS Provider_List
    FROM knoitall_users
    WHERE User_Type='Provider'
    ORDER BY Record_Key
END;
            if( $count ) {
                $query .= " LIMIT $count";
            }
            $stmt = $dbh->query( $query  );
            $data = $stmt->fetchAll( \PDO::FETCH_ASSOC );

            $countProviders = 0;
            $countExcludedProviders = 0;
            $countNicknames = [];
            $providerSuppliers = [];
            foreach( $data as $row ) {
                $output->writeln("--------------------------------------------------------------");
                $output->writeln("DEBUG: got row = " . print_r($row,true), OutputInterface::VERBOSITY_DEBUG);

                $Record_Key = $row['Record_Key'];
                $Entered_Date = $row['Entered_Date'];
                $Entered_Time = $row['Entered_Time'];
                $Entered_By_Email = $row['Entered_By_Email'];
                $Entered_By_First_Name = $row['Entered_By_First_Name'];
                $Entered_By_Last_Name = $row['Entered_By_Last_Name'];
                $Entered_By_Organization = $row['Entered_By_Organization'];
                $Provider = $row['Provider'];
                $Description_Of_Services = $row['Description_Of_Services'];
                $Nickname = $row['Nickname'];
                $Provider_List = $row['Provider_List'];

                /*
                 * check if this is in the excluded providers list:
                 */
                if( isset($this->excludedProviders[$Record_Key]) ) {
                    $output->writeln("INFO: excluding Record_Key=$Record_Key, Entered_By_Email='$Entered_By_Email', Provider='$Provider', Nickname='$Nickname'");
                    ++$countExcludedProviders;
                    continue;
                }

                if( $Nickname ) {
                    $countNicknames[strtolower($Nickname)] = ( isset($countNicknames[strtolower($Nickname)]) ? $countNicknames[strtolower($Nickname)] + 1 : 1 );
                    if( $countNicknames[strtolower($Nickname)] > 1 ) {
                        $Nickname .= '-' . $countNicknames[strtolower($Nickname)];
                    }
                    $output->writeln("DEBUG: got Nickname='$Nickname'", OutputInterface::VERBOSITY_DEBUG);
                }

                $level1Categories = [
                    'Art, Drama & Music',
                    'Business',
                    'Camps & Travel',
                    'Computers & Software',
                    'Cooking & Beverage',
                    'Education',
                    'Engineering',
                    'English, Literature & Writing',
                    'Health & Health Care',
                    'History',
                    'Hobbies & Games',
                    'Home & Garden',
                    'Languages',
                    'Legal Studies',
                    'Parenting',
                    'Philosophy',
                    'Religion',
                    'Science & Math',
                    'Sports & Leisure',
                    'Testing & Test Prep',
                ];

                $output->writeln("INFO: got Recory_Key=$Record_Key, Entered_Date='$Entered_Date', Entered_Time='$Entered_Time");
                $output->writeln("INFO: got Entered_By_Email='$Entered_By_Email', Entered_By_First_Name='$Entered_By_First_Name', Entered_By_Last_Name='$Entered_By_Last_Name', Entered_By_Organization='$Entered_By_Organization'");
                $output->writeln("INFO: got Provider='$Provider', Nickname='$Nickname'");

                $provider = new Provider();

                $output->writeln("DEBUG: setting original data...", OutputInterface::VERBOSITY_DEBUG);
                $provider
                    ->setOriginalRecordKey($Record_Key)
                    ->setOriginalEnteredDateTime(new \DateTime("$Entered_Date $Entered_Time"))
                    ->setOriginalEnteredByEmail($Entered_By_Email)
                    ->setOriginalEnteredByFirstName($Entered_By_First_Name)
                    ->setOriginalEnteredByLastName($Entered_By_Last_Name)
                    ->setOriginalEnteredByOrganization($Entered_By_Organization)
                ;

                /*
                 * set person:
                 */
                $output->writeln("DEBUG: setting person...", OutputInterface::VERBOSITY_DEBUG);
                $person = $personRepository->findOneBy([
                    'email' => $Entered_By_Email,
                    'firstName' => $Entered_By_First_Name,
                    'lastName' => $Entered_By_Last_Name,
                ]);
                if (!$person) {
                    $output->writeln("WARNING: could not find person by Email, First Name, Last Name; will try only using email");

                    $person = $personRepository->findOneBy([
                        'email' => $Entered_By_Email,
                    ]);
                    if (!$person) {
                        $output->writeln("WARNING: could not find person by only Email; will create orphaned provider (not connected to person)");
                    }
                }
                if ($person) {
                    $provider->addPerson($person);
                }

                /*
                 * set instructor:
                 */
                // TODO: complete this

                /*
                 * set advisor:
                 */
                // TODO: complete this

                /*
                 * set additional fields:
                 */
                $provider->setTitle($Provider);
                $provider->setProfile($Description_Of_Services);
                $provider->setNickname($Nickname);
                // TODO: complete this:
//                $provider->setAdditionalInformation(...);

                /*
                 * set taxonomies:
                 */
                $output->writeln("INFO: finding taxonomies...", OutputInterface::VERBOSITY_VERBOSE);
                if( isset($this->eventTaxonomy[$Provider]) ) {
                    foreach( $this->eventTaxonomy[$Provider] as $t ) {
                        $taxonomy = $taxonomyRepository->findOneBy(['level1' => $t[0], 'level2' => $t[1]]);
                        if( $taxonomy) {
                            $provider->addTaxonomy($taxonomy);
                        } else {
                            $output->writeln("WARNING: taxonomy $t[0],$t[1] not found");
                        }
                    }
                } else {
                    foreach( $level1Categories as $level1Category ) {
                        $x = preg_replace("/&/", '', $level1Category);
                        $x = preg_replace("/,/", '', $x);
                        $x = preg_replace("/\s+/", '_', $x);
                        $x = preg_replace("/Sports_Leisure/", 'Sport_Leisure', $x);
                        $level2 = $row[$x];
                        $level2Categories = explode('|', $level2);
                        foreach( $level2Categories as $level2Category ) {
                            $level2Category = trim($level2Category);
                            if( $level2Category == '' ) continue;

                            if( $level2Category == 'Critical Thinking Problem Solving' ) {
                                $output->writeln("INFO: splitting '$level2Category' into 'Critical & Analytical Thinking' and 'Problem Solving'");
                                $taxonomy = $taxonomyRepository->findOneBy(['level1' => 'Business', 'level2' => 'Critical & Analytical Thinking']);
                                $provider->addTaxonomy($taxonomy);
                                $taxonomy = $taxonomyRepository->findOneBy(['level1' => 'Business', 'level2' => 'Problem Solving']);
                                $provider->addTaxonomy($taxonomy);
                                continue;
                            }

                            list($level1remapped,$level2remapped) = $this->remapCategories($level1Category,$level2Category);

                            $output->writeln("INFO: searching for $level1remapped:$level2remapped", OutputInterface::VERBOSITY_VERBOSE);
                            $taxonomy = $taxonomyRepository->findFuzzy($level1remapped, $level2remapped);
                            if( $taxonomy ) {
                                if( $provider->getTaxonomies()->contains($taxonomy) ) {
                                    $output->writeln("INFO: taxonomy already present, skipping", OutputInterface::VERBOSITY_VERBOSE);
                                } else {
                                    $provider->addTaxonomy($taxonomy);
                                }
                            } else {
                                $output->writeln("WARNING: category $level1remapped:$level2remapped not found");
                            }

                        }
                    }
                }

                /*
                 * set images:
                 */
                $output->writeln("DEBUG: finding images...", OutputInterface::VERBOSITY_DEBUG);
                $dirDataAttachments = "/home/david/Projects/Knoitall/knoitall/data/attachments2";
                $srcDir = "$dirDataAttachments/" . substr($Record_Key,0,5);
                $destDir = __DIR__ . "/../../../web/media/provider/" . $provider->getHash();
                $output->writeln("DEBUG: destDir='$destDir'", OutputInterface::VERBOSITY_DEBUG);
                $filename = "${Record_Key}_4.jpg";
                if( file_exists("$srcDir/$filename") ) {
                    $output->writeln("DEBUG: provider image found, copying...", OutputInterface::VERBOSITY_DEBUG);
                    mkdir($destDir, 0755, true);
                    copy("$srcDir/$filename", "$destDir/$filename");
                    $provider->setImage($filename);

                    /*
                     * create thumbnails for the image:
                     */
                    $output->writeln("DEBUG: creating thumbnails...", OutputInterface::VERBOSITY_DEBUG);
                    $filenameThumb1 = $filename . '-thumb1'; //basename($filename, '.jpg') . '-thumb1.jpg';
                    exec("convert $destDir/$filename -resize 75x -density 75 -quality 70 -strip $destDir/$filenameThumb1");
                    $filenameThumb2 = $filename . '-thumb2'; //basename($filename, '.jpg') . '-thumb2.jpg';
                    exec("convert $destDir/$filename -resize 150x -density 150 -quality 80 -strip $destDir/$filenameThumb2");
                    $filenameThumb3 = $filename . '-thumb3'; //basename($filename, '.jpg') . '-thumb3.jpg';
                    exec("convert $destDir/$filename -resize 300x -density 300 -quality 90 -strip $destDir/$filenameThumb3");
                    $filenameThumb4 = $filename . '-thumb4'; //basename($filename, '.jpg') . '-thumb4.jpg';
                    exec("convert $destDir/$filename -resize 600x -density 600 -quality 95 -strip $destDir/$filenameThumb4");
                } else {
                    $output->writeln("DEBUG: no profile image found");
                }

                /*
                 * set suppliers:
                 */
                $output->writeln("DEBUG: processing suppliers...", OutputInterface::VERBOSITY_DEBUG);
                if( $Provider_List != '' ) {
                    if( strpos($Provider_List, '|') !== false ) {
                        $suppliers = explode("|", $Provider_List);
                    } elseif( strpos($Provider_List, ',') !== false ) {
                        $suppliers = explode(",", $Provider_List);
                    } else {
                        $suppliers = [$Provider_List];
                    }
                    $providerSuppliers[$provider->getTitle()] = [];
                    foreach( $suppliers as $supplier ) {
                        $supplier = trim($supplier);
                        if( in_array($supplier, $providerSuppliers[$provider->getTitle()]) ) {
                            $output->writeln("WARNING: supplier='$supplier' already present, skipping");
                            continue;
                        }
                        $providerSuppliers[$provider->getTitle()][] = $supplier;
                    }
                }

                $output->writeln("DEBUG: setting published flag...", OutputInterface::VERBOSITY_DEBUG);
                $provider->setPublished(true);

                $output->writeln("DEBUG: persisting...", OutputInterface::VERBOSITY_DEBUG);
                $em->persist($provider);

                $output->writeln("DEBUG: flushing...", OutputInterface::VERBOSITY_DEBUG);
                $em->flush();
                $output->writeln("INFO: successfully migrated Provider.");
                ++$countProviders;
            }

            $output->writeln("DEBUG: post-processing suppliers...", OutputInterface::VERBOSITY_DEBUG);
            foreach( $providerSuppliers as $providerTitle => $suppliers ) {
                $output->writeln("DEBUG: processing providerTitle='$providerTitle'", OutputInterface::VERBOSITY_DEBUG);
                $provider = $providerRepository->findOneBy(['title' => $providerTitle]);
                if( ! $provider ) {
                    $output->writeln("WARNING: could not find provider with title='$providerTitle', skipping");
                    continue;
                }
                foreach( $suppliers as $supplier) {
                    $output->writeln("DEBUG: searching for supplier='$supplier'...", OutputInterface::VERBOSITY_DEBUG);
                    $provider_supplier = $providerRepository->findOneBy(['title' => $supplier]);
                    if( $provider_supplier ) {
                        $provider->addSupplier($provider_supplier);
                        $suppliersAdded[] = $supplier;
                    } else {
                        $output->writeln("WARNING: could not find supplier='$supplier'");
                    }
                }
                $em->persist($provider);
            }
            $em->flush();

            $output->writeln("--------------------------------------------------------------");
            $output->writeln("INFO: successfully migrated $countProviders provider(s).");
            $output->writeln("INFO: excluded $countExcludedProviders provider(s).");
        }

        if( in_array('advisor',$entities) ) {
            $output->writeln( "INFO: migrating Advisor..." );

            /*
             * first check that all advisor-related info in the `knoitall_users` table is also in the `knoitall_advisors` table:
             */
            $query = <<<END
                SELECT
                    A.Record_Key,
                    A.Your_Email,
                    A.First_Name,
                    A.Last_Name,
                    A.Advisor_Name,
                    A.Advisor_Email
                FROM knoitall_users A
                WHERE
                    (
                        A.Advisor_Name != '' OR
                        A.Advisor_Profile != '' OR
                        A.Advisor_Email != '' OR
                        A.Advisor_Title != '' OR
                        A.Advisor_Additional_Information != ''
                    ) AND
                    NOT EXISTS (
                        SELECT *
                        FROM knoitall_advisors B
                        WHERE
                            B.Advisor_Name = A.Advisor_Name AND
                            B.Advisor_Profile = A.Advisor_Profile AND
                            B.Advisor_Email = A.Advisor_Email AND
                            B.Advisor_Title = A.Advisor_Title AND
                            B.Advisor_Additional_Information = A.Advisor_Additional_Information
                  )
                ORDER BY Record_Key
END;
            if( $count ) {
                $query .= " LIMIT $count";
            }
            $stmt = $dbh->query( $query  );
            $data = $stmt->fetchAll( \PDO::FETCH_ASSOC );
            if( count($data) > 0 ) {
                $output->writeln( "WARNING: the following 'knoitall_users' records contain advisor info that is not in the 'knoitall_advisors' table:" );
                foreach( $data as $row ) {
                    $output->writeln( sprintf( "WARNING: Record_Key=%d, Your_Email='%s', First_Name='%s' Last_Name='%s', Advisor_Name='%s', Advisor_Email='%s'",
                        $row['Record_Key'],
                        $row['Your_Email'],
                        $row['First_Name'],
                        $row['Last_Name'],
                        $row['Advisor_Name'],
                        $row['Advisor_Email']
                    ) );
                }
            }

            /*
             * migrate all info from `knoitall_advisors` table:
             */
            $query = "SELECT * FROM knoitall_advisors";
            if( $count ) {
                $query .= " LIMIT $count";
            }
            $stmt = $dbh->query( $query  );
            $data = $stmt->fetchAll( \PDO::FETCH_ASSOC );
            foreach( $data as $row ) {
                $output->writeln( "----------------------------------------------------------------------", OutputInterface::VERBOSITY_DEBUG );
                $output->writeln( sprintf("DEBUG: Entered_By_Email='%s', Advisor_Name='%s', Advisor_Email='%s'",
                    $row['Entered_By_Email'],
                    $row['Advisor_Name'],
                    $row['Advisor_Email']
                ), OutputInterface::VERBOSITY_DEBUG );

                $advisor = new Advisor();
                $advisor->setProfile( $row['Advisor_Profile'] );
                $advisor->setTitle( $row['Advisor_Title'] );
                $advisor->setAdditionalInformation( $row['Advisor_Additional_Information'] );
                $advisor->setNickname( $row['Nickname'] );

                /*
                 * try to find the relavant Person entity:
                 */
                $output->writeln( sprintf("DEBUG: searching for Advisor_Email='%s'...",$row['Advisor_Email']) );
                if(
                    trim($row['Advisor_Email']) != '' and
                    $user = $userRepository->findOneBy(['emailCanonical' => strtolower($row['Advisor_Email'])])
                ) {
                    $output->writeln( "INFO: Advisor_Email found in userRepository" );
                    $advisor->setPerson( $user->getPerson() );
                } elseif(
                    trim($row['Advisor_Name']) != '' and
                    $person = $personRepository->findOneByFullName( $row['Advisor_Name'] )
                ) {
                    $output->writeln( "INFO: Advisor_Name found in personRepository" );
                    $advisor->setPerson( $person );
                } else {
                    $output->writeln( "INFO: Advisor_Email, Advisor_Name not found, creating Person and User entries..." );

                    $person = new Person();
                    $nameParts = explode( ' ', $row['Advisor_Name'] );
                    if( count($nameParts) == 1 ) {
                        $person->setFirstName( $nameParts[0] );
                        $person->setLastName( 'UNKNOWN' );
                    } elseif( count($nameParts) == 2 ) {
                        $person->setFirstName( $nameParts[0] );
                        $person->setLastName( $nameParts[1] );
                    } elseif( count($nameParts) == 3 and in_array($nameParts[0],['Dr.','Mr..','Mrs.','Ms.']) ) {
                        $person->setTitle( $nameParts[0] );
                        $person->setFirstName( $nameParts[1] );
                        $person->setLastName( $nameParts[2] );
                    } else {
                        $output->writeln( sprintf("WARNING: could not parse Advisor_Name='%s'",$row['Advisor_Name']) );
                        $person->setFirstName( 'UNKNOWN' );
                        $person->setLastName( 'UNKNOWN' );
                    }
                    $em->persist( $person );
                    $advisor->setPerson( $person );

                    if( trim($row['Advisor_Email']) != '' ) {
                        $user = new User;
                        $user->setEmail( $row['Advisor_Email'] );
                        $user->setUsername( $row['Advisor_Email'] );
                        $user->setPassword( '##TODO##' );
                        $user->setEnabled( false );
                        $user->setLocked( true );
                        $user->setPerson( $person );
                        $em->persist( $user );
                    }

                    /*
                     * flush early to pick up duplicates:
                     */
                    $em->flush();
                }

                /*
                 * ##TODO##: add the correct Provider entry to this advisor
                 */

                $em->persist( $advisor );
            }
            $em->flush();
            $output->writeln( "INFO: successfully migrated Advisor." );
        }

        if( in_array('instructor',$entities) ) {
            $output->writeln( "INFO: migrating Instructor..." );

            /*
             * check for instructor information in 'knoitall_users' table:
             */
            $query = <<<END
                SELECT
                    A.Record_Key,
                    A.Your_Email,
                    A.First_Name,
                    A.Last_Name,
                    A.Instructor_Name,
                    A.Insructor_Profile
                FROM knoitall_users A
                WHERE
                    (
                        A.Instructor_Name != '' OR
                        A.Insructor_Profile
                    ) AND
                    NOT EXISTS (
                        SELECT *
                        FROM knoitall_instructors B
                        WHERE
                            B.Instructor_Name = A.Instructor_Name AND
                            B.Instructor_Profile = A.Insructor_Profile
                  )
                ORDER BY Record_Key
END;
            if( $count ) {
                $query .= " LIMIT $count";
            }
            $stmt = $dbh->query( $query  );
            $data = $stmt->fetchAll( \PDO::FETCH_ASSOC );
            if( count($data) > 0 ) {
                $output->writeln( "WARNING: the following 'knoitall_users' records contain instructor info that is not in the 'knoitall_instructors' table:" );
                foreach( $data as $row ) {
                    $output->writeln( sprintf( "WARNING: Record_Key=%d, Your_Email='%s', First_Name='%s' Last_Name='%s', Instructor_Name='%s', Insructor_Profile='%s'",
                        $row['Record_Key'],
                        $row['Your_Email'],
                        $row['First_Name'],
                        $row['Last_Name'],
                        $row['Instructor_Name'],
                        $row['Insructor_Profile']
                    ) );
                }
            }

            /*
             * migrate all info from 'knoitall_instructors' table:
             */
            $query = "SELECT * FROM knoitall_instructors";
            if( $count ) {
                $query .= " LIMIT $count";
            }
            $stmt = $dbh->query( $query  );
            $data = $stmt->fetchAll( \PDO::FETCH_ASSOC );
            foreach( $data as $row ) {
                $output->writeln( "----------------------------------------------------------------------", OutputInterface::VERBOSITY_DEBUG );
                $output->writeln( sprintf("DEBUG: Entered_By_Email='%s', Instructor_Name='%s', Instructor_Email='%s'",
                    $row['Entered_By_Email'],
                    $row['Instructor_Name'],
                    $row['Instructor_Email']
                ), OutputInterface::VERBOSITY_DEBUG );

                $instructor = new Instructor();
                $instructor->setProfile( $row['Instructor_Profile'] );
                $instructor->setTitle( $row['Instructor_Title'] );
                $instructor->setAdditionalInformation( $row['Instructor_Additional_Information'] );
                $instructor->setAwards( $row['Instructor_Awards'] );
                $instructor->setFacebookId( $row['Instructor_Facebook_ID'] );
                $instructor->setNickname( $row['Nickname'] );

                /*
                 * try to find the relavant Person entity:
                 */
                $output->writeln( sprintf("DEBUG: searching for Instructor_Email='%s'...",$row['Instructor_Email']) );
                if(
                    trim($row['Instructor_Email']) != '' and
                    $user = $userRepository->findOneBy(['emailCanonical' => strtolower($row['Instructor_Email'])])
                ) {
                    $output->writeln("INFO: Instructor_Email found in userRepository");
                    $instructor->setPerson($user->getPerson());
                } elseif(
                    trim($row['Instructor_Name']) != '' and
                    $person = $personRepository->findOneByFullName( $row['Instructor_Name'] )
                ) {
                    $output->writeln( "INFO: Instructor_Name found in personRepository" );
                    $instructor->setPerson( $person );
                } else {
                    $output->writeln( "INFO: Instructor_Email, Instructor_Name not found, creating Person and User entries..." );

                    $person = new Person();
                    $nameParts = explode( ' ', $row['Instructor_Name'] );
                    if( count($nameParts) == 1 ) {
                        $person->setFirstName( $nameParts[0] );
                        $person->setLastName( 'UNKNOWN' );
                    } elseif( count($nameParts) == 2 ) {
                        $person->setFirstName( $nameParts[0] );
                        $person->setLastName( $nameParts[1] );
                    } elseif( count($nameParts) == 3 and in_array($nameParts[0],['Dr.','Mr..','Mrs.','Ms.']) ) {
                        $person->setTitle( $nameParts[0] );
                        $person->setFirstName( $nameParts[1] );
                        $person->setLastName( $nameParts[2] );
                    } else {
                        $output->writeln( sprintf("WARNING: could not parse Instructor_Name='%s'",$row['Instructor_Name']) );
                        $person->setFirstName( 'UNKNOWN' );
                        $person->setLastName( 'UNKNOWN' );
                    }
                    $em->persist( $person );
                    $instructor->setPerson( $person );

                    if( trim($row['Instructor_Email']) != '' ) {
                        $user = new User;
                        $user->setEmail( $row['Instructor_Email'] );
                        $user->setUsername( $row['Instructor_Email'] );
                        $user->setPassword( '##TODO##' );
                        $user->setEnabled( false );
                        $user->setLocked( true );
                        $user->setPerson( $person );
                        $em->persist( $user );
                    }

                    /*
                     * flush early to pick up duplicates:
                     */
                    $em->flush();
                }

                /*
                 * ##TODO##: add the correct Provider entry to this instructor
                 */

                /*
                 * ##TODO## add instructor's projects
                 */

                $em->persist( $instructor );
            }

            $em->flush();
            $output->writeln( "INFO: successfully migrated Instructor." );
        }

        if( in_array('location',$entities) ) {
            $output->writeln("INFO: migrating Location...");

            $query = <<<END
                SELECT
                    Record_Key,
                    Record_Key_2,
                    Entered_Date,
                    Entered_Time,
                    CASE WHEN trim(Entered_By_Email) = '' THEN NULL ELSE trim(Entered_By_Email) END AS Entered_By_Email,
                    CASE WHEN trim(Entered_By_First_Name) = '' THEN NULL ELSE trim(Entered_By_First_Name) END AS Entered_By_First_Name,
                    CASE WHEN trim(Entered_By_Last_Name) = '' THEN NULL ELSE trim(Entered_By_Last_Name) END AS Entered_By_Last_Name,
                    CASE WHEN trim(Entered_By_Organization) = '' THEN NULL ELSE trim(Entered_By_Organization) END AS Entered_By_Organization,
                    /*
                    Updated_Date,
                    Updated_Time,
                    Updated_By_Email,
                    Updated_By_First_Name,
                    Updated_By_Last_Name,
                    Updated_By_Organization,
                    */
                    Location_Nickname,
                    Location_Name,
                    Location_Type,
                    Location_Phone,
                    Location_Description,
                    Location_Location,
                    Location_Address1,
                    Location_Address2,
                    Location_City,
                    Location_State,
                    Location_Zip,
                    Location_Lease_Terms,
                    Location_Public,
                    Location_Latitude,
                    Location_Longitude,
                    Nickname
                FROM knoitall_locations
                ORDER BY Record_Key
END;
            if( $count ) {
                $query .= " LIMIT $count";
            }
            $stmt = $dbh->query( $query  );
            $data = $stmt->fetchAll( \PDO::FETCH_ASSOC );

            $countLocations = 0;
            foreach( $data as $row ) {
                $output->writeln("--------------------------------------------------------------");
                $output->writeln("DEBUG: got row = " . print_r($row, true), OutputInterface::VERBOSITY_DEBUG);

                $Record_Key = $row['Record_Key'];
                $Entered_Date = $row['Entered_Date'];
                $Entered_Time = $row['Entered_Time'];
                $Entered_By_Email = $row['Entered_By_Email'];
                $Entered_By_First_Name = $row['Entered_By_First_Name'];
                $Entered_By_Last_Name = $row['Entered_By_Last_Name'];
                $Entered_By_Organization = $row['Entered_By_Organization'];
                //$Location_Nickname = $row['Location_Nickname']; // apparently not used (rather, field 'Nickname' is used)
                $Location_Name = $row['Location_Name'];
                $Location_Type = $row['Location_Type'];
                $Location_Phone = $row['Location_Phone'];
                $Location_Description = $row['Location_Description'];
                $Location_Location = $row['Location_Location'];
                $Location_Address1 = $row['Location_Address1'];
                $Location_Address2 = $row['Location_Address2'];
                $Location_City = $row['Location_City'];
                $Location_State = $row['Location_State'];
                $Location_Zip = $row['Location_Zip'];
                $Location_Lease_Terms = $row['Location_Lease_Terms'];
                $Location_Public = $row['Location_Public'];
                $Location_Latitude = $row['Location_Latitude'];
                $Location_Longitude = $row['Location_Longitude'];
                $Nickname = $row['Nickname'];

                $location = new Location();

                $output->writeln("INFO: setting original data...");
                $location
                    ->setOriginalRecordKey($Record_Key)
                    ->setOriginalEnteredDateTime(new \DateTime("$Entered_Date $Entered_Time"))
                    ->setOriginalEnteredByEmail($Entered_By_Email)
                    ->setOriginalEnteredByFirstName($Entered_By_First_Name)
                    ->setOriginalEnteredByLastName($Entered_By_Last_Name)
                    ->setOriginalEnteredByOrganization($Entered_By_Organization)
                ;

                if( $Nickname ) {
                    $location->setNickname($Nickname);
                }
                if( $Location_Name ) {
                    $location->setName($Location_Name);
                }
                if( $Location_Description) {
                    $location->setDescription($Location_Description);
                }
                if( $Location_Address1 || $Location_Address2 ) {
                    $address = $Location_Address1;
                    if( $Location_Address2 ) {
                        $address .= ", " . $Location_Address2;
                    }
                    $location->setStreet($address);
                }
                if( $Location_City ) {
                    $location->setCity($Location_City);
                }
                if( $Location_State ) {
                    $state = $stateRepository->findOneBy(['alpha2Code' => $Location_State]);
                    if( $state ) {
                        $location->setState($state);
                    } else {
                        $output->writeln("WARNING: could not identify state '$Location_State', not setting");
                    }
                }
                if( $Location_Zip) {
                    $location->setZip($Location_Zip);
                }
                if( $Location_Phone ) {
                    $location->setPhone($Location_Phone);
                }
                if( $Location_Lease_Terms ) {
                    $location->setLeaseTerms($Location_Lease_Terms);
                }
                if( in_array($Location_Public, ['No','Yes']) ) {
                    $location->setPublic( $Location_Public == 'Yes' ? true : false );
                }
                if( $Location_Latitude != 0 || $Location_Longitude != 0 ) {
                    $location->setLatitude($Location_Latitude);
                    $location->setLongitude($Location_Longitude);
                }

                $locationType = $locationTypeRepository->findOneBy(['description' => $Location_Type]);
                if( $locationType ) {
                    $location->setLocationType($locationType);
                } else {
                    $locationType = $locationTypeRepository->findOneBy(['description' => 'Other']);
                    if( $locationType ) {
                        $location->setLocationType($locationType);
                    } else {
                        $output->writeln("WARNING: could not find location type");
                    }
                }

                $provider = $providerRepository->findOneBy(['originalEnteredByEmail' => $Entered_By_Email, 'originalEnteredByFirstName' => $Entered_By_First_Name, 'originalEnteredByLastName' => $Entered_By_Last_Name]);
                if( $provider) {
                    $location->setProvider($provider);
                } else {
                    $output->writeln("WARNING: no provider found; creating orphan location");
                }

                /*
                 * set images:
                 */
                $output->writeln("INFO: finding images...", OutputInterface::VERBOSITY_VERBOSE);
                $dirDataAttachments = "/home/david/Projects/Knoitall/knoitall/data/attachments2";
                $srcDir = "$dirDataAttachments/" . substr($Record_Key,0,5);
                $destDir = __DIR__ . "/../../../web/media/location/" . $location->getHash();
                $output->writeln("DEBUG: destDir='$destDir'", OutputInterface::VERBOSITY_DEBUG);
                $filename = "${Record_Key}_1.jpg";
                if( file_exists("$srcDir/$filename") ) {
                    $output->writeln("DEBUG: location image found, copying...", OutputInterface::VERBOSITY_DEBUG);
                    mkdir($destDir, 0755, true);
                    copy("$srcDir/$filename", "$destDir/$filename");
                    $location->setImage($filename);

                    /*
                     * create thumbnails for the image:
                     */
                    $output->writeln("DEBUG: creating thumbnails...", OutputInterface::VERBOSITY_DEBUG);
                    $filenameThumb1 = $filename . '-thumb1'; //basename($filename, '.jpg') . '-thumb1.jpg';
                    exec("convert $destDir/$filename -resize 75x -density 75 -quality 70 -strip $destDir/$filenameThumb1");
                    $filenameThumb2 = $filename . '-thumb2'; //basename($filename, '.jpg') . '-thumb2.jpg';
                    exec("convert $destDir/$filename -resize 150x -density 150 -quality 80 -strip $destDir/$filenameThumb2");
                    $filenameThumb3 = $filename . '-thumb3'; //basename($filename, '.jpg') . '-thumb3.jpg';
                    exec("convert $destDir/$filename -resize 300x -density 300 -quality 90 -strip $destDir/$filenameThumb3");
                    $filenameThumb4 = $filename . '-thumb4'; //basename($filename, '.jpg') . '-thumb4.jpg';
                    exec("convert $destDir/$filename -resize 600x -density 600 -quality 95 -strip $destDir/$filenameThumb4");
                } else {
                    $output->writeln("DEBUG: no location image found");
                }

                $em->persist($location);
                ++$countLocations;
            }
            $output->writeln("--------------------------------------------------------------");
            $em->flush();
            $output->writeln("INFO: successfully migrated $countLocations location(s)");
        }

        if( in_array('Event',$entities) ) {
            $output->writeln( "INFO: migrating Event..." );

            $query = <<<END
                SELECT
                    Record_Key,
                    Record_Key_2,
                    Entered_Date,
                    Entered_Time,
                    CASE WHEN trim(Entered_By_Email) = '' THEN NULL ELSE trim(Entered_By_Email) END AS Entered_By_Email,
                    CASE WHEN trim(Entered_By_First_Name) = '' THEN NULL ELSE trim(Entered_By_First_Name) END AS Entered_By_First_Name,
                    CASE WHEN trim(Entered_By_Last_Name) = '' THEN NULL ELSE trim(Entered_By_Last_Name) END AS Entered_By_Last_Name,
                    CASE WHEN trim(Entered_By_Organization) = '' THEN NULL ELSE trim(Entered_By_Organization) END AS Entered_By_Organization,
                    Updated_Date,
                    Updated_Time,
                    Updated_By_Email,
                    Updated_By_First_Name,
                    Updated_By_Last_Name,
                    Updated_By_Organization,
                    trim(Event_Title) AS Event_Title,
                    trim(Event_Description) AS Event_Description,
                    CASE WHEN trim(Event_Category) = '' THEN NULL ELSE trim(Event_Category) END AS Event_Category,
                    CASE WHEN trim(Event_Category_2) = '' THEN NULL ELSE trim(Event_Category_2) END AS Event_Category_2,
                    CASE WHEN trim(Event_Category_3) = '' THEN NULL ELSE trim(Event_Category_3) END AS Event_Category_3,
                    trim(Event_Provider) AS Event_Provider,
                    trim(Event_Format) AS Event_Format,
                    trim(Event_Age) AS Event_Age,
                    Event_Number_Sessions,
                    Event_Duration,
                    trim(Event_Duration_UOM) AS Event_Duration_UOM,
                    trim(Event_Outcomes) AS Event_Outcomes,
                    trim(Event_Location_Name) AS Event_Location_Name,
                    trim(Event_Location_Type) AS Event_Location_Type,
                    trim(Event_Location_Phone) AS Event_Location_Phone,
                    trim(Event_Location_Description) AS Event_Location_Description,
                    trim(Event_Location_Address1) AS Event_Location_Address1,
                    trim(Event_Location_Address2) AS Event_Location_Address2,
                    trim(Event_Location_City) AS Event_Location_City,
                    trim(Event_Location_Zip) AS Event_Location_Zip,
                    trim(Event_Location_State) AS Event_Location_State,
                    Event_Location_Longitude,
                    Event_Location_Latitude,
                    Event_Price,
                    trim(Event_External_Link) AS Event_External_Link
                FROM knoitall_events E
                ORDER BY Record_Key
END;
            if( $count ) {
                $query .= " LIMIT $count";
            }
            $stmt = $dbh->query( $query  );
            $data = $stmt->fetchAll( \PDO::FETCH_ASSOC );

            $countEvents = 0;
            $countExcludedEvents = 0;
            $countSkippedEvents = 0;
            foreach( $data as $row ) {
                $output->writeln("--------------------------------------------------------------");
                $output->writeln("DEBUG: got row = " . print_r($row, true), OutputInterface::VERBOSITY_DEBUG);

                $Record_Key = $row['Record_Key'];
                $Entered_Date = $row['Entered_Date'];
                $Entered_Time = $row['Entered_Time'];
                $Entered_By_Email = $row['Entered_By_Email'];
                $Entered_By_First_Name = $row['Entered_By_First_Name'];
                $Entered_By_Last_Name = $row['Entered_By_Last_Name'];
                $Entered_By_Organization = $row['Entered_By_Organization'];
                $Event_Title = $row['Event_Title'];
                $Event_Description = $row['Event_Description'];
                $Event_Category = $row['Event_Category'];
                $Event_Category_2 = $row['Event_Category_2'];
                $Event_Category_3 = $row['Event_Category_3'];
                $Event_Provider = $row['Event_Provider'];
                $Event_Format = $row['Event_Format'];
                $Event_Age = $row['Event_Age'];
                $Event_Number_Sessions = $row['Event_Number_Sessions'];
                $Event_Duration = $row['Event_Duration'];
                $Event_Duration_UOM = $row['Event_Duration_UOM'];
                $Event_Outcomes = $row['Event_Outcomes'];
                $Event_Location_Name = $row['Event_Location_Name'];
                $Event_Location_Type = $row['Event_Location_Type'];
                $Event_Location_Phone = $row['Event_Location_Phone'];
                $Event_Location_Description = $row['Event_Location_Description'];
                $Event_Location_Address1 = $row['Event_Location_Address1'];
                $Event_Location_Address2 = $row['Event_Location_Address2'];
                $Event_Location_City = $row['Event_Location_City'];
                $Event_Location_Zip = $row['Event_Location_Zip'];
                $Event_Location_State = $row['Event_Location_State'];
                $Event_Location_Latitude = $row['Event_Location_Latitude'];
                $Event_Location_Longitude = $row['Event_Location_Longitude'];
                $Event_Price = $row['Event_Price'];
                $Event_External_Link = $row['Event_External_Link'];

                /*
                 * check if this is in the excluded events list (temporary excludes list):
                 */
                if( in_array($Event_Provider, $this->excludeEventsByProvider) ) {
                    $output->writeln("INFO: excluding event Event_Title='$Event_Title', Event_Provider='$Event_Provider' (found in temporary excludes list)");
                    ++$countExcludedEvents;
                    continue;
                }

                /*
                 * check if this event's provider has been excluded (permanent excludes list):
                 */
                $isExcluded = false;
                foreach( $this->excludedProviders as $excludedProvider ) {
                    if( $excludedProvider['Provider'] == $Event_Provider ) {
                        $isExcluded = true;
                        break;
                    }
                }
                if( $isExcluded ) {
                    $output->writeln("INFO: excluding event Event_Title='$Event_Title', Event_Provider='$Event_Provider' (found in permanent excludes list)");
                    ++$countExcludedEvents;
                    continue;
                }

                /*
                 * find provider:
                 */
                /** @var Provider $provider */
                $provider = $providerRepository->findOneBy(['title' => $Event_Provider]);
                if( $provider ) {
                    $output->writeln("INFO: OK, found provider", OutputInterface::VERBOSITY_VERBOSE);
                } else {
                    $output->writeln("WARNING: could not find provider '$Event_Provider', skipping");
                    ++$countSkippedEvents;
                    continue;
                }

                $output->writeln("INFO: migrating event Event_Title='$Event_Title', Event_Provider='$Event_Provider'");

                $event = new Event();
                $event->setProvider($provider);

                $output->writeln("DEBUG: setting original data...", OutputInterface::VERBOSITY_DEBUG);
                $event
                    ->setOriginalRecordKey($Record_Key)
                    ->setOriginalEnteredDateTime(new \DateTime("$Entered_Date $Entered_Time"))
                    ->setOriginalEnteredByEmail($Entered_By_Email)
                    ->setOriginalEnteredByFirstName($Entered_By_First_Name)
                    ->setOriginalEnteredByLastName($Entered_By_Last_Name)
                    ->setOriginalEnteredByOrganization($Entered_By_Organization)
                ;

                if( isset($this->eventTitleRemap[$Event_Title]) ) {
                    $output->writeln("INFO: remapping title '" . $Event_Title . "' => '" . $this->eventTitleRemap[$Event_Title] . "'");
                    $Event_Title = $this->eventTitleRemap[$Event_Title];
                }
                $event->setTitle($Event_Title);

                $event->setDescription($Event_Description);
                $event->setLearningOutcomes($Event_Outcomes);

                /*
                 * location data:
                 */
                if( $Event_Location_Name ) {
                    $event->setLocationName($Event_Location_Name);
                }
                if( $Event_Location_Type ) {
                    $locationType = $locationTypeRepository->findOneBy(['description' => $Event_Location_Type]);
                    if( $locationType ) {
                        $event->setLocationType($locationType);
                    } else {
                        $output->writeln("WARNING could not find location type '$Event_Location_Type', using 'Other'");
                        $locationType = $locationTypeRepository->findOneBy(['description' => 'Other']);
                        if( $locationType ) {
                            $event->setLocationType($locationType);
                        } else {
                            $output->writeln("WARNING could not find location type 'Other', skipping");
                        }
                    }
                }
                if( $Event_Location_Phone ) {
                    $event->setLocationPhone($Event_Location_Phone);
                }
                if( $Event_Location_Description ) {
                    $event->setLocationDescription($Event_Location_Description);
                }
                if( $Event_Location_Address1 || $Event_Location_Address2 ) {
                    $address = $Event_Location_Address1;
                    if( $Event_Location_Address2 ) {
                        $address .= ", " . $Event_Location_Address2;
                    }
                    $event->setLocationStreet($address);
                }
                if( $Event_Location_City ) {
                    $event->setLocationCity($Event_Location_City);
                }
                if( $Event_Location_Zip ) {
                    $event->setLocationZip($Event_Location_Zip);
                }
                if( $Event_Location_State ) {
                    $state = $stateRepository->findOneBy(['alpha2Code' => $Event_Location_State]);
                    if( $state ) {
                        $event->setLocationState($state);
                        $country = $countryRepository->findOneBy(['alpha3Code' => 'USA']);
                        if( $country ) {
                            $event->setLocationCountry($country);
                        } else {
                            $output->writeln("WARNING: could not find country 'USA', skipping");
                        }
                    } else {
                        $output->writeln("WARNING: could not find state '$Event_Location_State', skipping");
                    }
                }
                if( $Event_Location_Latitude != 0 && $Event_Location_Longitude != 0 ) {
                    $event->setLocationLatitude($Event_Location_Latitude);
                    $event->setLocationLongitude($Event_Location_Longitude);
                }

                /*
                 * price, external link, etc.:
                 */
                $event->setPrice($Event_Price);
                if( isset($Event_External_Link) && $Event_External_Link != '' ) {
                    $event->setExternalLink($Event_External_Link);
                }

                /*
                 * find taxonomy:
                 */
                $output->writeln("DEBUG: processing taxonomy...", OutputInterface::VERBOSITY_DEBUG);
                list($level1,$level2,$level3) = $this->remapCategories($Event_Category, $Event_Category_2);
                $output->writeln("DEBUG: level1='$level1', level2='$level2', level3='$level3'", OutputInterface::VERBOSITY_DEBUG);
                $taxonomy = $taxonomyRepository->findFuzzy($level1, $level2,$level3);
                if( $taxonomy ) {
                    $event->addTaxonomy($taxonomy);
                } else {
                    if( $Event_Provider == 'Craftsy' && $Event_Category == 'Art Drama Music' and $Event_Category_2 == '' ) {
                        $taxonomy = $taxonomyRepository->findOneBy(['level1' => 'Arts & Crafts', 'level2' => null, 'level3' => null]);
                        if( $taxonomy ) {
                            $event->addTaxonomy($taxonomy);
                        } else {
                            $output->writeln("WARNING: could not find taxonomy for Crafts '$Event_Category:$Event_Category_2:$Event_Category_3'");
                        }
                    } else {
                        $output->writeln("WARNING: could not find taxonomy '$level1:$level2'");
                    }
                }

                /*
                 * find event format:
                 */
                $output->writeln("DEBUG: searching for Event_Format='$Event_Format'...", OutputInterface::VERBOSITY_DEBUG);
                $eventFormat = $eventFormatRepository->findOneBy(['description' => $this->eventFormatMap[$Event_Format]]);
                if( $eventFormat ) {
                    $event->setEventFormat($eventFormat);
                } else {
                    $output->writeln("WARNING: could not find event format '$Event_Format'; will use 'Other'");
                    $eventFormat = $eventFormatRepository->findOneBy(['description' => 'Other']);
                    if( $eventFormat ) {
                        $event->setEventFormat($eventFormat);
                    } else {
                        $output->writeln("WARNING: could not find event format 'Other'");
                    }
                }

                /*
                 * find event ages:
                 */
                $output->writeln("DEBUG: processing ages...", OutputInterface::VERBOSITY_DEBUG);
                if( $Event_Age != '' ) {
                    if( preg_match("/\|/", $Event_Age) ) {
                        $ageGroups = explode("|", $Event_Age);
                    } else {
                        $ageGroups = explode(",", $Event_Age);
                    }
                    foreach( $ageGroups as $ageGroup ) {
                        $age = $ageRepository->findOneBy(['description' => trim($this->ageMap[$ageGroup])]);
                        if( ! $age ) {
                            $output->writeln("WARNING: could not find event age '$ageGroup', skipping");
                            continue;
                        }
                        $event->addAge($age);
                    }
                } else {
                    $output->writeln("WARNING: Event_Age='$Event_Age'");
                }

                /*
                 * find number of sessions and duration:
                 */
                $event->setNumberOfSessions($Event_Number_Sessions);
                $event->setDurationAmount($Event_Duration);
                if( $Event_Duration_UOM ) {
                    $eventDurationTimeUnit = $timeUnitRepository->findOneBy(['description' => $Event_Duration_UOM]);
                    if( $eventDurationTimeUnit ) {
                        $event->setDurationTimeUnit($eventDurationTimeUnit);
                    } else {
                        $output->writeln("WARNING: could not find event duration time unit '$Event_Duration_UOM'");
                    }
                }

                /*
                 * set images:
                 */
                $output->writeln("DEBUG: finding images...", OutputInterface::VERBOSITY_DEBUG);
                $dirDataAttachments = "/home/david/Projects/Knoitall/knoitall/data/attachments2";
                $srcDir = "$dirDataAttachments/" . substr($Record_Key,0,5);
                $destDir = __DIR__ . "/../../../web/media/event/" . $event->getHash();
                $output->writeln("DEBUG: destDir='$destDir'", OutputInterface::VERBOSITY_DEBUG);
                $filename = "${Record_Key}_1.jpg";
                if( file_exists("$srcDir/$filename") ) {
                    $output->writeln("DEBUG: event image found, copying...", OutputInterface::VERBOSITY_DEBUG);
                    mkdir($destDir, 0755, true);
                    copy("$srcDir/$filename", "$destDir/$filename");
                    $event->setImage($filename);

                    /*
                     * create thumbnails for the image:
                     */
                    $filenameThumb1 = $filename . '-thumb1'; //basename($filename, '.jpg') . '-thumb1.jpg';
                    exec("convert $destDir/$filename -resize 75x -density 75 -quality 70 -strip $destDir/$filenameThumb1");
                    $filenameThumb2 = $filename . '-thumb2'; //basename($filename, '.jpg') . '-thumb2.jpg';
                    exec("convert $destDir/$filename -resize 150x -density 150 -quality 80 -strip $destDir/$filenameThumb2");
                    $filenameThumb3 = $filename . '-thumb3'; //basename($filename, '.jpg') . '-thumb3.jpg';
                    exec("convert $destDir/$filename -resize 300x -density 300 -quality 90 -strip $destDir/$filenameThumb3");
                    $filenameThumb4 = $filename . '-thumb4'; //basename($filename, '.jpg') . '-thumb4.jpg';
                    exec("convert $destDir/$filename -resize 600x -density 600 -quality 95 -strip $destDir/$filenameThumb4");
                } else {
                    $output->writeln("DEBUG: no event image found");
                }

                $event->setPublished(true);

                $em->persist($event);
                ++$countEvents;

                if( $countExcludedEvents % 100 == 0 ) {
                    $output->writeln("INFO: performing intermediate flush...");
                    $em->flush();
                }
            }
            $output->writeln("--------------------------------------------------------------");
            $em->flush();
            $output->writeln("INFO: successfully migrated $countEvents event(s)");
            $output->writeln("INFO: excluded $countExcludedEvents event(s)");
            $output->writeln("INFO: skipped $countSkippedEvents event(s)");
        }

        $output->writeln( "Exitting" );
    }
}

<?php

namespace AppBundle\Command;

use Doctrine\DBAL\Driver\PDOException;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use AppBundle\Entity\Taxonomy;

class AdminTaxonomySetParentCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('admin:taxonomy:set-parent')
            ->setDescription("Set parent for each taxonomy entity") // TODO: could be better handled in migration
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $output->writeln( "INFO: setting parent for each taxonomy entity..." );

        $em = $this->getContainer()->get('doctrine')->getManager();
        $taxonomyRepository = $em->getRepository(Taxonomy::class);

        $taxonomies = $taxonomyRepository->findAll();
        $countTaxonomies = 0;
        /** @var Taxonomy $taxonomy */
        foreach( $taxonomies as $taxonomy ) {
            $level1 = $taxonomy->getLevel1();
            $level2 = $taxonomy->getLevel2();
            $level3 = $taxonomy->getLevel3();
            if( $level3 ) {
                $level3 = null;
            } elseif( $level2 ) {
                $level2 = null;
            } else {
                $level1 = null;
            }
            $parentTaxonomy = $taxonomyRepository->findOneBy(['level1' => $level1, 'level2' => $level2, 'level3' => $level3]);
            if( $parentTaxonomy ) {
                $taxonomy->setParent($parentTaxonomy);
            } else {
                $taxonomy->setParent(null);
            }
            $em->persist($taxonomy);
            ++$countTaxonomies;
        }
        $output->writeln("INFO: flushing...");
        $em->flush();
        $output->writeln("INFO: successfully set parent for $countTaxonomies taxonomies");

        $output->writeln( "Exitting" );
    }
}

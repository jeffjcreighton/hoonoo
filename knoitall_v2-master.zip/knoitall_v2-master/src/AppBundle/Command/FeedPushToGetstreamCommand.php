<?php

namespace AppBundle\Command;

require_once __DIR__ . '/../../../vendor/autoload.php';

use Doctrine\DBAL\Driver\PDOException;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;

use AppBundle\Entity\Learner;
use AppBundle\Entity\Provider;
use AppBundle\Entity\Event;
use AppBundle\Entity\FeedCommentEvent;
use AppBundle\Entity\FeedFollowProvider;
use AppBundle\Entity\FeedLikeEvent;
use AppBundle\Entity\FeedShareEvent;

class FeedPushToGetstreamCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('feed:push-to-getstream')
            ->setDescription("Push feed data to getstream.io")
        ;
    }

//$providerFeed = $client->feed('Providers', $provider->getId());
//$data = [
//'actor' => 'Providers:' . $provider->getId(),
//'verb' => 'addPost',
//'object' => 'Events:' . $eventPost->getId(),
//];
//$providerFeed->addActivity($data);

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $output->writeln( "INFO: pushing feed data to getstream.io..." );

        $getstream_key = $this->getContainer()->getParameter('getstream_key');
        $getstream_secret = $this->getContainer()->getParameter('getstream_secret');
        $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );
        $output->writeln("DEBUG: successfully created getstream client object");

        $em = $this->getContainer()->get('doctrine')->getManager();
        $feedFollowProviderRepository = $em->getRepository(FeedFollowProvider::class);
        $feedLikeEventRepository = $em->getRepository(FeedLikeEvent::class);
        $feedCommentEventRepository = $em->getRepository(FeedCommentEvent::class);
        $feedShareEventRepository = $em->getRepository(FeedShareEvent::class);

        /*
         * push all follow/unfollow events to getstream.io:
         */
        $feedFollowProviders = $feedFollowProviderRepository->findBy(['pushedToGetstream' => false]);
        /** @var FeedFollowProvider $feedFollowProvider */
        foreach( $feedFollowProviders as $feedFollowProvider ) {
            $learner_id = $feedFollowProvider->getLearner()->getId();
            $provider_id = $feedFollowProvider->getProvider()->getId();
            $output->writeln("DEBUG: got learner_id=$learner_id, provider_id=$provider_id");
            $learner_feed = $client->feed('Learners', $learner_id);
            $output->writeln("DEBUG: got learner feed object for learner_id=$learner_id");

            if( $feedFollowProvider->getFollow() ) {
                $learner_feed->followFeed('Providers', $provider_id);
            } else {
                $learner_feed->unfollowFeed('Providers', $provider_id);
            }

            $feedFollowProvider->setPushedToGetstream(true);
            $em->persist($feedFollowProvider);

            $output->writeln("INFO: successfully pushed follow/unfollow event for learner_id=$learner_id, $provider_id=$provider_id" );
        }
        $em->flush();

        /*
         * push all like events to getstream:
         */
        $feedLikeEvents = $feedLikeEventRepository->findBy(['pushedToGetstream' => false]);
        /** @var FeedLikeEvent $feedLikeEvent */
        foreach( $feedLikeEvents as $feedLikeEvent ) {
            $learner_id = $feedLikeEvent->getLearner()->getId();
            $event_id = $feedLikeEvent->getEvent()->getId();
            $event_provider_id = $feedLikeEvent->getEvent()->getProvider()->getId();
            $learner_feed = $client->feed('Learners', $learner_id);
            $learner_feed->addActivity([
                'actor' => "Learners:$learner_id",
                'verb' => "like",
                'object' => "Events:$event_id",
                'to' => ["Notifications:$event_provider_id"],
            ]);

            $feedLikeEvent->setPushedToGetstream(true);
            $em->persist($feedLikeEvent);

            $output->writeln("INFO: successfully pushed like event for learner_id=$learner_id, event_id=$event_id" );
        }
        $em->flush();

        /*
         * push all comment events to getstream:
         */
        $feedCommentEvents = $feedCommentEventRepository->findBy(['pushedToGetstream' => false]);
        /** @var FeedCommentEvent $feedCommentEvent */
        foreach( $feedCommentEvents as $feedCommentEvent ) {
            $learner_id = $feedCommentEvent->getLearner()->getId();
            $event_id = $feedCommentEvent->getEvent()->getId();
            $event_provider_id = $feedCommentEvent->getEvent()->getProvider()->getId();
            $learner_feed = $client->feed('Learners', $learner_id);
            $learner_feed->addActivity([
                'actor' => "Learners:$learner_id",
                'verb' => "comment",
                'object' => "Events:$event_id",
                'to' => ["Notifications:$event_provider_id"],
            ]);

            $feedCommentEvent->setPushedToGetstream(true);
            $em->persist($feedCommentEvent);

            $output->writeln("INFO: successfully pushed comment event for learner_id=$learner_id, event_id=$event_id" );
        }
        $em->flush();

        /*
         * push all share events to getstream:
         */
        $feedShareEvents = $feedShareEventRepository->findBy(['pushedToGetstream' => false]);
        /** @var FeedShareEvent $feedShareEvent */
        foreach( $feedShareEvents as $feedShareEvent ) {
            $learner_id = $feedShareEvent->getLearner()->getId();
            $event_id = $feedShareEvent->getEvent()->getId();
            $event_provider_id = $feedShareEvent->getEvent()->getProvider()->getId();
            $learner_feed = $client->feed('Learners', $learner_id);
            $learner_feed->addActivity([
                'actor' => "Learners:$learner_id",
                'verb' => "share",
                'object' => "Events:$event_id",
                'to' => ["Notifications:$event_provider_id"],
            ]);

            $feedShareEvent->setPushedToGetstream(true);
            $em->persist($feedShareEvent);

            $output->writeln("INFO: successfully pushed share event for learner_id=$learner_id, event_id=$event_id" );
        }

        $output->writeln("INFO: flushing...");
        $em->flush();

        $output->writeln( "Exitting" );
    }
}

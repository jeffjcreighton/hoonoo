<?php

namespace AppBundle\Command;

use Doctrine\DBAL\Driver\PDOException;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use AppBundle\Entity\Taxonomy;

class ReportBadTaxonomyCommand extends ContainerAwareCommand
{
    private $knoitall_v1_host   = 'localhost';
    private $knoitall_v1_userid = 'knoitalluser';
    private $knoitall_v1_passwd = 'knoitallpass';
    private $knoitall_v1_db     = 'knoitall_v1';

    private $taxonomyLevel1Map = [
    ];

    private $taxonomyLevel2Map = [
        'triathlon' => 'Triathlon',
        'Cycling Road Biking' => 'Cycling & Mountain Biking',
        'Mountain Biking' => 'Cycling & Mountain Biking',
    ];

    private $taxonomyLevel3Map = [
    ];

    protected function configure()
    {
        $this
            ->setName('report:bad-taxonomy')
            ->setDescription("Find taxonomy referred to by provider/event but not in knoitall_taxonomy table")
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $output->writeln( "INFO: finding bad taxonomies..." );

        try {
            $dsn = sprintf( "mysql:dbname=%s;host=%s", $this->knoitall_v1_db, $this->knoitall_v1_host );
            $dbh = new \PDO( $dsn, $this->knoitall_v1_userid, $this->knoitall_v1_passwd );
            $output->writeln( "INFO: successfully connected to database $this->knoitall_v1_db" );
        } catch( PDOException $e ) {
            $output->writeln( 'Connection failed: ' . $e->getMessage() );
            exit( -1 );
        }

        $em = $this->getContainer()->get('doctrine')->getManager();
        $taxonomyRepository = $em->getRepository(Taxonomy::class);

        $output->writeln("INFO: checkout for bad taxonomy in learning centers...");

        $query = <<<END
    SELECT
        Record_Key,
        CASE WHEN trim(Entered_By_Email) = '' THEN NULL ELSE trim(Entered_By_Email) END AS Entered_By_Email,
        CASE WHEN trim(Entered_By_First_Name) = '' THEN NULL ELSE trim(Entered_By_First_Name) END AS Entered_By_First_Name,
        CASE WHEN trim(Entered_By_Last_Name) = '' THEN NULL ELSE trim(Entered_By_Last_Name) END AS Entered_By_Last_Name,
        CASE WHEN trim(Provider) = '' THEN NULL ELSE trim(Provider) END AS Provider,
        CASE WHEN trim(Description_Of_Services) = '' THEN NULL ELSE trim(Description_Of_Services) END AS Description_Of_Services,
        CASE WHEN trim(Nickname) = '' THEN NULL ELSE trim(Nickname) END AS Nickname,
		Art_Drama_Music,
		Business,
		Camps_Travel,
		Computers_Software,
		Cooking_Beverage,
		Education,
		Engineering,
		English_Literature_Writing,
		Health_Health_Care,
		History,
		Hobbies_Games,
		Home_Garden,
		Languages,
		Legal_Studies,
		Parenting,
		Philosophy,
		Religion,
		Science_Math,
		Sport_Leisure,
		Testing_Test_Prep
    FROM knoitall_users
    WHERE User_Type='Provider'
    ORDER BY Record_Key
END;

        $stmt = $dbh->query( $query  );
        $data = $stmt->fetchAll( \PDO::FETCH_ASSOC );

        $level1Categories = [
            'Art, Drama & Music',
            'Business',
            'Camps & Travel',
            'Computers & Software',
            'Cooking & Beverage',
            'Education',
            'Engineering',
            'English, Literature & Writing',
            'Health & Health Care',
            'History',
            'Hobbies & Games',
            'Home & Garden',
            'Languages',
            'Legal Studies',
            'Parenting',
            'Philosophy',
            'Religion',
            'Science & Math',
            'Sports & Leisure',
            'Testing & Test Prep',
        ];

        $countProviders = 0;
        foreach( $data as $row ) {
            $output->writeln("--------------------------------------------------------------------------------");
            $Provider = $row['Provider'];
            $Nickname = $row['Nickname'];
            $output->writeln("INFO: checking taxonomies for Provider='$Provider', Nickname='$Nickname'");

            foreach( $level1Categories as $level1Category ) {
                $x = preg_replace("/&/", '', $level1Category);
                $x = preg_replace("/,/", '', $x);
                $x = preg_replace("/\s+/", '_', $x);
                $x = preg_replace("/Sports_Leisure/", 'Sport_Leisure', $x);
                $level2 = $row[$x];
                $level2Categories = explode('|', $level2);
                foreach( $level2Categories as $level2Category ) {
                    $level2Category = trim($level2Category);
                    if( $level2Category == '' ) continue;

                    /*
                     * some things changed from v1 to v2, e.g., 'triathlon' is now 'Triathlon'
                     */
                    if( isset($this->taxonomyLevel1Map[$level1Category]) ) {
                        $level1Category = $this->taxonomyLevel1Map[$level1Category];
                    }
                    if( isset($this->taxonomyLevel2Map[$level2Category]) ) {
                        $level2Category = $this->taxonomyLevel2Map[$level2Category];
                    }
//                    if( isset($this->taxonomyLevel3Map[$level3]) ) {
//                        $level3Category = $this->taxonomyLevel3Map[$level3Category];
//                    }

                    $output->writeln("INFO: searching for $level1Category:$level2Category");
                    $taxonomy = $taxonomyRepository->findFuzzy($level1Category, $level2Category);
                    if( $taxonomy ) {
                        $output->writeln("DEBUG: FOUND!", OutputInterface::VERBOSITY_VERBOSE);
                    } else {
                        $output->writeln("WARNING: category $level1Category:$level2Category not found");
                    }
                }
            }

            ++$countProviders;
        }
        $output->writeln("--------------------------------------------------------------------------------");
        $output->writeln("INFO: checked $countProviders provider(s)");

        $output->writeln("INFO: checking for bad taxonomy in events...");

        $query = <<<END
                SELECT
                    Record_Key,
                    Record_Key_2,
                    Entered_Date,
                    Entered_Time,
                    Entered_By_Email,
                    Entered_By_First_Name,
                    Entered_By_Last_Name,
                    Entered_By_Organization,
                    Updated_Date,
                    Updated_Time,
                    Updated_By_Email,
                    Updated_By_First_Name,
                    Updated_By_Last_Name,
                    Updated_By_Organization,
                    trim(Event_Title) AS Event_Title,
                    CASE WHEN trim(Event_Category) = '' THEN NULL ELSE trim(Event_Category) END AS Event_Category,
                    CASE WHEN trim(Event_Category_2) = '' THEN NULL ELSE trim(Event_Category_2) END AS Event_Category_2,
                    CASE WHEN trim(Event_Category_3) = '' THEN NULL ELSE trim(Event_Category_3) END AS Event_Category_3,
                    trim(Event_Provider) AS Event_Provider
                FROM knoitall_events E
                WHERE
                    Event_Provider IN (
                        'd',
                        'Zimbazee Learning Center',
                        'Chick-Fil-A Learning Together Program',
                        'Knoitall Academic Advising Services',
                        'Bike Commuting Resource Center',
                        'Kleiner Perkins Caufield Byers',
                        'Grilling, Barbecue and Southern Foods Expert',
                        'Dax Ross',
                        'The Enchanting Lawyer',
                        'French LSA',
                        'Berkshire Hathaway HomeServices / INDRA Group',
                        'Kristy Abbott',
                        'USC Viterbi School of Engineering',
                        'Craftsy',
                        'REI',
                        'Vado',
                        'Sea World San Diego',
                        'Deborah Ferber',
                        'Adobe',
                        'Knoitall, Inc.',
                        'Brad Feld',
                        'UC Berkeley Extension Programs for Corporate and Professional Training'
                    )
                ORDER BY Record_Key
END;

        $stmt = $dbh->query( $query  );
        $data = $stmt->fetchAll( \PDO::FETCH_ASSOC );

        $countEvents = 0;
        foreach( $data as $row ) {
            $output->writeln("--------------------------------------------------------------");
            $output->writeln("DEBUG: got row = " . print_r($row, true), OutputInterface::VERBOSITY_VERBOSE);

            $Record_Key = $row['Record_Key'];
            $Entered_By_Email = $row['Entered_By_Email'];
            $Entered_By_First_Name = $row['Entered_By_First_Name'];
            $Entered_By_Last_Name = $row['Entered_By_Last_Name'];
            $Event_Title = $row['Event_Title'];
            $Event_Category = $row['Event_Category'];
            $Event_Category_2 = $row['Event_Category_2'];
            $Event_Category_3 = $row['Event_Category_3'];
            $Event_Provider = $row['Event_Provider'];

            $output->writeln("INFO: checking taxonomies for Event_Title='$Event_Title', Event_Provider='$Event_Provider'");

            if( isset($this->taxonomyLevel1Map[$Event_Category]) ) {
                $Event_Category = $this->taxonomyLevel1Map[$Event_Category];
            }
            if( isset($this->taxonomyLevel2Map[$Event_Category_2]) ) {
                $Event_Category_2 = $this->taxonomyLevel2Map[$Event_Category_2];
            }
//            if( isset($this->taxonomyLevel3Map[$level3]) ) {
//                $Event_Category_3 = $this->taxonomyLevel3Map[$Event_Category_3];
//            }

            $output->writeln("INFO: searching for $Event_Category:$Event_Category_2");
            $taxonomy = $taxonomyRepository->findFuzzy($Event_Category, $Event_Category_2);
            if( $taxonomy ) {
                $output->writeln("DEBUG: FOUND!", OutputInterface::VERBOSITY_VERBOSE);
            } else {
                $output->writeln("WARNING: category $Event_Category:$Event_Category_2 not found");
            }

            ++$countEvents;
        }
        $output->writeln("--------------------------------------------------------------");
        $output->writeln("INFO: checked $countEvents Event(s)");

        $output->writeln( "Exitting" );
    }
}

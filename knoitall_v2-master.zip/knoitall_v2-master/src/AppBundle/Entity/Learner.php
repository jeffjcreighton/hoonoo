<?php

namespace AppBundle\Entity;

use Doctrine\Common\Collections\Collection;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\HttpFoundation\File\File;
use Vich\UploaderBundle\Mapping\Annotation as Vich;
use Gedmo\Mapping\Annotation as Gedmo;
use AppBundle\Entity\Traits\IdWithAccessors;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use AppBundle\Entity\FeedLikeEvent;
use AppBundle\Entity\FeedCommentEvent;
use AppBundle\Entity\FeedShareEvent;
use AppBundle\Entity\FeedFollowProvider;

/**
 * Class Learner
 *
 * @package AppBundle\Entity
 * @ORM\Entity(repositoryClass="AppBundle\Repository\LearnerRepository")
 * @ORM\Table(name="learner")
 * @UniqueEntity("nickname")
 * @Vich\Uploadable
 */
class Learner
{
    use IdWithAccessors;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $timestampAdded;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private $timestampUpdated;

    /**
     * @ORM\ManyToOne(targetEntity="Person", inversedBy="learners")
     * @ORM\JoinColumn(name="person_id", referencedColumnName="id", nullable=false)
     */
    private $person;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=128, nullable=true)
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(type="text", nullable=true)
     */
    private $profile;

    /**
     * @var string
     *
     * @ORM\Column(type="text", nullable=true)
     */
    private $specialNeeds;

    /**
     * @var string
     *
     * @ORM\Column(type="text", nullable=true)
     */
    private $additionalInformation;

    /**
     * @var Collection
     *
     * @ORM\ManyToMany(targetEntity="Goal", inversedBy="learners")
     * @ORM\JoinTable(name="learner_goal")
     */
    private $goals;

    /**
     * @var string
     *
     * @ORM\Column(type="text", nullable=true)
     */
    private $goalsOther;

    /**
     * @var Collection
     *
     * @ORM\ManyToMany(targetEntity="Age", inversedBy="learners")
     * @ORM\JoinTable(name="learner_age")
     */
    private $ages;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=128, nullable=true, unique=true)
     */
    private $nickname;

    /**
     * @var Collection
     *
     * @ORM\ManyToMany(targetEntity="Taxonomy", inversedBy="learners")
     * @ORM\JoinTable(name="learner_taxonomy")
     * )
     */
    private $taxonomies;

    /**
     * @ORM\Column(type="string", length=128, nullable=true)
     *
     * @var string
     */
    private $image;

    /**
     * @Vich\UploadableField(mapping="learner_media", fileNameProperty="image")
     *
     * @var File
     */
    private $imageFile;

    /**
     * @var boolean
     *
     * @ORM\Column(type="boolean", nullable=false)
     */
    private $published;

    /**
     * @var boolean
     *
     * @ORM\Column(type="boolean", nullable=true)
     */
    private $selfFollower;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=23, nullable=false)
     */
    private $hash;

    /**
     * @var integer
     *
     * @ORM\Column(type="integer", nullable=true)
     */
    private $originalRecordKey;

    /**
     * @ORM\OneToMany(targetEntity="AppBundle\Entity\FeedLikeEvent", mappedBy="learner")
     */
    private $feedLikeEvents;

    /**
     * @ORM\OneToMany(targetEntity="AppBundle\Entity\FeedCommentEvent", mappedBy="learner")
     */
    private $feedCommentEvents;

    /**
     * @ORM\OneToMany(targetEntity="AppBundle\Entity\FeedShareEvent", mappedBy="learner")
     */
    private $feedShareEvents;

    /**
     * @ORM\OneToMany(targetEntity="FeedFollowProvider", mappedBy="learner")
     */
    private $feedFollowProviders;

    /**
     * @ORM\ManyToMany(targetEntity="Provider", inversedBy="followers")
     * @ORM\JoinTable(name="follow")
     */
    private $followees;

    /**
     *
     * @ORM\OneToMany(targetEntity="PathwayFeedPos", mappedBy="learner")
     */
    private $pathwayFeedPoss;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->taxonomies = new ArrayCollection();
        $this->goals = new ArrayCollection();
        $this->ages = new ArrayCollection();
        $this->hash = uniqid( '', true );
        $this->published = false;
    }

    /**
     * @param \DateTime
     *
     * @return \AppBundle\Entity\Learner
     */
    public function setTimestampAdded($timestampAdded)
    {
        $this->timestampAdded = $timestampAdded;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampAdded()
    {
        return $this->timestampAdded;
    }

    /**
     * @param \DateTime
     *
     * @return \AppBundle\Entity\Learner
     */
    public function setTimestampUpdated(\DateTime $timestampUpdated = null)
    {
        if ($timestampUpdated === null) {
            $timestampUpdated = new \DateTime();
        }

        $this->timestampUpdated = $timestampUpdated;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampUpdated()
    {
        return $this->timestampUpdated;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return \AppBundle\Entity\Learner
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set profile
     *
     * @param string $profile
     *
     * @return \AppBundle\Entity\Learner
     */
    public function setProfile($profile)
    {
        $this->profile = $profile;

        return $this;
    }

    /**
     * Get profile
     *
     * @return string
     */
    public function getProfile()
    {
        return $this->profile;
    }

    /**
     * Set additionalInformation
     *
     * @param string $additionalInformation
     *
     * @return \AppBundle\Entity\Learner
     */
    public function setAdditionalInformation($additionalInformation)
    {
        $this->additionalInformation = $additionalInformation;

        return $this;
    }

    /**
     * Get additionalInformation
     *
     * @return string
     */
    public function getAdditionalInformation()
    {
        return $this->additionalInformation;
    }

    /**
     * Set nickname
     *
     * @param string $nickname
     *
     * @return \AppBundle\Entity\Learner
     */
    public function setNickname($nickname)
    {
        $this->nickname = $nickname;

        return $this;
    }

    /**
     * Get nickname
     *
     * @return string
     */
    public function getNickname()
    {
        return $this->nickname;
    }

    /**
     * Set person
     *
     * @param \AppBundle\Entity\Person $person
     *
     * @return \AppBundle\Entity\Learner
     */
    public function setPerson(Person $person = null)
    {
        $this->person = $person;

        return $this;
    }

    /**
     * Get person
     *
     * @return \AppBundle\Entity\Person
     */
    public function getPerson()
    {
        return $this->person;
    }

    /**
     * Add taxonomy
     *
     * @param \AppBundle\Entity\Taxonomy $taxonomy
     *
     * @return \AppBundle\Entity\Learner
     */
    public function addTaxonomy(Taxonomy $taxonomy)
    {
        $this->taxonomies[] = $taxonomy;

        return $this;
    }

    /**
     * Remove taxonomy
     *
     * @param \AppBundle\Entity\Taxonomy $taxonomy
     */
    public function removeTaxonomy(Taxonomy $taxonomy)
    {
        $this->taxonomies->removeElement($taxonomy);
    }

    /**
     * Get taxonomies
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getTaxonomies()
    {
        return $this->taxonomies;
    }

    /**
     * Set specialNeeds
     *
     * @param string $specialNeeds
     *
     * @return \AppBundle\Entity\Learner
     */
    public function setSpecialNeeds($specialNeeds)
    {
        $this->specialNeeds = $specialNeeds;

        return $this;
    }

    /**
     * Get specialNeeds
     *
     * @return string
     */
    public function getSpecialNeeds()
    {
        return $this->specialNeeds;
    }

    /**
     * Add goal
     *
     * @param \AppBundle\Entity\Goal $goal
     *
     * @return \AppBundle\Entity\Learner
     */
    public function addGoal(Goal $goal)
    {
        $this->goals[] = $goal;

        return $this;
    }

    /**
     * Remove goal
     *
     * @param \AppBundle\Entity\Goal $goal
     */
    public function removeGoal(Goal $goal)
    {
        $this->goals->removeElement($goal);
    }

    /**
     * Get goals
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getGoals()
    {
        return $this->goals;
    }

    /**
     * Add age
     *
     * @param \AppBundle\Entity\Age $age
     *
     * @return \AppBundle\Entity\Learner
     */
    public function addAge(Age $age)
    {
        $this->ages[] = $age;

        return $this;
    }

    /**
     * Remove age
     *
     * @param \AppBundle\Entity\Age $age
     */
    public function removeAge(Age $age)
    {
        $this->ages->removeElement($age);
    }

    /**
     * Get ages
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getAges()
    {
        return $this->ages;
    }

    /**
     * Set goalsOther
     *
     * @param string $goalsOther
     *
     * @return \AppBundle\Entity\Learner
     */
    public function setGoalsOther($goalsOther)
    {
        $this->goalsOther = $goalsOther;

        return $this;
    }

    /**
     * Get goalsOther
     *
     * @return string
     */
    public function getGoalsOther()
    {
        return $this->goalsOther;
    }

    /**
     * @param File|null $imageFile
     *
     * @return \AppBundle\Entity\Learner
     */
    public function setImageFile(File $imageFile = null)
    {
        $this->imageFile = $imageFile;

        // VERY IMPORTANT:
        // It is required that at least one field changes if you are using Doctrine,
        // otherwise the event listeners won't be called and the file is lost
        if ($imageFile) {
            $this->timestampUpdated = new \DateTime('now');
        }

        return $this;
    }

    /**
     * @return File
     */
    public function getImageFile()
    {
        return $this->imageFile;
    }

    /**
     * @param $image
     *
     * @return \AppBundle\Entity\Learner
     */
    public function setImage($image)
    {
        $this->image = $image;

        return $this;
    }

    /**
     * @return string
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * Add pathwayFeedPos
     *
     * @param \AppBundle\Entity\PathwayFeedPos $pathwayFeedPos
     *
     * @return \AppBundle\Entity\Learner
     */
    public function addPathwayFeedPos(PathwayFeedPos $pathwayFeedPos)
    {
        $this->pathwayFeedPoss[] = $pathwayFeedPos;

        return $this;
    }

    /**
     * Remove pathwayFeedPos
     *
     * @param \AppBundle\Entity\PathwayFeedPos $pathwayFeedPos
     */
    public function removePathwayFeedPos(PathwayFeedPos $pathwayFeedPos)
    {
        $this->pathwayFeedPoss->removeElement($pathwayFeedPos);
    }

    /**
     * Get pathwayFeedPoss
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPathwayFeedPoss()
    {
        return $this->pathwayFeedPoss;
    }

    /**
     * Set published
     *
     * @param boolean $published
     *
     * @return \AppBundle\Entity\Learner
     */
    public function setPublished($published)
    {
        $this->published = $published;

        return $this;
    }

    /**
     * Get published
     *
     * @return boolean
     */
    public function getPublished()
    {
        return $this->published;
    }

    /**
     * Set hash
     *
     * @param string $hash
     *
     * @return \AppBundle\Entity\Learner
     */
    public function setHash($hash)
    {
        $this->hash = $hash;

        return $this;
    }

    /**
     * Get hash
     *
     * @return string
     */
    public function getHash()
    {
        return $this->hash;
    }

    /**
     * @return array
     */
    public function getIsotopes()
    {
        return ['type-learner'];
    }

    /**
     * Set originalRecordKey
     *
     * @param integer $originalRecordKey
     *
     * @return Learner
     */
    public function setOriginalRecordKey($originalRecordKey)
    {
        $this->originalRecordKey = $originalRecordKey;

        return $this;
    }

    /**
     * Get originalRecordKey
     *
     * @return integer
     */
    public function getOriginalRecordKey()
    {
        return $this->originalRecordKey;
    }

    /**
     * Set selfFollower
     *
     * @param boolean $selfFollower
     *
     * @return Learner
     */
    public function setSelfFollower($selfFollower)
    {
        $this->selfFollower = $selfFollower;

        return $this;
    }

    /**
     * Get selfFollower
     *
     * @return boolean
     */
    public function getSelfFollower()
    {
        return $this->selfFollower;
    }

    /**
     * Add feedLikeEvent
     *
     * @param FeedLikeEvent $feedLikeEvent
     *
     * @return User
     */
    public function addFeedLikeEvent(FeedLikeEvent $feedLikeEvent)
    {
        $this->feedLikeEvents[] = $feedLikeEvent;

        return $this;
    }

    /**
     * Remove feedLikeEvent
     *
     * @param \AppBundle\Entity\FeedLikeEvent $feedLikeEvent
     */
    public function removeFeedLikeEvent(FeedLikeEvent $feedLikeEvent)
    {
        $this->feedLikeEvents->removeElement($feedLikeEvent);
    }

    /**
     * Get feedLikeEvents
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getFeedLikeEvents()
    {
        return $this->feedLikeEvents;
    }

    /**
     * Add feedCommentEvent
     *
     * @param FeedCommentEvent $feedCommentEvent
     *
     * @return User
     */
    public function addFeedCommentEvent(FeedCommentEvent $feedCommentEvent)
    {
        $this->feedCommentEvents[] = $feedCommentEvent;

        return $this;
    }

    /**
     * Remove feedCommentEvent
     *
     * @param FeedCommentEvent $feedCommentEvent
     */
    public function removeFeedCommentEvent(FeedCommentEvent $feedCommentEvent)
    {
        $this->feedCommentEvents->removeElement($feedCommentEvent);
    }

    /**
     * Get feedCommentEvents
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getFeedCommentEvents()
    {
        return $this->feedCommentEvents;
    }

    /**
     * Add feedShareEvent
     *
     * @param FeedShareEvent $feedShareEvent
     *
     * @return User
     */
    public function addFeedShareEvent(FeedShareEvent $feedShareEvent)
    {
        $this->feedShareEvents[] = $feedShareEvent;

        return $this;
    }

    /**
     * Remove feedShareEvent
     *
     * @param FeedShareEvent $feedShareEvent
     */
    public function removeFeedShareEvent(FeedShareEvent $feedShareEvent)
    {
        $this->feedShareEvents->removeElement($feedShareEvent);
    }

    /**
     * Get feedShareEvents
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getFeedShareEvents()
    {
        return $this->feedShareEvents;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getId() . ' ' . $this->getTitle() . ' ' . $this->getNickname();
    }

    /**
     * Add feedFollowProvider
     *
     * @param \AppBundle\Entity\FeedFollowProvider $feedFollowProvider
     *
     * @return Learner
     */
    public function addFeedFollowProvider(\AppBundle\Entity\FeedFollowProvider $feedFollowProvider)
    {
        $this->feedFollowProviders[] = $feedFollowProvider;

        return $this;
    }

    /**
     * Remove feedFollowProvider
     *
     * @param \AppBundle\Entity\FeedFollowProvider $feedFollowProvider
     */
    public function removeFeedFollowProvider(\AppBundle\Entity\FeedFollowProvider $feedFollowProvider)
    {
        $this->feedFollowProviders->removeElement($feedFollowProvider);
    }

    /**
     * Get feedFollowProviders
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getFeedFollowProviders()
    {
        return $this->feedFollowProviders;
    }

    /**
     * Add followee
     *
     * @param \AppBundle\Entity\Provider $followee
     *
     * @return Learner
     */
    public function addFollowee(\AppBundle\Entity\Provider $followee)
    {
        $this->followees[] = $followee;

        return $this;
    }

    /**
     * Remove followee
     *
     * @param \AppBundle\Entity\Provider $followee
     */
    public function removeFollowee(\AppBundle\Entity\Provider $followee)
    {
        $this->followees->removeElement($followee);
    }

    /**
     * Get followees
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getFollowees()
    {
        return $this->followees;
    }
}

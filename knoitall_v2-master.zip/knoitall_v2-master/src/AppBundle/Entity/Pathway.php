<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\HttpFoundation\File\File;
use Vich\UploaderBundle\Mapping\Annotation as Vich;
use Gedmo\Mapping\Annotation as Gedmo;
use AppBundle\Entity\Traits\IdWithAccessors;
use AppBundle\Entity\Traits\AddressWithAccessors;

/**
 * Class Pathway
 *
 * @package AppBundle\Entity
 * @ORM\Table(name="pathway")
 * @ORM\Entity(repositoryClass="\AppBundle\Repository\PathwayRepository")
 * @Vich\Uploadable
 */
class Pathway
{
    use IdWithAccessors;
    use AddressWithAccessors;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $timestampAdded;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private $timestampUpdated;

    /**
     * @var \AppBundle\Entity\Provider
     *
     * @ORM\ManyToOne(targetEntity="Provider", inversedBy="pathways")
     * @ORM\JoinColumn(name="provider_id", referencedColumnName="id", nullable=false)
     */
    private $provider;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64, nullable=true)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(type="text", nullable=true)
     */
    private $description;

    /**
     * @ORM\Column(type="string", length=128, nullable=true)
     *
     * @var string
     */
    private $image;

    /**
     * @Vich\UploadableField(mapping="pathway_media", fileNameProperty="image")
     *
     * @var File
     */
    private $imageFile;

    /**
     * @var boolean
     *
     * @ORM\Column(type="boolean", nullable=false)
     */
    private $published;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=23, nullable=false)
     */
    private $hash;

    /**
     * @var integer
     *
     * @ORM\Column(type="integer", nullable=true)
     */
    private $originalRecordKey;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $originalEnteredDateTime;

    /**
     * @var Collection
     *
     * @ORM\ManyToMany(targetEntity="Taxonomy", inversedBy="pathways")
     * @ORM\JoinTable(name="pathway_taxonomy")
     */
    private $taxonomies;

    /**
     *
     * @ORM\OneToMany(targetEntity="PathwayEvent", mappedBy="pathway")
     */
    private $pathwayEvents;

    /**
     *
     * @ORM\OneToMany(targetEntity="PathwayFeedPos", mappedBy="pathway")
     */
    private $pathwayFeedPoss;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->taxonomies = new ArrayCollection(); 
        $this->published = false;
        $this->hash = uniqid( '', true );
    }

    /**
     * @param \DateTime
     *
     * @return Pathway
     */
    public function setTimestampAdded($timestampAdded)
    {
        $this->timestampAdded = $timestampAdded;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampAdded()
    {
        return $this->timestampAdded;
    }

    /**
     * @param \DateTime
     *
     * @return Pathway
     */
    public function setTimestampUpdated(\DateTime $timestampUpdated = null)
    {
        if ($timestampUpdated === null) {
            $timestampUpdated = new \DateTime();
        }

        $this->timestampUpdated = $timestampUpdated;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampUpdated()
    {
        return $this->timestampUpdated;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return \AppBundle\Entity\Pathway
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return \AppBundle\Entity\Pathway
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @param File|null $imageFile
     *
     * @return \AppBundle\Entity\Pathway
     */
    public function setImageFile(File $imageFile = null)
    {
        $this->imageFile = $imageFile;

        // VERY IMPORTANT:
        // It is required that at least one field changes if you are using Doctrine,
        // otherwise the event listeners won't be called and the file is lost
        if ($imageFile) {
            $this->timestampUpdated = new \DateTime('now');
        }

        return $this;
    }

    /**
     * @return File
     */
    public function getImageFile()
    {
        return $this->imageFile;
    }

    /**
     * @param $image
     *
     * @return \AppBundle\Entity\Pathway
     */
    public function setImage($image)
    {
        $this->image = $image;

        return $this;
    }

    /**
     * @return string
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * Set provider
     *
     * @param \AppBundle\Entity\Provider $provider
     *
     * @return \AppBundle\Entity\Pathway
     */
    public function setProvider(Provider $provider = null)
    {
        $this->provider = $provider;

        return $this;
    }

    /**
     * Get provider
     *
     * @return \AppBundle\Entity\Provider
     */
    public function getProvider()
    {
        return $this->provider;
    }

    /**
     * Add taxonomy
     *
     * @param \AppBundle\Entity\Taxonomy $taxonomy
     *
     * @return \AppBundle\Entity\Pathway
     */
    public function addTaxonomy(Taxonomy $taxonomy)
    {
        $this->taxonomies[] = $taxonomy;

        return $this;
    }

    /**
     * Remove taxonomy
     *
     * @param \AppBundle\Entity\Taxonomy $taxonomy
     */
    public function removeTaxonomy(Taxonomy $taxonomy)
    {
        $this->taxonomies->removeElement($taxonomy);
    }

    /**
     * Get taxonomies
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getTaxonomies()
    {
        return $this->taxonomies;
    }

    /**
     * Add pathwayEvent
     *
     * @param \AppBundle\Entity\PathwayEvent $pathwayEvent
     *
     * @return \AppBundle\Entity\Pathway
     */
    public function addPathwayEvent(PathwayEvent $pathwayEvent)
    {
        $this->pathwayEvents[] = $pathwayEvent;

        return $this;
    }

    /**
     * Remove pathwayEvent
     *
     * @param \AppBundle\Entity\PathwayEvent $pathwayEvent
     */
    public function removePathwayEvent(PathwayEvent $pathwayEvent)
    {
        $this->pathwayEvents->removeElement($pathwayEvent);
    }

    /**
     * Get pathwayEvents
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPathwayEvents()
    {
        return $this->pathwayEvents;
    }

    /**
     * Add pathwayFeedPos
     *
     * @param \AppBundle\Entity\PathwayFeedPos $pathwayFeedPos
     *
     * @return \AppBundle\Entity\Pathway
     */
    public function addPathwayFeedPos(PathwayFeedPos $pathwayFeedPos)
    {
        $this->pathwayFeedPoss[] = $pathwayFeedPos;

        return $this;
    }

    /**
     * Remove pathwayFeedPos
     *
     * @param \AppBundle\Entity\PathwayFeedPos $pathwayFeedPos
     */
    public function removePathwayFeedPos(PathwayFeedPos $pathwayFeedPos)
    {
        $this->pathwayFeedPoss->removeElement($pathwayFeedPos);
    }

    /**
     * Get pathwayFeedPoss
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPathwayFeedPoss()
    {
        return $this->pathwayFeedPoss;
    }

    /**
     * Set published
     *
     * @param boolean $published
     *
     * @return \AppBundle\Entity\Pathway
     */
    public function setPublished($published)
    {
        $this->published = $published;

        return $this;
    }

    /**
     * Get published
     *
     * @return boolean
     */
    public function getPublished()
    {
        return $this->published;
    }

    /**
     * Set hash
     *
     * @param string $hash
     *
     * @return Pathway
     */
    public function setHash($hash)
    {
        $this->hash = $hash;

        return $this;
    }

    /**
     * Get hash
     *
     * @return string
     */
    public function getHash()
    {
        return $this->hash;
    }

    /**
     * Set originalRecordKey
     *
     * @param integer $originalRecordKey
     *
     * @return Pathway
     */
    public function setOriginalRecordKey($originalRecordKey)
    {
        $this->originalRecordKey = $originalRecordKey;

        return $this;
    }

    /**
     * Get originalRecordKey
     *
     * @return integer
     */
    public function getOriginalRecordKey()
    {
        return $this->originalRecordKey;
    }

    /**
     * Set originalEnteredDateTime
     *
     * @param \DateTime $originalEnteredDateTime
     *
     * @return Pathway
     */
    public function setOriginalEnteredDateTime($originalEnteredDateTime)
    {
        $this->originalEnteredDateTime = $originalEnteredDateTime;

        return $this;
    }

    /**
     * Get originalEnteredDateTime
     *
     * @return \DateTime
     */
    public function getOriginalEnteredDateTime()
    {
        return $this->originalEnteredDateTime;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->name;
    }
}

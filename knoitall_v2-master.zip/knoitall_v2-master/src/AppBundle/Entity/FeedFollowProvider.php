<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use AppBundle\Entity\Traits\IdWithAccessors;
use AppBundle\Entity\User;
use AppBundle\Entity\Provider;

/**
 * Class FeedFollowProvider
 *
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="feed_follow_provider")
 */
class FeedFollowProvider
{
    use IdWithAccessors;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $timestampAdded;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private $timestampUpdated;

    /**
     * @var Learner
     *
     * @ORM\ManyToOne(targetEntity="Learner", inversedBy="feedFollowProviders")
     * @ORM\JoinColumn(name="learner_id", referencedColumnName="id", nullable=false)
     */
    private $learner;

    /**
     * @var Provider
     *
     * @ORM\ManyToOne(targetEntity="Provider", inversedBy="feedFollowProviders")
     * @ORM\JoinColumn(name="provider_id", referencedColumnName="id", nullable=false)
     */
    private $provider;

    /**
     * @var boolean
     *
     * @ORM\Column(type="boolean", nullable=false, options={"default":false})
     */
    private $follow;

    /**
     * @var boolean
     *
     * @ORM\Column(type="boolean", nullable=false, options={"default": false})
     */
    private $pushedToGetstream;

    /**
     * Set timestampAdded
     *
     * @param \DateTime $timestampAdded
     *
     * @return FeedFollowProvider
     */
    public function setTimestampAdded($timestampAdded)
    {
        $this->timestampAdded = $timestampAdded;

        return $this;
    }

    /**
     * Get timestampAdded
     *
     * @return \DateTime
     */
    public function getTimestampAdded()
    {
        return $this->timestampAdded;
    }

    /**
     * Set timestampUpdated
     *
     * @param \DateTime $timestampUpdated
     *
     * @return FeedFollowProvider
     */
    public function setTimestampUpdated($timestampUpdated)
    {
        $this->timestampUpdated = $timestampUpdated;

        return $this;
    }

    /**
     * Get timestampUpdated
     *
     * @return \DateTime
     */
    public function getTimestampUpdated()
    {
        return $this->timestampUpdated;
    }

    /**
     * Set learner
     *
     * @param Learner $learner
     *
     * @return FeedFollowProvider
     */
    public function setLearner(Learner $learner)
    {
        $this->learner = $learner;

        return $this;
    }

    /**
     * Get learner
     *
     * @return Learner
     */
    public function getLearner()
    {
        return $this->learner;
    }

    /**
     * Set provider
     *
     * @param  $provider
     *
     * @return FeedFollowProvider
     */
    public function setProvider($provider)
    {
        $this->provider = $provider;

        return $this;
    }

    /**
     * Get provider
     *
     * @return 
     */
    public function getProvider()
    {
        return $this->provider;
    }

    /**
     * Set pushedToGetstream
     *
     * @param boolean $pushedToGetstream
     *
     * @return FeedFollowProvider
     */
    public function setPushedToGetstream($pushedToGetstream)
    {
        $this->pushedToGetstream = $pushedToGetstream;

        return $this;
    }

    /**
     * Get pushedToGetstream
     *
     * @return boolean
     */
    public function getPushedToGetstream()
    {
        return $this->pushedToGetstream;
    }

    /**
     * Set follow
     *
     * @param boolean $follow
     *
     * @return FeedFollowProvider
     */
    public function setFollow($follow)
    {
        $this->follow = $follow;

        return $this;
    }

    /**
     * Get follow
     *
     * @return boolean
     */
    public function getFollow()
    {
        return $this->follow;
    }
}

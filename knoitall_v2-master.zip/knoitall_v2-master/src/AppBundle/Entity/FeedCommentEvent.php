<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use AppBundle\Entity\Traits\IdWithAccessors;
use AppBundle\Entity\User;
use AppBundle\Entity\Event;

/**
 * Class FeedCommentEvent
 *
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="feed_comment_event")
 */
class FeedCommentEvent
{
    use IdWithAccessors;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $timestampAdded;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private $timestampUpdated;

    /**
     * @var Learner
     *
     * @ORM\ManyToOne(targetEntity="Learner", inversedBy="feedCommentEvents")
     * @ORM\JoinColumn(name="learner_id", referencedColumnName="id", nullable=false)
     */
    private $learner;

    /**
     * @var Event
     *
     * @ORM\ManyToOne(targetEntity="Event", inversedBy="feedCommentEvents")
     * @ORM\JoinColumn(name="event_id", referencedColumnName="id", nullable=false)
     */
    private $event;

    /**
     * @var string
     *
     * @ORM\Column(type="text", nullable=false)
     */
    private $commentText;

    /**
     * @var $pushedToGetstream
     *
     * @ORM\Column(type="boolean", nullable=false, options={"default":false})
     */
    private $pushedToGetstream;

    /**
     * @var integer
     *
     * @ORM\Column(type="integer", nullable=true)
     */
    private $replyAmount;

    /**
     * @var FeedCommentEvent
     *
     * @ORM\ManyToOne(targetEntity="FeedCommentEvent", inversedBy="feedCommentEvents")
     * @ORM\JoinColumn(name="reply_from_comment_id", referencedColumnName="id", nullable=true)
     */
    private $replyFromComment;

    /**
     * @var FeedCommentEvent
     *
     * @ORM\ManyToOne(targetEntity="FeedCommentEvent", inversedBy="feedCommentEvents")
     * @ORM\JoinColumn(name="reply_to_comment_id", referencedColumnName="id", nullable=true)
     */
    private $replyToComment;

    /**
     * Set timestampAdded
     *
     * @param \DateTime $timestampAdded
     *
     * @return FeedCommentEvent
     */
    public function setTimestampAdded($timestampAdded)
    {
        $this->timestampAdded = $timestampAdded;

        return $this;
    }

    /**
     * Get timestampAdded
     *
     * @return \DateTime
     */
    public function getTimestampAdded()
    {
        return $this->timestampAdded;
    }

    /**
     * Set timestampUpdated
     *
     * @param \DateTime $timestampUpdated
     *
     * @return FeedCommentEvent
     */
    public function setTimestampUpdated($timestampUpdated)
    {
        $this->timestampUpdated = $timestampUpdated;

        return $this;
    }

    /**
     * Get timestampUpdated
     *
     * @return \DateTime
     */
    public function getTimestampUpdated()
    {
        return $this->timestampUpdated;
    }

    /**
     * Set learner
     *
     * @param Learner $learner
     *
     * @return FeedCommentEvent
     */
    public function setLearner(Learner $learner)
    {
        $this->learner = $learner;

        return $this;
    }

    /**
     * Get learner
     *
     * @return Learner
     */
    public function getLearner()
    {
        return $this->learner;
    }

    /**
     * Set event
     *
     * @param  $event
     *
     * @return FeedCommentEvent
     */
    public function setEvent($event)
    {
        $this->event = $event;

        return $this;
    }

    /**
     * Get event
     *
     * @return 
     */
    public function getEvent()
    {
        return $this->event;
    }

    /**
     * Set commentText
     *
     * @param string $commentText
     *
     * @return FeedCommentEvent
     */
    public function setCommentText($commentText)
    {
        $this->commentText = $commentText;

        return $this;
    }

    /**
     * Get commentText
     *
     * @return string
     */
    public function getCommentText()
    {
        return $this->commentText;
    }

    /**
     * Set pushedToGetstream
     *
     * @param boolean $pushedToGetstream
     *
     * @return FeedCommentEvent
     */
    public function setPushedToGetstream($pushedToGetstream)
    {
        $this->pushedToGetstream = $pushedToGetstream;

        return $this;
    }

    /**
     * Get pushedToGetstream
     *
     * @return boolean
     */
    public function getPushedToGetstream()
    {
        return $this->pushedToGetstream;
    }

    /**
     * Set replyAmount
     *
     * @param integer replyAmount
     *
     * @return FeedCommentEvent
     */
    public function setReplyAmount($replyAmount)
    {
        $this->replyAmount = $replyAmount;

        return $this;
    }

    /**
     * Get replyAmount
     *
     * @return integer
     */
    public function getReplyAmount()
    {
        return $this->replyAmount;
    }

    /**
     * Set replyFromComment
     *
     * @param FeedCommentEvent $replyFromComment
     *
     * @return FeedCommentEvent
     */
    public function setReplyFromComment(FeedCommentEvent $replyFromComment)
    {
        $this->replyFromComment = $replyFromComment;

        return $this;
    }

    /**
     * Get replyFromComment
     *
     * @return FeedCommentEvent
     */
    public function getReplyFromComment()
    {
        return $this->replyFromComment;
    }

    /**
     * Set replyToComment
     *
     * @param FeedCommentEvent $replyToComment
     *
     * @return FeedCommentEvent
     */
    public function setReplyToComment(FeedCommentEvent $replyToComment)
    {
        $this->replyToComment = $replyToComment;

        return $this;
    }

    /**
     * Get replyToComment
     *
     * @return FeedCommentEvent
     */
    public function getReplyToComment()
    {
        return $this->replyToComment;
    }
}

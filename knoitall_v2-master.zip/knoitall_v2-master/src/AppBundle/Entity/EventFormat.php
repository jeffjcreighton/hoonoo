<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Gedmo\Mapping\Annotation as Gedmo;
use AppBundle\Entity\Traits\IdWithAccessors;

/**
 * Class EventFormat
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="event_format")
 */
class EventFormat
{
    use IdWithAccessors;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $timestampAdded;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private $timestampUpdated;

    /**
     * @var string
     *
     * @Gedmo\Slug(fields={"description"})
     * @ORM\Column(type="string", length=128, unique=true)
     */
    private $slug;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64)  // , unique=true)
     */
    private $code;

     /**
     * @var string
     *
     * @ORM\Column(type="string", length=64)  // , unique=true)
     */
    private $listgroup;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64)
     */
    private $description;

    /**
     * @ORM\ManyToOne(targetEntity="EventFormatSection", inversedBy="eventFormats")
     * @ORM\JoinColumn(name="event_format_section_id", referencedColumnName="id")
     */
    private $eventFormatSection;

    /**
     * @var ArrayCollection
     *
     * @ORM\OneToMany(targetEntity="Event", mappedBy="eventFormat")
     */
    private $events;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->events = new ArrayCollection();
    }

    /**
     * @param \DateTime
     *
     * @return EventFormat
     */
    public function setTimestampAdded($timestampAdded)
    {
        $this->timestampAdded = $timestampAdded;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampAdded()
    {
        return $this->timestampAdded;
    }

    /**
     * @param \DateTime
     *
     * @return EventFormat
     */
    public function setTimestampUpdated(\DateTime $timestampUpdated = null)
    {
        if ($timestampUpdated === null) {
            $timestampUpdated = new \DateTime();
        }

        $this->timestampUpdated = $timestampUpdated;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampUpdated()
    {
        return $this->timestampUpdated;
    }

    /**
     * Set slug
     *
     * @param string $slug
     *
     * @return EventFormat
     */
    public function setSlug($slug)
    {
        $this->slug = $slug;

        return $this;
    }

    /**
     * @return string
     */
    public function getSlug()
    {
        return $this->slug;
    }

    /**
     * Set code
     *
     * @param string $code
     *
     * @return EventFormat
     */
    public function setCode($code)
    {
        $this->code = $code;

        return $this;
    }

    /**
     * Get code
     *
     * @return string
     */
    public function getCode()
    {
        return $this->code;
    }

     /**
     * Set listgroup
     *
     * @param string $listgroup
     *
     * @return EventFormat
     */
    public function setListGroup($list)
    {
        $this->listgroup = $listgroup;

        return $this;
    }

    /**
     * Get listgroup
     *
     * @return string
     */
    public function getListGroup()
    {
        return $this->listgroup;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return EventFormat
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Add event
     *
     * @param Event $event
     *
     * @return EventFormat
     */
    public function addEvent(Event $event)
    {
        $this->events[] = $event;

        return $this;
    }

    /**
     * Remove event
     *
     * @param Event $event
     *
     * @return EventFormat
     */
    public function removeEvent(Event $event)
    {
        $this->events->removeElement($event);

        return $this;
    }

    /**
     * Get events
     *
     * @return ArrayCollection
     */
    public function getEvents()
    {
        return $this->events;
    }

    /**
     * Set event format section
     *
     * @param EventFormatSection $eventFormatSection
     *
     * @return EventFormat
     */
    public function setEventFormatSection(EventFormatSection $eventFormatSection)
    {
        $this->eventFormatSection = $eventFormatSection;

        return $this;
    }

    /**
     * Get event format section
     *
     * @return EventFormatSection
     */
    public function getEventFormatSection()
    {
        return $this->eventFormatSection;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->description;
    }
}

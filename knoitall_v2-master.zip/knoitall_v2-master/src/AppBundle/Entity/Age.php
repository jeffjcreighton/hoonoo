<?php

namespace AppBundle\Entity;

use AppBundle\Entity\Traits\IdWithAccessors;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * Class Age
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="age")
 */
class Age
{
    use IdWithAccessors;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=16, nullable=false)
     */
    private $description;

    /**
     * @ORM\ManyToMany(targetEntity="Learner", mappedBy="ages")
     */
    private $learners;

    /**
     * @ORM\ManyToMany(targetEntity="Event", mappedBy="ages")
     */
    private $events;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->learners = new ArrayCollection();
        $this->events = new ArrayCollection();
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return \AppBundle\Entity\Age
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Add learner
     *
     * @param \AppBundle\Entity\Learner $learner
     *
     * @return \AppBundle\Entity\Age
     */
    public function addLearner(Learner $learner)
    {
        $this->learners[] = $learner;

        return $this;
    }

    /**
     * Remove learner
     *
     * @param \AppBundle\Entity\Learner $learner
     */
    public function removeLearner(Learner $learner)
    {
        $this->learners->removeElement($learner);
    }

    /**
     * Get learners
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getLearners()
    {
        return $this->learners;
    }

    /**
     * Add event
     *
     * @param \AppBundle\Entity\Event $event
     *
     * @return \AppBundle\Entity\Age
     */
    public function addEvent(Event $event)
    {
        $this->events[] = $event;

        return $this;
    }

    /**
     * Remove event
     *
     * @param \AppBundle\Entity\Event $event
     */
    public function removeEvent(Event $event)
    {
        $this->events->removeElement($event);
    }

    /**
     * Get events
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getEvents()
    {
        return $this->events;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getDescription();
    }
}

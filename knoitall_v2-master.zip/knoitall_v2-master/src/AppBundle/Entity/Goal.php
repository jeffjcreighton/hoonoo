<?php

namespace AppBundle\Entity;

use AppBundle\Entity\Traits\IdWithAccessors;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * Class Goal
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="goal")
 */
class Goal
{
    use IdWithAccessors;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64, nullable=false)
     */
    private $description;

    /**
     * @ORM\ManyToMany(targetEntity="Learner", mappedBy="goals")
     */
    private $learners;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->learners = new ArrayCollection();
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return \AppBundle\Entity\Goal
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Add learner
     *
     * @param \AppBundle\Entity\Learner $learner
     *
     * @return \AppBundle\Entity\Goal
     */
    public function addLearner(\AppBundle\Entity\Learner $learner)
    {
        $this->learners[] = $learner;

        return $this;
    }

    /**
     * Remove learner
     *
     * @param \AppBundle\Entity\Learner $learner
     */
    public function removeLearner(\AppBundle\Entity\Learner $learner)
    {
        $this->learners->removeElement($learner);
    }

    /**
     * Get learners
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getLearners()
    {
        return $this->learners;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getDescription();
    }
}

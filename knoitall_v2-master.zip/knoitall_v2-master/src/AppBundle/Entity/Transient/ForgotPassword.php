<?php

namespace AppBundle\Entity\Transient;

class ForgotPassword
{
    /**
     * @var string
     */
    public $email;

    /**
     * @param $email string
     *
     * @return \AppBundle\Entity\Transient\ForgotPassword
     */
    public function setEmail( $email )
    {
        $this->email = $email;

        return $this;
    }

    /**
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    public function __toString()
    {
        return $this->getEmail();
    }
}

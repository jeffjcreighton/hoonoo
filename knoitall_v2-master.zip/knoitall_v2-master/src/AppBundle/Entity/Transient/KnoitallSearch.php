<?php

namespace AppBundle\Entity\Transient;

class KnoitallSearch
{
    /**
     * @var \AppBundle\Entity\Taxonomy
     */
    public $taxonomy;

    /**
     * @var \AppBundle\Entity\Tag
     */
    public $tag;

    /**
     * @var string
     */
    public $zip;

    /**
     * @param $taxonomy \AppBundle\Entity\Taxonomy
     *
     * @return \AppBundle\Entity\Transient\KnoitallSearch
     */
    public function setTaxonomy( $taxonomy )
    {
        $this->taxonomy = $taxonomy;

        return $this;
    }

    /**
     * @return \AppBundle\Entity\Taxonomy
     */
    public function getTaxonomy()
    {
        return $this->taxonomy;
    }

    /**
     * @param $tag \AppBundle\Entity\Tag
     *
     * @return \AppBundle\Entity\Transient\KnoitallSearch
     */
    public function setTag( $tag )
    {
        $this->tag = $tag;

        return $this;
    }

    /**
     * @return \AppBundle\Entity\Tag
     */
    public function getTag()
    {
        return $this->tag;
    }

    /**
     * @param $zip string
     *
     * @return \AppBundle\Entity\Transient\KnoitallSearch
     */
    public function setZip( $zip )
    {
        $this->zip = $zip;

        return $this;
    }

    /**
     * @return string
     */
    public function getZip()
    {
        return $this->zip;
    }

    public function __toString()
    {
        return $this->getTaxonomy() . ': ' . $this->getZip();
    }
}

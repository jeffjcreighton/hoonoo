<?php

namespace AppBundle\Entity;

use AppBundle\Entity\Traits\IdWithAccessors;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * Class Project
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="project")
 */
class Project
{
    use IdWithAccessors;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64, nullable=false)
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=256, nullable=false)
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=256, nullable=true)
     */
    private $link;

    /**
     * @var Instructor
     *
     * @ORM\ManyToOne(targetEntity="Instructor", inversedBy="projects")
     * @ORM\JoinColumn(name="instructor_id", referencedColumnName="id", nullable=false)
     */
    private $instructor;

    /**
     * Set title
     *
     * @param string $title
     *
     * @return \AppBundle\Entity\Project
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return \AppBundle\Entity\Project
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set link
     *
     * @param string $link
     *
     * @return \AppBundle\Entity\Project
     */
    public function setLink($link)
    {
        $this->link = $link;

        return $this;
    }

    /**
     * Get link
     *
     * @return string
     */
    public function getLink()
    {
        return $this->link;
    }

    /**
     * Set instructor
     *
     * @param \AppBundle\Entity\Instructor $instructor
     *
     * @return \AppBundle\Entity\Project
     */
    public function setInstructor(Instructor $instructor)
    {
        $this->instructor = $instructor;

        return $this;
    }

    /**
     * Get instructor
     *
     * @return \AppBundle\Entity\Instructor
     */
    public function getInstructor()
    {
        return $this->instructor;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->title;
    }
}

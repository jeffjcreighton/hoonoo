<?php

namespace AppBundle\Entity;

use AppBundle\Entity\Traits\IdWithAccessors;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Class ScheduleSession
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="schedule_session")
 */
class ScheduleSession
{
    use IdWithAccessors;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $timestampAdded;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private $timestampUpdated;

    /**
     * @var Event
     *
     * @ORM\ManyToOne(targetEntity="Event", inversedBy="scheduleSessions")
     * @ORM\JoinColumn(name="event_id", referencedColumnName="id")
     */
    private $event;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="date", nullable=true)
     */
    private $startDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="date", nullable=true)
     */
    private $endDate;

    /**
     * @ORM\OneToMany(targetEntity="TimeSlot", mappedBy="scheduleSession")
     */
    private $timeSlots;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->timeSlots = new ArrayCollection();
    }

    /**
     * Set timestampAdded
     *
     * @param \DateTime $timestampAdded
     *
     * @return ScheduleSession
     */
    public function setTimestampAdded($timestampAdded)
    {
        $this->timestampAdded = $timestampAdded;

        return $this;
    }

    /**
     * Get timestampAdded
     *
     * @return \DateTime
     */
    public function getTimestampAdded()
    {
        return $this->timestampAdded;
    }

    /**
     * Set timestampUpdated
     *
     * @param \DateTime $timestampUpdated
     *
     * @return ScheduleSession
     */
    public function setTimestampUpdated($timestampUpdated)
    {
        $this->timestampUpdated = $timestampUpdated;

        return $this;
    }

    /**
     * Get timestampUpdated
     *
     * @return \DateTime
     */
    public function getTimestampUpdated()
    {
        return $this->timestampUpdated;
    }

    /**
     * Set event
     *
     * @param \AppBundle\Entity\Event $event
     *
     * @return ScheduleSession
     */
    public function setEvent(Event $event = null)
    {
        $this->event = $event;

        return $this;
    }

    /**
     * Get event
     *
     * @return \AppBundle\Entity\Event
     */
    public function getEvent()
    {
        return $this->event;
    }

    /**
     * Add timeSlot
     *
     * @param \AppBundle\Entity\TimeSlot $timeSlot
     *
     * @return ScheduleSession
     */
    public function addTimeSlot(TimeSlot $timeSlot)
    {
        $this->timeSlots[] = $timeSlot;

        return $this;
    }

    /**
     * Remove timeSlot
     *
     * @param \AppBundle\Entity\TimeSlot $timeSlot
     */
    public function removeTimeSlot(TimeSlot $timeSlot)
    {
        $this->timeSlots->removeElement($timeSlot);
    }

    /**
     * Get timeSlots
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getTimeSlots()
    {
        return $this->timeSlots;
    }

    /**
     * Set startDate
     *
     * @param \DateTime $startDate
     *
     * @return ScheduleSession
     */
    public function setStartDate($startDate)
    {
        $this->startDate = $startDate;

        return $this;
    }

    /**
     * Get startDate
     *
     * @return \DateTime
     */
    public function getStartDate()
    {
        return $this->startDate;
    }

    /**
     * Set endDate
     *
     * @param \DateTime $endDate
     *
     * @return ScheduleSession
     */
    public function setEndDate($endDate)
    {
        $this->endDate = $endDate;

        return $this;
    }

    /**
     * Get endDate
     *
     * @return \DateTime
     */
    public function getEndDate()
    {
        return $this->endDate;
    }

    public function __toString()
    {
        return (string)$this->getId();
    }
}

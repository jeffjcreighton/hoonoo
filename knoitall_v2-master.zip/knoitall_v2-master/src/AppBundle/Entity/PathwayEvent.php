<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use AppBundle\Entity\Traits\IdWithAccessors;
use AppBundle\Entity\Pathway;
use AppBundle\Entity\Event;

/**
 * Class PathwayEvent
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="pathway_event")
 */
class PathwayEvent
{
    use IdWithAccessors;

    /**
     * @var \AppBundle\Entity\Pathway
     *
     * @ORM\ManyToOne(targetEntity="Pathway", inversedBy="pathwayEvents")
     * @ORM\JoinColumn(name="pathway_id", referencedColumnName="id", nullable=false)
     */
    private $pathway;

    /**
     * @var \AppBundle\Entity\Event
     *
     * @ORM\ManyToOne(targetEntity="Event", inversedBy="pathwayEvents")
     * @ORM\JoinColumn(name="event_id", referencedColumnName="id", nullable=false)
     */
    private $event;

    /**
     * @var int
     *
     * @ORM\Column(type="integer", nullable=false)
     */
    private $sequence;

    /**
     * Set sequence
     *
     * @param integer $sequence
     *
     * @return \AppBundle\Entity\PathwayEvent
     */
    public function setSequence($sequence)
    {
        $this->sequence = $sequence;

        return $this;
    }

    /**
     * Get sequence
     *
     * @return integer
     */
    public function getSequence()
    {
        return $this->sequence;
    }

    /**
     * Set pathway
     *
     * @param \AppBundle\Entity\Pathway $pathway
     *
     * @return \AppBundle\Entity\PathwayEvent
     */
    public function setPathway(\AppBundle\Entity\Pathway $pathway = null)
    {
        $this->pathway = $pathway;

        return $this;
    }

    /**
     * Get pathway
     *
     * @return \AppBundle\Entity\Pathway
     */
    public function getPathway()
    {
        return $this->pathway;
    }

    /**
     * Set event
     *
     * @param \AppBundle\Entity\Event $event
     *
     * @return \AppBundle\Entity\PathwayEvent
     */
    public function setEvent(\AppBundle\Entity\Event $event = null)
    {
        $this->event = $event;

        return $this;
    }

    /**
     * Get event
     *
     * @return \AppBundle\Entity\Event
     */
    public function getEvent()
    {
        return $this->event;
    }
}

<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use AppBundle\Entity\Traits\IdWithAccessors;
use AppBundle\Entity\Learner;
use AppBundle\Entity\Event;

/**
 * Class FeedShareEvent
 *
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="feed_share_event")
 */
class FeedShareEvent
{
    use IdWithAccessors;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $timestampAdded;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private $timestampUpdated;

    /**
     * @var Learner
     *
     * @ORM\ManyToOne(targetEntity="Learner", inversedBy="feedShareEvents")
     * @ORM\JoinColumn(name="learner_id", referencedColumnName="id", nullable=false)
     */
    private $learner;

    /**
     * @var Event
     *
     * @ORM\ManyToOne(targetEntity="Event", inversedBy="feedShareEvents")
     * @ORM\JoinColumn(name="event_id", referencedColumnName="id", nullable=false)
     */
    private $event;

    /**
     * @var $pushedToGetstream
     *
     * @ORM\Column(type="boolean", nullable=false, options={"default":false})
     */
    private $pushedToGetstream;

    /**
     * Set timestampAdded
     *
     * @param \DateTime $timestampAdded
     *
     * @return FeedShareEvent
     */
    public function setTimestampAdded($timestampAdded)
    {
        $this->timestampAdded = $timestampAdded;

        return $this;
    }

    /**
     * Get timestampAdded
     *
     * @return \DateTime
     */
    public function getTimestampAdded()
    {
        return $this->timestampAdded;
    }

    /**
     * Set timestampUpdated
     *
     * @param \DateTime $timestampUpdated
     *
     * @return FeedShareEvent
     */
    public function setTimestampUpdated($timestampUpdated)
    {
        $this->timestampUpdated = $timestampUpdated;

        return $this;
    }

    /**
     * Get timestampUpdated
     *
     * @return \DateTime
     */
    public function getTimestampUpdated()
    {
        return $this->timestampUpdated;
    }

    /**
     * Set learner
     *
     * @param Learner $learner
     *
     * @return FeedShareEvent
     */
    public function setLearner(Learner $learner)
    {
        $this->learner = $learner;

        return $this;
    }

    /**
     * Get learner
     *
     * @return Learner
     */
    public function getLearner()
    {
        return $this->learner;
    }

    /**
     * Set event
     *
     * @param  $event
     *
     * @return FeedShareEvent
     */
    public function setEvent($event)
    {
        $this->event = $event;

        return $this;
    }

    /**
     * Get event
     *
     * @return 
     */
    public function getEvent()
    {
        return $this->event;
    }

    /**
     * Set pushedToGetstream
     *
     * @param boolean $pushedToGetstream
     *
     * @return FeedShareEvent
     */
    public function setPushedToGetstream($pushedToGetstream)
    {
        $this->pushedToGetstream = $pushedToGetstream;

        return $this;
    }

    /**
     * Get pushedToGetstream
     *
     * @return boolean
     */
    public function getPushedToGetstream()
    {
        return $this->pushedToGetstream;
    }
}

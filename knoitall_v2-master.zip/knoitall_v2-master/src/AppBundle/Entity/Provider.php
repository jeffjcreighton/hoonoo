<?php

namespace AppBundle\Entity;

use Doctrine\Common\Collections\Collection;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\HttpFoundation\File\File;
use Vich\UploaderBundle\Mapping\Annotation as Vich;
use Gedmo\Mapping\Annotation as Gedmo;
use AppBundle\Entity\Traits\IdWithAccessors;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;

/**
 * Class Provider
 *
 * @package AppBundle\Entity
 * @ORM\Table(name="provider")
 * @ORM\Entity(repositoryClass="\AppBundle\Repository\ProviderRepository")
 * @UniqueEntity("nickname")
 * @Vich\Uploadable
 */
class Provider
{
    use IdWithAccessors;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $timestampAdded;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private $timestampUpdated;

    /**
     * @ORM\ManyToMany(targetEntity="Person", inversedBy="providers")
     * @ORM\JoinTable(name="provider_person")
     */
    private $persons;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=128, nullable=true)
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=128, nullable=true)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=128, nullable=true)
     */
    private $department;

    /**
     * @var string
     *
     * @ORM\Column(type="text", nullable=true)
     */
    private $profile;

    /**
     * @var string
     *
     * @ORM\Column(type="text", nullable=true)
     */
    private $additionalInformation;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=128, nullable=true, unique=true)
     */
    private $nickname;

    /**
     * @var Collection
     *
     * @ORM\ManyToMany(targetEntity="Taxonomy", inversedBy="providers")
     * @ORM\JoinTable(name="provider_taxonomy")
     */
    private $taxonomies;

    /**
     * @var Collection
     *
     * @ORM\OneToMany(targetEntity="Location", mappedBy="provider")
     */
    private $locations;

    /**
     * @var Collection
     *
     * @ORM\OneToMany(targetEntity="Event", mappedBy="provider")
     */
    private $events;

    /**
     * @var Collection
     *
     * @ORM\OneToMany(targetEntity="Pathway", mappedBy="provider")
     */
    private $pathways;

    /**
     * @var Collection
     *
     * @ORM\ManyToMany(targetEntity="Provider", inversedBy="supplyToProviders")
     * @ORM\JoinTable(name="supplier", joinColumns={@ORM\JoinColumn(name="provider_id", referencedColumnName="id")}, inverseJoinColumns={@ORM\JoinColumn(name="supplier_provider_id", referencedColumnName="id")})
     */
    private $suppliers;

    /**
     * @var Collection
     *
     * @ORM\ManyToMany(targetEntity="Provider", mappedBy="suppliers")
     */
    private $supplyToProviders;

    /**
     * @ORM\Column(type="string", length=128, nullable=true)
     *
     * @var string
     */
    private $image;

    /**
     * @Vich\UploadableField(mapping="provider_media", fileNameProperty="image")
     *
     * @var File
     */
    private $imageFile;

    /**
     * @var boolean
     *
     * @ORM\Column(type="boolean", nullable=false)
     */
    private $published;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=23, nullable=false)
     */
    private $hash;

    /**
     * @var integer
     *
     * @ORM\Column(type="integer", nullable=true)
     */
    private $originalRecordKey;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $originalEnteredDateTime;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=45, nullable=true)
     */
    private $originalEnteredByEmail;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=25, nullable=true)
     */
    private $originalEnteredByFirstName;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=25, nullable=true)
     */
    private $originalEnteredByLastName;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=45, nullable=true)
     */
    private $originalEnteredByOrganization;

    /**
     * @ORM\OneToMany(targetEntity="FeedFollowProvider", mappedBy="provider")
     */
    private $feedFollowProviders;

    /**
     * @ORM\ManyToMany(targetEntity="Learner", mappedBy="followees")
     */
    private $followers;

    /**
     * @ORM\OneToMany(targetEntity="AppBundle\Entity\FeedAddPostEvent", mappedBy="provider")
     */
    private $feedAddPostEvents;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->taxonomies = new ArrayCollection();
        $this->locations = new ArrayCollection();
        $this->events = new ArrayCollection();
        $this->persons = new ArrayCollection();
        $this->pathways = new ArrayCollection();
        $this->suppliers = new ArrayCollection();
        $this->supplyToProviders = new ArrayCollection();
        $this->hash = uniqid( '', true );
        $this->published = false;
    }

    /**
     * @param \DateTime
     *
     * @return \AppBundle\Entity\Provider
     */
    public function setTimestampAdded($timestampAdded)
    {
        $this->timestampAdded = $timestampAdded;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampAdded()
    {
        return $this->timestampAdded;
    }

    /**
     * @param \DateTime
     *
     * @return \AppBundle\Entity\Provider
     */
    public function setTimestampUpdated(\DateTime $timestampUpdated = null)
    {
        if ($timestampUpdated === null) {
            $timestampUpdated = new \DateTime();
        }

        $this->timestampUpdated = $timestampUpdated;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampUpdated()
    {
        return $this->timestampUpdated;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return \AppBundle\Entity\Provider
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set profile
     *
     * @param string $profile
     *
     * @return \AppBundle\Entity\Provider
     */
    public function setProfile($profile)
    {
        $this->profile = $profile;

        return $this;
    }

    /**
     * Get profile
     *
     * @return string
     */
    public function getProfile()
    {
        return $this->profile;
    }

    /**
     * Set additionalInformation
     *
     * @param string $additionalInformation
     *
     * @return \AppBundle\Entity\Provider
     */
    public function setAdditionalInformation($additionalInformation)
    {
        $this->additionalInformation = $additionalInformation;

        return $this;
    }

    /**
     * Get additionalInformation
     *
     * @return string
     */
    public function getAdditionalInformation()
    {
        return $this->additionalInformation;
    }

    /**
     * Set nickname
     *
     * @param string $nickname
     *
     * @return \AppBundle\Entity\Provider
     */
    public function setNickname($nickname)
    {
        $this->nickname = $nickname;

        return $this;
    }

    /**
     * Get nickname
     *
     * @return string
     */
    public function getNickname()
    {
        return $this->nickname;
    }

    /**
     * Add taxonomy
     *
     * @param \AppBundle\Entity\Taxonomy $taxonomy
     *
     * @return \AppBundle\Entity\Provider
     */
    public function addTaxonomy(Taxonomy $taxonomy)
    {
        $this->taxonomies[] = $taxonomy;

        return $this;
    }

    /**
     * Remove taxonomy
     *
     * @param \AppBundle\Entity\Taxonomy $taxonomy
     */
    public function removeTaxonomy(Taxonomy $taxonomy)
    {
        $this->taxonomies->removeElement($taxonomy);
    }

    /**
     * Get taxonomies
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getTaxonomies()
    {
        return $this->taxonomies;
    }

    /**
     * Add location
     *
     * @param \AppBundle\Entity\Location $location
     *
     * @return \AppBundle\Entity\Provider
     */
    public function addLocation(Location $location)
    {
        $this->locations[] = $location;

        return $this;
    }

    /**
     * Remove location
     *
     * @param \AppBundle\Entity\Location $location
     */
    public function removeLocation(Location $location)
    {
        $this->locations->removeElement($location);
    }

    /**
     * Get locations
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getLocations()
    {
        return $this->locations;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return \AppBundle\Entity\Provider
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set department
     *
     * @param string $department
     *
     * @return \AppBundle\Entity\Provider
     */
    public function setDepartment($department)
    {
        $this->department = $department;

        return $this;
    }

    /**
     * Get department
     *
     * @return string
     */
    public function getDepartment()
    {
        return $this->department;
    }

    /**
     * Add event
     *
     * @param \AppBundle\Entity\Event $event
     *
     * @return \AppBundle\Entity\Provider
     */
    public function addEvent(Event $event)
    {
        $this->events[] = $event;

        return $this;
    }

    /**
     * Remove event
     *
     * @param \AppBundle\Entity\Event $event
     */
    public function removeEvent(Event $event)
    {
        $this->events->removeElement($event);
    }

    /**
     * Get events
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getEvents()
    {
        return $this->events;
    }

    /**
     * Add person
     *
     * @param \AppBundle\Entity\Person $person
     *
     * @return \AppBundle\Entity\Provider
     */
    public function addPerson(Person $person)
    {
        $this->persons[] = $person;

        return $this;
    }

    /**
     * Remove person
     *
     * @param \AppBundle\Entity\Person $person
     */
    public function removePerson(Person $person)
    {
        $this->persons->removeElement($person);
    }

    /**
     * Get persons
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPersons()
    {
        return $this->persons;
    }

    /**
     * Add pathway
     *
     * @param \AppBundle\Entity\Pathway $pathway
     *
     * @return \AppBundle\Entity\Provider
     */
    public function addPathway(Pathway $pathway)
    {
        $this->pathways[] = $pathway;

        return $this;
    }

    /**
     * Remove pathway
     *
     * @param \AppBundle\Entity\Pathway $pathway
     */
    public function removePathway(Pathway $pathway)
    {
        $this->pathways->removeElement($pathway);
    }

    /**
     * Get pathways
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPathways()
    {
        return $this->pathways;
    }

    /**
     * @param File|null $imageFile
     *
     * @return \AppBundle\Entity\Provider
     */
    public function setImageFile(File $imageFile = null)
    {
        $this->imageFile = $imageFile;

        // VERY IMPORTANT:
        // It is required that at least one field changes if you are using Doctrine,
        // otherwise the event listeners won't be called and the file is lost
        if ($imageFile) {
            $this->timestampUpdated = new \DateTime('now');
        }

        return $this;
    }

    /**
     * @return File
     */
    public function getImageFile()
    {
        return $this->imageFile;
    }

    /**
     * @param $image
     *
     * @return \AppBundle\Entity\Provider
     */
    public function setImage($image)
    {
        $this->image = $image;

        return $this;
    }

    /**
     * @return string
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * Set published
     *
     * @param boolean $published
     *
     * @return \AppBundle\Entity\Provider
     */
    public function setPublished($published)
    {
        $this->published = $published;

        return $this;
    }

    /**
     * Get published
     *
     * @return boolean
     */
    public function getPublished()
    {
        return $this->published;
    }

    /**
     * Set hash
     *
     * @param string $hash
     *
     * @return \AppBundle\Entity\Provider
     */
    public function setHash($hash)
    {
        $this->hash = $hash;

        return $this;
    }

    /**
     * Get hash
     *
     * @return string
     */
    public function getHash()
    {
        return $this->hash;
    }

    /**
     * @return array
     */
    public function getIsotopes()
    {
        return [
            'type-provider',
            'provider-' . $this->getNickname()
        ];
    }

    /**
     * Set originalRecordKey
     *
     * @param integer $originalRecordKey
     *
     * @return Provider
     */
    public function setOriginalRecordKey($originalRecordKey)
    {
        $this->originalRecordKey = $originalRecordKey;

        return $this;
    }

    /**
     * Get originalRecordKey
     *
     * @return integer
     */
    public function getOriginalRecordKey()
    {
        return $this->originalRecordKey;
    }

    /**
     * Set originalEnteredDateTime
     *
     * @param \DateTime $originalEnteredDateTime
     *
     * @return Provider
     */
    public function setOriginalEnteredDateTime($originalEnteredDateTime)
    {
        $this->originalEnteredDateTime = $originalEnteredDateTime;

        return $this;
    }

    /**
     * Get originalEnteredDateTime
     *
     * @return \DateTime
     */
    public function getOriginalEnteredDateTime()
    {
        return $this->originalEnteredDateTime;
    }

    /**
     * Set originalEnteredByEmail
     *
     * @param string $originalEnteredByEmail
     *
     * @return Provider
     */
    public function setOriginalEnteredByEmail($originalEnteredByEmail)
    {
        $this->originalEnteredByEmail = $originalEnteredByEmail;

        return $this;
    }

    /**
     * Get originalEnteredByEmail
     *
     * @return string
     */
    public function getOriginalEnteredByEmail()
    {
        return $this->originalEnteredByEmail;
    }

    /**
     * Set originalEnteredByFirstName
     *
     * @param string $originalEnteredByFirstName
     *
     * @return Provider
     */
    public function setOriginalEnteredByFirstName($originalEnteredByFirstName)
    {
        $this->originalEnteredByFirstName = $originalEnteredByFirstName;

        return $this;
    }

    /**
     * Get originalEnteredByFirstName
     *
     * @return string
     */
    public function getOriginalEnteredByFirstName()
    {
        return $this->originalEnteredByFirstName;
    }

    /**
     * Set originalEnteredByLastName
     *
     * @param string $originalEnteredByLastName
     *
     * @return Provider
     */
    public function setOriginalEnteredByLastName($originalEnteredByLastName)
    {
        $this->originalEnteredByLastName = $originalEnteredByLastName;

        return $this;
    }

    /**
     * Get originalEnteredByLastName
     *
     * @return string
     */
    public function getOriginalEnteredByLastName()
    {
        return $this->originalEnteredByLastName;
    }

    /**
     * Set originalEnteredByOrganization
     *
     * @param string $originalEnteredByOrganization
     *
     * @return Provider
     */
    public function setOriginalEnteredByOrganization($originalEnteredByOrganization)
    {
        $this->originalEnteredByOrganization = $originalEnteredByOrganization;

        return $this;
    }

    /**
     * Get originalEnteredByOrganization
     *
     * @return string
     */
    public function getOriginalEnteredByOrganization()
    {
        return $this->originalEnteredByOrganization;
    }

    /**
     * Add supplier
     *
     * @param \AppBundle\Entity\Provider $supplier
     *
     * @return Provider
     */
    public function addSupplier(Provider $supplier)
    {
        $this->suppliers[] = $supplier;

        return $this;
    }

    /**
     * Remove supplier
     *
     * @param \AppBundle\Entity\Provider $supplier
     */
    public function removeSupplier(Provider $supplier)
    {
        $this->suppliers->removeElement($supplier);
    }

    /**
     * Get suppliers
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getSuppliers()
    {
        return $this->suppliers;
    }

    /**
     * Add supplyToProvider
     *
     * @param \AppBundle\Entity\Provider $supplyToProvider
     *
     * @return Provider
     */
    public function addSupplyToProvider(Provider $supplyToProvider)
    {
        $this->supplyToProviders[] = $supplyToProvider;

        return $this;
    }

    /**
     * Remove supplyToProvider
     *
     * @param \AppBundle\Entity\Provider $supplyToProvider
     */
    public function removeSupplyToProvider(Provider $supplyToProvider)
    {
        $this->supplyToProviders->removeElement($supplyToProvider);
    }

    /**
     * Get supplyToProviders
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getSupplyToProviders()
    {
        return $this->supplyToProviders;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        /*
         * TODO: perhaps we should disable null titles for providers; for now just use the id to generate a provider name so that things work:
         */
        if( ! $this->getTitle() ) {
            return "Provider " . $this->getId();
        }

        return $this->getTitle();
    }

    /**
     * Add feedFollowProvider
     *
     * @param \AppBundle\Entity\FeedFollowProvider $feedFollowProvider
     *
     * @return Provider
     */
    public function addFeedFollowProvider(\AppBundle\Entity\FeedFollowProvider $feedFollowProvider)
    {
        $this->feedFollowProviders[] = $feedFollowProvider;

        return $this;
    }

    /**
     * Remove feedFollowProvider
     *
     * @param \AppBundle\Entity\FeedFollowProvider $feedFollowProvider
     */
    public function removeFeedFollowProvider(\AppBundle\Entity\FeedFollowProvider $feedFollowProvider)
    {
        $this->feedFollowProviders->removeElement($feedFollowProvider);
    }

    /**
     * Get feedFollowProviders
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getFeedFollowProviders()
    {
        return $this->feedFollowProviders;
    }

    /**
     * Add follower
     *
     * @param \AppBundle\Entity\Learner $follower
     *
     * @return Provider
     */
    public function addFollower(\AppBundle\Entity\Learner $follower)
    {
        $this->followers[] = $follower;

        return $this;
    }

    /**
     * Remove follower
     *
     * @param \AppBundle\Entity\Learner $follower
     */
    public function removeFollower(\AppBundle\Entity\Learner $follower)
    {
        $this->followers->removeElement($follower);
    }

    /**
     * Get followers
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getFollowers()
    {
        return $this->followers;
    }

    /**
     * Add feedAddPostEvent
     *
     * @param FeedAddPostEvent $feedAddPostEvent
     *
     * @return User
     */
    public function addFeedAddPostEvent(FeedAddPostEvent $feedAddPostEvent)
    {
        $this->feedAddPostEvents[] = $feedAddPostEvent;

        return $this;
    }

    /**
     * Remove feedAddPostEvent
     *
     * @param FeedAddPostEvent $feedAddPostEvent
     */
    public function removeFeedAddPostEvent(FeedAddPostEvent $feedAddPostEvent)
    {
        $this->feedAddPostEvents->removeElement($feedAddPostEvent);
    }

    /**
     * Get feedAddPostEvents
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getFeedAddPostEvents()
    {
        return $this->feedAddPostEvents;
    }
}

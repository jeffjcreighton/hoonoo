<?php

namespace AppBundle\Entity;

use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\HttpFoundation\File\File;
use Vich\UploaderBundle\Mapping\Annotation as Vich;
use Gedmo\Mapping\Annotation as Gedmo;
use AppBundle\Entity\Traits\IdWithAccessors;

/**
 * Class Event
 *
 * @package AppBundle\Entity
 * @ORM\Entity(repositoryClass="AppBundle\Repository\EventRepository")
 * @ORM\Table(name="event")
 * @Vich\Uploadable
 */
class Event
{
    use IdWithAccessors;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $timestampAdded;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private $timestampUpdated;

    /**
     * @var Provider
     *
     * @ORM\ManyToOne(targetEntity="Provider", inversedBy="events")
     * @ORM\JoinColumn(name="provider_id", referencedColumnName="id", nullable=false)
     */
    private $provider;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=128)
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(type="text", nullable=true)
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(type="text", nullable=true)
     */
    private $learningOutcomes;

    /**
     * @var string
     *
     * @ORM\Column(type="text", nullable=true)
     */
    private $requirements;

    /**
     * @var string
     *
     * @ORM\Column(type="text", nullable=true)
     */
    private $specialInstructions;

    /**
     * @ORM\ManyToOne(targetEntity="EventFormat", inversedBy="events")
     * @ORM\JoinColumn(name="event_format_id", referencedColumnName="id", nullable=false)
     */
    private $eventFormat;

    /**
     * resources, classes, tutoring, certificates, degrees, supplies, etc.
     *
     * non-mapped property
     *
     * @var string
     * TODO: fix this: the type of the attribute should be EventFormatSection; but it could probably be removed entirely
     */
    private $eventFormatSection;

    /**
     * @var Collection
     *
     * @ORM\ManyToMany(targetEntity="Taxonomy", inversedBy="events")
     * @ORM\JoinTable(name="event_taxonomy")
     */
    private $taxonomies;

    /**
     * @var Collection
     *
     * @ORM\ManyToMany(targetEntity="Age", inversedBy="events")
     * @ORM\JoinTable(name="event_age")
     */
    private $ages;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $startDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $endDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $startTime;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $endTime;

    /**
     * @var boolean
     *
     * @ORM\Column(type="boolean", nullable=true)
     */
    private $sunday;

    /**
     * @var boolean
     *
     * @ORM\Column(type="boolean", nullable=true)
     */
    private $monday;   

    /**
     * @var boolean
     *
     * @ORM\Column(type="boolean", nullable=true)
     */
    private $tuesday;

    /**
     * @var boolean
     *
     * @ORM\Column(type="boolean", nullable=true)
     */
    private $wednesday;

    /**
     * @var boolean
     *
     * @ORM\Column(type="boolean", nullable=true)
     */
    private $thursday;

    /**
     * @var boolean
     *
     * @ORM\Column(type="boolean", nullable=true)
     */
    private $friday;    

    /**
     * @var boolean
     *
     * @ORM\Column(type="boolean", nullable=true)
     */
    private $saturday;    

    ///**
    // * @var string
    // *
    // * @ORM\Column(type="string", length=16, nullable=true)
    // */
    //private $dow;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=16, nullable=true)
     */
    private $postFrequency;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $postingDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $expirationDate;

    /**
     * @var int
     *
     * @ORM\Column(type="integer", nullable=true)
     */
    private $numberOfSeats;

    /**
     * @var int
     *
     * @ORM\Column(type="integer", nullable=true)
     */
    private $minimumSeats;

    /**
     * @var float
     *
     * @ORM\Column(type="decimal", scale=2, nullable=true)
     */
    private $price;

    /**
     * @var float
     *
     * @ORM\Column(type="decimal", scale=2, nullable=true)
     */
    private $discount;

    /**
     * @var int
     *
     * @ORM\Column(type="integer", nullable=true)
     */
    private $units;

    /**
     * @var Location
     *
     * @ORM\ManyToOne(targetEntity="Location", inversedBy="events")
     * @ORM\JoinColumn(name="location_id", referencedColumnName="id", nullable=true)
     */
    private $location;

    /**
     * @var Advisor
     *
     * @ORM\ManyToOne(targetEntity="Advisor", inversedBy="events")
     * @ORM\JoinColumn(name="advisor_id", referencedColumnName="id", nullable=true)
     */
    private $advisor;

    /**
     * @var Instructor
     *
     * @ORM\ManyToOne(targetEntity="Instructor", inversedBy="events")
     * @ORM\JoinColumn(name="instructor_id", referencedColumnName="id", nullable=true)
     */
    private $instructor;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=256, nullable=true)
     */
    private $externalLink;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64, nullable=true)
     */
    private $registrationLink;

    /**
     * @ORM\Column(type="string", length=128, nullable=true)
     *
     * @var string
     */
    private $image;

    /**
     * @Vich\UploadableField(mapping="event_media", fileNameProperty="image")
     *
     * @var File
     */
    private $imageFile;

    /**
     * @var boolean
     *
     * @ORM\Column(type="boolean", nullable=false)
     */
    private $published;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=23, nullable=false)
     */
    private $hash;

    /**
     * @var string
     *
     * @Gedmo\Slug(fields={"title"})
     * @ORM\Column(type="string", length=128, unique=true)
     */
    private $slug;

    /**
     * @ORM\OneToMany(targetEntity="ScheduleSession", mappedBy="event")
     */
    private $scheduleSessions;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64, nullable=true)
     */
    private $locationName;

    /**
     * @var LocationType
     *
     * @ORM\ManyToOne(targetEntity="LocationType")
     * @ORM\JoinColumn(name="location_type_id", referencedColumnName="id", nullable=true)
     */
    private $locationType;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=32, nullable=true)
     */
    private $locationPhone;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=256, nullable=true)
     */
    private $locationDescription;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64, nullable=true)
     */
    private $locationStreet;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64, nullable=true)
     */
    private $locationCity;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=16, nullable=true)
     */
    private $locationZip;

    /**
     * @var $locationState
     *
     * @ORM\ManyToOne(targetEntity="State")
     * @ORM\JoinColumn(name="location_state_id", referencedColumnName="id", nullable=true)
     */
    private $locationState;

    /**
     * @var $locationCountry
     *
     * @ORM\ManyToOne(targetEntity="Country")
     * @ORM\JoinColumn(name="location_country_id", referencedColumnName="id", nullable=true)
     */
    private $locationCountry;

    /**
     * @var float
     *
     * @ORM\Column(type="decimal", precision=10, scale=7, nullable=true)
     */
    private $locationLatitude;

    /**
     * @var float
     *
     * @ORM\Column(type="decimal", precision=10, scale=7, nullable=true)
     */
    private $locationLongitude;

    /**
     * e.g. for a course consisting of 10 90-minute classes, we would have numberOfSessions=10
     *
     * @var integer
     *
     * @ORM\Column(type="integer", nullable=true)
     */
    private $numberOfSessions;

    /**
     * @var float
     *
     * @ORM\Column(type="float", nullable=true)
     */
    private $durationAmount;

    /**
     * @ORM\ManyToOne(targetEntity="TimeUnit")
     * @ORM\JoinColumn(name="duration_time_unit_id", referencedColumnName="id", nullable=true)
     */
    private $durationTimeUnit;

    /**
     * @var integer
     *
     * @ORM\Column(type="integer", nullable=true)
     */
    private $originalRecordKey;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $originalEnteredDateTime;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=45, nullable=true)
     */
    private $originalEnteredByEmail;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=25, nullable=true)
     */
    private $originalEnteredByFirstName;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=25, nullable=true)
     */
    private $originalEnteredByLastName;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=45, nullable=true)
     */
    private $originalEnteredByOrganization;

    /**
     * @ORM\OneToMany(targetEntity="AppBundle\Entity\FeedLikeEvent", mappedBy="event")
     */
    private $feedLikeEvents;

    /**
     * @ORM\OneToMany(targetEntity="AppBundle\Entity\FeedCommentEvent", mappedBy="event")
     */
    private $feedCommentEvents;

    /**
     * @ORM\OneToMany(targetEntity="AppBundle\Entity\FeedShareEvent", mappedBy="event")
     */
    private $feedShareEvents;

    /**
     * @ORM\OneToMany(targetEntity="AppBundle\Entity\FeedAddPostEvent", mappedBy="event")
     */
    private $feedAddPostEvents;

    /**     
     *
     * @ORM\OneToMany(targetEntity="PathwayEvent", mappedBy="event")
     */
    private $pathwayEvents;

    /**
     * @var integer
     *
     * @ORM\Column(type="integer", nullable=true)
     */
    private $commentAmount;

    /**
     * @var integer
     *
     * @ORM\Column(type="integer", nullable=true)
     */
    private $likeAmount;


    /**
     * Constructor
     */
    public function __construct()
    {         
        $this->durationTimeUnit = 3;
        $this->taxonomies = new ArrayCollection();
        $this->ages = new ArrayCollection();
        $this->scheduleSessions = new ArrayCollection();
        $this->hash = uniqid( '', true );
        $this->published = false;
    }

    /**
     * @param \DateTime
     *
     * @return \AppBundle\Entity\Event
     */
    public function setTimestampAdded($timestampAdded)
    {
        $this->timestampAdded = $timestampAdded;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampAdded()
    {
        return $this->timestampAdded;
    }

    /**
     * @param \DateTime
     *
     * @return \AppBundle\Entity\Event
     */
    public function setTimestampUpdated(\DateTime $timestampUpdated = null)
    {
        if ($timestampUpdated === null) {
            $timestampUpdated = new \DateTime();
        }

        $this->timestampUpdated = $timestampUpdated;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampUpdated()
    {
        return $this->timestampUpdated;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return Event
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return Event
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set startDate
     *
     * @param \DateTime $startDate
     *
     * @return Event
     */
    public function setStartDate($startDate)
    {
        $this->startDate = $startDate;

        return $this;
    }

    /**
     * Get startDate
     *
     * @return \DateTime
     */
    public function getStartDate()
    {
        return $this->startDate;
    }

    /**
     * Set endDate
     *
     * @param \DateTime $endDate
     *
     * @return Event
     */
    public function setEndDate($endDate)
    {
        $this->endDate = $endDate;

        return $this;
    }

    /**
     * Get endDate
     *
     * @return \DateTime
     */
    public function getEndDate()
    {
        return $this->endDate;
    }

    /**
     * Set startTime
     *
     * @param \DateTime $startTime
     *
     * @return Event
     */
    public function setStartTime($startTime)
    {
        $this->startTime = $startTime;

        return $this;
    }

    /**
     * Get startTime
     *
     * @return \DateTime
     */
    public function getStartTime()
    {
        return $this->startTime;
    }

    /**
     * Set endTime
     *
     * @param \DateTime $endTime
     *
     * @return Event
     */
    public function setEndTime($endTime)
    {
        $this->endTime = $endTime;

        return $this;
    }

    /**
     * Get endTime
     *
     * @return \DateTime
     */
    public function getEndTime()
    {
        return $this->endTime;
    }

    /**
     * Set monday
     *
     * @param boolean $monday
     *
     * @return \AppBundle\Entity\Event
     */
    public function setMonday($monday)
    {
        $this->monday = $monday;

        return $this;
    }

    /**
     * Get monday
     *
     * @return boolean
     */
    public function getMonday()
    {
        return $this->monday;
    }

    /**
     * Set tuesday
     *
     * @param boolean $tuesday
     *
     * @return \AppBundle\Entity\Event
     */
    public function setTuesday($tuesday)
    {
        $this->tuesday = $tuesday;

        return $this;
    }

    /**
     * Get tuesday
     *
     * @return boolean
     */
    public function getTuesday()
    {
        return $this->tuesday;
    }

    /**
     * Set wednesday
     *
     * @param boolean $wednesday
     *
     * @return \AppBundle\Entity\Event
     */
    public function setWednesday($wednesday)
    {
        $this->wednesday = $wednesday;

        return $this;
    }

    /**
     * Get wednesday
     *
     * @return boolean
     */
    public function getWednesday()
    {
        return $this->wednesday;
    }

    /**
     * Set thursday
     *
     * @param boolean $thursday
     *
     * @return \AppBundle\Entity\Event
     */
    public function setThursday($thursday)
    {
        $this->thursday = $thursday;

        return $this;
    }

    /**
     * Get thursday
     *
     * @return boolean
     */
    public function getThursday()
    {
        return $this->thursday;
    }

    /**
     * Set friday
     *
     * @param boolean $friday
     *
     * @return \AppBundle\Entity\Event
     */
    public function setFriday($friday)
    {
        $this->friday = $friday;

        return $this;
    }

    /**
     * Get friday
     *
     * @return boolean
     */
    public function getFriday()
    {
        return $this->friday;
    }

    /**
     * Set saturday
     *
     * @param boolean $saturday
     *
     * @return \AppBundle\Entity\Event
     */
    public function setSaturday($saturday)
    {
        $this->saturday = $saturday;

        return $this;
    }

    /**
     * Get saturday
     *
     * @return boolean
     */
    public function getSaturday()
    {
        return $this->saturday;
    }

    /**
     * Set sunday
     *
     * @param boolean $sunday
     *
     * @return \AppBundle\Entity\Event
     */
    public function setSunday($sunday)
    {
        $this->sunday = $sunday;

        return $this;
    }

    /**
     * Get sunday
     *
     * @return boolean
     */
    public function getSunday()
    {
        return $this->sunday;
    }

    ///**
    // * Set dow
    // *
    // * @param string $dow
    // *
    // * @return Event
    // */
    //public function setDow($dow)
    //{
    //    $this->dow = $dow;

    //    return $this;
    //}

    ///**
    // * Get dow
    // *
    // * @return string
    // */
    //public function getDow()
    //{
    //    return $this->dow;
    //}

    /**
     * Set postFrequency
     *
     * @param string $postFrequency
     *
     * @return Event
     */
    public function setPostFrequency($postFrequency)
    {
        $this->postFrequency = $postFrequency;

        return $this;
    }

    /**
     * Get postFrequency
     *
     * @return string
     */
    public function getPostFrequency()
    {
        return $this->postFrequency;
    }

    /**
     * Set postingDate
     *
     * @param \DateTime $postingDate
     *
     * @return Event
     */
    public function setPostingDate($postingDate)
    {
        $this->postingDate = $postingDate;

        return $this;
    }

    /**
     * Get postingDate
     *
     * @return \DateTime
     */
    public function getPostingDate()
    {
        return $this->postingDate;
    }

    /**
     * Set expirationDate
     *
     * @param \DateTime $expirationDate
     *
     * @return Event
     */
    public function setExpirationDate($expirationDate)
    {
        $this->expirationDate = $expirationDate;

        return $this;
    }

    /**
     * Get expirationDate
     *
     * @return \DateTime
     */
    public function getExpirationDate()
    {
        return $this->expirationDate;
    }

    /**
     * Set numberOfSeats
     *
     * @param integer $numberOfSeats
     *
     * @return Event
     */
    public function setNumberOfSeats($numberOfSeats)
    {
        $this->numberOfSeats = $numberOfSeats;

        return $this;
    }

    /**
     * Get numberOfSeats
     *
     * @return integer
     */
    public function getNumberOfSeats()
    {
        return $this->numberOfSeats;
    }

    /**
     * Set minimumSeats
     *
     * @param integer $minimumSeats
     *
     * @return Event
     */
    public function setMinimumSeats($minimumSeats)
    {
        $this->minimumSeats = $minimumSeats;

        return $this;
    }

    /**
     * Get minimumSeats
     *
     * @return integer
     */
    public function getMinimumSeats()
    {
        return $this->minimumSeats;
    }

    /**
     * Set price
     *
     * @param string $price
     *
     * @return Event
     */
    public function setPrice($price)
    {
        $this->price = $price;

        return $this;
    }

    /**
     * Get price
     *
     * @return string
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * Set discount
     *
     * @param string $discount
     *
     * @return Event
     */
    public function setDiscount($discount)
    {
        $this->discount = $discount;

        return $this;
    }

    /**
     * Get discount
     *
     * @return string
     */
    public function getDiscount()
    {
        return $this->discount;
    }

    /**
     * Set units
     *
     * @param integer $units
     *
     * @return Event
     */
    public function setUnits($units)
    {
        $this->units = $units;

        return $this;
    }

    /**
     * Get units
     *
     * @return integer
     */
    public function getUnits()
    {
        return $this->units;
    }

    /**
     * Set provider
     *
     * @param Provider $provider
     *
     * @return Event
     */
    public function setProvider(Provider $provider)
    {
        $this->provider = $provider;

        return $this;
    }

    /**
     * Get provider
     *
     * @return Provider
     */
    public function getProvider()
    {
        return $this->provider;
    }

    /**
     * Add taxonomy
     *
     * @param \AppBundle\Entity\Taxonomy $taxonomy
     *
     * @return \AppBundle\Entity\Event
     */
    public function addTaxonomy(Taxonomy $taxonomy)
    {
        $this->taxonomies[] = $taxonomy;

        return $this;
    }

    /**
     * Remove taxonomy
     *
     * @param \AppBundle\Entity\Taxonomy $taxonomy
     */
    public function removeTaxonomy(Taxonomy $taxonomy)
    {
        $this->taxonomies->removeElement($taxonomy);
    }

    /**
     * Get taxonomies
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getTaxonomies()
    {
        return $this->taxonomies;
    }

    /**
     * Set location
     *
     * @param Location $location
     *
     * @return Event
     */
    public function setLocation(Location $location)
    {
        $this->location = $location;

        return $this;
    }

    /**
     * Get location
     *
     * @return Location
     */
    public function getLocation()
    {
        return $this->location;
    }

    /**
     * Set advisor
     *
     * @param Advisor $advisor
     *
     * @return Event
     */
    public function setAdvisor(Advisor $advisor)
    {
        $this->advisor = $advisor;

        return $this;
    }

    /**
     * Get advisor
     *
     * @return Advisor
     */
    public function getAdvisor()
    {
        return $this->advisor;
    }

    /**
     * Set instructor
     *
     * @param Instructor $instructor
     *
     * @return Event
     */
    public function setInstructor(Instructor $instructor)
    {
        $this->instructor = $instructor;

        return $this;
    }

    /**
     * Get instructor
     *
     * @return \AppBundle\Entity\Instructor
     */
    public function getInstructor()
    {
        return $this->instructor;
    }

    /**
     * Add age
     *
     * @param \AppBundle\Entity\Age $age
     *
     * @return \AppBundle\Entity\Event
     */
    public function addAge(Age $age)
    {
        $this->ages[] = $age;

        return $this;
    }

    /**
     * Remove age
     *
     * @param \AppBundle\Entity\Age $age
     */
    public function removeAge(Age $age)
    {
        $this->ages->removeElement($age);
    }

    /**
     * Get ages
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getAges()
    {
        return $this->ages;
    }

    /**
     * @param File|null $imageFile
     *
     * @return \AppBundle\Entity\Event
     */
    public function setImageFile(File $imageFile = null)
    {
        $this->imageFile = $imageFile;

        // VERY IMPORTANT:
        // It is required that at least one field changes if you are using Doctrine,
        // otherwise the event listeners won't be called and the file is lost
        if ($imageFile) {
            $this->timestampUpdated = new \DateTime('now');
        }

        return $this;
    }

    /**
     * @return File
     */
    public function getImageFile()
    {
        return $this->imageFile;
    }

    /**
     * @param $image
     *
     * @return \AppBundle\Entity\Event
     */
    public function setImage($image)
    {
        $this->image = $image;

        return $this;
    }

    /**
     * @return string
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * Set published
     *
     * @param boolean $published
     *
     * @return \AppBundle\Entity\Event
     */
    public function setPublished($published)
    {
        $this->published = $published;

        return $this;
    }

    /**
     * Get published
     *
     * @return boolean
     */
    public function getPublished()
    {
        return $this->published;
    }

    /**
     * Set hash
     *
     * @param string $hash
     *
     * @return \AppBundle\Entity\Event
     */
    public function setHash($hash)
    {
        $this->hash = $hash;

        return $this;
    }

    /**
     * Get hash
     *
     * @return string
     */
    public function getHash()
    {
        return $this->hash;
    }

    /**
     * Set slug
     *
     * @param string $slug
     *
     * @return Event
     */
    public function setSlug($slug)
    {
        $this->slug = $slug;

        return $this;
    }

    /**
     * Get slug
     *
     * @return string
     */
    public function getSlug()
    {
        return $this->slug;
    }

    /**
     * Set eventFormat
     *
     * @param \AppBundle\Entity\EventFormat $eventFormat
     *
     * @return \AppBundle\Entity\Event
     */
    public function setEventFormat(EventFormat $eventFormat)
    {
        $this->eventFormat = $eventFormat;

        return $this;
    }

    /**
     * Get eventFormat
     *
     * @return \AppBundle\Entity\EventFormat
     */
    public function getEventFormat()
    {
        return $this->eventFormat;
    }

    /**
     * Set eventFormatSection
     *
     * @param EventFormatSection $eventFormatSection
     *
     * @return Event
     */
    public function setEventFormatSection($eventFormatSection)
    {
        $this->eventFormatSection = $eventFormatSection;

        return $this;
    }

    /**
     * Get eventFormatSection
     *
     * @return EventFormatSection
     */
    public function getEventFormatSection()
    {
        return $this->eventFormatSection;
    }

    /**
     * Set learningOutcomes
     *
     * @param string $learningOutcomes
     *
     * @return \AppBundle\Entity\Event
     */
    public function setLearningOutcomes($learningOutcomes)
    {
        $this->learningOutcomes = $learningOutcomes;

        return $this;
    }

    /**
     * Get learningOutcomes
     *
     * @return string
     */
    public function getLearningOutcomes()
    {
        return $this->learningOutcomes;
    }

    /**
     * Set requirements
     *
     * @param string $requirements
     *
     * @return \AppBundle\Entity\Event
     */
    public function setRequirements($requirements)
    {
        $this->requirements = $requirements;

        return $this;
    }

    /**
     * Get requirements
     *
     * @return string
     */
    public function getRequirements()
    {
        return $this->requirements;
    }

    /**
     * Set externalLink
     *
     * @param string $externalLink
     *
     * @return \AppBundle\Entity\Event
     */
    public function setExternalLink($externalLink)
    {
        $this->externalLink = $externalLink;

        return $this;
    }

    /**
     * Get externalLink
     *
     * @return string
     */
    public function getExternalLink()
    {
        return $this->externalLink;
    }

    /**
     * Set registrationLink
     *
     * @param string $registrationLink
     *
     * @return \AppBundle\Entity\Event
     */
    public function setRegistrationLink($registrationLink)
    {
        $this->registrationLink = $registrationLink;

        return $this;
    }

    /**
     * Get registrationLink
     *
     * @return string
     */
    public function getRegistrationLink()
    {
        return $this->registrationLink;
    }

    /**
     * Set specialInstructions
     *
     * @param string $specialInstructions
     *
     * @return \AppBundle\Entity\Event
     */
    public function setSpecialInstructions($specialInstructions)
    {
        $this->specialInstructions = $specialInstructions;

        return $this;
    }

    /**
     * Get specialInstructions
     *
     * @return string
     */
    public function getSpecialInstructions()
    {
        return $this->specialInstructions;
    }

    /**
     * @return array
     */
    public function getIsotopes()
    {
        $isotopes = [
            'type-event',
            'provider-' . $this->getProvider()->getNickname(),
        ];
        if( preg_match( "/^Free Resource/", $this->getEventFormat() ) ) {
            $isotopes[] = 'format-free';
        }
        if( preg_match( "/^Product/i", $this->getEventFormat() ) ) {
            $isotopes[] = 'format-product';
        }
        if( preg_match( "/Certificate/i", $this->getEventFormat() ) ) {
            $isotopes[] = 'format-certificate';
        }
        if( preg_match( "/Undergraduate/", $this->getEventFormat() ) ) {
            $isotopes[] = 'format-undergraduate';
        }
        if( preg_match( "/Graduate/", $this->getEventFormat() ) ) {
            $isotopes[] = 'format-graduate';
        }
        if( preg_match( "/Live/", $this->getEventFormat() ) ) {
            $isotopes[] = 'format-live';
        }
        if( preg_match( "/Face-to-Face/", $this->getEventFormat() ) ) {
            $isotopes[] = 'format-facetoface';
        }
        if( preg_match( "/Online/", $this->getEventFormat() ) ) {
            $isotopes[] = 'format-online';
        }
        foreach( $this->getAges() as $age ) {
            $isotopes[] = 'age-' . strtolower( preg_replace("/-/", '', $age ) );
        }

        return $isotopes;
    }

    /**
     * Add scheduleSession
     *
     * @param \AppBundle\Entity\ScheduleSession $scheduleSession
     *
     * @return Event
     */
    public function addScheduleSession(ScheduleSession $scheduleSession)
    {
        $this->scheduleSessions[] = $scheduleSession;

        return $this;
    }

    /**
     * Remove scheduleSession
     *
     * @param \AppBundle\Entity\ScheduleSession $scheduleSession
     */
    public function removeScheduleSession(ScheduleSession $scheduleSession)
    {
        $this->scheduleSessions->removeElement($scheduleSession);
    }

    /**
     * Get scheduleSessions
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getScheduleSessions()
    {
        return $this->scheduleSessions;
    }

    /**
     * Set locationLatitude
     *
     * @param string $locationLatitude
     *
     * @return Event
     */
    public function setLocationLatitude($locationLatitude)
    {
        $this->locationLatitude = $locationLatitude;

        return $this;
    }

    /**
     * Get locationLatitude
     *
     * @return string
     */
    public function getLocationLatitude()
    {
        return $this->locationLatitude;
    }

    /**
     * Set locationLongitude
     *
     * @param string $locationLongitude
     *
     * @return Event
     */
    public function setLocationLongitude($locationLongitude)
    {
        $this->locationLongitude = $locationLongitude;

        return $this;
    }

    /**
     * Get locationLongitude
     *
     * @return string
     */
    public function getLocationLongitude()
    {
        return $this->locationLongitude;
    }

    /**
     * Set numberOfSessions
     *
     * @param integer $numberOfSessions
     *
     * @return Event
     */
    public function setNumberOfSessions($numberOfSessions)
    {
        $this->numberOfSessions = $numberOfSessions;

        return $this;
    }

    /**
     * Get numberOfSessions
     *
     * @return integer
     */
    public function getNumberOfSessions()
    {
        return $this->numberOfSessions;
    }

    /**
     * Set durationAmount
     *
     * @param float $durationAmount
     *
     * @return Event
     */
    public function setDurationAmount($durationAmount)
    {
        $this->durationAmount = $durationAmount;

        return $this;
    }

    /**
     * Get durationAmount
     *
     * @return float
     */
    public function getDurationAmount()
    {
        return $this->durationAmount;
    }

    /**
     * Set durationTimeUnit
     *
     * @param TimeUnit $durationTimeUnit
     *
     * @return Event
     */
    public function setDurationTimeUnit(TimeUnit $durationTimeUnit = null)
    {
        $this->durationTimeUnit = $durationTimeUnit;

        return $this;
    }

    /**
     * Get durationTimeUnit
     *
     * @return TimeUnit
     */
    public function getDurationTimeUnit()
    {
        return $this->durationTimeUnit;
    }

    /**
     * Set originalRecordKey
     *
     * @param integer $originalRecordKey
     *
     * @return Event
     */
    public function setOriginalRecordKey($originalRecordKey)
    {
        $this->originalRecordKey = $originalRecordKey;

        return $this;
    }

    /**
     * Get originalRecordKey
     *
     * @return integer
     */
    public function getOriginalRecordKey()
    {
        return $this->originalRecordKey;
    }

    /**
     * Set originalEnteredDateTime
     *
     * @param \DateTime $originalEnteredDateTime
     *
     * @return Event
     */
    public function setOriginalEnteredDateTime($originalEnteredDateTime)
    {
        $this->originalEnteredDateTime = $originalEnteredDateTime;

        return $this;
    }

    /**
     * Get originalEnteredDateTime
     *
     * @return \DateTime
     */
    public function getOriginalEnteredDateTime()
    {
        return $this->originalEnteredDateTime;
    }

    /**
     * Set originalEnteredByEmail
     *
     * @param string $originalEnteredByEmail
     *
     * @return Event
     */
    public function setOriginalEnteredByEmail($originalEnteredByEmail)
    {
        $this->originalEnteredByEmail = $originalEnteredByEmail;

        return $this;
    }

    /**
     * Get originalEnteredByEmail
     *
     * @return string
     */
    public function getOriginalEnteredByEmail()
    {
        return $this->originalEnteredByEmail;
    }

    /**
     * Set originalEnteredByFirstName
     *
     * @param string $originalEnteredByFirstName
     *
     * @return Event
     */
    public function setOriginalEnteredByFirstName($originalEnteredByFirstName)
    {
        $this->originalEnteredByFirstName = $originalEnteredByFirstName;

        return $this;
    }

    /**
     * Get originalEnteredByFirstName
     *
     * @return string
     */
    public function getOriginalEnteredByFirstName()
    {
        return $this->originalEnteredByFirstName;
    }

    /**
     * Set originalEnteredByLastName
     *
     * @param string $originalEnteredByLastName
     *
     * @return Event
     */
    public function setOriginalEnteredByLastName($originalEnteredByLastName)
    {
        $this->originalEnteredByLastName = $originalEnteredByLastName;

        return $this;
    }

    /**
     * Get originalEnteredByLastName
     *
     * @return string
     */
    public function getOriginalEnteredByLastName()
    {
        return $this->originalEnteredByLastName;
    }

    /**
     * Set originalEnteredByOrganization
     *
     * @param string $originalEnteredByOrganization
     *
     * @return Event
     */
    public function setOriginalEnteredByOrganization($originalEnteredByOrganization)
    {
        $this->originalEnteredByOrganization = $originalEnteredByOrganization;

        return $this;
    }

    /**
     * Get originalEnteredByOrganization
     *
     * @return string
     */
    public function getOriginalEnteredByOrganization()
    {
        return $this->originalEnteredByOrganization;
    }

    /**
     * Set locationName
     *
     * @param string $locationName
     *
     * @return Event
     */
    public function setLocationName($locationName)
    {
        $this->locationName = $locationName;

        return $this;
    }

    /**
     * Get locationName
     *
     * @return string
     */
    public function getLocationName()
    {
        return $this->locationName;
    }

    /**
     * Set locationPhone
     *
     * @param string $locationPhone
     *
     * @return Event
     */
    public function setLocationPhone($locationPhone)
    {
        $this->locationPhone = $locationPhone;

        return $this;
    }

    /**
     * Get locationPhone
     *
     * @return string
     */
    public function getLocationPhone()
    {
        return $this->locationPhone;
    }

    /**
     * Set locationDescription
     *
     * @param string $locationDescription
     *
     * @return Event
     */
    public function setLocationDescription($locationDescription)
    {
        $this->locationDescription = $locationDescription;

        return $this;
    }

    /**
     * Get locationDescription
     *
     * @return string
     */
    public function getLocationDescription()
    {
        return $this->locationDescription;
    }

    /**
     * Set locationStreet
     *
     * @param string $locationStreet
     *
     * @return Event
     */
    public function setLocationStreet($locationStreet)
    {
        $this->locationStreet = $locationStreet;

        return $this;
    }

    /**
     * Get locationStreet
     *
     * @return string
     */
    public function getLocationStreet()
    {
        return $this->locationStreet;
    }

    /**
     * Set locationCity
     *
     * @param string $locationCity
     *
     * @return Event
     */
    public function setLocationCity($locationCity)
    {
        $this->locationCity = $locationCity;

        return $this;
    }

    /**
     * Get locationCity
     *
     * @return string
     */
    public function getLocationCity()
    {
        return $this->locationCity;
    }

    /**
     * Set locationZip
     *
     * @param string $locationZip
     *
     * @return Event
     */
    public function setLocationZip($locationZip)
    {
        $this->locationZip = $locationZip;

        return $this;
    }

    /**
     * Get locationZip
     *
     * @return string
     */
    public function getLocationZip()
    {
        return $this->locationZip;
    }

    /**
     * Set locationType
     *
     * @param \AppBundle\Entity\LocationType $locationType
     *
     * @return Event
     */
    public function setLocationType(LocationType $locationType)
    {
        $this->locationType = $locationType;

        return $this;
    }

    /**
     * Get locationType
     *
     * @return \AppBundle\Entity\LocationType
     */
    public function getLocationType()
    {
        return $this->locationType;
    }

    /**
     * Set locationState
     *
     * @param \AppBundle\Entity\State $locationState
     *
     * @return Event
     */
    public function setLocationState(State $locationState = null)
    {
        $this->locationState = $locationState;

        return $this;
    }

    /**
     * Get locationState
     *
     * @return \AppBundle\Entity\State
     */
    public function getLocationState()
    {
        return $this->locationState;
    }

    /**
     * Set locationCountry
     *
     * @param \AppBundle\Entity\Country $locationCountry
     *
     * @return Event
     */
    public function setLocationCountry(Country $locationCountry = null)
    {
        $this->locationCountry = $locationCountry;

        return $this;
    }

    /**
     * Get locationCountry
     *
     * @return \AppBundle\Entity\Country
     */
    public function getLocationCountry()
    {
        return $this->locationCountry;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getTitle();
    }

    /**
     * Add feedLikeEvent
     *
     * @param FeedLikeEvent $feedLikeEvent
     *
     * @return User
     */
    public function addFeedLikeEvent(FeedLikeEvent $feedLikeEvent)
    {
        $this->feedLikeEvents[] = $feedLikeEvent;

        return $this;
    }

    /**
     * Remove feedLikeEvent
     *
     * @param \AppBundle\Entity\FeedLikeEvent $feedLikeEvent
     */
    public function removeFeedLikeEvent(FeedLikeEvent $feedLikeEvent)
    {
        $this->feedLikeEvents->removeElement($feedLikeEvent);
    }

    /**
     * Get feedLikeEvents
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getFeedLikeEvents()
    {
        return $this->feedLikeEvents;
    }

    /**
     * Add feedCommentEvent
     *
     * @param FeedCommentEvent $feedCommentEvent
     *
     * @return User
     */
    public function addFeedCommentEvent(FeedCommentEvent $feedCommentEvent)
    {
        $this->feedCommentEvents[] = $feedCommentEvent;

        return $this;
    }

    /**
     * Remove feedCommentEvent
     *
     * @param FeedCommentEvent $feedCommentEvent
     */
    public function removeFeedCommentEvent(FeedCommentEvent $feedCommentEvent)
    {
        $this->feedCommentEvents->removeElement($feedCommentEvent);
    }

    /**
     * Get feedCommentEvents
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getFeedCommentEvents()
    {
        return $this->feedCommentEvents;
    }

    /**
     * Add feedShareEvent
     *
     * @param FeedShareEvent $feedShareEvent
     *
     * @return User
     */
    public function addFeedShareEvent(FeedShareEvent $feedShareEvent)
    {
        $this->feedShareEvents[] = $feedShareEvent;

        return $this;
    }

    /**
     * Remove feedShareEvent
     *
     * @param FeedShareEvent $feedShareEvent
     */
    public function removeFeedShareEvent(FeedShareEvent $feedShareEvent)
    {
        $this->feedShareEvents->removeElement($feedShareEvent);
    }

    /**
     * Get feedShareEvents
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getFeedShareEvents()
    {
        return $this->feedShareEvents;
    }

    /**
     * Add feedAddPostEvent
     *
     * @param FeedAddPostEvent $feedAddPostEvent
     *
     * @return User
     */
    public function addFeedAddPostEvent(FeedAddPostEvent $feedAddPostEvent)
    {
        $this->feedAddPostEvents[] = $feedAddPostEvent;

        return $this;
    }

    /**
     * Remove feedAddPostEvent
     *
     * @param FeedAddPostEvent $feedAddPostEvent
     */
    public function removeFeedAddPostEvent(FeedAddPostEvent $feedAddPostEvent)
    {
        $this->feedAddPostEvents->removeElement($feedAddPostEvent);
    }

    /**
     * Get feedAddPostEvents
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getFeedAddPostEvents()
    {
        return $this->feedAddPostEvents;
    }

    /**
     * Add pathwayEvent
     *
     * @param \AppBundle\Entity\PathwayEvent $pathwayEvent
     *
     * @return \AppBundle\Entity\Event
     */
    public function addPathwayEvent(PathwayEvent $pathwayEvent)
    {
        $this->pathwayEvents[] = $pathwayEvent;

        return $this;
    }

    /**
     * Remove pathwayEvent
     *
     * @param \AppBundle\Entity\PathwayEvent $pathwayEvent
     */
    public function removePathwayEvent(PathwayEvent $pathwayEvent)
    {
       $this->pathwayEvents->removeElement($pathwayEvent);
    }

    /**
     * Get pathwayEvents
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPathwayEvents()
    {
        return $this->pathwayEvents;
    }

    /**
     * Set commentAmount
     *
     * @param integer commentAmount
     *
     * @return Event
     */
    public function setCommentAmount($commentAmount)
    {
        $this->commentAmount = $commentAmount;

        return $this;
    }

    /**
     * Get commentAmount
     *
     * @return integer
     */
    public function getCommentAmount()
    {
        return $this->commentAmount;
    }

    /**
     * Set likeAmount
     *
     * @param integer likeAmount
     *
     * @return Event
     */
    public function setLikeAmount($likeAmount)
    {
        $this->likeAmount = $likeAmount;

        return $this;
    }

    /**
     * Get likeAmount
     *
     * @return integer
     */
    public function getLikeAmount()
    {
        return $this->likeAmount;
    }
}
<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Gedmo\Mapping\Annotation as Gedmo;
use AppBundle\Entity\Traits\IdWithAccessors;

/**
 * Class EventFormatSection
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="event_format_section")
 */
class EventFormatSection
{
    use IdWithAccessors;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $timestampAdded;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private $timestampUpdated;

    /**
     * @var string
     *
     * @Gedmo\Slug(fields={"description"})
     * @ORM\Column(type="string", length=128, unique=true)
     */
    private $slug;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64, unique=true)
     */
    private $code;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64)
     */
    private $description;

    /**
     * @var ArrayCollection
     *
     * @ORM\OneToMany(targetEntity="EventFormat", mappedBy="eventFormatSection")
     */
    private $eventFormats;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->eventFormats = new ArrayCollection();
    }

    /**
     * @param \DateTime
     *
     * @return EventFormatSection
     */
    public function setTimestampAdded($timestampAdded)
    {
        $this->timestampAdded = $timestampAdded;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampAdded()
    {
        return $this->timestampAdded;
    }

    /**
     * @param \DateTime
     *
     * @return EventFormatSection
     */
    public function setTimestampUpdated(\DateTime $timestampUpdated = null)
    {
        if ($timestampUpdated === null) {
            $timestampUpdated = new \DateTime();
        }

        $this->timestampUpdated = $timestampUpdated;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampUpdated()
    {
        return $this->timestampUpdated;
    }

    /**
     * Set slug
     *
     * @param string $slug
     *
     * @return EventFormatSection
     */
    public function setSlug($slug)
    {
        $this->slug = $slug;

        return $this;
    }

    /**
     * @return string
     */
    public function getSlug()
    {
        return $this->slug;
    }

    /**
     * Set code
     *
     * @param string $code
     *
     * @return EventFormat
     */
    public function setCode($code)
    {
        $this->code = $code;

        return $this;
    }

    /**
     * Get code
     *
     * @return string
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return EventFormatSection
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Add event format
     *
     * @param EventFormat $eventFormat
     *
     * @return EventFormatSection
     */
    public function addEventFormat(EventFormat $eventFormat)
    {
        $this->eventFormats[] = $eventFormat;

        return $this;
    }

    /**
     * Remove event format
     *
     * @param EventFormat $eventFormat
     *
     * @return EventFormatSection
     */
    public function removeEvent(EventFormat $eventFormat)
    {
        $this->eventFormats->removeElement($eventFormat);

        return $this;
    }

    /**
     * Get event formats
     *
     * @return ArrayCollection
     */
    public function getEventFormats()
    {
        return $this->eventFormats;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->description;
    }
}

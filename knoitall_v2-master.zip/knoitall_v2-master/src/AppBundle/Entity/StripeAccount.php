<?php

namespace AppBundle\Entity;

use AppBundle\Entity\Traits\IdWithAccessors;
use Gedmo\Mapping\Annotation as Gedmo;
use Doctrine\ORM\Mapping as ORM;

/**
 * Class StripeAccount
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="stripe_account")
 */
class StripeAccount
{
    use IdWithAccessors;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $timestampAdded;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private $timestampUpdated;

    /**
     * @var Person
     *
     * @ORM\ManyToOne(targetEntity="Person", inversedBy="stripeAccounts")
     * @ORM\JoinColumn(name="person_id", referencedColumnName="id", nullable=false)
     */
    private $person;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64, nullable=false)
     */
    private $publishableKey;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64, nullable=false)
     */
    private $stripeUserId;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64, nullable=false)
     */
    private $refreshToken;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64, nullable=false)
     */
    private $accessToken;

    /**
     * Set timestampAdded
     *
     * @param \DateTime $timestampAdded
     *
     * @return StripeAccount
     */
    public function setTimestampAdded($timestampAdded)
    {
        $this->timestampAdded = $timestampAdded;

        return $this;
    }

    /**
     * Get timestampAdded
     *
     * @return \DateTime
     */
    public function getTimestampAdded()
    {
        return $this->timestampAdded;
    }

    /**
     * Set timestampUpdated
     *
     * @param \DateTime $timestampUpdated
     *
     * @return StripeAccount
     */
    public function setTimestampUpdated($timestampUpdated)
    {
        $this->timestampUpdated = $timestampUpdated;

        return $this;
    }

    /**
     * Get timestampUpdated
     *
     * @return \DateTime
     */
    public function getTimestampUpdated()
    {
        return $this->timestampUpdated;
    }

    /**
     * Set publishableKey
     *
     * @param string $publishableKey
     *
     * @return StripeAccount
     */
    public function setPublishableKey($publishableKey)
    {
        $this->publishableKey = $publishableKey;

        return $this;
    }

    /**
     * Get publishableKey
     *
     * @return string
     */
    public function getPublishableKey()
    {
        return $this->publishableKey;
    }

    /**
     * Set stripeUserId
     *
     * @param string $stripeUserId
     *
     * @return StripeAccount
     */
    public function setStripeUserId($stripeUserId)
    {
        $this->stripeUserId = $stripeUserId;

        return $this;
    }

    /**
     * Get stripeUserId
     *
     * @return string
     */
    public function getStripeUserId()
    {
        return $this->stripeUserId;
    }

    /**
     * Set refreshToken
     *
     * @param string $refreshToken
     *
     * @return StripeAccount
     */
    public function setRefreshToken($refreshToken)
    {
        $this->refreshToken = $refreshToken;

        return $this;
    }

    /**
     * Get refreshToken
     *
     * @return string
     */
    public function getRefreshToken()
    {
        return $this->refreshToken;
    }

    /**
     * Set accessToken
     *
     * @param string $accessToken
     *
     * @return StripeAccount
     */
    public function setAccessToken($accessToken)
    {
        $this->accessToken = $accessToken;

        return $this;
    }

    /**
     * Get accessToken
     *
     * @return string
     */
    public function getAccessToken()
    {
        return $this->accessToken;
    }

    /**
     * Set person
     *
     * @param \AppBundle\Entity\Person $person
     *
     * @return StripeAccount
     */
    public function setPerson(Person $person)
    {
        $this->person = $person;

        return $this;
    }

    /**
     * Get person
     *
     * @return \AppBundle\Entity\Person
     */
    public function getPerson()
    {
        return $this->person;
    }
}

<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\HttpFoundation\File\File;
use Vich\UploaderBundle\Mapping\Annotation as Vich;
use Gedmo\Mapping\Annotation as Gedmo;
use AppBundle\Entity\Traits\IdWithAccessors;
use AppBundle\Entity\Traits\AddressWithAccessors;

/**
 * Class Location
 *
 * @package AppBundle\Entity
 * @ORM\Table(name="location")
 * @ORM\Entity(repositoryClass="\AppBundle\Repository\LocationRepository")
 * @Vich\Uploadable
 */
class Location
{
    use IdWithAccessors;
    use AddressWithAccessors;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $timestampAdded;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private $timestampUpdated;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64, nullable=true)
     */
    private $city;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64, nullable=true)
     */
    private $street;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=16, nullable=true)
     */
    private $zip;

    /**
     * @var State
     *
     * @ORM\ManyToOne(targetEntity="State", inversedBy="locations")
     * @ORM\JoinColumn(name="state_id", referencedColumnName="id")
     */
    private $state;

    /**
     * @var Country
     *
     * @ORM\ManyToOne(targetEntity="Country", inversedBy="locations")
     * @ORM\JoinColumn(name="country_id", referencedColumnName="id")
     */
    private $country;

    /**
     * @var Provider
     *
     * @ORM\ManyToOne(targetEntity="Provider", inversedBy="locations")
     * @ORM\JoinColumn(name="provider_id", referencedColumnName="id", nullable=true)
     */
    private $provider;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64, nullable=true)
     */
    private $name;

    /**
     * @var LocationType
     *
     * @ORM\ManyToOne(targetEntity="LocationType", inversedBy="locations")
     * @ORM\JoinColumn(name="location_type_id", referencedColumnName="id", nullable=false)
     */
    private $locationType;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=32, nullable=true)
     */
    private $phone;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=256, nullable=true)
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=16, nullable=true)
     */
    private $location;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=16, nullable=true)
     */
    private $leaseTerms;

    /**
     * @var boolean
     *
     * @ORM\Column(type="boolean", nullable=true)
     *
     * TODO: we can probably do away with this field; it's here because migration from v1 to v2. It doesn't seem
     * to be used anywhere in v1 either
     */
    private $public;

    /**
     * @var float
     *
     * @ORM\Column(type="decimal", precision=10, scale=7, nullable=true)
     */
    private $latitude;

    /**
     * @var float
     *
     * @ORM\Column(type="decimal", precision=10, scale=7, nullable=true)
     */
    private $longitude;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=128, nullable=true, unique=true)
     */
    private $nickname;

    /**
     * @ORM\OneToMany(targetEntity="Event", mappedBy="location")
     */
    private $events;

    /**
     * @ORM\Column(type="string", length=128, nullable=true)
     *
     * @var string
     */
    private $image;

    /**
     * @Vich\UploadableField(mapping="location_media", fileNameProperty="image")
     *
     * @var File
     */
    private $imageFile;

    /**
     * @var boolean
     *
     * @ORM\Column(type="boolean", nullable=false)
     */
    private $published;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=23, nullable=false)
     */
    private $hash;

    /**
     * @var integer
     *
     * @ORM\Column(type="integer", nullable=true)
     */
    private $originalRecordKey;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $originalEnteredDateTime;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=45, nullable=true)
     */
    private $originalEnteredByEmail;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=25, nullable=true)
     */
    private $originalEnteredByFirstName;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=25, nullable=true)
     */
    private $originalEnteredByLastName;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=45, nullable=true)
     */
    private $originalEnteredByOrganization;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->events = new ArrayCollection();
        $this->hash = uniqid( '', true );
        $this->published = false;
        $this->latitude = '32.715733';
        $this->longitude = '-117.161148';
    }

    /**
     * @param \DateTime
     *
     * @return Location
     */
    public function setTimestampAdded($timestampAdded)
    {
        $this->timestampAdded = $timestampAdded;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampAdded()
    {
        return $this->timestampAdded;
    }

    /**
     * @param \DateTime
     *
     * @return Location
     */
    public function setTimestampUpdated(\DateTime $timestampUpdated = null)
    {
        if ($timestampUpdated === null) {
            $timestampUpdated = new \DateTime();
        }

        $this->timestampUpdated = $timestampUpdated;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampUpdated()
    {
        return $this->timestampUpdated;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return \AppBundle\Entity\Location
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set phone
     *
     * @param string $phone
     *
     * @return \AppBundle\Entity\Location
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;

        return $this;
    }

    /**
     * Get phone
     *
     * @return string
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return \AppBundle\Entity\Location
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set location
     *
     * @param string $location
     *
     * @return \AppBundle\Entity\Location
     */
    public function setLocation($location)
    {
        $this->location = $location;

        return $this;
    }

    /**
     * Get location
     *
     * @return string
     */
    public function getLocation()
    {
        return $this->location;
    }

    /**
     * Set leaseTerms
     *
     * @param string $leaseTerms
     *
     * @return \AppBundle\Entity\Location
     */
    public function setLeaseTerms($leaseTerms)
    {
        $this->leaseTerms = $leaseTerms;

        return $this;
    }

    /**
     * Get leaseTerms
     *
     * @return string
     */
    public function getLeaseTerms()
    {
        return $this->leaseTerms;
    }

    /**
     * Set public
     *
     * @param boolean $public
     *
     * @return \AppBundle\Entity\Location
     */
    public function setPublic($public)
    {
        $this->public = $public;

        return $this;
    }

    /**
     * Get public
     *
     * @return boolean
     */
    public function getPublic()
    {
        return $this->public;
    }

    /**
     * Set latitude
     *
     * @param string $latitude
     *
     * @return \AppBundle\Entity\Location
     */
    public function setLatitude($latitude)
    {
        $this->latitude = $latitude;

        return $this;
    }

    /**
     * Get latitude
     *
     * @return string
     */
    public function getLatitude()
    {
        return $this->latitude;
    }

    /**
     * Set longitude
     *
     * @param string $longitude
     *
     * @return \AppBundle\Entity\Location
     */
    public function setLongitude($longitude)
    {
        $this->longitude = $longitude;

        return $this;
    }

    /**
     * Get longitude
     *
     * @return string
     */
    public function getLongitude()
    {
        return $this->longitude;
    }

    /**
     * Set nickname
     *
     * @param string $nickname
     *
     * @return \AppBundle\Entity\Location
     */
    public function setNickname($nickname)
    {
        $this->nickname = $nickname;

        return $this;
    }

    /**
     * Get nickname
     *
     * @return string
     */
    public function getNickname()
    {
        return $this->nickname;
    }

    /**
     * Set provider
     *
     * @param \AppBundle\Entity\Provider $provider
     *
     * @return \AppBundle\Entity\Location
     */
    public function setProvider(Provider $provider)
    {
        $this->provider = $provider;

        return $this;
    }

    /**
     * Get provider
     *
     * @return \AppBundle\Entity\Provider Provider
     */
    public function getProvider()
    {
        return $this->provider;
    }

    /**
     * Set locationType
     *
     * @param \AppBundle\Entity\LocationType $locationType
     *
     * @return \AppBundle\Entity\Location
     */
    public function setLocationType(LocationType $locationType)
    {
        $this->locationType = $locationType;

        return $this;
    }

    /**
     * Get locationType
     *
     * @return \AppBundle\Entity\LocationType
     */
    public function getLocationType()
    {
        return $this->locationType;
    }

    /**
     * Add event
     *
     * @param \AppBundle\Entity\Event $event
     *
     * @return \AppBundle\Entity\Location
     */
    public function addEvent(Event $event)
    {
        $this->events[] = $event;

        return $this;
    }

    /**
     * Remove event
     *
     * @param \AppBundle\Entity\Event $event
     */
    public function removeEvent(Event $event)
    {
        $this->events->removeElement($event);
    }

    /**
     * Get events
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getEvents()
    {
        return $this->events;
    }

    /**
     * Set country
     *
     * @param \AppBundle\Entity\Country $country
     *
     * @return \AppBundle\Entity\Location
     */
    public function setCountry(Country $country = null)
    {
        $this->country = $country;

        return $this;
    }

    /**
     * Get country
     *
     * @return \AppBundle\Entity\Country
     */
    public function getCountry()
    {
        return $this->country;
    }

    /**
     * Set state
     *
     * @param \AppBundle\Entity\State $state
     *
     * @return \AppBundle\Entity\Location
     */
    public function setState(State $state = null)
    {
        $this->state = $state;

        return $this;
    }

    /**
     * Get state
     *
     * @return \AppBundle\Entity\State
     */
    public function getState()
    {
        return $this->state;
    }

    /**
     * Set city
     *
     * @param string $city
     *
     * @return \AppBundle\Entity\Location
     */
    public function setCity($city)
    {
        $this->city = $city;

        return $this;
    }

    /**
     * Get city
     *
     * @return string
     */
    public function getCity()
    {
        return $this->city;
    }

    /**
     * Set street
     *
     * @param string $street
     *
     * @return \AppBundle\Entity\Location
     */
    public function setStreet($street)
    {
        $this->street = $street;

        return $this;
    }

    /**
     * Get street
     *
     * @return string
     */
    public function getStreet()
    {
        return $this->street;
    }

    /**
     * Set zip
     *
     * @param string $zip
     *
     * @return \AppBundle\Entity\Location
     */
    public function setZip($zip)
    {
        $this->zip = $zip;

        return $this;
    }

    /**
     * Get zip
     *
     * @return string
     */
    public function getZip()
    {
        return $this->zip;
    }

    /**
     * @param File|null $imageFile
     *
     * @return Location
     */
    public function setImageFile(File $imageFile = null)
    {
        $this->imageFile = $imageFile;

        // VERY IMPORTANT:
        // It is required that at least one field changes if you are using Doctrine,
        // otherwise the event listeners won't be called and the file is lost
        if ($imageFile) {
            $this->timestampUpdated = new \DateTime('now');
        }

        return $this;
    }

    /**
     * @return File
     */
    public function getImageFile()
    {
        return $this->imageFile;
    }

    /**
     * @param $image
     *
     * @return Location
     */
    public function setImage($image)
    {
        $this->image = $image;

        return $this;
    }

    /**
     * @return string
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * Set published
     *
     * @param boolean $published
     *
     * @return Location
     */
    public function setPublished($published)
    {
        $this->published = $published;

        return $this;
    }

    /**
     * Get published
     *
     * @return boolean
     */
    public function getPublished()
    {
        return $this->published;
    }

    /**
     * Set hash
     *
     * @param string $hash
     *
     * @return Location
     */
    public function setHash($hash)
    {
        $this->hash = $hash;

        return $this;
    }

    /**
     * Get hash
     *
     * @return string
     */
    public function getHash()
    {
        return $this->hash;
    }

    /**
     * Set originalRecordKey
     *
     * @param integer $originalRecordKey
     *
     * @return Location
     */
    public function setOriginalRecordKey($originalRecordKey)
    {
        $this->originalRecordKey = $originalRecordKey;

        return $this;
    }

    /**
     * Get originalRecordKey
     *
     * @return integer
     */
    public function getOriginalRecordKey()
    {
        return $this->originalRecordKey;
    }

    /**
     * Set originalEnteredDateTime
     *
     * @param \DateTime $originalEnteredDateTime
     *
     * @return Location
     */
    public function setOriginalEnteredDateTime($originalEnteredDateTime)
    {
        $this->originalEnteredDateTime = $originalEnteredDateTime;

        return $this;
    }

    /**
     * Get originalEnteredDateTime
     *
     * @return \DateTime
     */
    public function getOriginalEnteredDateTime()
    {
        return $this->originalEnteredDateTime;
    }

    /**
     * Set originalEnteredByEmail
     *
     * @param string $originalEnteredByEmail
     *
     * @return Location
     */
    public function setOriginalEnteredByEmail($originalEnteredByEmail)
    {
        $this->originalEnteredByEmail = $originalEnteredByEmail;

        return $this;
    }

    /**
     * Get originalEnteredByEmail
     *
     * @return string
     */
    public function getOriginalEnteredByEmail()
    {
        return $this->originalEnteredByEmail;
    }

    /**
     * Set originalEnteredByFirstName
     *
     * @param string $originalEnteredByFirstName
     *
     * @return Location
     */
    public function setOriginalEnteredByFirstName($originalEnteredByFirstName)
    {
        $this->originalEnteredByFirstName = $originalEnteredByFirstName;

        return $this;
    }

    /**
     * Get originalEnteredByFirstName
     *
     * @return string
     */
    public function getOriginalEnteredByFirstName()
    {
        return $this->originalEnteredByFirstName;
    }

    /**
     * Set originalEnteredByLastName
     *
     * @param string $originalEnteredByLastName
     *
     * @return Location
     */
    public function setOriginalEnteredByLastName($originalEnteredByLastName)
    {
        $this->originalEnteredByLastName = $originalEnteredByLastName;

        return $this;
    }

    /**
     * Get originalEnteredByLastName
     *
     * @return string
     */
    public function getOriginalEnteredByLastName()
    {
        return $this->originalEnteredByLastName;
    }

    /**
     * Set originalEnteredByOrganization
     *
     * @param string $originalEnteredByOrganization
     *
     * @return Location
     */
    public function setOriginalEnteredByOrganization($originalEnteredByOrganization)
    {
        $this->originalEnteredByOrganization = $originalEnteredByOrganization;

        return $this;
    }

    /**
     * Get originalEnteredByOrganization
     *
     * @return string
     */
    public function getOriginalEnteredByOrganization()
    {
        return $this->originalEnteredByOrganization;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        if( $this->getLocation() != null ) {
            return $this->getLocation();
        }
        if( $this->getName() != null ) {
            return $this->getName();
        }
        if( $this->getStreet() != null || $this->getCity() != null ) {
            return $this->getStreet() . " " . $this->getCity();
        }

        return "Location " . $this->id . " UNKNOWN";
    }
}

<?php

namespace AppBundle\Entity;

use AppBundle\Entity\Traits\IdWithAccessors;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * Class State
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="state")
 */
class State
{
    use IdWithAccessors;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64, nullable=false)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=2, nullable=false)
     */
    private $alpha2Code;

    /**
     * @var Country
     *
     * @ORM\ManyToOne(targetEntity="Country", inversedBy="states")
     * @ORM\JoinColumn(name="country_id", referencedColumnName="id")
     */
    private $country;

    /**
     * @ORM\OneToMany(targetEntity="Person", mappedBy="state")
     */
    private $persons;

    /**
     * @ORM\OneToMany(targetEntity="Location", mappedBy="state")
     */
    private $locations;

    /**
     * @ORM\OneToMany(targetEntity="Postalcode", mappedBy="state")
     */
    private $postalcodes;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->persons = new ArrayCollection();
        $this->locations = new ArrayCollection();
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return \AppBundle\Entity\State
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set alpha2Code
     *
     * @param string $alpha2Code
     *
     * @return \AppBundle\Entity\State
     */
    public function setAlpha2Code($alpha2Code)
    {
        $this->alpha2Code = $alpha2Code;

        return $this;
    }

    /**
     * Get alpha2Code
     *
     * @return string
     */
    public function getAlpha2Code()
    {
        return $this->alpha2Code;
    }

    /**
     * Set country
     *
     * @param \AppBundle\Entity\Country $country
     *
     * @return \AppBundle\Entity\State
     */
    public function setCountry(Country $country = null)
    {
        $this->country = $country;

        return $this;
    }

    /**
     * Get country
     *
     * @return \AppBundle\Entity\Country
     */
    public function getCountry()
    {
        return $this->country;
    }

    /**
     * Add location
     *
     * @param \AppBundle\Entity\Location $location
     *
     * @return \AppBundle\Entity\State
     */
    public function addLocation(Location $location)
    {
        $this->locations[] = $location;

        return $this;
    }

    /**
     * Remove location
     *
     * @param \AppBundle\Entity\Location $location
     */
    public function removeLocation(Location $location)
    {
        $this->locations->removeElement($location);
    }

    /**
     * Get locations
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getLocations()
    {
        return $this->locations;
    }

    /**
     * Add person
     *
     * @param \AppBundle\Entity\Person $person
     *
     * @return \AppBundle\Entity\State
     */
    public function addPerson(Person $person)
    {
        $this->persons[] = $person;

        return $this;
    }

    /**
     * Remove person
     *
     * @param \AppBundle\Entity\Person $person
     */
    public function removePerson(Person $person)
    {
        $this->persons->removeElement($person);
    }

    /**
     * Get persons
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPersons()
    {
        return $this->persons;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->alpha2Code . ' ' . $this->name;
    }

    /**
     * Add postalcode
     *
     * @param \AppBundle\Entity\Postalcode $postalcode
     *
     * @return State
     */
    public function addPostalcode(\AppBundle\Entity\Postalcode $postalcode)
    {
        $this->postalcodes[] = $postalcode;

        return $this;
    }

    /**
     * Remove postalcode
     *
     * @param \AppBundle\Entity\Postalcode $postalcode
     */
    public function removePostalcode(\AppBundle\Entity\Postalcode $postalcode)
    {
        $this->postalcodes->removeElement($postalcode);
    }

    /**
     * Get postalcodes
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPostalcodes()
    {
        return $this->postalcodes;
    }
}

<?php

namespace AppBundle\Entity;

use AppBundle\Entity\Traits\IdWithAccessors;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * Class Country
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="country")
 */
class Country
{
    use IdWithAccessors;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64, nullable=false)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=2, nullable=false)
     */
    private $alpha2Code;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=3, nullable=false)
     */
    private $alpha3Code;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=3, nullable=false)
     */
    private $numericCode;

    /**
     * @ORM\OneToMany(targetEntity="State", mappedBy="country")
     */
    private $states;

    /**
     * @ORM\OneToMany(targetEntity="Person", mappedBy="country")
     */
    private $persons;

    /**
     * @ORM\OneToMany(targetEntity="Location", mappedBy="country")
     */
    private $locations;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->states = new ArrayCollection();
        $this->persons = new ArrayCollection();
        $this->locations = new ArrayCollection();
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return Country
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set alpha2Code
     *
     * @param string $alpha2Code
     *
     * @return Country
     */
    public function setAlpha2Code($alpha2Code)
    {
        $this->alpha2Code = $alpha2Code;

        return $this;
    }

    /**
     * Get alpha2Code
     *
     * @return string
     */
    public function getAlpha2Code()
    {
        return $this->alpha2Code;
    }

    /**
     * Set alpha3Code
     *
     * @param string $alpha3Code
     *
     * @return Country
     */
    public function setAlpha3Code($alpha3Code)
    {
        $this->alpha3Code = $alpha3Code;

        return $this;
    }

    /**
     * Get alpha3Code
     *
     * @return string
     */
    public function getAlpha3Code()
    {
        return $this->alpha3Code;
    }

    /**
     * Add state
     *
     * @param State $state
     *
     * @return Country
     */
    public function addState(State $state)
    {
        $this->states[] = $state;

        return $this;
    }

    /**
     * Remove state
     *
     * @param State $state
     */
    public function removeState(State $state)
    {
        $this->states->removeElement($state);
    }

    /**
     * Get states
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getStates()
    {
        return $this->states;
    }

    /**
     * Add location
     *
     * @param Location $location
     *
     * @return Country
     */
    public function addLocation(Location $location)
    {
        $this->locations[] = $location;

        return $this;
    }

    /**
     * Remove location
     *
     * @param Location $location
     */
    public function removeLocation(Location $location)
    {
        $this->locations->removeElement($location);
    }

    /**
     * Get locations
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getLocations()
    {
        return $this->locations;
    }

    /**
     * Add person
     *
     * @param Person $person
     *
     * @return Country
     */
    public function addPerson(Person $person)
    {
        $this->persons[] = $person;

        return $this;
    }

    /**
     * Remove person
     *
     * @param Person $person
     */
    public function removePerson(Person $person)
    {
        $this->persons->removeElement($person);
    }

    /**
     * Get persons
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPersons()
    {
        return $this->persons;
    }

    /**
     * Set numericCode
     *
     * @param string $numericCode
     *
     * @return Country
     */
    public function setNumericCode($numericCode)
    {
        $this->numericCode = $numericCode;

        return $this;
    }

    /**
     * Get numericCode
     *
     * @return string
     */
    public function getNumericCode()
    {
        return $this->numericCode;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->alpha3Code . ' ' . $this->name;
    }
}

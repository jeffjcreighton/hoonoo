<?php

namespace AppBundle\Entity;

use Doctrine\Common\Collections\Collection;
use Doctrine\Common\Collections\ArrayCollection;
use FOS\UserBundle\Model\User as BaseUser;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Class User
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="fos_user")
 */
class User extends BaseUser
{
    /**
     * @var int
     *
     * @ORM\Column(type="integer", unique=true)
     * @ORM\Id()
     * @ORM\GeneratedValue(strategy="AUTO")
     *
     * TODO: see if we can use IdWithAccessors here as in the rest of the entities
     */
    protected $id;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $timestampAdded;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private $timestampUpdated;

    /**
     * @ORM\ManyToOne(targetEntity="Person", inversedBy="users")
     * @ORM\JoinColumn(name="person_id", referencedColumnName="id", nullable=true)
     */
    private $person;

    /*
     * Other fields that are present in the registration form but are not persisted:
     */

    /**
     * @var string
     */
    private $firstName;

    /**
     * @var string
     */
    private $lastName;

    /**
     * @var string
     */
    private $title;

    /**
     * @var \AppBundle\Entity\PersonTitle
     *
     * @ORM\ManyToOne(targetEntity="PersonTitle")
     * @ORM\JoinColumn(name="person_title_id", referencedColumnName="id", nullable=true)
     */
    private $personTitle;

    /**
     * @var \AppBundle\Entity\Age
     *
     * @ORM\ManyToOne(targetEntity="Age")
     * @ORM\JoinColumn(name="age_id", referencedColumnName="id", nullable=true)
     */
    private $age;

    /**
     * @var Collection
     *
     * @ORM\ManyToMany(targetEntity="Taxonomy", inversedBy="users")
     * @ORM\JoinTable(name="fos_user_taxonomy")
     */
    private $taxonomies;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=128, nullable=true, unique=false)
     */
    private $nickname;

    /**
     * @var integer
     *
     * @ORM\Column(type="integer", nullable=true)
     */
    private $originalRecordKey;

    /**
     * Constructor
     */
    public function __construct()
    {
        parent::__construct();
        /*
         * our own logic here:
         */
        $this->taxonomies = new ArrayCollection();
    }

    /**
     * @param \DateTime
     *
     * @return \AppBundle\Entity\User
     */
    public function setTimestampAdded($timestampAdded)
    {
        $this->timestampAdded = $timestampAdded;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampAdded()
    {
        return $this->timestampAdded;
    }

    /**
     * @param \DateTime
     *
     * @return \AppBundle\Entity\User
     */
    public function setTimestampUpdated(\DateTime $timestampUpdated = null)
    {
        if ($timestampUpdated === null) {
            $timestampUpdated = new \DateTime();
        }

        $this->timestampUpdated = $timestampUpdated;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampUpdated()
    {
        return $this->timestampUpdated;
    }

    /**
     * Set person
     *
     * @param \AppBundle\Entity\Person $person
     *
     * @return \AppBundle\Entity\User
     */
    public function setPerson(Person $person)
    {
        $this->person = $person;

        return $this;
    }

    /**
     * Get person
     *
     * @return \AppBundle\Entity\Person
     */
    public function getPerson()
    {
        return $this->person;
    }

    /**
     * Set firstName
     *
     * @param string $firstName
     *
     * @return \AppBundle\Entity\User
     */
    public function setFirstName($firstName)
    {
        $this->firstName = $firstName;

        if( $this->person) {
            $this->getPerson()->setFirstName( $firstName );
        }

        return $this;
    }

    /**
     * Get firstName
     *
     * @return string
     */
    public function getFirstName()
    {
        return $this->firstName;
    }

    /**
     * Set lastName
     *
     * @param string $lastName
     *
     * @return \AppBundle\Entity\User
     */
    public function setLastName($lastName)
    {
        $this->lastName = $lastName;

        if( $this->person ) {
            $this->getPerson()->setLastName( $lastName );
        }

        return $this;
    }

    /**
     * Get lastName
     *
     * @return string
     */
    public function getLastName()
    {
        return $this->lastName;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return \AppBundle\Entity\User;
     */
    public function setTitle($title)
    {
        $this->title = $title;

        if( $this->person ) {
            $this->getPerson()->setTitle( $title );
        }

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Add taxonomy
     *
     * @param \AppBundle\Entity\Taxonomy $taxonomy
     *
     * @return \AppBundle\Entity\User
     */
    public function addTaxonomy(Taxonomy $taxonomy)
    {
        $this->taxonomies[] = $taxonomy;

        return $this;
    }

    /**
     * Remove taxonomy
     *
     * @param \AppBundle\Entity\Taxonomy $taxonomy
     */
    public function removeTaxonomy(Taxonomy $taxonomy)
    {
        $this->taxonomies->removeElement($taxonomy);
    }

    /**
     * Get taxonomies
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getTaxonomies()
    {
        return $this->taxonomies;
    }

    /**
     * Set nickname
     *
     * @param string $nickname
     *
     * @return \AppBundle\Entity\User;
     */
    public function setNickname($nickname)
    {
        $this->nickname = $nickname;

        return $this;
    }

    /**
     * Get nickname
     *
     * @return string
     */
    public function getNickname()
    {
        return $this->nickname;
    }

    /**
     * @param PersonTitle $personTitle
     *
     * @return \AppBundle\Entity\User
     */
    public function setPersonTitle(PersonTitle $personTitle)
    {
        $this->personTitle = $personTitle;

        return $this;
    }

    /**
     * @return \AppBundle\Entity\PersonTitle
     */
    public function getPersonTitle()
    {
        return $this->personTitle;
    }

    /**
     * @param \AppBundle\Entity\Age $age
     *
     * @return \AppBundle\Entity\User
     */
    public function setAge(Age $age)
    {
        $this->age = $age;

        return $this;
    }

    /**
     * @return \AppBundle\Entity\Age
     */
    public function getAge()
    {
        return $this->age;
    }

    /**
     * Set originalRecordKey
     *
     * @param integer $originalRecordKey
     *
     * @return User
     */
    public function setOriginalRecordKey($originalRecordKey)
    {
        $this->originalRecordKey = $originalRecordKey;

        return $this;
    }

    /**
     * Get originalRecordKey
     *
     * @return integer
     */
    public function getOriginalRecordKey()
    {
        return $this->originalRecordKey;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getEmail();
    }
}

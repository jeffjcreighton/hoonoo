<?php

namespace AppBundle\Entity;

use AppBundle\Entity\Traits\IdWithAccessors;
use Doctrine\DBAL\Types\DateTimeType;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * Class Message
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="message")
 */
class Message
{
    use IdWithAccessors;

    /**
     * Administrative attribute
     *
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $timestampAdded;

    /**
     * Administrative attribute
     *
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private $timestampUpdated;

    /**
     * @var \AppBundle\Entity\Person
     *
     * @ORM\ManyToOne(targetEntity="Person", inversedBy="messagesSent")
     * @ORM\JoinColumn(name="person_id_from", referencedColumnName="id", nullable=true)
     */
    private $personFrom;

    /**
     * @var \AppBundle\Entity\Person
     *
     * @ORM\ManyToOne(targetEntity="Person", inversedBy="messagesReceived")
     * @ORM\JoinColumn(name="person_id_to", referencedColumnName="id", nullable=false)
     */
    private $personTo;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=256, nullable=true)
     */
    private $subject;

    /**
     * @var $text
     *
     * @ORM\Column(type="text", nullable=false)
     */
    private $content;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="datetime", nullable=false)
     */
    private $sentAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $readAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $repliedAt;

    /**
     * Set timestampAdded
     *
     * @param \DateTime $timestampAdded
     *
     * @return \AppBundle\Entity\Message
     */
    public function setTimestampAdded($timestampAdded)
    {
        $this->timestampAdded = $timestampAdded;

        return $this;
    }

    /**
     * Get timestampAdded
     *
     * @return \DateTime
     */
    public function getTimestampAdded()
    {
        return $this->timestampAdded;
    }

    /**
     * Set timestampUpdated
     *
     * @param \DateTime $timestampUpdated
     *
     * @return \AppBundle\Entity\Message
     */
    public function setTimestampUpdated($timestampUpdated)
    {
        $this->timestampUpdated = $timestampUpdated;

        return $this;
    }

    /**
     * Get timestampUpdated
     *
     * @return \DateTime
     */
    public function getTimestampUpdated()
    {
        return $this->timestampUpdated;
    }

    /**
     * Set subject
     *
     * @param string $subject
     *
     * @return \AppBundle\Entity\Message
     */
    public function setSubject($subject)
    {
        $this->subject = $subject;

        return $this;
    }

    /**
     * Get subject
     *
     * @return string
     */
    public function getSubject()
    {
        return $this->subject;
    }

    /**
     * Set content
     *
     * @param string $content
     *
     * @return \AppBundle\Entity\Message
     */
    public function setContent($content)
    {
        $this->content = $content;

        return $this;
    }

    /**
     * Get content
     *
     * @return string
     */
    public function getContent()
    {
        return $this->content;
    }

    /**
     * Set sentAt
     *
     * @param \DateTime $sentAt
     *
     * @return \AppBundle\Entity\Message
     */
    public function setSentAt($sentAt)
    {
        $this->sentAt = $sentAt;

        return $this;
    }

    /**
     * Get sentAt
     *
     * @return \DateTime
     */
    public function getSentAt()
    {
        return $this->sentAt;
    }

    /**
     * Set readAt
     *
     * @param \DateTime $readAt
     *
     * @return \AppBundle\Entity\Message
     */
    public function setReadAt($readAt)
    {
        $this->readAt = $readAt;

        return $this;
    }

    /**
     * Get readAt
     *
     * @return \DateTime
     */
    public function getReadAt()
    {
        return $this->readAt;
    }

    /**
     * Set repliedAt
     *
     * @param \DateTime $repliedAt
     *
     * @return \AppBundle\Entity\Message
     */
    public function setRepliedAt($repliedAt)
    {
        $this->repliedAt = $repliedAt;

        return $this;
    }

    /**
     * Get repliedAt
     *
     * @return \DateTime
     */
    public function getRepliedAt()
    {
        return $this->repliedAt;
    }

    /**
     * Set personFrom
     *
     * @param \AppBundle\Entity\Person $personFrom
     *
     * @return \AppBundle\Entity\Message
     */
    public function setPersonFrom(\AppBundle\Entity\Person $personFrom = null)
    {
        $this->personFrom = $personFrom;

        return $this;
    }

    /**
     * Get personFrom
     *
     * @return \AppBundle\Entity\Person
     */
    public function getPersonFrom()
    {
        return $this->personFrom;
    }

    /**
     * Set personTo
     *
     * @param \AppBundle\Entity\Person $personTo
     *
     * @return \AppBundle\Entity\Message
     */
    public function setPersonTo(\AppBundle\Entity\Person $personTo)
    {
        $this->personTo = $personTo;

        return $this;
    }

    /**
     * Get personTo
     *
     * @return \AppBundle\Entity\Person
     */
    public function getPersonTo()
    {
        return $this->personTo;
    }
}

<?php

namespace AppBundle\Entity;

use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Gedmo\Mapping\Annotation as Gedmo;
use AppBundle\Entity\Traits\IdWithAccessors;
use AppBundle\Entity\Traits\NameWithAccessors;
use AppBundle\Entity\Traits\AddressWithAccessors;

/**
 * Class Person
 * @package AppBundle\Entity
 * @ORM\Entity(repositoryClass="AppBundle\Repository\PersonRepository")
 * @ORM\Table(name="person")
 */
class Person
{
    use IdWithAccessors;
    use NameWithAccessors;
    use AddressWithAccessors;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $timestampAdded;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private $timestampUpdated;

    /**
     * @var \AppBundle\Entity\PersonTitle
     *
     * @ORM\ManyToOne(targetEntity="PersonTitle", inversedBy="persons")
     * @ORM\JoinColumn(name="person_title_id", referencedColumnName="id", nullable=true)
     */
    private $personTitle;

    /**
     * @var \AppBundle\Entity\Postalcode
     *
     * @ORM\ManyToOne(targetEntity="Postalcode", inversedBy="persons")
     * @ORM\JoinColumn(name="postalcode_id", referencedColumnName="id")
     */
    private $postalcode;

    /**
     * @var \AppBundle\Entity\State
     *
     * @ORM\ManyToOne(targetEntity="State", inversedBy="persons")
     * @ORM\JoinColumn(name="state_id", referencedColumnName="id")
     */
    private $state;

    /**
     * @var \AppBundle\Entity\Country
     *
     * @ORM\ManyToOne(targetEntity="Country", inversedBy="persons")
     * @ORM\JoinColumn(name="country_id", referencedColumnName="id")
     */
    private $country;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=16, nullable=true)
     */
    private $phone;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64, nullable=true)
     */
    private $email;

    /**
     * @ORM\OneToMany(targetEntity="User", mappedBy="person")
     */
    private $users;

    /**
     * @ORM\OneToMany(targetEntity="Advisor", mappedBy="person")
     */
    private $advisors;

    /**
     * @ORM\OneToMany(targetEntity="Instructor", mappedBy="person")
     */
    private $instructors;

    /**
     * @ORM\OneToMany(targetEntity="Learner", mappedBy="person")
     */
    private $learners;

    /**
     * @ORM\ManyToMany(targetEntity="Provider", mappedBy="persons")
     */
    private $providers;

    /**
     * @var Collection
     *
     * @ORM\OneToMany(targetEntity="Message", mappedBy="personFrom")
     */
    private $messagesSent;

    /**
     * @var Collection
     *
     * @ORM\OneToMany(targetEntity="Message", mappedBy="personTo")
     */
    private $messagesReceived;

    /**
     * @var Collection
     *
     * @ORM\OneToMany(targetEntity="StripeAccount", mappedBy="person")
     */
    private $stripeAccounts;

    /**
     * @var integer
     *
     * @ORM\Column(type="integer", nullable=true)
     */
    private $originalRecordKey;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->users = new ArrayCollection();
        $this->advisors = new ArrayCollection();
        $this->instructors = new ArrayCollection();
        $this->learners = new ArrayCollection();
        $this->providers = new ArrayCollection();
        $this->messagesSent = new ArrayCollection();
        $this->messagesReceived = new ArrayCollection();
        $this->stripeAccounts = new ArrayCollection();
    }

    /**
     * @param \DateTime
     *
     * @return \AppBundle\Entity\Person
     */
    public function setTimestampAdded($timestampAdded)
    {
        $this->timestampAdded = $timestampAdded;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampAdded()
    {
        return $this->timestampAdded;
    }

    /**
     * @param \DateTime
     *
     * @return \AppBundle\Entity\Person
     */
    public function setTimestampUpdated(\DateTime $timestampUpdated = null)
    {
        if ($timestampUpdated === null) {
            $timestampUpdated = new \DateTime();
        }

        $this->timestampUpdated = $timestampUpdated;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampUpdated()
    {
        return $this->timestampUpdated;
    }

    /**
     * Add learner
     *
     * @param \AppBundle\Entity\Learner $learner
     *
     * @return \AppBundle\Entity\Person
     */
    public function addLearner(Learner $learner)
    {
        $this->learners[] = $learner;

        return $this;
    }

    /**
     * Remove learner
     *
     * @param \AppBundle\Entity\Learner $learner
     */
    public function removeLearner(Learner $learner)
    {
        $this->learners->removeElement($learner);

        return $this;
    }

    /**
     * Get learners
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getLearners()
    {
        return $this->learners;
    }

    /**
     * Add instructor
     *
     * @param \AppBundle\Entity\Instructor $instructor
     *
     * @return \AppBundle\Entity\Person
     */
    public function addInstructor(Instructor $instructor)
    {
        $this->instructors[] = $instructor;

        return $this;
    }

    /**
     * Remove instructor
     *
     * @param \AppBundle\Entity\Instructor $instructor
     */
    public function removeInstructor(Instructor $instructor)
    {
        $this->instructors->removeElement($instructor);

        return $this;
    }

    /**
     * Get instructors
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getInstructors()
    {
        return $this->instructors;
    }

    /**
     * Add advisor
     *
     * @param \AppBundle\Entity\Advisor $advisor
     *
     * @return \AppBundle\Entity\Person
     */
    public function addAdvisor(Advisor $advisor)
    {
        $this->advisors[] = $advisor;

        return $this;
    }

    /**
     * Remove advisor
     *
     * @param \AppBundle\Entity\Advisor $advisor
     */
    public function removeAdvisor(Advisor $advisor)
    {
        $this->advisors->removeElement($advisor);

        return $this;
    }

    /**
     * Get advisors
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getAdvisors()
    {
        return $this->advisors;
    }

    /**
     * Add user
     *
     * @param \AppBundle\Entity\User $user
     *
     * @return \AppBundle\Entity\Person
     */
    public function addUser(User $user)
    {
        $this->users[] = $user;

        return $this;
    }

    /**
     * Remove user
     *
     * @param \AppBundle\Entity\User $user
     */
    public function removeUser(User $user)
    {
        $this->users->removeElement($user);

        return $this;
    }

    /**
     * Get users
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getUsers()
    {
        return $this->users;
    }

    /**
     * Add provider
     *
     * @param \AppBundle\Entity\Provider $provider
     *
     * @return \AppBundle\Entity\Person
     */
    public function addProvider(Provider $provider)
    {
        $this->providers[] = $provider;

        return $this;
    }

    /**
     * Remove provider
     *
     * @param \AppBundle\Entity\Provider $provider
     */
    public function removeProvider(Provider $provider)
    {
        $this->providers->removeElement($provider);
    }

    /**
     * Get providers
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getProviders()
    {
        return $this->providers;
    }

    /**
     * Set state
     *
     * @param \AppBundle\Entity\State $state
     *
     * @return \AppBundle\Entity\Person
     */
    public function setState(State $state = null)
    {
        $this->state = $state;

        return $this;
    }

    /**
     * Get state
     *
     * @return \AppBundle\Entity\State
     */
    public function getState()
    {
        return $this->state;
    }

    /**
     * Set country
     *
     * @param \AppBundle\Entity\Country $country
     *
     * @return \AppBundle\Entity\Person
     */
    public function setCountry(Country $country = null)
    {
        $this->country = $country;

        return $this;
    }

    /**
     * Get country
     *
     * @return \AppBundle\Entity\Country
     */
    public function getCountry()
    {
        return $this->country;
    }

    /**
     * Set postalcode
     *
     * @param \AppBundle\Entity\Postalcode $postalcode
     *
     * @return Person
     */
    public function setPostalcode(Postalcode $postalcode = null)
    {
        $this->postalcode = $postalcode;

        return $this;
    }

    /**
     * Get postalcode
     *
     * @return \AppBundle\Entity\Postalcode
     */
    public function getPostalcode()
    {
        return $this->postalcode;
    }

    /**
     * Set phone
     *
     * @param string $phone
     *
     * @return \AppBundle\Entity\Person
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;

        return $this;
    }

    /**
     * Get phone
     *
     * @return string
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * Set email
     *
     * @param string $email
     *
     * @return \AppBundle\Entity\Person
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set personTitle
     *
     * @param \AppBundle\Entity\PersonTitle $personTitle
     *
     * @return \AppBundle\Entity\Person
     */
    public function setPersonTitle(PersonTitle $personTitle = null)
    {
        $this->personTitle = $personTitle;

        return $this;
    }

    /**
     * Get personTitle
     *
     * @return \AppBundle\Entity\PersonTitle
     */
    public function getPersonTitle()
    {
        return $this->personTitle;
    }

    /**
     * Add messagesSent
     *
     * @param \AppBundle\Entity\Message $messagesSent
     *
     * @return \AppBundle\Entity\Person
     */
    public function addMessagesSent(Message $messagesSent)
    {
        $this->messagesSent[] = $messagesSent;

        return $this;
    }

    /**
     * Remove messagesSent
     *
     * @param \AppBundle\Entity\Message $messagesSent
     */
    public function removeMessagesSent(Message $messagesSent)
    {
        $this->messagesSent->removeElement($messagesSent);

        return $this;
    }

    /**
     * Get messagesSent
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getMessagesSent()
    {
        return $this->messagesSent;
    }

    /**
     * Add messagesReceived
     *
     * @param \AppBundle\Entity\Message $messagesReceived
     *
     * @return \AppBundle\Entity\Person
     */
    public function addMessagesReceived(Message $messagesReceived)
    {
        $this->messagesReceived[] = $messagesReceived;

        return $this;
    }

    /**
     * Remove messagesReceived
     *
     * @param \AppBundle\Entity\Message $messagesReceived
     */
    public function removeMessagesReceived(Message $messagesReceived)
    {
        $this->messagesReceived->removeElement($messagesReceived);

        return $this;
    }

    /**
     * Get messagesReceived
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getMessagesReceived()
    {
        return $this->messagesReceived;
    }

    /**
     * Set originalRecordKey
     *
     * @param integer $originalRecordKey
     *
     * @return Person
     */
    public function setOriginalRecordKey($originalRecordKey)
    {
        $this->originalRecordKey = $originalRecordKey;

        return $this;
    }

    /**
     * Get originalRecordKey
     *
     * @return integer
     */
    public function getOriginalRecordKey()
    {
        return $this->originalRecordKey;
    }

    /**
     * Add stripeAccount
     *
     * @param \AppBundle\Entity\StripeAccount $stripeAccount
     *
     * @return Person
     */
    public function addStripeAccount(StripeAccount $stripeAccount)
    {
        $this->stripeAccounts[] = $stripeAccount;

        return $this;
    }

    /**
     * Remove stripeAccount
     *
     * @param \AppBundle\Entity\StripeAccount $stripeAccount
     */
    public function removeStripeAccount(StripeAccount $stripeAccount)
    {
        $this->stripeAccounts->removeElement($stripeAccount);

        return $this;
    }

    /**
     * Get stripeAccounts
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getStripeAccounts()
    {
        return $this->stripeAccounts;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getId() . ' ' . $this->getFirstName() . ' ' . $this->getLastName();
    }
}

<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use AppBundle\Entity\Traits\IdWithAccessors;
use Gedmo\Mapping\Annotation as Gedmo;
use AppBundle\Entity\Pathway;
use AppBundle\Entity\Learner;

/**
 * Class PathwayFeedPos
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="pathway_feed_pos")
 */
class PathwayFeedPos
{
    use IdWithAccessors;

    /**
     * @var \AppBundle\Entity\Learner
     *
     * @ORM\ManyToOne(targetEntity="Learner", inversedBy="pathwayFeedPoss")
     * @ORM\JoinColumn(name="learner_id", referencedColumnName="id", nullable=false)
     */
    private $learner;

    /**
     * @var \AppBundle\Entity\Pathway
     *
     * @ORM\ManyToOne(targetEntity="Pathway", inversedBy="pathwayFeedPoss")
     * @ORM\JoinColumn(name="pathway_id", referencedColumnName="id", nullable=false)
     */
    private $pathway;

    /**
     * @var int
     *
     * @ORM\Column(type="integer", nullable=false)
     */
    private $feedPos;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $timestampAdded;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private $timestampUpdated;

    /**
     * Constructor
     */
    public function __construct()
    {
        
    }

    /**
     * Set learner
     *
     * @param \AppBundle\Entity\Learner $learner
     *
     * @return \AppBundle\Entity\PathwayFeedPos
     */
    public function setLearner(\AppBundle\Entity\Learner $learner = null)
    {
        $this->learner = $learner;

        return $this;
    }

    /**
     * Get learner
     *
     * @return \AppBundle\Entity\Learner
     */
    public function getLearner()
    {
        return $this->learner;
    }

    /**
     * Set pathway
     *
     * @param \AppBundle\Entity\Pathway $pathway
     *
     * @return \AppBundle\Entity\PathwayFeedPos
     */
    public function setPathway(\AppBundle\Entity\Pathway $pathway = null)
    {
        $this->pathway = $pathway;

        return $this;
    }

    /**
     * Get pathway
     *
     * @return \AppBundle\Entity\Pathway
     */
    public function getPathway()
    {
        return $this->pathway;
    }

    /**
     * Set feedPos
     *
     * @param integer $feedPos
     *
     * @return \AppBundle\Entity\PathwayFeedPos
     */
    public function setFeedPos($feedPos)
    {
        $this->feedPos = $feedPos;

        return $this;
    }

    /**
     * Get feedPos
     *
     * @return integer
     */
    public function getFeedPos()
    {
        return $this->feedPos;
    }

    /**
     * @param \DateTime
     *
     * @return \AppBundle\Entity\PathwayFeedPos
     */
    public function setTimestampAdded($timestampAdded)
    {
        $this->timestampAdded = $timestampAdded;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampAdded()
    {
        return $this->timestampAdded;
    }

    /**
     * @param \DateTime
     *
     * @return \AppBundle\Entity\PathwayFeedPos
     */
    public function setTimestampUpdated(\DateTime $timestampUpdated = null)
    {
        if ($timestampUpdated === null) {
            $timestampUpdated = new \DateTime();
        }

        $this->timestampUpdated = $timestampUpdated;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampUpdated()
    {
        return $this->timestampUpdated;
    }
}

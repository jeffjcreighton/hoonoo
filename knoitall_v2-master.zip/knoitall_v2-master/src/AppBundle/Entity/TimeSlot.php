<?php

namespace AppBundle\Entity;

use AppBundle\Entity\Traits\IdWithAccessors;
use Gedmo\Mapping\Annotation as Gedmo;
use Doctrine\ORM\Mapping as ORM;

/**
 * Class TimeSlot
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="time_slot")
 */
class TimeSlot
{
    const SLOT_TYPE_SPECIFIC_DATE_TIME = 1;
    const SLOT_TYPE_REPEAT_DAILY = 2;
    const SLOT_TYPE_REPEAT_WEEKLY = 3;
    const SLOT_TYPE_REPEAT_MONTHLY = 4;
    const SLOT_TYPE_REPEAT_YEARLY = 5;

    use IdWithAccessors;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $timestampAdded;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private $timestampUpdated;

    /**
     * @var ScheduleSession
     *
     * @ORM\ManyToOne(targetEntity="ScheduleSession", inversedBy="timeSlots")
     * @ORM\JoinColumn(name="schedule_session_id", referencedColumnName="id")
     */
    private $scheduleSession;

    /**
     * @var int
     *
     * @ORM\Column(type="integer")
     *
     * 1 = specific date, specific time
     * 2 = daily repetition (every day or every N days)
     * 3 = weekly repetition (every week or every N weeks)
     * 3 = monthly repetition (every month or every N months)
     * 4 = yearly repetition (every year or N years)
     */
    private $slotType;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="datetime")
     */
    private $startDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="datetime")
     */
    private $finishDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="datetime")
     */
    private $startTime;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="datetime")
     */
    private $finishTime;

    /**
     * @var int
     *
     * @ORM\Column(type="integer", nullable=true)
     */
    private $repeatDailyN;

    /**
     * @var int
     *
     * @ORM\Column(type="integer", nullable=true)
     */
    private $repeatWeeklyN;

    /**
     * @var int
     *
     * @ORM\Column(type="integer", nullable=true)
     */
    private $repeatMonthlyN;

    /**
     * @var int
     *
     * @ORM\Column(type="integer", nullable=true)
     */
    private $repeatYearlyN;


    /**
     * Set timestampAdded
     *
     * @param \DateTime $timestampAdded
     *
     * @return TimeSlot
     */
    public function setTimestampAdded($timestampAdded)
    {
        $this->timestampAdded = $timestampAdded;

        return $this;
    }

    /**
     * Get timestampAdded
     *
     * @return \DateTime
     */
    public function getTimestampAdded()
    {
        return $this->timestampAdded;
    }

    /**
     * Set timestampUpdated
     *
     * @param \DateTime $timestampUpdated
     *
     * @return TimeSlot
     */
    public function setTimestampUpdated($timestampUpdated)
    {
        $this->timestampUpdated = $timestampUpdated;

        return $this;
    }

    /**
     * Get timestampUpdated
     *
     * @return \DateTime
     */
    public function getTimestampUpdated()
    {
        return $this->timestampUpdated;
    }

    /**
     * Set scheduleSession
     *
     * @param \AppBundle\Entity\ScheduleSession $scheduleSession
     *
     * @return TimeSlot
     */
    public function setScheduleSession(ScheduleSession $scheduleSession = null)
    {
        $this->scheduleSession = $scheduleSession;

        return $this;
    }

    /**
     * Get scheduleSession
     *
     * @return \AppBundle\Entity\ScheduleSession
     */
    public function getScheduleSession()
    {
        return $this->scheduleSession;
    }

    /**
     * Set slotType
     *
     * @param integer $slotType
     *
     * @return TimeSlot
     */
    public function setSlotType($slotType)
    {
        $this->slotType = $slotType;

        return $this;
    }

    /**
     * Get slotType
     *
     * @return integer
     */
    public function getSlotType()
    {
        return $this->slotType;
    }

    /**
     * Set startDate
     *
     * @param \DateTime $startDate
     *
     * @return TimeSlot
     */
    public function setStartDate($startDate)
    {
        $this->startDate = $startDate;

        return $this;
    }

    /**
     * Get startDate
     *
     * @return \DateTime
     */
    public function getStartDate()
    {
        return $this->startDate;
    }

    /**
     * Set finishDate
     *
     * @param \DateTime $finishDate
     *
     * @return TimeSlot
     */
    public function setFinishDate($finishDate)
    {
        $this->finishDate = $finishDate;

        return $this;
    }

    /**
     * Get finishDate
     *
     * @return \DateTime
     */
    public function getFinishDate()
    {
        return $this->finishDate;
    }

    /**
     * Set startTime
     *
     * @param \DateTime $startTime
     *
     * @return TimeSlot
     */
    public function setStartTime($startTime)
    {
        $this->startTime = $startTime;

        return $this;
    }

    /**
     * Get startTime
     *
     * @return \DateTime
     */
    public function getStartTime()
    {
        return $this->startTime;
    }

    /**
     * Set finishTime
     *
     * @param \DateTime $finishTime
     *
     * @return TimeSlot
     */
    public function setFinishTime($finishTime)
    {
        $this->finishTime = $finishTime;

        return $this;
    }

    /**
     * Get finishTime
     *
     * @return \DateTime
     */
    public function getFinishTime()
    {
        return $this->finishTime;
    }

    /**
     * Set repeatDailyN
     *
     * @param integer $repeatDailyN
     *
     * @return TimeSlot
     */
    public function setRepeatDailyN($repeatDailyN)
    {
        $this->repeatDailyN = $repeatDailyN;

        return $this;
    }

    /**
     * Get repeatDailyN
     *
     * @return integer
     */
    public function getRepeatDailyN()
    {
        return $this->repeatDailyN;
    }

    /**
     * Set repeatWeeklyN
     *
     * @param integer $repeatWeeklyN
     *
     * @return TimeSlot
     */
    public function setRepeatWeeklyN($repeatWeeklyN)
    {
        $this->repeatWeeklyN = $repeatWeeklyN;

        return $this;
    }

    /**
     * Get repeatWeeklyN
     *
     * @return integer
     */
    public function getRepeatWeeklyN()
    {
        return $this->repeatWeeklyN;
    }

    /**
     * Set repeatMonthlyN
     *
     * @param integer $repeatMonthlyN
     *
     * @return TimeSlot
     */
    public function setRepeatMonthlyN($repeatMonthlyN)
    {
        $this->repeatMonthlyN = $repeatMonthlyN;

        return $this;
    }

    /**
     * Get repeatMonthlyN
     *
     * @return integer
     */
    public function getRepeatMonthlyN()
    {
        return $this->repeatMonthlyN;
    }

    /**
     * Set repeatYearlyN
     *
     * @param integer $repeatYearlyN
     *
     * @return TimeSlot
     */
    public function setRepeatYearlyN($repeatYearlyN)
    {
        $this->repeatYearlyN = $repeatYearlyN;

        return $this;
    }

    /**
     * Get repeatYearlyN
     *
     * @return integer
     */
    public function getRepeatYearlyN()
    {
        return $this->repeatYearlyN;
    }

    public function __toString()
    {
        return (string)$this->getId();
    }
}

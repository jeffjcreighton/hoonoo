<?php

namespace AppBundle\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\HttpFoundation\File\File;
use Vich\UploaderBundle\Mapping\Annotation as Vich;
use Gedmo\Mapping\Annotation as Gedmo;
use AppBundle\Entity\Traits\IdWithAccessors;

/**
 * Class Taxonomy
 * @package AppBundle\Entity
 * @ORM\Entity(repositoryClass="\AppBundle\Repository\TaxonomyRepository")
 * @ORM\Table(name="taxonomy",uniqueConstraints={@ORM\UniqueConstraint(name="taxonomy_idx1",columns={"level1","level2","level3"})})
 * @Vich\Uploadable
 */
class Taxonomy
{
    /*
     * This list defines the default images to be used in the case that none is defined for the entity
     * (this is returned by the methid 'getDisplayImage')
     *
     * NOTE: the only top-level category not in this list is 'Camps & Travel'
     */
    private $taxonomyImageMap = [
        'Testing & Test Prep' => 'knoitall_0000_testing_test_prep.jpg',
        'Sports & Leisure' => 'knoitall_0001_sports_leisure.jpg',
        'Science & Math' => 'knoitall_0002_science_math.jpg',
        'Religion' => 'knoitall_0003_religion.jpg',
        'Philosophy' => 'knoitall_0004_philosophy.jpg',
        'Parenting' => 'knoitall_0005_parenting.jpg',
        'Legal Studies' => 'knoitall_0006_legal_studies.jpg',
        'Languages' => 'knoitall_0007_languages.jpg',
        'Home & Garden' => 'knoitall_0008_home_garden.jpg',
        'Hobbies & Games' => 'knoitall_0009_hobbies_games.jpg',
        'History' => 'knoitall_0010_history.jpg',
        'Health & Health Care' => 'knoitall_0011_health_health_care.jpg',
        'English, Literature & Writing' => 'knoitall_0012_english_literature_writing.jpg',
        'Engineering' => 'knoitall_0013_engineering.jpg',
        'Education' => 'knoitall_0014_education.jpg',
        'Cooking & Beverage' => 'knoitall_0015_cooking_beverage.jpg',
        'Computers & Software' => 'knoitall_0016_computers_software.jpg',
        'Business' => 'knoitall_0017_business.jpg',
        'Art, Drama & Music' => 'knoitall_0018_art_drama_music.jpg',
    ];

    /*
     * This defines the image to be used in the case that none is defined in the above list
     *
     * NOTE: because of the above list's almost-completeness, this should only be used for taxonomies where level1='Camps & Travel'
     */
    private $taxonomyImageDefault = 'default.jpg';

    use IdWithAccessors;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $timestampAdded;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private $timestampUpdated;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64)
     */
    private $level1;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64, nullable=true)
     */
    private $level2;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64, nullable=true)
     */
    private $level3;

    /**
     * @var string
     *
     * @Gedmo\Slug(fields={"level1","level2","level3"})
     * @ORM\Column(type="string", length=128, unique=true)
     */
    private $slug;

    /**
     * @ORM\Column(type="string", length=128, nullable=true)
     *
     * @var string
     */
    private $image;

    /**
     * @Vich\UploadableField(mapping="taxonomy_media", fileNameProperty="image")
     *
     * @var File
     */
    private $imageFile;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=23, nullable=false)
     */
    private $hash;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Tag", inversedBy="taxonomies")
     * @ORM\JoinTable(
     *     name="taxonomy_tag",
     *     joinColumns={@ORM\JoinColumn(name="taxonomy_id", referencedColumnName="id")},
     *     inverseJoinColumns={@ORM\JoinColumn(name="tag_keyword", referencedColumnName="keyword")}
     * )
     */
    private $tags;

    /**
     * @var $advisors \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Advisor", mappedBy="taxonomies")
     */
    private $advisors;

    /**
     * @var $instructors \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Instructor", mappedBy="taxonomies")
     */
    private $instructors;

    /**
     * @var $learners \Doctrine\Common\Collections\Collection;
     *
     * @ORM\ManyToMany(targetEntity="Learner", mappedBy="taxonomies")
     */
    private $learners;

    /**
     * @var $providers \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Provider", mappedBy="taxonomies")
     */
    private $providers;

    /**
     * @var $events \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Event", mappedBy="taxonomies")
     */
    private $events;

    /**
     * TODO: remove users attribute
     *
     * @var $users \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="User", mappedBy="taxonomies")
     */
    private $users;

    /**
     * @var $articles \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Article", mappedBy="taxonomies")
     */
    private $articles;

    /**
     * @var $inShortList boolean
     *
     * @ORM\Column(type="boolean", nullable=false)
     */
    private $inShortList;

    /**
     * @var integer
     *
     * @ORM\Column(type="integer", nullable=true)
     */
    private $originalRecordKey;

    /**
     * @ORM\ManyToOne(targetEntity="Taxonomy", inversedBy="children")
     * @ORM\JoinColumn(name="parent_id", referencedColumnName="id")
     */
    private $parent;

    /**
     * @ORM\OneToMany(targetEntity="Taxonomy", mappedBy="parent")
     */
    private $children;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->tags = new ArrayCollection();
        $this->learners = new ArrayCollection();
        $this->advisors = new ArrayCollection();
        $this->instructors = new ArrayCollection();
        $this->providers = new ArrayCollection();
        $this->users = new ArrayCollection(); // TODO: remove users property
        $this->events = new ArrayCollection();
        $this->articles = new ArrayCollection();
        $this->hash = uniqid( '', true );
        $this->children = new ArrayCollection();
    }

    /**
     * @param \DateTime
     *
     * @return \AppBundle\Entity\Taxonomy
     */
    public function setTimestampAdded($timestampAdded)
    {
        $this->timestampAdded = $timestampAdded;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampAdded()
    {
        return $this->timestampAdded;
    }

    /**
     * @param \DateTime
     *
     * @return \AppBundle\Entity\Taxonomy
     */
    public function setTimestampUpdated(\DateTime $timestampUpdated = null)
    {
        if ($timestampUpdated === null) {
            $timestampUpdated = new \DateTime();
        }

        $this->timestampUpdated = $timestampUpdated;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampUpdated()
    {
        return $this->timestampUpdated;
    }

    /**
     * Set level1
     *
     * @param string $level1
     *
     * @return \AppBundle\Entity\Taxonomy
     */
    public function setLevel1($level1)
    {
        $this->level1 = $level1;

        return $this;
    }

    /**
     * Get level1
     *
     * @return string
     */
    public function getLevel1()
    {
        return $this->level1;
    }

    /**
     * Set level2
     *
     * @param string $level2
     *
     * @return \AppBundle\Entity\Taxonomy
     */
    public function setLevel2($level2)
    {
        $this->level2 = $level2;

        return $this;
    }

    /**
     * Get level2
     *
     * @return string
     */
    public function getLevel2()
    {
        return $this->level2;
    }

    /**
     * Set level3
     *
     * @param string $level3
     *
     * @return \AppBundle\Entity\Taxonomy
     */
    public function setLevel3($level3)
    {
        $this->level3 = $level3;

        return $this;
    }

    /**
     * Get level3
     *
     * @return string
     */
    public function getLevel3()
    {
        return $this->level3;
    }

    /**
     * Add advisor
     *
     * @param \AppBundle\Entity\Advisor $advisor
     *
     * @return \AppBundle\Entity\Taxonomy
     */
    public function addAdvisor(Advisor $advisor)
    {
        $this->advisors[] = $advisor;

        return $this;
    }

    /**
     * Remove advisor
     *
     * @param \AppBundle\Entity\Advisor $advisor
     */
    public function removeAdvisor(Advisor $advisor)
    {
        $this->advisors->removeElement($advisor);
    }

    /**
     * Get advisors
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getAdvisors()
    {
        return $this->advisors;
    }

    /**
     * Add instructor
     *
     * @param \AppBundle\Entity\Instructor $instructor
     *
     * @return \AppBundle\Entity\Taxonomy
     */
    public function addInstructor(Instructor $instructor)
    {
        $this->instructors[] = $instructor;

        return $this;
    }

    /**
     * Remove instructor
     *
     * @param \AppBundle\Entity\Instructor $instructor
     */
    public function removeInstructor(Instructor $instructor)
    {
        $this->instructors->removeElement($instructor);
    }

    /**
     * Get instructors
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getInstructors()
    {
        return $this->instructors;
    }

    /**
     * Add learner
     *
     * @param \AppBundle\Entity\Learner $learner
     *
     * @return \AppBundle\Entity\Taxonomy
     */
    public function addLearner(Learner $learner)
    {
        $this->learners[] = $learner;

        return $this;
    }

    /**
     * Remove learner
     *
     * @param \AppBundle\Entity\Learner $learner
     */
    public function removeLearner(Learner $learner)
    {
        $this->learners->removeElement($learner);
    }

    /**
     * Get learners
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getLearners()
    {
        return $this->learners;
    }

    /**
     * Add provider
     *
     * @param \AppBundle\Entity\Provider $provider
     *
     * @return \AppBundle\Entity\Taxonomy
     */
    public function addProvider(Provider $provider)
    {
        $this->providers[] = $provider;

        return $this;
    }

    /**
     * Remove provider
     *
     * @param \AppBundle\Entity\Provider $provider
     */
    public function removeProvider(Provider $provider)
    {
        $this->providers->removeElement($provider);
    }

    /**
     * Get providers
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getProviders()
    {
        return $this->providers;
    }

    /**
     * Add user
     *
     * @param \AppBundle\Entity\User $user
     *
     * @return \AppBundle\Entity\Taxonomy
     */
    public function addUser(User $user)
    {
        $this->users[] = $user;

        return $this;
    }

    /**
     * Remove user
     *
     * @param \AppBundle\Entity\User $user
     */
    public function removeUser(User $user)
    {
        $this->users->removeElement($user);
    }

    /**
     * Get users
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getUsers()
    {
        return $this->users;
    }

    /**
     * Add event
     *
     * @param \AppBundle\Entity\Event $event
     *
     * @return \AppBundle\Entity\Taxonomy
     */
    public function addEvent(Event $event)
    {
        $this->events[] = $event;

        return $this;
    }

    /**
     * Remove event
     *
     * @param \AppBundle\Entity\Event $event
     */
    public function removeEvent(Event $event)
    {
        $this->events->removeElement($event);
    }

    /**
     * Get events
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getEvents()
    {
        return $this->events;
    }

    /**
     * Add article
     *
     * @param \AppBundle\Entity\Article $article
     *
     * @return \AppBundle\Entity\Taxonomy
     */
    public function addArticle(Article $article)
    {
        $this->articles[] = $article;

        return $this;
    }

    /**
     * Remove article
     *
     * @param \AppBundle\Entity\Article $article
     */
    public function removeArticle(Article $article)
    {
        $this->articles->removeElement($article);
    }

    /**
     * Get articles
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getArticles()
    {
        return $this->articles;
    }

    /**
     * @param File|null $imageFile
     *
     * @return \AppBundle\Entity\Taxonomy
     */
    public function setImageFile(File $imageFile = null)
    {
        $this->imageFile = $imageFile;

        // VERY IMPORTANT:
        // It is required that at least one field changes if you are using Doctrine,
        // otherwise the event listeners won't be called and the file is lost
        if ($imageFile) {
            $this->timestampUpdated = new \DateTime('now');
        }

        return $this;
    }

    /**
     * @return File
     */
    public function getImageFile()
    {
        return $this->imageFile;
    }

    /**
     * @param $image
     *
     * @return \AppBundle\Entity\Taxonomy
     */
    public function setImage($image)
    {
        $this->image = $image;

        return $this;
    }

    /**
     * @return string
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * Set hash
     *
     * @param string $hash
     *
     * @return \AppBundle\Entity\Taxonomy
     */
    public function setHash($hash)
    {
        $this->hash = $hash;

        return $this;
    }

    /**
     * Get hash
     *
     * @return string
     */
    public function getHash()
    {
        return $this->hash;
    }

    /**
     * Set slug
     *
     * @param string $slug
     *
     * @return \AppBundle\Entity\Taxonomy
     */
    public function setSlug($slug)
    {
        $this->slug = $slug;

        return $this;
    }

    /**
     * Get slug
     *
     * @return string
     */
    public function getSlug()
    {
        return $this->slug;
    }

    /**
     * Add tag
     *
     * @param \AppBundle\Entity\Tag $tag
     *
     * @return Taxonomy
     */
    public function addTag(Tag $tag)
    {
        $this->tags[] = $tag;

        return $this;
    }

    /**
     * Remove tag
     *
     * @param \AppBundle\Entity\Tag $tag
     */
    public function removeTag(Tag $tag)
    {
        $this->tags->removeElement($tag);
    }

    /**
     * Get tags
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getTags()
    {
        return $this->tags;
    }

    /**
     * Set inShortList
     *
     * @param boolean $inShortList
     *
     * @return Taxonomy
     */
    public function setInShortList($inShortList)
    {
        $this->inShortList = $inShortList;

        return $this;
    }

    /**
     * Get inShortList
     *
     * @return boolean
     */
    public function getInShortList()
    {
        return $this->inShortList;
    }

    /**
     * Set originalRecordKey
     *
     * @param integer $originalRecordKey
     *
     * @return Taxonomy
     */
    public function setOriginalRecordKey($originalRecordKey)
    {
        $this->originalRecordKey = $originalRecordKey;

        return $this;
    }

    /**
     * Get originalRecordKey
     *
     * @return integer
     */
    public function getOriginalRecordKey()
    {
        return $this->originalRecordKey;
    }

    /**
     * Set parent
     *
     * @param \AppBundle\Entity\Taxonomy $parent
     *
     * @return Taxonomy
     */
    public function setParent(Taxonomy $parent = null)
    {
        $this->parent = $parent;

        return $this;
    }

    /**
     * Get parent
     *
     * @return \AppBundle\Entity\Taxonomy
     */
    public function getParent()
    {
        return $this->parent;
    }

    /**
     * Add child
     *
     * @param \AppBundle\Entity\Taxonomy $child
     *
     * @return Taxonomy
     */
    public function addChild(Taxonomy $child)
    {
        $this->children[] = $child;

        return $this;
    }

    /**
     * Remove child
     *
     * @param \AppBundle\Entity\Taxonomy $child
     */
    public function removeChild(Taxonomy $child)
    {
        $this->children->removeElement($child);
    }

    /**
     * Get children
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getChildren()
    {
        return $this->children;
    }

    /**
     * @return string
     */
    public function getDisplayImage()
    {
        if( $this->getImage() ) {
            return "/media/taxonomy/" . $this->getHash() . "/" . $this->image;
        }

        if( $this->getParent() && $this->getParent()->getImage() ) {
            return "/media/taxonomy/" . $this->getParent()->getHash() . "/" . $this->getParent()->getImage();
        }

        if( $this->getParent() && $this->getParent()->getParent() && $this->getParent()->getParent()->getImage() ) {
            return "/media/taxonomy/" . $this->getParent()->getParent()->getHash() . "/" . $this->getParent()->getParent()->getImage();
        }

        if( isset($this->taxonomyImageMap[$this->getLevel1()]) ) {
            return "/images/classes/" . $this->taxonomyImageMap[$this->getLevel1()];
        }

        return "/images/classes/" . $this->taxonomyImageDefault;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        $name = $this->getLevel1();
        if( $this->getLevel2() ) { $name .= ': ' . $this->getLevel2(); }
        if( $this->getLevel3() ) { $name .= ': ' . $this->getLevel3(); }
        return $name;
    }
}

<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use AppBundle\Entity\Traits\IdWithAccessors;
use AppBundle\Entity\Provider;
use AppBundle\Entity\Event;

/**
 * Class FeedAddPostEvent
 *
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="feed_addpost_event")
 */
class FeedAddPostEvent
{
    use IdWithAccessors;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $timestampAdded;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private $timestampUpdated;

    /**
     * @var Provider
     *
     * @ORM\ManyToOne(targetEntity="Provider", inversedBy="feedAddPostEvents")
     * @ORM\JoinColumn(name="provider_id", referencedColumnName="id", nullable=false)
     */
    private $provider;

    /**
     * @var Event
     *
     * @ORM\ManyToOne(targetEntity="Event", inversedBy="feedAddPostEvents")
     * @ORM\JoinColumn(name="event_id", referencedColumnName="id", nullable=false)
     */
    private $event;

    /**
     * @var $pushedToGetstream
     *
     * @ORM\Column(type="boolean", nullable=false, options={"default":false})
     */
    private $pushedToGetstream;

    /**
     * Set timestampAdded
     *
     * @param \DateTime $timestampAdded
     *
     * @return FeedAddPostEvent
     */
    public function setTimestampAdded($timestampAdded)
    {
        $this->timestampAdded = $timestampAdded;

        return $this;
    }

    /**
     * Get timestampAdded
     *
     * @return \DateTime
     */
    public function getTimestampAdded()
    {
        return $this->timestampAdded;
    }

    /**
     * Set timestampUpdated
     *
     * @param \DateTime $timestampUpdated
     *
     * @return FeedAddPostEvent
     */
    public function setTimestampUpdated($timestampUpdated)
    {
        $this->timestampUpdated = $timestampUpdated;

        return $this;
    }

    /**
     * Get timestampUpdated
     *
     * @return \DateTime
     */
    public function getTimestampUpdated()
    {
        return $this->timestampUpdated;
    }

    /**
     * Set provider
     *
     * @param Provider $provider
     *
     * @return FeedAddPostEvent
     */
    public function setProvider(Provider $provider)
    {
        $this->provider = $provider;

        return $this;
    }

    /**
     * Get provider
     *
     * @return Provider
     */
    public function getProvider()
    {
        return $this->provider;
    }

    /**
     * Set event
     *
     * @param  $event
     *
     * @return FeedAddPostEvent
     */
    public function setEvent($event)
    {
        $this->event = $event;

        return $this;
    }

    /**
     * Get event
     *
     * @return 
     */
    public function getEvent()
    {
        return $this->event;
    }

    /**
     * Set pushedToGetstream
     *
     * @param boolean $pushedToGetstream
     *
     * @return FeedAddPostEvent
     */
    public function setPushedToGetstream($pushedToGetstream)
    {
        $this->pushedToGetstream = $pushedToGetstream;

        return $this;
    }

    /**
     * Get pushedToGetstream
     *
     * @return boolean
     */
    public function getPushedToGetstream()
    {
        return $this->pushedToGetstream;
    }
}

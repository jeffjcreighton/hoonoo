<?php

namespace AppBundle\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * @ORM\Table(name="tag")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\TagRepository")
 */
class Tag
{
    /**
     * @var string
     *
     * @ORM\Column(type="string", length=128, nullable=false)
     * @ORM\Id
     */
    private $keyword;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $timestampAdded;

    /**
     * @var \DateTime
     *
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private $timestampUpdated;

    /**
     * @var string
     *
     * @Gedmo\Slug(fields={"keyword"})
     * @ORM\Column(type="string", length=64, unique=true)
     */
    private $slug;

    /**
     * @var $taxonomies \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Taxonomy", mappedBy="tags")
     */
    private $taxonomies;

    /**
     * @var Collection;
     *
     * @ORM\ManyToMany(targetEntity="Article", mappedBy="tags")
     */
    private $articles;

    public function __construct()
    {
        $this->articles = new ArrayCollection();
    }

    /**
     * @param \DateTime
     *
     * @return \AppBundle\Entity\Taxonomy
     */
    public function setTimestampAdded($timestampAdded)
    {
        $this->timestampAdded = $timestampAdded;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampAdded()
    {
        return $this->timestampAdded;
    }

    /**
     * @param \DateTime
     *
     * @return \AppBundle\Entity\Taxonomy
     */
    public function setTimestampUpdated(\DateTime $timestampUpdated = null)
    {
        if ($timestampUpdated === null) {
            $timestampUpdated = new \DateTime();
        }

        $this->timestampUpdated = $timestampUpdated;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getTimestampUpdated()
    {
        return $this->timestampUpdated;
    }

    /**
     * @param string $keyword
     * @return Tag
     */
    public function set($keyword)
    {
        $this->keyword = $keyword;

        return $this;
    }

    /**
     * @return string
     */
    public function getKeyword()
    {
        return $this->keyword;
    }

    /**
     * @param string $slug
     *
     * @return Tag
     */
    public function setSlug($slug)
    {
        $this->slug = $slug;

        return $this;
    }

    /**
     * @return string
     */
    public function getSlug()
    {
        return $this->slug;
    }

    /**
     * @param Article $article
     *
     * @return Tag
     */
    public function addArticle(Article $article)
    {
        $this->articles[] = $article;

        return $this;
    }

    /**
     * @param Article $article
     *
     * @return Tag
     */
    public function removeArticle(Article $article)
    {
        $this->articles->removeElement($article);

        return $this;
    }

    /**
     * @return Collection
     */
    public function getArticles()
    {
        return $this->articles;
    }

    /**
     * Set keyword
     *
     * @param string $keyword
     *
     * @return Tag
     */
    public function setKeyword($keyword)
    {
        $this->keyword = $keyword;

        return $this;
    }

    /**
     * Add taxonomy
     *
     * @param \AppBundle\Entity\Taxonomy $taxonomy
     *
     * @return Tag
     */
    public function addTaxonomy(Taxonomy $taxonomy)
    {
        $this->taxonomies[] = $taxonomy;

        return $this;
    }

    /**
     * Remove taxonomy
     *
     * @param \AppBundle\Entity\Taxonomy $taxonomy
     */
    public function removeTaxonomy(Taxonomy $taxonomy)
    {
        $this->taxonomies->removeElement($taxonomy);
    }

    /**
     * Get taxonomies
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getTaxonomies()
    {
        return $this->taxonomies;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->keyword;
    }
}

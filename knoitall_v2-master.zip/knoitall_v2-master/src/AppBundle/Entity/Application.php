<?php

namespace AppBundle\Entity;

class Application
{
    const KNOITALL_NAME = "Knoitall";
    const KNOITALL_TITLE = "The World's Learning Network";
    const KNOITALL_DESCRIPTION = "Knoitall is the world's human capital network, connecting individuals to a network of people, learning opportunities and resources to help them grow in their careers and personal lives. We build community around learning content from training providers, accredited education, coaches, and elearning sources to fulfill an organization's or individual's needed skills. The result is a custom learning center to support human capital development.";
    const KNOITALL_KEYWORDS = "learning management system,lms, human capital, corporate university,corporate learning,skills development,skills mapping,competency mapping,education institutes, faculty, teaching professionals, education lead generation, education advertising, cpc, click through advertising, training and development,leadership training train my employees, online employee training, human resources, corporate university, learning center, corporate learning center, chief learning officer";
}

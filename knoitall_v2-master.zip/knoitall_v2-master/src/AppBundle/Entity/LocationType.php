<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use AppBundle\Entity\Traits\IdWithAccessors;

/**
 * Class Taxonomy
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="location_type")
 */
class LocationType
{
    use IdWithAccessors;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64)
     */
    private $description;

    /**
     * @ORM\OneToMany(targetEntity="Location", mappedBy="locationType")
     */
    private $locations;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->locations = new ArrayCollection();
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return \AppBundle\Entity\LocationType
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Add location
     *
     * @param \AppBundle\Entity\Location $location
     *
     * @return LocationType
     */
    public function addLocation(Location $location)
    {
        $this->locations[] = $location;

        return $this;
    }

    /**
     * Remove location
     *
     * @param \AppBundle\Entity\Location $location
     */
    public function removeLocation(Location $location)
    {
        $this->locations->removeElement($location);
    }

    /**
     * Get locations
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getLocations()
    {
        return $this->locations;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->description;
    }
}

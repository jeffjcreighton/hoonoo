<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\Collection;
use AppBundle\Entity\Traits\IdWithAccessors;

/**
 * Class PersonTitle
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="person_title")
 */
class PersonTitle
{
    use IdWithAccessors;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=16)
     */
    private $description;

    /**
     * @var Collection
     *
     * @ORM\OneToMany(targetEntity="Person", mappedBy="personTitle")
     */
    private $persons;
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->persons = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return PersonTitle
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Add person
     *
     * @param \AppBundle\Entity\Person $person
     *
     * @return PersonTitle
     */
    public function addPerson(Person $person)
    {
        $this->persons[] = $person;

        return $this;
    }

    /**
     * Remove person
     *
     * @param \AppBundle\Entity\Person $person
     */
    public function removePerson(Person $person)
    {
        $this->persons->removeElement($person);
    }

    /**
     * Get persons
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPersons()
    {
        return $this->persons;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->description;
    }
}

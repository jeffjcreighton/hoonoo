<?php

namespace AppBundle\Entity;

use AppBundle\Entity\Traits\IdWithAccessors;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * Class Taxonomy
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="postalcode")
 */
class Postalcode
{
    use IdWithAccessors;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=16)
     */
    private $zip;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=64)
     */
    private $city;

    /**
     * @var \AppBundle\Entity\State
     *
     * @ORM\ManyToOne(targetEntity="State", inversedBy="postalcodes")
     * @ORM\JoinColumn(name="state_id", referencedColumnName="id")
     */
    private $state;

    /**
     * @var float
     *
     * @ORM\Column(type="decimal", scale=6)
     */
    private $latitude;

    /**
     * @var float
     *
     * @ORM\Column(type="decimal", scale=6)
     */
    private $longitude;

    /**
     * @ORM\OneToMany(targetEntity="Person", mappedBy="postalcode")
     */
    private $persons;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->persons = new ArrayCollection();
    }

    /**
     * Set zip
     *
     * @param string $zip
     *
     * @return \AppBundle\Entity\Postalcode
     */
    public function setZip($zip)
    {
        $this->zip = $zip;

        return $this;
    }

    /**
     * Get zip
     *
     * @return string
     */
    public function getZip()
    {
        return $this->zip;
    }

    /**
     * Set city
     *
     * @param string $city
     *
     * @return \AppBundle\Entity\Postalcode
     */
    public function setCity($city)
    {
        $this->city = $city;

        return $this;
    }

    /**
     * Get city
     *
     * @return string
     */
    public function getCity()
    {
        return $this->city;
    }

    /**
     * Set state
     *
     * @param \AppBundle\Entity\State $state
     *
     * @return \AppBundle\Entity\Postalcode
     */
    public function setState(State $state)
    {
        $this->state = $state;

        return $this;
    }

    /**
     * Get state
     *
     * @return \AppBundle\Entity\State
     */
    public function getState()
    {
        return $this->state;
    }

    /**
     * Set latitude
     *
     * @param float $latitude
     *
     * @return \AppBundle\Entity\Postalcode
     */
    public function setLatitude($latitude)
    {
        $this->latitude = $latitude;

        return $this;
    }

    /**
     * Get latitude
     *
     * @return float
     */
    public function getLatitude()
    {
        return $this->latitude;
    }

    /**
     * Set longitude
     *
     * @param float $longitude
     *
     * @return \AppBundle\Entity\Postalcode
     */
    public function setLongitude($longitude)
    {
        $this->longitude = $longitude;

        return $this;
    }

    /**
     * Get longitude
     *
     * @return float
     */
    public function getLongitude()
    {
        return $this->longitude;
    }

    /**
     * Add person
     *
     * @param \AppBundle\Entity\Person $person
     *
     * @return \AppBundle\Entity\Postalcode
     */
    public function addPerson(Person $person)
    {
        $this->persons[] = $person;

        return $this;
    }

    /**
     * Remove person
     *
     * @param \AppBundle\Entity\Person $person
     */
    public function removePerson(Person $person)
    {
        $this->persons->removeElement($person);
    }

    /**
     * Get persons
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPersons()
    {
        return $this->persons;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->zip;
    }
}

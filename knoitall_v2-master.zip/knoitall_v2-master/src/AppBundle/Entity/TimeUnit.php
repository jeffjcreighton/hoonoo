<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use AppBundle\Entity\Traits\IdWithAccessors;

/**
 * Class TimeUnit
 * @package AppBundle\Entity
 * @ORM\Entity
 * @ORM\Table(name="time_unit")
 */
class TimeUnit
{
    use IdWithAccessors;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=16)
     */
    private $description;

    /**
     * Set description
     *
     * @param string $description
     *
     * @return \AppBundle\Entity\TimeUnit
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->description;
    }
}

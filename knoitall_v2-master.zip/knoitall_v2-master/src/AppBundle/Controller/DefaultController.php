<?php

namespace AppBundle\Controller;

use AppBundle\Entity\TopEvent;
use AppBundle\Entity\TopProvider;
use AppBundle\Entity\TopTaxonomy;
use AppBundle\Entity\Transient\ForgotPassword;
use AppBundle\Entity\User;
use AppBundle\Form\RegistrationType;
use AppBundle\Form\Transient\ForgotPasswordType;
use FOS\UserBundle\Form\Type\RegistrationFormType;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Security\Core\Security;
use AppBundle\Entity\Advisor;
use AppBundle\Entity\Age;
use AppBundle\Entity\Article;
use AppBundle\Entity\Event;
use AppBundle\Entity\Instructor;
use AppBundle\Entity\Learner;
use AppBundle\Entity\Provider;
use AppBundle\Entity\Taxonomy;
use AppBundle\Entity\Transient\KnoitallSearch;
use AppBundle\Form\Transient\KnoitallSearchType;
use AppBundle\Repository\LearnerRepository;
use AppBundle\Repository\AdvisorRepository;
use AppBundle\Repository\InstructorRepository;
use AppBundle\Repository\ProviderRepository;
use AppBundle\Repository\EventRepository;
use AppBundle\Repository\ArticleRepository;

use FOS\UserBundle\Form\Factory\FactoryInterface;
use FOS\UserBundle\Model\UserManagerInterface;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use FOS\UserBundle\FOSUserEvents;
use FOS\UserBundle\Event\GetResponseUserEvent;
use FOS\UserBundle\Event\FormEvent;
use Symfony\Component\HttpFoundation\RedirectResponse;
use FOS\UserBundle\Event\FilterUserResponseEvent;

class DefaultController extends Controller
{
    /**
     * @param Request $request
     * @return Response
     * @Route("/", name="knoitall_homepage")
     */
    public function indexAction(Request $request)
    {
        if( $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            /** @var \AppBundle\Entity\User $user */
            $user = $this->get('security.token_storage')->getToken()->getUser();
            if( ! count($user->getPerson()->getProviders()) ) {
                return $this->redirectToRoute('knoitall_provider_profile_wizard');
            }         
            if( ! count($user->getPerson()->getLearners()) ) {
                return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
            }  
        }

        $topTaxonomyRepository = $this->getDoctrine()->getRepository(TopTaxonomy::class);
        /** @var TopTaxonomy[] $topTaxonomies */
        $topTaxonomies = $topTaxonomyRepository->findAll();

        $topProviderRepository = $this->getDoctrine()->getRepository(TopProvider::class);
        /** @var TopProvider[] $topProviders */
        $topProviders = $topProviderRepository->findAll();

        $topEventRepository = $this->getDoctrine()->getRepository(TopEvent::class);
        /** @var TopEvent[] $topEvents */
        $topEvents = $topEventRepository->findAll();

        $knoitallSearch = new KnoitallSearch();
        $searchForm = $this->createForm( KnoitallSearchType::class, $knoitallSearch, [
            'action' => $this->generateUrl('knoitall_search')
        ] );

        return $this->render('default/index.html.twig', [
            ////'base_dir' => realpath($this->getParameter('kernel.root_dir').'/..'),
            'topTaxonomies' => $topTaxonomies,
            'topProviders' => $topProviders,
            'topEvents' => $topEvents,
            'searchForm' => $searchForm->createView(),
//            'disableSearchInNavbar' => true,
        ]);
    }

    /**
     * @param Request $request
     * @return Response
     * @Route("/debug", name="knoitall_debug")
     */
    public function debugAction(Request $request, $data=null)
    {
        return $this->render('debug.html.twig', [
            'data' => $data
        ]);
    }

    /**
     * @param Request $request
     * @return Response
     * @Route("/lorem-ipsum", name="knoitall_lorem_ipsum")
     */
    public function loremIpsumAction(Request $request)
    {
        return $this->render('default/lorem_ipsum.html.twig');
    }

    /**
     * @param Request $request
     * @return Response
     * @Route("/search", name="knoitall_search")
     *
     * TODO: make this controller handle GET requests as well
     */
    public function searchAction( Request $request )
    {
        $knoitallSearch = new KnoitallSearch();

        $form = $this->createForm( KnoitallSearchType::class, $knoitallSearch );

        $form->handleRequest($request);

        if( $form->isSubmitted() and $form->isValid() ) {
            $knoitallSearch = $form->getData();

            /** @var LearnerRepository $learnerRepository */
            $learnerRepository = $this->getDoctrine()->getRepository('AppBundle:Learner');

            /** @var AdvisorRepository $advisorRepository */
            $advisorRepository = $this->getDoctrine()->getRepository('AppBundle:Advisor');

            /** @var InstructorRepository $instructorRepository */
            $instructorRepository = $this->getDoctrine()->getRepository('AppBundle:Instructor');

            /** @var ProviderRepository $providerRepository */
            $providerRepository = $this->getDoctrine()->getRepository('AppBundle:Provider');

            /** @var EventRepository $eventRepository */
            $eventRepository = $this->getDoctrine()->getRepository('AppBundle:Event');

            /** @var ArticleRepository $articleRepository */
            $articleRepository = $this->getDoctrine()->getRepository('AppBundle:Article');

            $learners = [];
            $advisors = [];
            $instructors = [];
            $providers = [];
            $events = [];
            $articles = [];
            if( $taxonomy = $knoitallSearch->getTaxonomy() ) {
                $learners = $learnerRepository->findAllHavingTaxonomy( $taxonomy );
                $advisors = $advisorRepository->findAllHavingTaxonomy( $taxonomy );
                $instructors = $instructorRepository->findAllHavingTaxonomy( $taxonomy );
                $providers = $providerRepository->findAllHavingTaxonomy( $taxonomy );
                $events = $eventRepository->findAllHavingTaxonomy($taxonomy);
                $articles = $articleRepository->findAllHavingTaxonomy( $taxonomy );
            }

            $materials = array_merge( $events, $providers, $advisors, $instructors, $learners, $articles );

            /*
             * get isotope data for the set of materials:
             * i.e. find out which isotopes are actually present in the data set $materials
             */
            $isotopes = [];
            $labels = [];
            foreach( $materials as $material ) {
                if( $material instanceof Learner ) {
                    /** @var $material Learner */
                    if( ! isset($labels['Learner']) ) {
                        $isotopes[] = [
                            'label' => 'Learner',
                            'group' => 'type',
                            'isotopes' => ['type-learner'],
                            'order' => 1,
                        ];
                        $labels['Learner'] = true;
                    }
                } elseif( $material instanceof Advisor ) {
                    /** @var $material Advisor */
                    if( ! isset($labels['Advisor']) ) {
                        $isotopes[] = [
                            'label' => 'Advisor',
                            'group' => 'type',
                            'isotopes' => ['type-advisor'],
                            'order' => 2,
                        ];
                        $labels['Advisor'] = true;
                    }
                } elseif( $material instanceof Instructor ) {
                    /** @var $material Instructor */
                    if( ! isset($labels['Instructor']) ) {
                        $isotopes[] = [
                            'label' => 'Instructor',
                            'group' => 'type',
                            'isotopes' => ['type-instructor'],
                            'order' => 3,
                        ];
                        $labels['Instructor'] = true;
                    }
                } elseif(  $material instanceof Provider ) {
                    /** @var $material Provider */
                    if( ! isset($labels['Provider']) ) {
                        $isotopes[] = [
                            'label' => 'Provider',
                            'group' => 'type',
                            'isotopes' => ['type-provider'],
                            'order' => 4,
                        ];
                        $labels['Provider'] = true;
                    }
                    if( ! isset($labels[$material->getTitle()]) ) {
                        $isotopes[] = [
                            'label' => $material->getTitle(),
                            'group' => 'provider',
                            'isotopes' => ['provider-' . $material->getNickname()],
                            'order' => 100,
                        ];
                        $labels[$material->getTitle()] = true;
                    }
                } elseif( $material instanceof Event ) {
                    /** @var $material Event */
                    if( ! isset($labels['Event']) ) {
                        $isotopes[] = [
                            'label' => 'Event',
                            'group' => 'type',
                            'isotopes' => ['type-event'],
                            'order' => 5,
                        ];
                        $labels['Event'] = true;
                    }
                    if( ! isset($labels[$material->getProvider()->getTitle()])) {
                        $isotopes[] = [
                            'label' => $material->getProvider()->getTitle(),
                            'group' => 'provider',
                            'isotopes' => ['provider-' . $material->getProvider()->getNickname()],
                            'order' => 100,
                        ];
                        $labels[$material->getTitle()] = true;
                    }

                    if( preg_match( "/Free/i", $material->getEventFormat() ) and ! isset($labels['Free']) ) {
                        $isotopes[] =  [
                            'label' => 'Free',
                            'group' => 'format',
                            'isotopes' => ['format-free'],
                            'order' => 10,
                        ];
                        $labels['Free'] = true;
                    }

                    if( preg_match( "/Certificate/i", $material->getEventFormat() ) and ! isset($labels['Certificate']) ) {
                        $isotopes[] = [
                            'label' => 'Certificate',
                            'group' => 'format',
                            'isotopes' => ['format-certificate'],
                            'order' => 11,
                        ];
                        $labels['Certificate'] = true;
                    }

                    if( preg_match( "/Undergraduate/i", $material->getEventFormat() ) and ! isset($labels['Undergrad']) ) {
                        $isotopes[] = [
                            'label' => 'Undergrad',
                            'group' => 'format',
                            'isotopes' => ['format-undergraduate'],
                            'order' => 12,
                        ];
                        $labels['Undergrad'] = true;
                    }

                    if(
                        preg_match( "/Graduate/i", $material->getEventFormat() ) and
                        ! preg_match( "/Undergraduate/i", $material->getEventFormat() ) and
                        ! isset($labels['Grad'])
                    ) {
                        $isotopes[] = [
                            'label' => 'Grad',
                            'group' => 'format',
                            'isotopes' => ['format-graduate'],
                            'order' => 13,
                        ];
                        $labels['Grad'] = true;
                    }

                    if( preg_match( "/Product/i", $material->getEventFormat() ) and ! isset($labels['Product']) ) {
                        $isotopes[] = [
                            'label' => 'Product',
                            'group' => 'format',
                            'isotopes' => ['format-product'],
                            'order' => 14,
                        ];
                        $labels['Product'] = true;
                    }

                    if( preg_match( "/Face-to-Face/i", $material->getEventFormat() ) and ! isset($labels['Face-to-Face']) ) {
                        $isotopes[] = [
                            'label' => 'Face-to-Face',
                            'group' => 'format',
                            'isotopes' => ['format-facetoface'],
                            'order' => 15,
                        ];
                        $labels['Face-to-Face'] = true;
                    }

                    if( preg_match( "/Online/i", $material->getEventFormat() ) and ! isset($labels['Online']) ) {
                        $isotopes[] = [
                            'label' => 'Online',
                            'group' => 'format',
                            'isotopes' => ['format-online'],
                            'order' => 16,
                        ];
                        $labels['Online'] = true;
                    }

                    foreach( $material->getAges() as $age ) {
                        /** @var $age Age */
                        if( in_array( $age->getDescription(), ['Infant','Toddler','Child','Pre-teen'] ) and ! isset($labels['Child']) ) {
                            $isotopes[] = [
                                'label' => 'Child',
                                'group' => 'age',
                                'isotopes' => ['age-infant','age-toddler','age-child','age-preteen'],
                                'order' => 20,
                            ];
                            $labels['Child'] = true;
                        }
                        if( in_array( $age->getDescription(), ['Teen','Adult','Senior'] ) and ! isset($labels['Adult']) ) {
                            $isotopes[] = [
                                'label' => 'Adult',
                                'group' => 'age',
                                'isotopes' => ['age-teen','age-adult','age-senior'],
                                'order' => 21,
                            ];
                            $labels['Adult'] = true;
                        }
                    }

                } elseif( $material instanceof Article ) {
                    /** @var $material Article */
                    if( ! isset($labels['Article']) ) {
                        $isotopes[] = [
                            'label' => 'Article',
                            'group' => 'type',
                            'isotopes' => ['type-article'],
                            'order' => 6,
                        ];
                        $labels['Article'] = true;
                    }
                }
            }

            usort( $isotopes, [$this,'isotope_cmp'] );

            return $this->render( 'search.html.twig', [
                'form' => $form->createView(),
                'materials' => $materials,
                'isotopes' => $isotopes,
            ]);
        }

        return $this->render( 'search.html.twig', ['form' => $form->createView(), 'materials' => [], 'isotopes' => []] );
    }

    /**
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @param $taxonomy \AppBundle\Entity\Taxonomy
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/search-by-url-input/{id}", name="knoitall_search_by_url_input", defaults={"id" = null})
     * @ParamConverter("taxonomy", class="AppBundle\Entity\Taxonomy", isOptional="true")
     */
    public function searchByUrlInputAction( Request $request, Taxonomy $taxonomy = null )
    {
        if( !$taxonomy ) {
            return $this->redirectToRoute('knoitall_search');
        }

        $knoitallSearch = new KnoitallSearch();
        $knoitallSearch->setTaxonomy($taxonomy);

        $form = $this->createForm( KnoitallSearchType::class, $knoitallSearch );

        $form->handleRequest($request);

        if( $form->isSubmitted() and $form->isValid() ) {
            $knoitallSearch = $form->getData();

            /** @var LearnerRepository $learnerRepository */
            $learnerRepository = $this->getDoctrine()->getRepository('AppBundle:Learner');

            /** @var AdvisorRepository $advisorRepository */
            $advisorRepository = $this->getDoctrine()->getRepository('AppBundle:Advisor');

            /** @var InstructorRepository $instructorRepository */
            $instructorRepository = $this->getDoctrine()->getRepository('AppBundle:Instructor');

            /** @var ProviderRepository $providerRepository */
            $providerRepository = $this->getDoctrine()->getRepository('AppBundle:Provider');

            /** @var EventRepository $eventRepository */
            $eventRepository = $this->getDoctrine()->getRepository('AppBundle:Event');

            /** @var ArticleRepository $articleRepository */
            $articleRepository = $this->getDoctrine()->getRepository('AppBundle:Article');

            $learners = [];
            $advisors = [];
            $instructors = [];
            $providers = [];
            $events = [];
            $articles = [];
            if( $taxonomy = $knoitallSearch->getTaxonomy() ) {
                $learners = $learnerRepository->findAllHavingTaxonomy( $taxonomy );
                $advisors = $advisorRepository->findAllHavingTaxonomy( $taxonomy );
                $instructors = $instructorRepository->findAllHavingTaxonomy( $taxonomy );
                $providers = $providerRepository->findAllHavingTaxonomy( $taxonomy );
                $events = $eventRepository->findAllHavingTaxonomy($taxonomy);
                $articles = $articleRepository->findAllHavingTaxonomy( $taxonomy );
            }

            $materials = array_merge( $events, $providers, $advisors, $instructors, $learners, $articles );

            /*
             * get isotope data for the set of materials:
             * i.e. find out which isotopes are actually present in the data set $materials
             */
            $isotopes = [];
            $labels = [];
            foreach( $materials as $material ) {
                if( $material instanceof Learner ) {
                    /** @var $material Learner */
                    if( ! isset($labels['Learner']) ) {
                        $isotopes[] = [
                            'label' => 'Learner',
                            'group' => 'type',
                            'isotopes' => ['type-learner'],
                            'order' => 1,
                        ];
                        $labels['Learner'] = true;
                    }
                } elseif( $material instanceof Advisor ) {
                    /** @var $material Advisor */
                    if( ! isset($labels['Advisor']) ) {
                        $isotopes[] = [
                            'label' => 'Advisor',
                            'group' => 'type',
                            'isotopes' => ['type-advisor'],
                            'order' => 2,
                        ];
                        $labels['Advisor'] = true;
                    }
                } elseif( $material instanceof Instructor ) {
                    /** @var $material Instructor */
                    if( ! isset($labels['Instructor']) ) {
                        $isotopes[] = [
                            'label' => 'Instructor',
                            'group' => 'type',
                            'isotopes' => ['type-instructor'],
                            'order' => 3,
                        ];
                        $labels['Instructor'] = true;
                    }
                } elseif(  $material instanceof Provider ) {
                    /** @var $material Provider */
                    if( ! isset($labels['Provider']) ) {
                        $isotopes[] = [
                            'label' => 'Provider',
                            'group' => 'type',
                            'isotopes' => ['type-provider'],
                            'order' => 4,
                        ];
                        $labels['Provider'] = true;
                    }
                    if( ! isset($labels[$material->getTitle()]) ) {
                        $isotopes[] = [
                            'label' => $material->getTitle(),
                            'group' => 'provider',
                            'isotopes' => ['provider-' . $material->getNickname()],
                            'order' => 100,
                        ];
                        $labels[$material->getTitle()] = true;
                    }
                } elseif( $material instanceof Event ) {
                    /** @var $material Event */
                    if( ! isset($labels['Event']) ) {
                        $isotopes[] = [
                            'label' => 'Event',
                            'group' => 'type',
                            'isotopes' => ['type-event'],
                            'order' => 5,
                        ];
                        $labels['Event'] = true;
                    }
                    if( ! isset($labels[$material->getProvider()->getTitle()])) {
                        $isotopes[] = [
                            'label' => $material->getProvider()->getTitle(),
                            'group' => 'provider',
                            'isotopes' => ['provider-' . $material->getProvider()->getNickname()],
                            'order' => 100,
                        ];
                        $labels[$material->getTitle()] = true;
                    }

                    if( preg_match( "/Free/i", $material->getEventFormat() ) and ! isset($labels['Free']) ) {
                        $isotopes[] =  [
                            'label' => 'Free',
                            'group' => 'format',
                            'isotopes' => ['format-free'],
                            'order' => 10,
                        ];
                        $labels['Free'] = true;
                    }

                    if( preg_match( "/Certificate/i", $material->getEventFormat() ) and ! isset($labels['Certificate']) ) {
                        $isotopes[] = [
                            'label' => 'Certificate',
                            'group' => 'format',
                            'isotopes' => ['format-certificate'],
                            'order' => 11,
                        ];
                        $labels['Certificate'] = true;
                    }

                    if( preg_match( "/Undergraduate/i", $material->getEventFormat() ) and ! isset($labels['Undergrad']) ) {
                        $isotopes[] = [
                            'label' => 'Undergrad',
                            'group' => 'format',
                            'isotopes' => ['format-undergraduate'],
                            'order' => 12,
                        ];
                        $labels['Undergrad'] = true;
                    }

                    if(
                        preg_match( "/Graduate/i", $material->getEventFormat() ) and
                        ! preg_match( "/Undergraduate/i", $material->getEventFormat() ) and
                        ! isset($labels['Grad'])
                    ) {
                        $isotopes[] = [
                            'label' => 'Grad',
                            'group' => 'format',
                            'isotopes' => ['format-graduate'],
                            'order' => 13,
                        ];
                        $labels['Grad'] = true;
                    }

                    if( preg_match( "/Product/i", $material->getEventFormat() ) and ! isset($labels['Product']) ) {
                        $isotopes[] = [
                            'label' => 'Product',
                            'group' => 'format',
                            'isotopes' => ['format-product'],
                            'order' => 14,
                        ];
                        $labels['Product'] = true;
                    }

                    if( preg_match( "/Face-to-Face/i", $material->getEventFormat() ) and ! isset($labels['Face-to-Face']) ) {
                        $isotopes[] = [
                            'label' => 'Face-to-Face',
                            'group' => 'format',
                            'isotopes' => ['format-facetoface'],
                            'order' => 15,
                        ];
                        $labels['Face-to-Face'] = true;
                    }

                    if( preg_match( "/Online/i", $material->getEventFormat() ) and ! isset($labels['Online']) ) {
                        $isotopes[] = [
                            'label' => 'Online',
                            'group' => 'format',
                            'isotopes' => ['format-online'],
                            'order' => 16,
                        ];
                        $labels['Online'] = true;
                    }

                    foreach( $material->getAges() as $age ) {
                        /** @var $age Age */
                        if( in_array( $age->getDescription(), ['Infant','Toddler','Child','Pre-teen'] ) and ! isset($labels['Child']) ) {
                            $isotopes[] = [
                                'label' => 'Child',
                                'group' => 'age',
                                'isotopes' => ['age-infant','age-toddler','age-child','age-preteen'],
                                'order' => 20,
                            ];
                            $labels['Child'] = true;
                        }
                        if( in_array( $age->getDescription(), ['Teen','Adult','Senior'] ) and ! isset($labels['Adult']) ) {
                            $isotopes[] = [
                                'label' => 'Adult',
                                'group' => 'age',
                                'isotopes' => ['age-teen','age-adult','age-senior'],
                                'order' => 21,
                            ];
                            $labels['Adult'] = true;
                        }
                    }

                } elseif( $material instanceof Article ) {
                    /** @var $material Article */
                    if( ! isset($labels['Article']) ) {
                        $isotopes[] = [
                            'label' => 'Article',
                            'group' => 'type',
                            'isotopes' => ['type-article'],
                            'order' => 6,
                        ];
                        $labels['Article'] = true;
                    }
                }
            }

            usort( $isotopes, [$this,'isotope_cmp'] );

            return $this->render( 'search.html.twig', [
                'form' => $form->createView(),
                'materials' => $materials,
                'isotopes' => $isotopes,
            ]);
        }

        /** @var LearnerRepository $learnerRepository */
        $learnerRepository = $this->getDoctrine()->getRepository('AppBundle:Learner');

        /** @var AdvisorRepository $advisorRepository */
        $advisorRepository = $this->getDoctrine()->getRepository('AppBundle:Advisor');

        /** @var InstructorRepository $instructorRepository */
        $instructorRepository = $this->getDoctrine()->getRepository('AppBundle:Instructor');

        /** @var ProviderRepository $providerRepository */
        $providerRepository = $this->getDoctrine()->getRepository('AppBundle:Provider');

        /** @var EventRepository $eventRepository */
        $eventRepository = $this->getDoctrine()->getRepository('AppBundle:Event');

        /** @var ArticleRepository $articleRepository */
        $articleRepository = $this->getDoctrine()->getRepository('AppBundle:Article');

        $learners = [];
        $advisors = [];
        $instructors = [];
        $providers = [];
        $events = [];
        $articles = [];
        if( $taxonomy = $knoitallSearch->getTaxonomy() ) {
            $learners = $learnerRepository->findAllHavingTaxonomy( $taxonomy );
            $advisors = $advisorRepository->findAllHavingTaxonomy( $taxonomy );
            $instructors = $instructorRepository->findAllHavingTaxonomy( $taxonomy );
            $providers = $providerRepository->findAllHavingTaxonomy( $taxonomy );
            $events = $eventRepository->findAllHavingTaxonomy($taxonomy);
            $articles = $articleRepository->findAllHavingTaxonomy( $taxonomy );
        }

        $materials = array_merge( $events, $providers, $advisors, $instructors, $learners, $articles );

        /*
         * get isotope data for the set of materials:
         * i.e. find out which isotopes are actually present in the data set $materials
         */
        $isotopes = [];
        $labels = [];
        foreach( $materials as $material ) {
            if( $material instanceof Learner ) {
                /** @var $material Learner */
                if( ! isset($labels['Learner']) ) {
                    $isotopes[] = [
                        'label' => 'Learner',
                        'group' => 'type',
                        'isotopes' => ['type-learner'],
                        'order' => 1,
                    ];
                    $labels['Learner'] = true;
                }
            } elseif( $material instanceof Advisor ) {
                /** @var $material Advisor */
                if( ! isset($labels['Advisor']) ) {
                    $isotopes[] = [
                        'label' => 'Advisor',
                        'group' => 'type',
                        'isotopes' => ['type-advisor'],
                        'order' => 2,
                    ];
                    $labels['Advisor'] = true;
                }
            } elseif( $material instanceof Instructor ) {
                /** @var $material Instructor */
                if( ! isset($labels['Instructor']) ) {
                    $isotopes[] = [
                        'label' => 'Instructor',
                        'group' => 'type',
                        'isotopes' => ['type-instructor'],
                        'order' => 3,
                    ];
                    $labels['Instructor'] = true;
                }
            } elseif(  $material instanceof Provider ) {
                /** @var $material Provider */
                if( ! isset($labels['Provider']) ) {
                    $isotopes[] = [
                        'label' => 'Provider',
                        'group' => 'type',
                        'isotopes' => ['type-provider'],
                        'order' => 4,
                    ];
                    $labels['Provider'] = true;
                }
                if( ! isset($labels[$material->getTitle()]) ) {
                    $isotopes[] = [
                        'label' => $material->getTitle(),
                        'group' => 'provider',
                        'isotopes' => ['provider-' . $material->getNickname()],
                        'order' => 100,
                    ];
                    $labels[$material->getTitle()] = true;
                }
            } elseif( $material instanceof Event ) {
                /** @var $material Event */
                if( ! isset($labels['Event']) ) {
                    $isotopes[] = [
                        'label' => 'Event',
                        'group' => 'type',
                        'isotopes' => ['type-event'],
                        'order' => 5,
                    ];
                    $labels['Event'] = true;
                }
                if( ! isset($labels[$material->getProvider()->getTitle()])) {
                    $isotopes[] = [
                        'label' => $material->getProvider()->getTitle(),
                        'group' => 'provider',
                        'isotopes' => ['provider-' . $material->getProvider()->getNickname()],
                        'order' => 100,
                    ];
                    $labels[$material->getTitle()] = true;
                }

                if( preg_match( "/Free/i", $material->getEventFormat() ) and ! isset($labels['Free']) ) {
                    $isotopes[] =  [
                        'label' => 'Free',
                        'group' => 'format',
                        'isotopes' => ['format-free'],
                        'order' => 10,
                    ];
                    $labels['Free'] = true;
                }

                if( preg_match( "/Certificate/i", $material->getEventFormat() ) and ! isset($labels['Certificate']) ) {
                    $isotopes[] = [
                        'label' => 'Certificate',
                        'group' => 'format',
                        'isotopes' => ['format-certificate'],
                        'order' => 11,
                    ];
                    $labels['Certificate'] = true;
                }

                if( preg_match( "/Undergraduate/i", $material->getEventFormat() ) and ! isset($labels['Undergrad']) ) {
                    $isotopes[] = [
                        'label' => 'Undergrad',
                        'group' => 'format',
                        'isotopes' => ['format-undergraduate'],
                        'order' => 12,
                    ];
                    $labels['Undergrad'] = true;
                }

                if( preg_match( "/Graduate/i", $material->getEventFormat() ) and
                    ! preg_match( "/Undergraduate/i", $material->getEventFormat() ) and
                    ! isset($labels['Grad'])
                ) {
                    $isotopes[] = [
                        'label' => 'Grad',
                        'group' => 'format',
                        'isotopes' => ['format-graduate'],
                        'order' => 13,
                    ];
                    $labels['Grad'] = true;
                }

                if( preg_match( "/Product/i", $material->getEventFormat() ) and ! isset($labels['Product']) ) {
                    $isotopes[] = [
                        'label' => 'Product',
                        'group' => 'format',
                        'isotopes' => ['format-product'],
                        'order' => 14,
                    ];
                    $labels['Product'] = true;
                }

                if( preg_match( "/Face-to-Face/i", $material->getEventFormat() ) and ! isset($labels['Face-to-Face']) ) {
                    $isotopes[] = [
                        'label' => 'Face-to-Face',
                        'group' => 'format',
                        'isotopes' => ['format-facetoface'],
                        'order' => 15,
                    ];
                    $labels['Face-to-Face'] = true;
                }

                if( preg_match( "/Online/i", $material->getEventFormat() ) and ! isset($labels['Online']) ) {
                    $isotopes[] = [
                        'label' => 'Online',
                        'group' => 'format',
                        'isotopes' => ['format-online'],
                        'order' => 16,
                    ];
                    $labels['Online'] = true;
                }

                foreach( $material->getAges() as $age ) {
                    /** @var $age Age */
                    if( in_array( $age->getDescription(), ['Infant','Toddler','Child','Pre-teen'] ) and ! isset($labels['Child']) ) {
                        $isotopes[] = [
                            'label' => 'Child',
                            'group' => 'age',
                            'isotopes' => ['age-infant','age-toddler','age-child','age-preteen'],
                            'order' => 20,
                        ];
                        $labels['Child'] = true;
                    }
                    if( in_array( $age->getDescription(), ['Teen','Adult','Senior'] ) and ! isset($labels['Adult']) ) {
                        $isotopes[] = [
                            'label' => 'Adult',
                            'group' => 'age',
                            'isotopes' => ['age-teen','age-adult','age-senior'],
                            'order' => 21,
                        ];
                        $labels['Adult'] = true;
                    }
                }

            } elseif( $material instanceof Article ) {
                /** @var $material Article */
                if( ! isset($labels['Article']) ) {
                    $isotopes[] = [
                        'label' => 'Article',
                        'group' => 'type',
                        'isotopes' => ['type-article'],
                        'order' => 6,
                    ];
                    $labels['Article'] = true;
                }
            }
        }

        usort( $isotopes, [$this,'isotope_cmp'] );

        return $this->render( 'search.html.twig', [
            'form' => $form->createView(),
            'materials' => $materials,
            'isotopes' => $isotopes,
        ]);
    }

    /*
     * TODO: the providers should be sorted alphabetically
     * (use provider title as sort key if we have order=100 for both entities )
     */
    static function isotope_cmp($a,$b) {
        return $a['order'] - $b['order'];
    }

    /**
     * @param Request $request
     * @return Response
     * @Route("/signup-modal", name="knoitall-signup-modal")
     *
     * This is basically a slightly modified copy of the registerAction() method in FOSUserBundle
     */
    public function signupModalAction( Request $request )
    {
        /** @var $formFactory FactoryInterface */
        $formFactory = $this->get('fos_user.registration.form.factory');
        /** @var $userManager UserManagerInterface */
        $userManager = $this->get('fos_user.user_manager');
        /** @var $dispatcher EventDispatcherInterface */
        $dispatcher = $this->get('event_dispatcher');

        $user = $userManager->createUser();
        $user->setEnabled(true);

        $event = new GetResponseUserEvent($user, $request);
        $dispatcher->dispatch(FOSUserEvents::REGISTRATION_INITIALIZE, $event);

        if (null !== $event->getResponse()) {
            return $event->getResponse();
        }

        $form = $this->createForm( RegistrationType::class, $user, [
            'action' => $this->generateUrl('knoitall-signup-modal'),
        ] );

        $form->handleRequest($request);

        if ($form->isSubmitted()) {
            if ($form->isValid()) {
                $event = new FormEvent($form, $request);
                $dispatcher->dispatch(FOSUserEvents::REGISTRATION_SUCCESS, $event);

                /*
                 * TODO: explain why the above $user->setEnabled(true) doesn't work
                 */
                $user->setEnabled(true);                

                // Set Nickname to be used in the next signup process
                $tempNickname = $user->getFirstName() . " " . $user->getLastName() . " Classroom";
                $user->setNickname($tempNickname);
                $userManager->updateUser($user);

                if (null === $response = $event->getResponse()) {
                    $url = $this->generateUrl('fos_user_registration_confirmed');
                    $response = new RedirectResponse($url);
                }

                $dispatcher->dispatch(FOSUserEvents::REGISTRATION_COMPLETED, new FilterUserResponseEvent($user, $request, $response));

                return $response;
            }

            $errors = $form->getErrors();
            if (count($errors) > 0) {
                //echo($errors);
                ?> <script> alert('Email already registered, please use other Email address.'); </script> <?php 
            }

            $event = new FormEvent($form, $request);
            $dispatcher->dispatch(FOSUserEvents::REGISTRATION_FAILURE, $event);

            //return $this->redirectToRoute( 'knoitall-signup-modal');            
            /* ?> <script> $.cookie('signupModalShown', 'enabled', {path: '/', domain: 'knoitall.com'}); </script> <?php */
            if ($_SERVER['HTTP_HOST'] == 'www.knoitall.com') {
                setcookie('signupModalShown', 'enabled', time() + (86400 * 365), '/', 'knoitall.com');
                setcookie('lastSignupSignin', 'fail', time() + (86400 * 365), '/', 'knoitall.com');
            }
            ?> <script> window.history.back(); </script> <?php            

            if (null !== $response = $event->getResponse()) {
                return $response;
            }
            exit();
            // return $this->redirectToRoute( 'knoitall_homepage'); 
        }

        return $this->render('signup_modal.html.twig', [
            'form' => $form->createView(),
        ]);
    }

    /**
     * @param Request $request
     * @return Response
     * @Route("/signin-modal", name="knoitall-signin-modal")
     */
    public function signinModalAction( Request $request )
    {
        $session = $request->getSession();

        $authErrorKey = Security::AUTHENTICATION_ERROR;
        $lastUsernameKey = Security::LAST_USERNAME;

        // get the error if any (works with forward and redirect -- see below)
        if ($request->attributes->has($authErrorKey)) {
            $error = $request->attributes->get($authErrorKey);
        } elseif (null !== $session && $session->has($authErrorKey)) {
            $error = $session->get($authErrorKey);
            $session->remove($authErrorKey);
        } else {
            $error = null;
        }

        if (!$error instanceof AuthenticationException) {
            $error = null; // The value does not come from the security component.
        }

        // last username entered by the user
        $lastUsername = (null === $session) ? '' : $session->get($lastUsernameKey);

        $csrfToken = $this->has('security.csrf.token_manager')
            ? $this->get('security.csrf.token_manager')->getToken('authenticate')->getValue()
            : null;

        return $this->render('signin_modal.html.twig', [
            'last_username' => $lastUsername,
            'error' => $error,
            'csrf_token' => $csrfToken,
        ]);
    }

    /**
     * @param Request $request
     * @return Response
     * @Route("/search-modal", name="knoitall_search_modal")
     */
    public function searchModalAction( Request $request )
    {
        $knoitallSearch = new KnoitallSearch();

        $form = $this->createForm( KnoitallSearchType::class, $knoitallSearch, [
            'action' => $this->generateUrl('knoitall_search'),
        ] );

        return $this->render( 'search_modal.html.twig', ['form' => $form->createView()] );
    }

    /**
     * @param Request $request
     * @return Response
     * @Route("/search-inline", name="knoitall_search_inline")
     */
    public function searchInlineAction( Request $request)
    {
        $knoitallSearch = new KnoitallSearch();

        $form = $this->createForm( KnoitallSearchType::class, $knoitallSearch, [
            'action' => $this->generateUrl('knoitall_search')
        ] );

        return $this->render( 'search_inline.html.twig', ['form' => $form->createView()] );
    }

    /**
     * @param Request $request
     * @return Response
     * @Route("/getting-started", name="knoitall_getting_started")
     */
    public function gettingStartedAction( Request $request )
    {
        return $this->render( ':default:getting_started.html.twig' );
    }

    /**
     * @Route("/forgot-password", name="knoitall_forgot_password")
     * @return Response
     */
    public function forgotPasswordAction(  Request $request )
    {
        $forgotPassword = new ForgotPassword();

        $form = $this->createForm( ForgotPasswordType::class, $forgotPassword, [
            'action' => $this->generateUrl('knoitall_forgot_password'),
        ] );

        /*$form->handleRequest($request);

        if( $form->isSubmitted() and $form->isValid() ) {
            $forgotPassword = $form->getData();
            $email = $forgotPassword->getEmail();
            $resettingURL = $this->generateUrl('fos_user_resetting_send_email');
            return $this->redirectToRoute($resettingURL."/check-email?username=".$email);
        }*/

        return $this->render('forgot-password.html.twig', ['form' => $form->createView()] );
    }
}
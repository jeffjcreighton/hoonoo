<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Provider;
use AppBundle\Entity\Location;
use AppBundle\Form\EventType;
use AppBundle\Form\EventPostType;
use AppBundle\Form\EventTypeForPost;
use AppBundle\Form\EventTypeForList;
use AppBundle\Form\EventTypeForAd;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use AppBundle\Entity\Event;
use AppBundle\Entity\PathwayEvent;
use AppBundle\Entity\FeedCommentEvent;
use AppBundle\Entity\FeedFollowProvider;
use AppBundle\Entity\FeedLikeEvent;
use AppBundle\Entity\FeedShareEvent;
use AppBundle\Entity\FeedAddPostEvent;
use AppBundle\Entity\CkeditorImageChecking;
use \DateTime;

class EventController extends Controller
{   
    /**
     * @param \DateTime $timestamp
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function getElapsedTimeTextAction( DateTime $timestamp ) 
    {
        $currentTime = new DateTime();                    
        $interval = $timestamp->diff($currentTime);

        $diff_in_seconds = ($interval->format('%y') * 365 * 86400) + ($interval->format('%m') * 30 * 86400) + ($interval->format('%d') * 86400) + ($interval->format('%h') * 3600) + ($interval->format('%i') * 60) + $interval->format('%s'); 

        $sec   = $diff_in_seconds; 
        $min   = floor($diff_in_seconds / 60 ); 
        $hrs   = floor($diff_in_seconds / 3600); 
        $days  = floor($diff_in_seconds / 86400 ); 
        $weeks = floor($diff_in_seconds / 604800); 
        $mnths = floor($diff_in_seconds / 2628000 ); 
        $yrs   = floor($diff_in_seconds / 31557600 ); 

        // Check for seconds 
        if ($sec < 60) { 
            if ($sec <= 1) { 
                $ElapsedTimeText = "1 second ago";
            } else {
                $ElapsedTimeText = $sec . " seconds ago";
            }
        } else if ($min < 60) { 
            if ($min == 1) { 
                $ElapsedTimeText = "1 minute ago";  // "one minute ago"; 
            } else {
                $ElapsedTimeText = $min ." minutes ago"; 
            }
        } else if ($hrs < 24) { 
            if ($hrs == 1) { 
                $ElapsedTimeText = "1 hour ago";   // "an hour ago"; 
            } else {
                $ElapsedTimeText = $hrs . " hours ago"; 
            }
        } else if ($days < 7) { 
            if ($days == 1) { 
                $ElapsedTimeText = "1 day ago";   // "Yesterday"; 
            } else {
                $ElapsedTimeText = $days . " days ago"; 
            }
        } else if ( ($weeks <= 4) && ($mnths < 1) ) { 
            if ($weeks == 1) { 
                $ElapsedTimeText = "1 week ago";   // "a week ago"; 
            } else {
                $ElapsedTimeText = $weeks . " weeks ago"; 
            }
        } else if ( ($mnths <= 12) && ($yrs < 1) ) { 
            if ($mnths == 1) { 
                $ElapsedTimeText = "1 month ago";   // "a month ago"; 
            } else {
                $ElapsedTimeText = $mnths . " months ago"; 
            }
        } else {
            if ($yrs == 1) { 
                $ElapsedTimeText = "1 year ago";   // "one year ago"; 
            } else {
                $ElapsedTimeText = $yrs . " years ago"; 
            }
        }
 
        $response = new Response($ElapsedTimeText, Response::HTTP_OK);
        return $response;
    }


    /**
     * @param $event \AppBundle\Entity\Event
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function getRealFeedLikeAmountAction( Event $event ) 
    {
        $em = $this->getDoctrine()->getManager();
        $qb = $em->createQueryBuilder();
        $qb->select('count(feed_like_event.id)');
        $qb->from('AppBundle:FeedLikeEvent','feed_like_event');
        $qb->where('feed_like_event.event = ' . $event->getId());
        $TotalFeedLike = $qb->getQuery()->getSingleScalarResult();        
        $response = new Response($TotalFeedLike, Response::HTTP_OK);
        return $response;
    }

    /**
     * @param $event \AppBundle\Entity\Event
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function getRealFeedCommentAmountAction( Event $event ) 
    {
        $em = $this->getDoctrine()->getManager();
        $qb = $em->createQueryBuilder();
        $qb->select('count(feed_comment_event.id)');
        $qb->from('AppBundle:FeedCommentEvent','feed_comment_event');
        $qb->where('feed_comment_event.event = ' . $event->getId());
        $TotalFeedComment = $qb->getQuery()->getSingleScalarResult();
        $response = new Response($TotalFeedComment, Response::HTTP_OK);
        return $response;
    }

    /**
     * @param $primaryFeedCommentEvent \AppBundle\Entity\FeedCommentEvent
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function getRealFeedReplyAmountAction( FeedCommentEvent $primaryFeedCommentEvent ) 
    {
        $em = $this->getDoctrine()->getManager();
        $qb = $em->createQueryBuilder();
        $qb->select('count(feed_comment_event.id)');
        $qb->from('AppBundle:FeedCommentEvent','feed_comment_event');
        $qb->where('feed_comment_event.replyFromComment = ' . $primaryFeedCommentEvent->getId());
        $TotalFeedReply = $qb->getQuery()->getSingleScalarResult();
        $response = new Response($TotalFeedReply, Response::HTTP_OK);
        return $response;
    }

    /**
     * @Route("/event/filling/like_and_comment_total_amount", name="knoitall_filling_like_and_comment_total_amount")
     */
    public function fillingLikeAndCommentTotalAmountAction( Request $request )
    {   
        $prevMaxExecTime = ini_get('max_execution_time');
        ini_set('max_execution_time', 1200); // 20 minutes

        $em = $this->getDoctrine()->getManager();
        $qb = $em->createQueryBuilder();
        $qb->select('count(event.id)');
        $qb->from('AppBundle:Event','event');
        $eventTotalAmount = $qb->getQuery()->getSingleScalarResult();

        $eventRepository = $this->getDoctrine()->getRepository('AppBundle:Event');

        $TotalLikeFilled = 0;
        $TotalCommentFilled = 0;
        $totalCounter = ceil($eventTotalAmount / 100);
        if ($totalCounter > 0) {
            for ($count = 0; $count < $totalCounter; $count++) {
                $eventStartPos = $count * 100;               
                $eventEndPos = $eventStartPos + 100;  // Not included the end pos
                $totalFilling = 100;
                if ($eventEndPos > $eventTotalAmount) {            
                    $totalFilling = $eventTotalAmount - $eventStartPos;
                    $eventEndPos = $eventStartPos + $totalFilling;
                }

                $eventFillingList = $eventRepository->findBy(
                    array(),
                    ['id' => 'ASC'],     // ASC = Ascending  DESC = Descending
                    $totalFilling,       // limit or result amount
                    $eventStartPos       // offset
                );

                foreach($eventFillingList as $eventFilling) {
                    $totalLike = $eventFilling->getLikeAmount();
                    if ($totalLike == NULL) {
                        $totalLike = (int) $this->getRealFeedLikeAmountAction( $eventFilling )->getContent();
                        //$totalLike = count($eventFilling->getFeedLikeEvents());
                        if ($totalLike > 0) {
                            $TotalLikeFilled++ ;
                            $eventFilling->setLikeAmount($totalLike);
                            $em->persist( $eventFilling );
                        }
                    }     
                    $totalComment =$eventFilling->getCommentAmount();
                    if ($totalComment == NULL) {
                        $totalComment = (int) $this->getRealFeedCommentAmountAction( $eventFilling )->getContent();
                        //$totalComment = count($eventFilling->getFeedCommentEvents());
                        if ($totalComment > 0) {
                            $TotalCommentFilled++ ;
                            $eventFilling->setCommentAmount($totalComment);
                            $em->persist( $eventFilling ); 
                        }
                    }     
                    $em->flush();                     
                }                
                $logger = $this->get('logger');        
                $logger->err('🔔 Mex ExecutionTime: '. $prevMaxExecTime . ' - Total Counter: ' . $totalCounter . '- count: ' . $count . ' - Totel Like Filled: ' . $TotalLikeFilled . ' - Total Comment Filled: ' . $TotalCommentFilled);
            }
        }

        $logger = $this->get('logger');        
        $logger->err('🔔 Total Event: ' . $eventTotalAmount . ' - Totel Like Filled: ' . $TotalLikeFilled . ' - Total Comment Filled: ' . $TotalCommentFilled);

        ini_set('max_execution_time', $prevMaxExecTime);

        return $this->render( ':default:empty.html.twig' );
    }     

    /**
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @param $event \AppBundle\Entity\Event
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/event/{slug}", name="knoitall_event_public_view")
     * @ParamConverter("event", class="AppBundle\Entity\Event")
     */
    public function publicViewAction( Request $request, Event $event )
    {
        /*
         * get a list of coordinates/labels for the google map api:
         * TODO: eliminate duplication locations (several events may possibly refer to the same location)
         */
        if( $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            /** @var \AppBundle\Entity\User $user */
            $user = $this->get('security.token_storage')->getToken()->getUser();
            if( ! count($user->getPerson()->getProviders()) ) {    
                return $this->redirectToRoute('knoitall_provider_profile_wizard');
            }
            // if( ! isset($user->getPerson()->getLearners()[0]) ) {
            if( ! count($user->getPerson()->getLearners()) ) {    
                // $learner = $this->forward('AppBundle:Learner:createLearnerProfile');
                return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
            }
        }

        $geoLocations = [];
        $location = $event->getLocation();        
        if( $location ) {
            if( $location->getPublished() ) { 
                $geoLocations[] = [
                    'latitude' => $location->getLatitude(),
                    'longitude' => $location->getLongitude(),
                    'label' => ( $location->getName() ? $location->getName() : $event->getTitle() ),
                ];
            }
        } elseif( $event->getLocationLatitude() != 0 and $event->getLocationLongitude() != 0 ) {
            $geoLocations[] = [
                'latitude' => $event->getLocationLatitude(),
                'longitude' => $event->getLocationLongitude(),
                'label' => ( $event->getLocationName() ? $event->getLocationName() : $event->getTitle() ),
            ];
        }

        $dow = "";
        if( $event->getMonday() ) { $dow = $dow . "Mon"; }
        if( $event->getTuesday() ) { 
            if($dow !== "") { $dow = $dow . ", "; }
            $dow = $dow . "Tue"; }
        if( $event->getWednesday() ) {
            if($dow !== "") { $dow = $dow . ", "; }
            $dow = $dow . "Wed"; }
        if( $event->getThursday() ) {
            if($dow !== "") { $dow = $dow . ", "; }
            $dow = $dow . "Thu"; }
        if( $event->getFriday() ) {
            if($dow !== "") { $dow = $dow . ", "; }
            $dow = $dow . "Fri"; }
        if( $event->getSaturday() ) {
            if($dow !== "") { $dow = $dow . ", "; }
            $dow = $dow . "Sat"; }
        if( $event->getSunday() ) {
            if($dow !== "") { $dow = $dow . ", "; }
            $dow = $dow . "Sun"; }                
        
        return $this->render( 'event/public_view.html.twig', [
            'event' => $event,
            'dow' => $dow,
            'location' => $location,
            'geoLocations' => $geoLocations,
        ] );
    }

    /**
     * @Route("/member/event/show/comment", name="knoitall_event_show_comment")
     */
    public function showCommentAction(Request $request)
    {
        $data = null;
        if( $content = $request->getContent() ) {
            $data = json_decode( $content, true );
        }

        if( $data ) {
            $event_id = ( isset($data['event_id']) ? $data['event_id'] : null );
            $commentOffsetId = ( isset($data['comment_offset_id']) ? $data['comment_offset_id'] : null );
            $client_timezone = ( isset($data['client_timezone']) ? $data['client_timezone'] : null );
            
            $eventRepository = $this->getDoctrine()->getRepository(Event::class);
            $event = ( isset($event_id) ? $eventRepository->find($event_id) : null );
            $em = $this->getDoctrine()->getManager();

            $totalComment = $event->getCommentAmount();

            $feedCommentEventRepository = $this->getDoctrine()->getRepository(FeedCommentEvent::class);

            $feedCommentEventIds = null;

            if ($totalComment) {
                if ($commentOffsetId == 'first') {
                    $feedCommentEvents = $feedCommentEventRepository->findBy(
                        ['event' => $event, 'replyFromComment' => NULL],
                        ['timestampAdded' => 'DESC'],  // ASC = Ascending  DESC = Descending
                        1,                   // limit
                        0                    // offset
                    );
                    $commentOffsetId = $feedCommentEvents[0]->getId();
                }

                // $pageLimit = 20;
                $commentPerRequest = 20;
                $testRequest = $commentPerRequest + 1;

                $qb = $em->createQueryBuilder();
                $qb->select('feed_comment_event.id');
                $qb->from('AppBundle:FeedCommentEvent','feed_comment_event');
                $qb->where($qb->expr()->andX($qb->expr()->eq('feed_comment_event.event', $event->getId()),$qb->expr()->isNull('feed_comment_event.replyFromComment'),$qb->expr()->lte('feed_comment_event.id', $commentOffsetId) ));
                $qb->orderBy('feed_comment_event.timestampAdded', 'DESC');
                $qb->setMaxResults( $testRequest );            
                $feedCommentEventIds = $qb->getQuery()->getResult();
            }

            if( $feedCommentEventIds ) {                
                //$Comments = "";
                $CommentList = array();
                $CommentIdList = array();
                $ReplyAmountList = array();
                $commentCount = 0; 
                $commentShownCount = 0;
                foreach ( $feedCommentEventIds as $feedCommentEventId ) {
                    $commentCount++;
                    $feedCommentEvent = $feedCommentEventRepository->find($feedCommentEventId);
                    $commentOffsetId = $feedCommentEvent->getId();

                    if ( $commentCount <= $commentPerRequest ) {
                        $learner = $feedCommentEvent->getLearner();
                        $comment_text = $feedCommentEvent->getCommentText();
                        $replyAmount = $feedCommentEvent->getReplyAmount();
                        $timeTag = $feedCommentEvent->getTimestampAdded();
                        $temp_timezone = date_default_timezone_get();
                        date_default_timezone_set($client_timezone);
                        $timezoneName = date('T');
                        date_default_timezone_set($temp_timezone);

                        $eventLearner = $event->getProvider()->getPersons()[0]->getLearners()[0];
                        $eventLearnerId = $eventLearner->getId();

                        $qb = $em->createQueryBuilder();
                        $qb->select('count(feed_comment_event.id)');
                        $qb->from('AppBundle:FeedCommentEvent','feed_comment_event');
                        $qb->where($qb->expr()->andX($qb->expr()->eq('feed_comment_event.learner',$eventLearnerId), $qb->expr()->eq('feed_comment_event.replyFromComment',$feedCommentEvent->getId()) ));
                        $TotalEventOwnerComment = $qb->getQuery()->getSingleScalarResult();

                        $addedText = "";
                        if ($TotalEventOwnerComment) {
                            $addedText = " from " . $eventLearner->getTitle();
                            if ($replyAmount > $TotalEventOwnerComment) {
                                $addedText = $addedText . " and others";
                            }
                        }

                        $user = $this->get('security.token_storage')->getToken()->getUser();
                        $userLearner = $user->getPerson()->getLearners()[0];

                        $isEventOwner = false;  
                        if ($eventLearnerId == $learner->getId()) {
                            $isEventOwner = true;
                        }

                        $ElapsedTimeText = $this->getElapsedTimeTextAction( $timeTag )->getContent();

                        $isForEventPage = true;

                        //$Comments = $Comments . $this->renderView( ':event:show_comment.html.twig', [
                        $Comment = $this->renderView( ':feed:feed_show_comment.html.twig', [
                            'userLearner' => $userLearner,
                            'learner' => $learner,
                            'event' => $event,
                            'comment_text' => $comment_text,
                            'reply_amount' => $replyAmount,
                            'added_text' => $addedText,
                            'isEventOwner' => $isEventOwner,
                            'commentID' => strval($feedCommentEvent->getId()),
                            'activityID' => '',
                            'comment_place_id' => '',
                            'elapsedTimeText' => $ElapsedTimeText,
                            'timetag' => $timeTag->format(DateTime::ISO8601),
                            'client_timezone' => $client_timezone,
                            'timezone_name' => $timezoneName,
                            'isForEventPage' => $isForEventPage
                        ] );
                        $commentShownCount++;
                        array_push($CommentList, $Comment);
                        array_push($CommentIdList, strval($feedCommentEvent->getId()));
                        array_push($ReplyAmountList, $replyAmount);
                    }                     
                }   

                $isEndOfComment = false;
                if ( $commentCount <= $commentPerRequest ) {
                    $isEndOfComment = true;                    
                } 

                $returnValues = [
                    'commentOffsetId' => $commentOffsetId,
                    //'Comments' => $Comments,
                    'CommentList' => $CommentList,
                    'CommentIdList' => $CommentIdList,
                    'ReplyAmountList' => $ReplyAmountList,
                    'commentShownCount' => $commentShownCount,
                    'isEndOfComment' => $isEndOfComment,
                ];
            } else {
                $returnValues = [
                    'commentOffsetId' => $commentOffsetId,
                    //'Comments' => '',
                    'CommentList' => null,
                    'CommentIdList' => null,
                    'ReplyAmountList' => null,
                    'commentShownCount' => 0,
                    'isEndOfComment' => true,
                ];
            }

            $returnValues['status'] = 'OK';
            $response = new Response(json_encode($returnValues));
            $response->headers->set('Content-Type', 'application/json');
            return $response;
        }

        $response = new Response(json_encode(['status' => 'ERROR']));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    /**
     * @Route("/member/event/show/reply", name="knoitall_event_show_reply")
     */
    public function showReplyAction(Request $request)
    {
        $data = null;
        if( $content = $request->getContent() ) {
            $data = json_decode( $content, true );
        }

        if( $data ) {
            $event_id = ( isset($data['event_id']) ? $data['event_id'] : null );
            $primary_comment_id = ( isset($data['primary_comment_id']) ? $data['primary_comment_id'] : null );
            $replyOffsetId = ( isset($data['reply_offset_id']) ? $data['reply_offset_id'] : null );
            $client_timezone = ( isset($data['client_timezone']) ? $data['client_timezone'] : null );
            
            $eventRepository = $this->getDoctrine()->getRepository(Event::class);
            $event = ( isset($event_id) ? $eventRepository->find($event_id) : null );
            $em = $this->getDoctrine()->getManager();

            $feedCommentEventRepository = $this->getDoctrine()->getRepository(FeedCommentEvent::class);

            $primaryCommentEvent = $feedCommentEventRepository->find($primary_comment_id);

            if ($replyOffsetId == 'first') {
                $feedReplyEvents = $feedCommentEventRepository->findBy(
                    ['event' => $event, 'replyFromComment' => $primaryCommentEvent],
                    ['timestampAdded' => 'ASC'],  // ASC = Ascending  DESC = Descending
                    1,                   // limit
                    0                    // offset
                );
                $replyOffsetId = $feedReplyEvents[0]->getId();
                $replyPerRequest = 10;
            } else {
                $replyPerRequest = 50;
            }

            $testRequest = $replyPerRequest + 1;

            $qb = $em->createQueryBuilder();
            $qb->select('feed_comment_event.id');
            $qb->from('AppBundle:FeedCommentEvent','feed_comment_event');
            $qb->where($qb->expr()->andX($qb->expr()->eq('feed_comment_event.event', $event->getId()),$qb->expr()->eq('feed_comment_event.replyFromComment', $primary_comment_id),$qb->expr()->gte('feed_comment_event.id', $replyOffsetId) ));
            $qb->orderBy('feed_comment_event.timestampAdded', 'ASC');
            $qb->setMaxResults( $testRequest );            
            $feedReplyEventIds = $qb->getQuery()->getResult();
            
            if( $feedReplyEventIds ) {                
                //$Comments = "";
                $ReplyList = array();
                $ReplyIdList = array();
                // $ReplyAmountList = array();
                $replyCount = 0; 
                $replyShownCount = 0;
                foreach ( $feedReplyEventIds as $feedReplyEventId ) {
                    $replyCount++;
                    $feedReplyEvent = $feedCommentEventRepository->find($feedReplyEventId);
                    $replyOffsetId = $feedReplyEvent->getId();

                    if ( $replyCount <= $replyPerRequest ) {
                        $learner = $feedReplyEvent->getLearner();
                        $reply_text = $feedReplyEvent->getCommentText();
                        // $replyAmount = $feedCommentEvent->getReplyAmount();
                        $timeTag = $feedReplyEvent->getTimestampAdded();
                        $temp_timezone = date_default_timezone_get();
                        date_default_timezone_set($client_timezone);
                        $timezoneName = date('T');
                        date_default_timezone_set($temp_timezone);

                        $eventLearner = $event->getProvider()->getPersons()[0]->getLearners()[0];
                        $eventLearnerId = $eventLearner->getId();

                        $user = $this->get('security.token_storage')->getToken()->getUser();
                        $userLearner = $user->getPerson()->getLearners()[0];

                        $isEventOwner = false;  
                        if ($eventLearnerId == $learner->getId()) {
                            $isEventOwner = true;
                        }

                        $ElapsedTimeText = $this->getElapsedTimeTextAction( $timeTag )->getContent();

                        $isForEventPage = true;

                        //$Comments = $Comments . $this->renderView( ':event:show_comment.html.twig', [
                        $Reply = $this->renderView( ':feed:feed_show_reply.html.twig', [
                            'userLearner' => $userLearner,
                            'learner' => $learner,
                            'event' => $event,
                            'reply_text' => $reply_text,
                            'isEventOwner' => $isEventOwner,
                            'commentID' => strval($feedReplyEvent->getId()),
                            'activityID' => '',
                            'primaryCommentID' => $primary_comment_id,
                            'elapsedTimeText' => $ElapsedTimeText,
                            'timetag' => $timeTag->format(DateTime::ISO8601),
                            'client_timezone' => $client_timezone,
                            'timezone_name' => $timezoneName,
                            'isForEventPage' => $isForEventPage
                        ] );
                        $replyShownCount++;
                        array_push($ReplyList, $Reply);
                        array_push($ReplyIdList, strval($feedReplyEvent->getId()));
                    }   
                }   

                $isEndOfReply = false;
                if ( $replyCount <= $replyPerRequest ) {
                    $isEndOfReply = true;                    
                } 

                $returnValues = [
                    'replyOffsetId' => $replyOffsetId,
                    //'Comments' => $Comments,
                    'ReplyList' => $ReplyList,
                    'ReplyIdList' => $ReplyIdList,
                    'replyShownCount' => $replyShownCount,
                    'isEndOfReply' => $isEndOfReply,
                ];
            } else {
                $returnValues = [
                    'replyOffsetId' => $replyOffsetId,
                    //'Comments' => '',
                    'ReplyList' => null,
                    'ReplyIdList' => null,
                    'replyShownCount' => 0,
                    'isEndOfReply' => true,
                ];
            }

            $returnValues['status'] = 'OK';
            $response = new Response(json_encode($returnValues));
            $response->headers->set('Content-Type', 'application/json');
            return $response;
        }

        $response = new Response(json_encode(['status' => 'ERROR']));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    /**
     * @param $event \AppBundle\Entity\Event
     */
    public function removeActualEventFunction( Event $event )
    {
        $getstream_key = $this->getParameter('getstream_key');
        $getstream_secret = $this->getParameter('getstream_secret');
        $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );

        $em = $this->getDoctrine()->getManager();
        
        // delete feed Like data
        $feedLikeEventRepository = $this->getDoctrine()->getRepository(FeedLikeEvent::class);
        $feedLikeEvents = $feedLikeEventRepository->findBy(['event' => $event]);
        //$feedLikeEvents = $event->getFeedLikeEvents();
        $activityFeed = null;
        $prevLearnerId = null;
        foreach($feedLikeEvents as $feedLikeEvent) {
            if ($feedLikeEvent->getPushedToGetstream()) {
                $learnerId = $feedLikeEvent->getLearner()->getId();
                $foreignId = 'like:'.strval($feedLikeEvent->getId());
                if ($learnerId != $prevLearnerId) {
                    $activityFeed = $client->feed('activity', strval($learnerId));
                    $activityFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));
                    $prevLearnerId = $learnerId;
                }
                $activityFeed->removeActivity($foreignId, true);
            }
            $em->remove($feedLikeEvent);
        }
        $em->flush(); 

        // delete feed Comment data
        $feedCommentEventRepository = $this->getDoctrine()->getRepository(FeedCommentEvent::class);
        $feedCommentEvents = $feedCommentEventRepository->findBy(['event' => $event]);
        //$feedCommentEvents = $event->getFeedCommentEvents();
        $activityFeed = null;
        $prevLearnerId = null;
        $learner_feedFeed = null;        
        $prevlearnerFeedId = null;
        foreach($feedCommentEvents as $feedCommentEvent) {
            if ($feedCommentEvent->getPushedToGetstream()) {

                $primaryFeedCommentEvent = $feedCommentEvent->getReplyFromComment();
                $destFeedCommentEvent = $feedCommentEvent->getReplyToComment();                

                if ( !$primaryFeedCommentEvent && !$destFeedCommentEvent ) {
                    $learnerId = $feedCommentEvent->getLearner()->getId();
                    $foreignId = 'comment:'.strval($feedCommentEvent->getId());
                    if ( $learnerId != $prevLearnerId) {
                        $activityFeed = $client->feed('activity', strval($learnerId));
                        $activityFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));
                        $prevLearnerId = $learnerId;
                    }            
                    $activityFeed->removeActivity($foreignId, true);
                } else {                    
                    if ( $primaryFeedCommentEvent && !$destFeedCommentEvent ) {
                        $replyToId = $primaryFeedCommentEvent->getLearner()->getId();
                    } 
                    if ( $primaryFeedCommentEvent && $destFeedCommentEvent ) {
                        $replyToId = $destFeedCommentEvent->getLearner()->getId();
                    }
                    $learnerId = $feedCommentEvent->getLearner()->getId();
                    $foreignId = 'comment:'.strval($feedCommentEvent->getId());
                    if ($replyToId != $learnerId) {
                        if ( $replyToId != $prevlearnerFeedId) {
                            $learner_feedFeed = $client->feed('learner_feed', strval($replyToId));
                            $learner_feedFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));
                            $prevlearnerFeedId = $replyToId;
                        }            
                        $learner_feedFeed->removeActivity($foreignId, true);
                    }
                }            
            }
            $em->remove($feedCommentEvent);
        }
        $em->flush(); 

        // delete feed Share data
        $feedShareEventRepository = $this->getDoctrine()->getRepository(FeedShareEvent::class);
        $feedShareEvents = $feedShareEventRepository->findBy(['event' => $event]);
        //$feedShareEvents = $event->getFeedShareEvents();
        $activityFeed = null;
        $prevLearnerId = null;
        foreach($feedShareEvents as $feedShareEvent) {
            if ($feedShareEvent->getPushedToGetstream()) {
                $learnerId = $feedShareEvent->getLearner()->getId();
                $foreignId = 'share:'.strval($feedShareEvent->getId());
                if ($learnerId != $prevLearnerId) {
                    $activityFeed = $client->feed('activity', strval($learnerId));
                    $activityFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));
                    $prevLearnerId = $learnerId;
                }            
                $activityFeed->removeActivity($foreignId, true);
            }
            $em->remove($feedShareEvent);
        }
        $em->flush(); 

        // delete feed AddPost data
        $feedAddPostEventRepository = $this->getDoctrine()->getRepository(FeedAddPostEvent::class);
        $feedAddPostEvents = $feedAddPostEventRepository->findBy(['event' => $event]);
        //$feedAddPostEvents = $event->getFeedAddPostEvents();
        $activityFeed = null;
        $prevProvider_LearnerId = null;
        foreach($feedAddPostEvents as $feedAddPostEvent) {
            if ($feedAddPostEvent->getPushedToGetstream()) {
                $provider = $feedAddPostEvent->getProvider();                
                $person = $provider->getPersons()[0];
                $learners = $person->getLearners();
                $provider_Learner = null;
                if (count($learners)) {
                   $provider_Learner = $learners[0];
                }
                if ($provider_Learner) {
                    $provider_LearnerId = $provider_Learner->getId();
                    $foreignId = 'post:'.strval($feedAddPostEvent->getId());
                    if ($provider_LearnerId != $prevProvider_LearnerId) {
                        $activityFeed = $client->feed('activity', strval($provider_LearnerId));
                        $activityFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));
                        $prevProvider_LearnerId = $provider_LearnerId;
                    }            
                    $activityFeed->removeActivity($foreignId, true);
                }
            }
            $em->remove($feedAddPostEvent);
        }
        $em->flush(); 

        // remove pathway's event
        $pathwayEvents = $event->getPathwayEvents();
        foreach($pathwayEvents as $pathwayEvent) {
            $em->remove($pathwayEvent);
        }
        $em->flush(); 

        $eventHash = $event->getHash();

        $em->remove($event);
        $em->flush(); 

        // delete CKEditor and Event Image Files
        $dirPath = realpath($this->getParameter('media_upload_destination'));
        $dirPath = $dirPath . "/event/" . $eventHash;
        if (file_exists($dirPath) && is_dir($dirPath)) {
            $dir = opendir($dirPath);
            while(false !== ( $file = readdir($dir)) ) { 
                if (( $file != '.' ) && ( $file != '..' )) { 
                    if ( !is_dir($dirPath . '/' . $file) ) { 
                        $fname = $dirPath . '/' . $file;
                        unlink($fname); 
                    }
                } 
            } 
            closedir($dir); 
            rmdir($dirPath);
        }

        // remove CKEditorImageChecking data
        $ckeditorImageCheckingRepository = $this->getDoctrine()->getRepository('AppBundle:CkeditorImageChecking');
        $checkingData = $ckeditorImageCheckingRepository->findOneBy([
            'entity' => 'event',
            'hash' => $eventHash,
        ]);
        if ( count($checkingData) ) {
            $em->remove($checkingData);
            $em->flush(); 
        }

        return true;
    }

    /**
     * @Route("/member/event/remove/event", name="knoitall_event_remove_event")     
     */
    public function removeEventAction(Request $request)
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        $data = null;
        if( $content = $request->getContent() ) {
            $data = json_decode( $content, true );
        }

        if( $data ) {
            $eventId = ( isset($data['event_id']) ? $data['event_id'] : null );         
            $eventHash = ( isset($data['event_hash']) ? $data['event_hash'] : null );    

            $eventRepository = $this->getDoctrine()->getRepository(Event::class);
            $event = ( isset($eventId) ? $eventRepository->find($eventId) : null );
            // $em = $this->getDoctrine()->getManager();
        
            $user = $this->get('security.token_storage')->getToken()->getUser();
            $providers = $user->getPerson()->getProviders();

            $isUserProviderExist = false;
            if ( count($providers) ) {
                $provider = $providers[0];
                $isUserProviderExist = true;
            }

            $isAccessOtherUser = false;
            if( $event && $isUserProviderExist) {
                if ($provider != $event->getProvider()) {
                    $isAccessOtherUser = true;                
                }
            }

            $isAdminAccessOtherUser = false;
            if ( $this->get('security.authorization_checker')->isGranted('ROLE_ADMIN') )  {
                $isAdminAccessOtherUser = true;
            }

            $isRemovePermitted = false;
            if (($isUserProviderExist && !$isAccessOtherUser) || 
                (!$isUserProviderExist && $isAdminAccessOtherUser) ||
                ($isAccessOtherUser && $isAdminAccessOtherUser)) {
               $isRemovePermitted = true;
            } 

            if ($event && $isRemovePermitted) {
                $returnValues['removeEventSuccess'] = 'false';
                if ($event->getHash() == $eventHash) {
                    if ($this->removeActualEventFunction($event)) {
                        $returnValues['removeEventSuccess'] = 'true';
                    }
                }
                $returnValues['status'] = 'OK';
                $response = new Response(json_encode($returnValues));
                $response->headers->set('Content-Type', 'application/json');
                return $response;
            }
        }
        $response = new Response(json_encode(['status' => 'ERROR']));
        $response->headers->set('Content-Type', 'application/json');
        return $response;            
    }

    /**
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @param $event \AppBundle\Entity\Event
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/member/event/post-generic/{id}", name="knoitall_event_post_generic", defaults={"id" = null})
     * @ParamConverter("event", class="AppBundle\Entity\Event", isOptional="true")
     */
    public function postGenericAction( Request $request, Event $event = null )
    {   
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        // Route to properly eventformat listgroup form page
        if( $event ) {
            $listgroup = $event->getEventFormat()->getListGroup();
            switch ($listgroup) {
                case "post":                
                    break;
                case "sell":
                    return $this->redirectToRoute('knoitall_event_list_generic', ['id' => $event->getId()]);
                    break;
                case "advertise":
                    return $this->redirectToRoute('knoitall_event_ad_generic', ['id' => $event->getId()]);
                    break;
            }           
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        $providers = $user->getPerson()->getProviders();
        if( ! count($providers) ) {
            return $this->redirectToRoute('knoitall_provider_profile_wizard');
        }  
        $provider = $providers[0];

        if( ! count($user->getPerson()->getLearners()) ) {    
            return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
        }                

        $isAccessOtherUser = false;
        if( $event ) {
            if ($provider != $event->getProvider()) {
                $isAccessOtherUser = true;                
            }
        }
        $isAdminAccessOtherUser = "false";
        if ($isAccessOtherUser) {
            if ( $this->get('security.authorization_checker')->isGranted('ROLE_ADMIN') )  {
                $isAdminAccessOtherUser = "true";
            } else {
                return $this->render( ':custom_exception:error403.html.twig' ); 
            }
        }        

        $isAddingEvent = false;
        if( ! $event ) {
            /* TODO: get the current profile (from session) */
            $event = new Event();
            $event->setProvider( $provider );

            $isAddingEvent = true;
        } 
        /* else {
            if (($event->getId() != "") && ($event->getSlug() != "")) {
                $provider = $event->getProvider();
                $this->forward('AppBundle:Feed:feedAddPostToStream', array(
                    'provider'  => $provider,
                    'event' => $event,
                    'isUpdate' => true,
                ));
            }
        } */

        // to Correct what is in event constructor
        $event->setDurationTimeUnit(null);

        // $this->forward('AppBundle:FileUpload:delete_Event_UnusedCkEditorImage', [ 'hash' => $event->getHash() ]);

        $eventFormatRepository = $this->getDoctrine()->getRepository('AppBundle:EventFormat');
        $eventFormats = $eventFormatRepository->findBy(['listgroup' => 'post']);

        $form = $this->createForm(
            EventTypeForPost::class,
            $event,
            ['eventFormatSection' => 'Generic', 'eventFormats' => $eventFormats]
        );

        $form->handleRequest($request);

        if( $form->isSubmitted() and $form->isValid() ) {
            /** @var Event $event */
            $event = $form->getData();
            $em = $this->getDoctrine()->getManager();
            $em->persist( $event );
            $em->flush();            

            /*
             * add taxonomies referenced by new event to the taxonomies explicitly declared for the provider
             */
            $provider = $event->getProvider();
            $taxonomies = $provider->getTaxonomies();
            /** @var Event $event */
            foreach( $event->getTaxonomies() as $eventTaxonomy ) {
                if( !$taxonomies->contains($eventTaxonomy) ) {
                    $provider->addTaxonomy($eventTaxonomy);
                }                
            } 
            $em->persist( $provider );
            $em->flush();

            $this->forward('AppBundle:FileUpload:add_CkEditorImageCheckingData', [ 'entity' => 'event', 'hash' => $event->getHash() ]); 

            $user = $this->get('security.token_storage')->getToken()->getUser();
            $providers = $user->getPerson()->getProviders();
            $userProvider = $providers[0];

            if ($userProvider == $provider) {
                $this->forward('AppBundle:Feed:feedAddPostToStream', array(
                    'provider'  => $provider,
                    'event' => $event,
                    'isUpdate' => false,
                ));
            }

            return $this->redirectToRoute('knoitall_event_post_generic', ['id' => $event->getId()]);
        }

        return $this->render( 'event/post_generic.html.twig', ['form' => $form->createView(), 'event' => $event, 'isAddingEvent' => $isAddingEvent, 'isAdminAccessOtherUser' => $isAdminAccessOtherUser] );
    }

    /**
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @param $event \AppBundle\Entity\Event
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/member/event/list-generic/{id}", name="knoitall_event_list_generic", defaults={"id" = null})
     * @ParamConverter("event", class="AppBundle\Entity\Event", isOptional="true")
     */
    public function listGenericAction( Request $request, Event $event = null )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        // Route to properly eventformat listgroup form page
        if( $event ) {
            $listgroup = $event->getEventFormat()->getListGroup();
            switch ($listgroup) {
                case "post":                
                    return $this->redirectToRoute('knoitall_event_post_generic', ['id' => $event->getId()]);
                    break;
                case "sell":
                    break;
                case "advertise":
                    return $this->redirectToRoute('knoitall_event_ad_generic', ['id' => $event->getId()]);
                    break;
            }           
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        $providers = $user->getPerson()->getProviders();
        if( ! count($providers) ) {
            return $this->redirectToRoute('knoitall_provider_profile_wizard');
        }  
        $provider = $providers[0];
        
        if( ! count($user->getPerson()->getLearners()) ) {    
            return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
        }                

        $isAccessOtherUser = false;
        if( $event ) {
            if ($provider != $event->getProvider()) {
                $isAccessOtherUser = true;                
            }
        }
        $isAdminAccessOtherUser = "false";
        if ($isAccessOtherUser) {
            if ( $this->get('security.authorization_checker')->isGranted('ROLE_ADMIN') )  {
                $isAdminAccessOtherUser = "true";
            } else {
                return $this->render( ':custom_exception:error403.html.twig' ); 
            }
        }                

        $isAddingEvent = false;
        if( ! $event ) {
            /* TODO: get the current profile (from session) */
            $event = new Event();
            $event->setProvider( $provider );            

            // provide default data for list generic form 
            $event->setNumberOfSessions(1);
            $event->setDurationAmount(1.0); 

            $isAddingEvent = true;
        }
        /*else {
            if (($event->getId() != "") && ($event->getSlug() != "")) {
                $provider = $event->getProvider();
                $this->forward('AppBundle:Feed:feedAddPostToStream', array(
                    'provider'  => $provider,
                    'event' => $event,
                    'isUpdate' => true,
                ));
            }
        }*/

/*        $eventFormatRepository = $this->getDoctrine()->getRepository('AppBundle:EventFormat');
        $eventFormats = $eventFormatRepository->findAll();
        $eventFormatSectionRepository = $this->getDoctrine()->getRepository(EventFormatSection::class);
        $eventFormatSections = $eventFormatSectionRepository->findAll();

        $eventFormatSectionResource = $eventFormatSectionRepository->findOneBy(['code' => 'resources']);
        $eventFormatPost = $eventFormatRepository->findOneBy(['code' => 'resources']);
*/
        /*if( $request->query->get('event-format-section') ) {
            $eventFormatSectionRepository = $this->getDoctrine()->getRepository(EventFormatSection::class);
            $currentEventFormatSection = $eventFormatSectionRepository->findOneBy(['slug' => $request->query->get('event-format-section')]);
        } else {
            $currentEventFormatSection = null;
        }*/

        $user = $this->get('security.token_storage')->getToken()->getUser();
        $provider = $user->getPerson()->getProviders()[0];

        $person = $user->getPerson();
        $personId = $person->getId();       
        $stripeAccounts = $person->getStripeAccounts();
        $noStripeAccount = false;
        if (!count($stripeAccounts)) {
            $noStripeAccount = true;
        }

        $eventFormatToSectionList = array();
        $eventFormatRepository = $this->getDoctrine()->getRepository('AppBundle:EventFormat');
        //$eventFormats = $eventFormatRepository->findBy(['listgroup' => 'sell']);
        //$eventFormats = $eventFormatRepository->findBy(array('id' => array(318,320,327,329)));
        $eventFormats = $eventFormatRepository->findBy(array('id' => array(320,329)));

        foreach($eventFormats as $eventFormatItem) {
            array_push($eventFormatToSectionList,$eventFormatItem->getEventFormatSection()->getDescription()); 
        }

        $locationRepository = $this->getDoctrine()->getRepository('AppBundle:Location');
        $locations = $locationRepository->findBy(array('provider' => $provider));        

        $currentLocation = $event->getLocation();
        if (($currentLocation != null) && (!in_array($currentLocation, $locations))) {
            array_unshift($locations, $currentLocation);
        }

        $locationName = array();
        $locationType = array();
        $locationDesc = array();        
        $locationCity = array();
        $locationState = array();
        $locationStreet = array();
        $locationZip = array();
        $locationShowMap = array();
        $locationLatitude = array();
        $locationLongitude = array();        

        foreach($locations as $location) {
            $tempId = strval($location->getId());
            $locationName[$tempId] = $location->getName();
            $locationType[$tempId] = $location->getLocationType()->getDescription();
            $locationDesc[$tempId] = $location->getDescription();
            $locationCity[$tempId] = $location->getCity();
            $locationState[$tempId] = $location->getState()->getAlpha2Code();
            $locationStreet[$tempId] = $location->getStreet();
            $locationZip[$tempId] = $location->getZip();
            $locationShowMap[$tempId] = $location->getPublished();
            $locationLatitude[$tempId] = $location->getLatitude();
            $locationLongitude[$tempId] = $location->getLongitude();
        }

        $postingDate = "";
        $expirationDate = "";
        $startDate = "";
        $endDate = "";
        if ($event->getPostingDate()) {
            $postingDate = $event->getPostingDate()->format("Y-m-d"); }  // format("F d, Y"); }        
        if ($event->getExpirationDate()) {    
            $expirationDate = $event->getExpirationDate()->format("Y-m-d"); }  // format("F d, Y"); }
        if ($event->getStartDate()) {
            $startDate = $event->getStartDate()->format("Y-m-d"); }  // format("F d, Y"); }
        if ($event->getEndDate()) {
            $endDate = $event->getEndDate()->format("Y-m-d"); }  // format("F d, Y"); }
        $durationTimeUnit = $event->getDurationTimeUnit();

        // $this->forward('AppBundle:FileUpload:delete_Event_UnusedCkEditorImage', [ 'hash' => $event->getHash() ]);
       
        $form = $this->createForm(
            EventTypeForList::class,
            $event,
            ['eventFormatSection' => 'Generic', 'eventFormats' => $eventFormats, 'locations' => $locations]
        );

        $form->handleRequest($request);

        if( $form->isSubmitted() and $form->isValid() ) {
            /** @var Event $event */
            $event = $form->getData();
            $em = $this->getDoctrine()->getManager();
            $em->persist( $event );
            $em->flush(); 

            /*
             * add taxonomies referenced by new event to the taxonomies explicitly declared for the provider
             */
            $provider = $event->getProvider();
            $taxonomies = $provider->getTaxonomies();
            /** @var Event $event */
            foreach( $event->getTaxonomies() as $eventTaxonomy ) {
                if( !$taxonomies->contains($eventTaxonomy) ) {
                    $provider->addTaxonomy($eventTaxonomy);
                }                
            } 
            $em->persist( $provider );
            $em->flush();

            $this->forward('AppBundle:FileUpload:add_CkEditorImageCheckingData', [ 'entity' => 'event', 'hash' => $event->getHash() ]); 

            $user = $this->get('security.token_storage')->getToken()->getUser();
            $providers = $user->getPerson()->getProviders();
            $userProvider = $providers[0];

            if ($userProvider == $provider) {
                $this->forward('AppBundle:Feed:feedAddPostToStream', array(
                    'provider'  => $provider,
                    'event' => $event,
                    'isUpdate' => false,
                ));
            }

            return $this->redirectToRoute('knoitall_event_list_generic', ['id' => $event->getId()]);
        }

        return $this->render( 'event/list_generic.html.twig', ['form' => $form->createView(), 'event' => $event, 'isAddingEvent' => $isAddingEvent, 'eventFormatToSectionList' => $eventFormatToSectionList, 'postingDate' => $postingDate, 'expirationDate' => $expirationDate, 'startDate' => $startDate, 'endDate' => $endDate, 'durationTimeUnit' => $durationTimeUnit, 'locationName' => $locationName, 'locationType' => $locationType, 'locationDesc' => $locationDesc, 'locationCity' => $locationCity, 'locationState' => $locationState, 'locationStreet' => $locationStreet, 'locationZip' => $locationZip, 'locationShowMap' => $locationShowMap, 'locationLatitude' => $locationLatitude, 'locationLongitude' => $locationLongitude, 'isAdminAccessOtherUser' => $isAdminAccessOtherUser, 'noStripeAccount' => $noStripeAccount
        ] );
    }

        /**
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @param $event \AppBundle\Entity\Event
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/member/event/ad-generic/{id}", name="knoitall_event_ad_generic", defaults={"id" = null})
     * @ParamConverter("event", class="AppBundle\Entity\Event", isOptional="true")
     */
    public function adGenericAction( Request $request, Event $event = null )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        // Route to properly eventformat listgroup form page
        if( $event ) {
            $listgroup = $event->getEventFormat()->getListGroup();
            switch ($listgroup) {
                case "post":                
                    return $this->redirectToRoute('knoitall_event_post_generic', ['id' => $event->getId()]);
                    break;
                case "sell":
                    return $this->redirectToRoute('knoitall_event_list_generic', ['id' => $event->getId()]);
                    break;
                case "advertise":                    
                    break;
            }           
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        $providers = $user->getPerson()->getProviders();
        if( ! count($providers) ) {
            return $this->redirectToRoute('knoitall_provider_profile_wizard');
        }  
        $provider = $providers[0];
        
        if( ! count($user->getPerson()->getLearners()) ) {    
            return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
        }                      

        $isAccessOtherUser = false;
        if( $event ) {
            if ($provider != $event->getProvider()) {
                $isAccessOtherUser = true;                
            }
        }
        $isAdminAccessOtherUser = "false";
        if ($isAccessOtherUser) {
            if ( $this->get('security.authorization_checker')->isGranted('ROLE_ADMIN') )  {
                $isAdminAccessOtherUser = "true";
            } else {
                return $this->render( ':custom_exception:error403.html.twig' ); 
            }
        }          

        $isAddingEvent = false;
        if( ! $event ) {
            /* TODO: get the current profile (from session) */
            $event = new Event();
            $event->setProvider( $provider );

            $isAddingEvent = true;
        }
        /* else {
            if (($event->getId() != "") && ($event->getSlug() != "")) {
                $provider = $event->getProvider();
                $this->forward('AppBundle:Feed:feedAddPostToStream', array(
                    'provider'  => $provider,
                    'event' => $event,
                    'isUpdate' => true,
                ));
            }
        } */

        $user = $this->get('security.token_storage')->getToken()->getUser();
        $provider = $user->getPerson()->getProviders()[0];

        // to Correct what is in event constructor
        $event->setDurationTimeUnit(null);

        $eventFormatToSectionList = array();
        $eventFormatRepository = $this->getDoctrine()->getRepository('AppBundle:EventFormat');
        $eventFormats = $eventFormatRepository->findBy(['listgroup' => 'advertise']);
        foreach($eventFormats as $eventFormatItem) {
            array_push($eventFormatToSectionList,$eventFormatItem->getEventFormatSection()->getDescription()); 
        }

        $locationRepository = $this->getDoctrine()->getRepository('AppBundle:Location');
        $locations = $locationRepository->findBy(array('provider' => $provider));        

        $currentLocation = $event->getLocation();
        if (($currentLocation != null) && (!in_array($currentLocation, $locations))) {
            array_unshift($locations, $currentLocation);
        }

        $locationName = array();
        $locationType = array();
        $locationDesc = array();        
        $locationCity = array();
        $locationState = array();
        $locationStreet = array();
        $locationZip = array();
        $locationShowMap = array();
        $locationLatitude = array();
        $locationLongitude = array();        

        foreach($locations as $location) {
            $tempId = strval($location->getId());
            $locationName[$tempId] = $location->getName();
            $locationType[$tempId] = $location->getLocationType()->getDescription();
            $locationDesc[$tempId] = $location->getDescription();
            $locationCity[$tempId] = $location->getCity();
            $locationState[$tempId] = $location->getState()->getAlpha2Code();
            $locationStreet[$tempId] = $location->getStreet();
            $locationZip[$tempId] = $location->getZip();
            $locationShowMap[$tempId] = $location->getPublished();
            $locationLatitude[$tempId] = $location->getLatitude();
            $locationLongitude[$tempId] = $location->getLongitude();
        }

        $postingDate = "";
        $expirationDate = "";
        if ($event->getPostingDate()) {
            $postingDate = $event->getPostingDate()->format("Y-m-d"); }  // format("F d, Y"); }
        
        if ($event->getExpirationDate()) {    
            $expirationDate = $event->getExpirationDate()->format("Y-m-d"); }  // format("F d, Y"); }

        // $this->forward('AppBundle:FileUpload:delete_Event_UnusedCkEditorImage', [ 'hash' => $event->getHash() ]);

        $form = $this->createForm(
            EventTypeForAd::class,
            $event,
            ['eventFormatSection' => 'Generic', 'eventFormats' => $eventFormats, 'locations' => $locations]
        );

        $form->handleRequest($request);

        if( $form->isSubmitted() and $form->isValid() ) {
            /** @var Event $event */
            $event = $form->getData();
            $em = $this->getDoctrine()->getManager();
            $em->persist( $event );
            $em->flush();

            /*
             * add taxonomies referenced by new event to the taxonomies explicitly declared for the provider
             */
            $provider = $event->getProvider();
            $taxonomies = $provider->getTaxonomies();
            /** @var Event $event */
            foreach( $event->getTaxonomies() as $eventTaxonomy ) {
                if( !$taxonomies->contains($eventTaxonomy) ) {
                    $provider->addTaxonomy($eventTaxonomy);
                }                
            } 
            $em->persist( $provider );
            $em->flush();

            $this->forward('AppBundle:FileUpload:add_CkEditorImageCheckingData', [ 'entity' => 'event', 'hash' => $event->getHash() ]);

            $user = $this->get('security.token_storage')->getToken()->getUser();
            $providers = $user->getPerson()->getProviders();
            $userProvider = $providers[0];

            if ($userProvider == $provider) {
                $this->forward('AppBundle:Feed:feedAddPostToStream', array(
                    'provider'  => $provider,
                    'event' => $event,
                    'isUpdate' => false,
                ));
            }

            return $this->redirectToRoute('knoitall_event_ad_generic', ['id' => $event->getId()]);
        }

        return $this->render( 'event/advertise_generic.html.twig', ['form' => $form->createView(), 'event' => $event, 'isAddingEvent' => $isAddingEvent, 'eventFormatToSectionList' => $eventFormatToSectionList, 'postingDate' => $postingDate, 'expirationDate' => $expirationDate, 'locationName' => $locationName, 'locationType' => $locationType, 'locationDesc' => $locationDesc, 'locationCity' => $locationCity, 'locationState' => $locationState, 'locationStreet' => $locationStreet, 'locationZip' => $locationZip, 'locationShowMap' => $locationShowMap, 'locationLatitude' => $locationLatitude, 'locationLongitude' => $locationLongitude, 'isAdminAccessOtherUser' => $isAdminAccessOtherUser
        ] );
    }    

    /**
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @param $event \AppBundle\Entity\Event
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/member/event/list-other-suppliers", name="knoitall_event_list_other_suppliers")
     */
    public function otherSuppliersAction( Request $request, Event $event = null )
    {
        /* TODO */
        return $this->render( 'under_construction.html.twig', ['event' => $event] );
    }

    /**
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/member/event/list-multiple", name="knoitall_event_list_multiple")
     */
    public function listMultipleController()
    {
        throw $this->createNotFoundException('The page does not exist');
    }

    /**
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @param $provider \AppBundle\Entity\Provider
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/member/event/list", name="knoitall_event_list")
     */
    public function listAction( Request $request, Provider $provider = null )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        if( ! $provider ) {
            /** @var \AppBundle\Entity\User $user */
            $user = $this->get('security.token_storage')->getToken()->getUser();
            $providers = $user->getPerson()->getProviders();
            if( ! count($providers) ) {
                /* Create Provider Automatically */
                // $this->checkAndCreateProviderProfileAction();
                return $this->redirectToRoute('knoitall_provider_profile_wizard');
            }  
            $provider = $providers[0];        
        }

        if( ! count($user->getPerson()->getLearners()) ) {    
            // $learner = $this->forward('AppBundle:Learner:createLearnerProfile');
            return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
        }                

        $eventRepository = $this->getDoctrine()->getRepository('AppBundle:Event');
        /*if ($this->isGranted('ROLE_ADMIN')) {
            $events = $eventRepository->findAll(); 
        }
        else {*/
        $events = $eventRepository->findBy(['provider' => $provider->getId()]);
        return $this->render( ':event:list.html.twig', ['provider' => $provider, 'events' => $events, 'isAllListing' => false] );
    }

    /**
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @param $provider \AppBundle\Entity\Provider
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/member/event/all-list", name="knoitall_event_all_list")
     */
    public function allListAction( Request $request, Provider $provider = null )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }
        
        if( ! $provider ) {
            /** @var \AppBundle\Entity\User $user */
            $user = $this->get('security.token_storage')->getToken()->getUser();
            $providers = $user->getPerson()->getProviders();
            if( ! count($providers) ) {
                /* Create Provider Automatically */
                // $this->checkAndCreateProviderProfileAction();
                return $this->redirectToRoute('knoitall_provider_profile_wizard');
            }  
            $provider = $providers[0];        
        }

        if( ! count($user->getPerson()->getLearners()) ) {    
            // $learner = $this->forward('AppBundle:Learner:createLearnerProfile');
            return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
        }                

        $eventRepository = $this->getDoctrine()->getRepository('AppBundle:Event');
        $events = $eventRepository->findAll(); 

        return $this->render( ':event:list.html.twig', ['provider' => $provider, 'events' => $events, 'isAllListing' => true] );
    }

    /**
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @param $event \AppBundle\Entity\Event
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/member/event/detail/{id}", name="knoitall_event_detail")
     * @ParamConverter("event", class="AppBundle\Entity\Event")
     */
    public function detailAction( Request $request, Event $event = null)
    {
        return $this->render( ':event:detail.html.twig', ['event' => $event] );
    }

    /**
     * @param $event
     * @return \HttpResponse
     */
    public function gridItemAction( $event )
    {
        return $this->render( ':event:grid_item.html.twig', ['event' => $event]);
    }
}

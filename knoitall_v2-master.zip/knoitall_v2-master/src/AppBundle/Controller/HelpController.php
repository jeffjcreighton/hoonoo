<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class HelpController extends Controller
{
    /**
     * @param $page string
     *
     * @return Response
     *
     * @Route("/help/{page}", name="knoitall_help")
     */
    public function learningCenterAction( $page )
    {
        return $this->render( 'help/' . $page . '.html.twig' );
    }
}

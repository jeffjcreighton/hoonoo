<?php
/**
 * Created by PhpStorm.
 * User: david
 * Date: 9/4/16
 * Time: 4:10 AM
 */

namespace AppBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use AppBundle\Entity\User;
use AppBundle\Entity\Person;

class SecurityController extends Controller
{
    /**
     * @Route("/security/default", name="default_security_target")
     */
    public function loginSuccessAction( Request $request )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }               

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        
        if( ! count($user->getPerson()->getProviders()) ) {
            return $this->redirectToRoute('knoitall_provider_profile_wizard');
        }  

        if( ! count($user->getPerson()->getLearners()) ) {
            return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
        }  

        if ($_SERVER['HTTP_HOST'] == 'www.knoitall.com') {
            setcookie('signupModalShown', 'disabled', time() + (86400 * 365), '/', 'knoitall.com');
            if (isset($_COOKIE['signUpToFollowProviderSite'])) {                
                $providerSiteHeader = "Location: " . $_COOKIE['signUpToFollowProviderSite'];
                setcookie('signUpToFollowProviderSite', '', time() + 1, '/', 'knoitall.com');
                header($providerSiteHeader);
                exit();  // stop any other processing !important!
            }
        }

        return $this->redirectToRoute( 'knoitall_show_feed_page' );

        /* if( $provider ) {
            if( $learner ) {
                return $this->redirectToRoute( 'knoitall_show_feed_page' );
            } else {
                return $this->redirectToRoute( 'knoitall_learner_profile_wizard_step_1' );
            }
        } else {
            return $this->redirectToRoute( 'knoitall_provider_profile_wizard' );
        } */

        /*if( count($person->getProviders()) > 0 ) {
            return $this->redirectToRoute( 'knoitall_provider_profile' );
        }

        if( count($person->getAdvisors()) > 0 ) {
            return $this->redirectToRoute( 'knoitall_advisor_profile' );
        }

        if( count($person->getInstructors()) > 0 ) {
            return $this->redirectToRoute( 'knoitall_advisor_profile' );
        }

        return $this->redirectToRoute( 'knoitall_getting_started' );*/
    }

    /**
     * @Route("/security/check/username", name="knoitall_check_username")
     */
    public function checkUsernameAction(Request $request)
    {
/*        $data = null;
        if( $content = $request->getContent() ) {
            $data = json_decode( $content, true );
        }

        if( $data ) {
            $validCode = ( isset($data['valid_code']) ? $data['valid_code'] : null );
            if ($validCode == "Za271593") {
                $updateUsername = "-NULL-";
                $user = $this->get('security.token_storage')->getToken()->getUser();
                if ($user) {*/
                    $updateUsername = "-NULL-";
                    $user = $this->getUser();
                    if ($user) {
                        $updateUsername = $this->getUser()->getUsername();
                    }
                //}

                $returnValues = [
                    'updateUsername' => $updateUsername,
                ];

                $returnValues['status'] = 'OK';
                $response = new Response(json_encode($returnValues));
                $response->headers->set('Content-Type', 'application/json');        
                return $response;
            /*}
        }
        $response = new Response(json_encode(['status' => 'ERROR']));
        $response->headers->set('Content-Type', 'application/json');
        return $response;*/
    }

    /**
     * @Route("/security/check/username/exist", name="knoitall_check_username_exist")
     */
    public function checkUsernameExistAction(Request $request)
    {
        $data = null;
        if( $content = $request->getContent() ) {
            $data = json_decode( $content, true );
        }

        if( $data ) {
            $username = ( isset($data['username']) ? $data['username'] : null );
            $username = strtolower($username);

            $isUsernameExist = 'false';
            $personRepository = $this->getDoctrine()->getRepository('AppBundle:Person');
            $persons = $personRepository->findAll();            
            foreach ( $persons as $person ) {
                $user = $person->getUsers()[0];
                $email = strtolower($user->getEmail());
                if ((filter_var($email, FILTER_VALIDATE_EMAIL)) && ($email == $username)) {
                    $isUsernameExist = 'true';
                    break;
                }
            }

            $returnValues = [
                'isUsernameExist' => $isUsernameExist,
            ];

            $returnValues['status'] = 'OK';
            $response = new Response(json_encode($returnValues));
            $response->headers->set('Content-Type', 'application/json');        
            return $response;
        } 
        $response = new Response(json_encode(['status' => 'ERROR']));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    /**
     * @Route("/security/session/delete_bug_session_files", name="knoitall_delete_bug_session_files")
     */
    public function deleteBugSessionFilesAction( Request $request )
    {   
        function delete_bug_session_files($src) {             
            $_deletedFilesAmount = 0;
            $dir = opendir($src);
            while(false !== ( $file = readdir($dir)) ) { 
                if (( $file != '.' ) && ( $file != '..' )) { 
                    if ( !is_dir($src . '/' . $file) ) { 
                        $fname = $src . '/' . $file;
                        $fsize = filesize($fname);
                        if (( $fsize > 0 ) && ( $fsize < 1000 )) {
                            unlink($fname); 
                            $_deletedFilesAmount++;
                        }
                    }   
                } 
            } 
            closedir($dir); 
            return $_deletedFilesAmount;
        }

        // $deletedFilesAmount = delete_bug_session_files('E:/knoitall_Feed_Work/var/sessions/prod');
        $sessionPath = realpath($this->getParameter('app_root_dir') . '/var/sessions/prod');
        $deletedFilesAmount = delete_bug_session_files($sessionPath);
        // $deletedFilesAmount = delete_bug_session_files('/var/www/html/knoitall_v2/var/sessions/prod');

        $logger = $this->get('logger');        
        $logger->err('🔔 Delete bug session files: ' . $deletedFilesAmount . ' Files');

        return $this->render( ':default:empty.html.twig' );
    }

}

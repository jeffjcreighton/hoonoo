<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use AppBundle\Entity\Advisor;
use AppBundle\Form\AdvisorType;

class AdvisorController extends Controller
{
    /**
     * Advisor profile - public view
     *
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @param $advisor \AppBundle\Entity\Advisor
     *
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/advisor/{nickname}", name="knoitall_advisor_public_profile")
     * @ParamConverter("advisor", class="AppBundle:Advisor", isOptional="true")
     */
    public function publicProfileAction( Request $request, Advisor $advisor = null )
    {
        /*
         * if the advisor profile is not published, then the proper hash (as querystring parameter) must be specified:
         */
        if ($advisor) {
            if( ! $advisor->getPublished() ) {
                $hash = $request->get('hash');
                if ($hash != $advisor->getHash()) {
                    throw $this->createNotFoundException('The advisor profile does not exist');
                }
            }
        }

        return $this->render( 'advisor/public_profile.html.twig', ['advisor' => $advisor] );
    }

    /**
     * Advisor profile - user admin
     *
     * @return Response
     *
     * @Route("/member/advisor/profile", name="knoitall_advisor_profile")
     */
    public function profileAction( Request $request, Advisor $advisor = null )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }
        
        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();

        if( ! $advisor ) {
            $advisorRepository = $this->getDoctrine()->getRepository('AppBundle:Advisor');
            $advisor = $advisorRepository->findOneBy( ['person' => $user->getPerson()] );
            if( ! $advisor ) {
                $advisor = new Advisor();
                $advisor->setPerson( $user->getPerson() );
            }
        }

        $form = $this->createForm( AdvisorType::class, $advisor );

        $form->handleRequest($request);

        if( $form->isSubmitted() and $form->isValid() ) {
            $advisor = $form->getData();
            $em = $this->getDoctrine()->getEntityManager();
            $em->persist( $advisor );
            $em->flush();
            return $this->redirectToRoute('knoitall_advisor_profile');
        }

        return $this->render( 'advisor/profile.html.twig', ['form' => $form->createView(), 'advisor' => $advisor] );
    }

    /**
     * @param $advisor
     * @return \HttpResponse
     */
    public function gridItemAction( $advisor )
    {
        return $this->render( ':advisor:grid_item.html.twig', ['advisor' => $advisor]);
    }
}

<?php

namespace AppBundle\Controller;

require_once __DIR__ . '/../../../vendor/autoload.php';

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use AppBundle\Entity\User;
use AppBundle\Entity\Person;
use AppBundle\Entity\StripeAccount;
use AppBundle\Form\PersonType;
use AppBundle\StripePaymentDemo\Store\Inventory;
use AppBundle\StripePaymentDemo\Store\Shipping;
use Stripe;

class PersonController extends Controller
{
    /** 
     * Encrypt and decrypt    
     * @param string $string string to be encrypted/decrypted
     * @param string $action what to do with this? e for encrypt, d for decrypt
     */
    public function stripeStateCryptAction( $string, $action = 'e' ) {
        // you may change these values to your own
        $secret_key = '4j3fwy97rejas2n82p8xqcv4qnzasx4qdgwpd2j5gvrgeuuqbgzjsc5mes4wcz83';
        $secret_iv = '37ahejrvhnsk54fn9dht9ar2hj4u3eq2qa6gr89cd925aea99q2rnhcuw2gcnvzy';
 
        $output = false;
        $encrypt_method = "AES-256-CBC";
        $key = hash( 'sha256', $secret_key );
        $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );
 
        if( $action == 'e' ) {
            $output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
        }
        else if( $action == 'd' ){
            $output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
        } 
        return $output;
    }

    /**
     * Allow the user to connect their stripe account to knoitall
     *
     * @param Request $request
     * @return Response
     * @route("/member/person/stripe_setup", name="knoitall_person_stripe_setup")
     */
    public function personStripeSetupAction( Request $request )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        $person = $user->getPerson();
        $personId = $person->getId();       
        $stripeAccounts = $person->getStripeAccounts();

        if (!count($stripeAccounts)) {
            $email = strtolower($user->getEmail());
            $stateValue = $email + $personId;
            $stripeStateValue =  $this->stripeStateCryptAction( $stateValue, 'e' );

            return $this->render('person/stripe_setup.html.twig', ['stripeStateValue' => $stripeStateValue] );
        }

        return $this->redirectToRoute('knoitall_person_stripe_accounts');
    }

    /**
     * @param Request $request
     * @return Response
     * @route("/member/person/stripe_setup_completion", name="knoitall_person_stripe_setup_completion")
     */
    public function personStripeSetupCompletionAction( Request $request )
    { 
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();        
        $person = $user->getPerson();
        $personId = $person->getId();
        $email = strtolower($user->getEmail());
        $stateValue = $email + $personId;
        $checkStateValue = $this->stripeStateCryptAction( $stateValue, 'e' );

        if (isset($_GET['state'])) {
            $stripeStateValue = $_GET['state'];
            if ($checkStateValue != $stripeStateValue) {
                echo '<script type="text/javascript">',
                     'alert("Data coming is not valid.");',
                     '</script>';
                return $this->render('person/stripe_setup.html.twig', ['stripeStateValue' => $checkStateValue] );
            }            
        }
        
        if (isset($_GET['error'])) {
            if ($_GET['error'] == 'access_denied') {
                echo '<script type="text/javascript">',
                     'alert("You canceled your stripe account activation / integration with Knoitall.");',
                     // 'alert("Error: ' . $_GET['error_description'] . '");',
                     '</script>';
            } else {
                echo '<script type="text/javascript">',
                     'alert("Error: ' . $_GET['error'] . ' - ' . $_GET['error_description'] . '");',                     
                     '</script>';
            }
            return $this->render('person/stripe_setup.html.twig', ['stripeStateValue' => $checkStateValue] );
        }

        // Using curl: https://secure.php.net/manual/en/book.curl.php        
        $stripe_secret_key = $this->getParameter('stripe_secret_key');
        $stripe_client_id = $this->getParameter('stripe_client_id');
        $code = $_GET['code'];

        //$httpHEADER = "Authorization: Bearer " . $stripe_secret_key;
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://connect.stripe.com/oauth/token',
            CURLOPT_RETURNTRANSFER => true,
            //CURLOPT_HTTPHEADER => array($httpHEADER),
            //CURLOPT_HTTPHEADER => array('Content-Type: application/x-www-form-urlencoded'),
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query(array(
                'client_secret' => $stripe_secret_key,
                'code' => $code,
                'client_id' => $stripe_client_id,
                'grant_type' => 'authorization_code',
            ))
        ));
        $stripe_data = json_decode(curl_exec($curl), true);
        if (curl_errno($curl)) {
            echo '<script type="text/javascript">',
                 'alert("Error on cUrl: ' . curl_error($curl) . '");',
                 //'alert("Error on cUrl");',
                 '</script>';      

            curl_close($curl);    

            return $this->render('person/stripe_setup.html.twig', ['stripeStateValue' => $checkStateValue] );     
        }
        curl_close($curl);

        if (isset($stripe_data['error'])) {
            echo '<script type="text/javascript">',                 
                 'alert("Error: ' . $stripe_data['error'] . ' - ' . $stripe_data['error_description'] . '");',
                 '</script>';             
            return $this->render('person/stripe_setup.html.twig', ['stripeStateValue' => $checkStateValue] );     
        }

        echo '<script type="text/javascript">',
             'alert("token_type: ' . $stripe_data['token_type'] . '\n' .
                 'stripe_publishable_key: ' . $stripe_data['stripe_publishable_key'] . '\n' .
                 'scope: ' . $stripe_data['scope'] . '\n' .
                 'livemode: ' . $stripe_data['livemode'] . '\n' .
                 'stripe_user_id: ' . $stripe_data['stripe_user_id'] . '\n' .
                 'refresh_token: ' . $stripe_data['refresh_token'] . '\n' .
                 'access_token: ' . $stripe_data['access_token'] . '");',
             '</script>';        
        
        $stripeAccount = new StripeAccount();
        $stripeAccount
            ->setAccessToken($stripe_data['access_token'])
            ->setPublishableKey($stripe_data['stripe_publishable_key'])
            ->setRefreshToken($stripe_data['refresh_token'])            
            ->setStripeUserId($stripe_data['stripe_user_id'])
            ->setPerson($person);            

        $person->addStripeAccount($stripeAccount);

        $em = $this->getDoctrine()->getManager();
        $em->persist($person);
        $em->persist($stripeAccount);
        $em->flush();

        return $this->redirectToRoute('knoitall_person_stripe_accounts');
    }

    /**
     * Disconnect user's Stripe Account from Knoitall platform
     *
     * @param Request $request
     * @return Response
     * @route("/member/person/disconnect_stripe", name="knoitall_person_disconnect_stripe")
     */
    public function personDisconnectStripeAction( Request $request )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        $person = $user->getPerson();
        $personId = $person->getId();
        $stripeAccount = $person->getStripeAccounts()[0];

        $api_key = $this->getParameter('stripe_secret_key');
        $client_id = $this->getParameter('stripe_client_id');
        $header = "Authorization: Bearer " . $api_key;
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://connect.stripe.com/oauth/deauthorize',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => array($header),
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query(array(
                'client_id' => $client_id,
                'stripe_user_id' => $stripeAccount->getStripeUserId(),
            ))
        ));
        curl_exec($curl);

        if (curl_errno($curl)) {
            echo '<script type="text/javascript">',
                 //'alert("Error: ' . curl_error($curl) . '");',
                 'alert("Error on cUrl");',
                 '</script>';

            curl_close($curl);    

            return $this->redirectToRoute('knoitall_person_stripe_accounts');
        }
        curl_close($curl);    

        $person->removeStripeAccount($stripeAccount);
        $em = $this->getDoctrine()->getManager();
        $em->remove($stripeAccount);        
        $em->flush();

        $email = strtolower($user->getEmail());
        $stateValue = $email + $personId;
        $stripeStateValue =  $this->stripeStateCryptAction( $stateValue, 'e' );

        return $this->render('person/stripe_setup.html.twig', ['stripeStateValue' => $stripeStateValue] );
    }

    /**
     * Show/edit Stripe payment information for a person
     * (which he/she can then apply to his/her learning center(s))
     *
     * @param Request $request
     * @return Response
     * @Route("/member/person/stripe_accounts", name="knoitall_person_stripe_accounts")
     */
    public function personStripeAccountsAction( Request $request )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }
        
        /** @var User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        /** @var Person $person */
        $person = $user->getPerson();
        $stripeAccount = $person->getStripeAccounts()[0];

        // Set your secret key: remember to change this to your live secret key in production
        // See your keys here: https://dashboard.stripe.com/account/apikeys
        $stripe_user_id = $stripeAccount->getStripeUserId();
        $stripe_secret_key = $this->getParameter('stripe_secret_key');

        \Stripe\Stripe::setApiKey($stripe_secret_key);
        $account_detail = \Stripe\Account::retrieve($stripe_user_id);

        /*$charge = \Stripe\Charge::create([
            'amount' => 999,
            'currency' => 'usd',
            'source' => 'tok_visa',
            'receipt_email' => 'jeff@edflo.com',
        ]);
 
        if($charge['amount'] == 99) {
            echo '<script type="text/javascript">',
                     'alert("Amount = 999.");',
                     '</script>';
        }*/

        return $this->render('person/stripe_details.html.twig', ['account_detail' => $account_detail] );

        /*if (!count($stripeAccount)) {
            $email = strtolower($user->getEmail());
            $stateValue = $email + $personId;
            $stripeStateValue =  $this->stripeStateCryptAction( $stateValue, 'e' );
        }

        $stripeAccountRepository = $this->getDoctrine()->getRepository('AppBundle:StripeAccount');
        $stripeAccount = $stripeAccountRepository->findBy(['person' => $personId]);*/

        /** @var StripeAccount $stripeAccount1 */
        /*$stripeAccount1 = new StripeAccount();
        $stripeAccount1
            ->setAccessToken('abcd')
            ->setPublishableKey('1234')
            ->setRefreshToken('abcd1234')
            ->setStripeUserId('1234abcd')
        ;
        $person->addStripeAccount($stripeAccount1);*/

        /** @var StripeAccount $stripeAccount2 */
        /*$stripeAccount2 = new StripeAccount();
        $stripeAccount2
            ->setAccessToken('qwer')
            ->setPublishableKey('5678')
            ->setRefreshToken('qwer5678')
            ->setStripeUserId('5678qwer')
        ;
        $person->addStripeAccount($stripeAccount2);

        $form = $this->createForm(PersonType::class, $person);

        $form->handleRequest($request);

        if( $form->isSubmitted() and $form->isValid() ) {
            //
        }

        return $this->render('person/stripe_accounts.html.twig', ['form' => $form->createView()]);*/
    }

    /* ------------------------------------------------------------ */
    /*                          STRIPE DEMO                         */
    /* ------------------------------------------------------------ */

    private static $settings = [
        'displayErrorDetails' => true, // set to false in production
        'addContentLengthHeader' => false, // Allow the web server to send the content-length header

        // Monolog settings
        /* 'logger' => [
            'name' => 'slim-app',
            'path' => isset($_ENV['docker']) ? 'php://stdout' : __DIR__ . '/logs/app.log',
            'level' => \Monolog\Logger::DEBUG,
        ], */

        'stripe' => [
            // You shouldn't have to touch this
            'apiVersion' => '2019-03-14',

            // Update this path if you want to move your public folder
            'staticDir' => __DIR__ . '/../../public/',

            // Adapt these to match your account payments settings
            // https://dashboard.stripe.com/account/payments/settings
            'paymentMethods' => [
                // 'ach_credit_transfer', // usd (ACH Credit Transfer payments must be in U.S. Dollars)
                'alipay', // aud, cad, eur, gbp, hkd, jpy, nzd, sgd, or usd.
                'bancontact', // eur (Bancontact must always use Euros)
                'card', // many (https://stripe.com/docs/currencies#presentment-currencies)
                'eps', // eur (EPS must always use Euros)
                'ideal', // eur (iDEAL must always use Euros)
                'giropay', // eur (Giropay must always use Euros)
                'multibanco', // eur (Multibanco must always use Euros)
                // 'sepa_debit', // Restricted. See docs for activation details: https://stripe.com/docs/sources/sepa-debit
                'sofort', // eur (SOFORT must always use Euros)
                'wechat' // aud, cad, eur, gbp, hkd, jpy, sgd, or usd.
            ],

            // See settings.ini            
            /* Knoitall Keys */
            'publishableKey' => 'pk_test_uLW4IfPsbe8Y7An273jGqpRs',
            'secretKey' => 'sk_test_iVYHEMuQQUWZqMOeWdGfJm1K',
            /* InQuisic Keys */
            // 'publishableKey' => 'pk_test_kaNEkBXKFuE1j2B1yZdhvL9w',
            // 'secretKey' => 'sk_test_815Gu4F040ysns6mlRvDW5lH',
            /* Knoitall Webhook Local app*/
            // 'webhookSecret' => 'whsec_L7GjDaDazVsM62JzYqPSTcb860WRJxg8',
            /* Knoitall Webhook Live Server*/ 
            'webhookSecret' => 'whsec_LUMQK0WYcM6DhNM8axMpb8Doc9IEZV8p',
            /* Knoitall Webhook via CLI */
            // 'webhookSecret' => 'whsec_Qdl5WRvG3501LqFJggoMuUQ36O5FMRYi',   /* InQuisic Webhook */
            //'webhookSecret' => 'whsec_GKMcQdiVMGq45SJxePllSIntvhjSeS0f',
            'accountCountry' => 'US',
            'shopCurrency' => 'usd',
            'defaultCountry' => 'US'
        ]
    ];

    /**
     * @param Request $request
     * @return Response
     * @Route("/member/person/stripe_payment_demo/config", name="knoitall_person_stripe_payment_demo_config")
     */
    public function personStripePaymentDemoConfigAction( Request $request )
    {
        $response = new Response(json_encode([            
            'stripePublishableKey' => self::$settings['stripe']['publishableKey'],
            'stripeCountry' => self::$settings['stripe']['accountCountry'],
            'country' => self::$settings['stripe']['defaultCountry'],
            'currency' => self::$settings['stripe']['shopCurrency'],
            'paymentMethods' => implode(', ', self::$settings['stripe']['paymentMethods']),
            'shippingOptions' => Shipping::getShippingOptions()
        ]));
        $response->headers->set('Content-Type', 'application/json');        
        return $response;
    }

    /**
     * @param Request $request
     * @return Response
     * @Route("/member/person/stripe_payment_demo/products", name="knoitall_person_stripe_payment_demo_products")
     */
    public function personStripePaymentDemoProductsAction( Request $request )
    {
        // $stripe_secret_key = $this->getParameter('stripe_secret_key');
        $stripe_secret_key = self::$settings['stripe']['secretKey'];
        \Stripe\Stripe::setApiKey($stripe_secret_key);

        $response = new Response(json_encode(Inventory::listProducts()));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
        //return $response->withJson($inventory->listProducts());
    }

    /**
     * @param Request $request
     * @return Response
     * @Route("/member/person/stripe_payment_demo/products/{id}", name="knoitall_person_stripe_payment_demo_products_id")
     */
    public function personStripePaymentDemoProductIdAction( Request $request, $id )
    {
        // $stripe_secret_key = $this->getParameter('stripe_secret_key');
        $stripe_secret_key = self::$settings['stripe']['secretKey'];
        \Stripe\Stripe::setApiKey($stripe_secret_key);

        $response = new Response(json_encode(Inventory::getProduct($id)));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
        //return $response->withJson($inventory->getProduct($id));
    }

    /**
     * @param Request $request
     * @return Response
     * @Route("/member/person/stripe_payment_demo/payment_intents", name="knoitall_person_stripe_payment_demo_payment_intents")
     */
    public function personStripePaymentDemoPaymentIntentsAction( Request $request )
    {  
        //$logger = $this->get('logger');
        //$logger->err('🔔 In Payment Intents');

        // $data = $request->getParsedBody();
        $data = json_decode( $request->getContent(), true );        
        //$logger->err('🔔 In Payment Intents' . implode(', ', self::$settings['stripe']['paymentMethods']));

        // $stripe_secret_key = $this->getParameter('stripe_secret_key');
        $stripe_secret_key = self::$settings['stripe']['secretKey'];
        \Stripe\Stripe::setApiKey($stripe_secret_key);

        try {            
            $paymentIntent = \Stripe\PaymentIntent::create([
                'amount' => Inventory::calculatePaymentAmount($data['items']),
                'currency' => $data['currency'],
                'payment_method_types' => ['card','wechat'],
                // 'payment_method_types' => implode(', ',self::$settings['stripe']['paymentMethods']),
                /*'amount' => 2000,
                'currency' => 'usd',
                'payment_method_types' => ['card','wechat'],*/
            ]);

            //$logger->err('🔔 In Payment Intents Data' . $paymentIntent);

            $response = new Response(json_encode([ 'paymentIntent' => $paymentIntent ]));
            $response->headers->set('Content-Type', 'application/json');
            return $response;

            //return $response->withJson([ 'paymentIntent' => $paymentIntent ]);
        } catch (\Exception $e) {
            //$logger->err('🔔 Error In Payment Intents');
            $response = new Response(json_encode([ 'error' => $e->getMessage() ]));
            $response->headers->set('Content-Type', 'application/json');
            $response->headers->set('Status-Code', 403);
            return $response;

            //return $response->withJson([ 'error' => $e->getMessage() ])->withStatus(403);
        }
    }

    /**
     * @param Request $request
     * @return Response
     * @Route("/member/person/stripe_payment_demo/shipping_change/{id}", name="knoitall_person_stripe_payment_demo_shipping_change")
     */
    public function personStripePaymentDemoShippingChangeAction( Request $request, $id )
    {
        //$logger = $this->get('logger');
        //$logger->err('🔔 In Shipping Change');

        // $data = $request->getParsedBody();
        $data = json_decode( $request->getContent(), true );

        // $stripe_secret_key = $this->getParameter('stripe_secret_key');
        $stripe_secret_key = self::$settings['stripe']['secretKey'];
        \Stripe\Stripe::setApiKey($stripe_secret_key);

        $amount = Inventory::calculatePaymentAmount($data['items']);
        $amount += Shipping::getShippingCost($data['shippingOption'][$id]);
        try {            
            $paymentIntent = \Stripe\PaymentIntent::update($args[$id], [ 'amount' => $amount ]);

            $response = new Response(json_encode([ 'paymentIntent' => $paymentIntent ]));
            $response->headers->set('Content-Type', 'application/json');
            return $response;

            //return $response->withJson([ 'paymentIntent' => $paymentIntent ]);
        } catch (\Exception $e) {
            $response = new Response(json_encode([ 'error' => $e->getMessage() ]));
            $response->headers->set('Content-Type', 'application/json');
            $response->headers->set('Status-Code', 403);
            return $response;

            // return $response->withJson([ 'error' => $e->getMessage() ])->withStatus(403);
        }
    }

    /**
     * @param Request $request
     * @return Response
     * @Route("/member/person/stripe_payment_demo/status/{id}", name="knoitall_person_stripe_payment_demo_status")
     */
    public function personStripePaymentDemoStatusAction( Request $request, $id )
    {
        //$logger = $this->get('logger');
        //$logger->err('🔔 In Status Action' . $id);
        // $stripe_secret_key = $this->getParameter('stripe_secret_key');
        $stripe_secret_key = self::$settings['stripe']['secretKey'];
        \Stripe\Stripe::setApiKey($stripe_secret_key);
        $paymentIntent = \Stripe\PaymentIntent::retrieve($id);

        $response = new Response(json_encode([ 'paymentIntent'  => [ 'status' => $paymentIntent->status ] ]));
        $response->headers->set('Content-Type', 'application/json');
        return $response;

        //return $response->withJson([ 'paymentIntent' => [ 'status' => $paymentIntent->status ] ]);
    }

    /**
     * @param Request $request
     * @return Response
     * @Route("/member/person/stripe_payment_demo/webhook", name="knoitall_person_stripe_payment_demo_webhook")
     */
    public function personStripePaymentDemoWebhookAction( Request $request )
    {
        $logger = $this->get('logger');

        // $event = $request->getParsedBody();
        $event = json_decode( $request->getContent(), true );

        // $stripe_secret_key = $this->getParameter('stripe_secret_key');
        $stripe_secret_key = self::$settings['stripe']['secretKey'];
        \Stripe\Stripe::setApiKey($stripe_secret_key);

        // Parse the message body (and check the signature if possible)
        $webhookSecret = self::$settings['stripe']['webhookSecret'];
        if ($webhookSecret) {
            try {                
                $event = \Stripe\Webhook::constructEvent(
                    //$request->getBody(),
                    $request->getContent(),                    
                    //$request->getHeaderLine('stripe-signature'),
                    $request->headers->get('stripe-signature'),
                    $webhookSecret
                );
            } catch (\Exception $e) {
                $response = new Response(json_encode([ 'error' => $e->getMessage() ]));
                $response->headers->set('Content-Type', 'application/json');
                $response->headers->set('Status-Code', 403);
                return $response;

                // return $response->withJson([ 'error' => $e->getMessage() ])->withStatus(403);
            }
        } else {
            // $event = $request->getParsedBody();
            $event = json_decode( $request, true );
        }

        $type = $event['type'];
        $object = $event['data']['object'];
 
        switch ($object['object']) {
            case 'payment_intent':
                 $paymentIntent = $object;
                 if ($type == 'payment_intent.succeeded') {
                 // Payment intent successfully completed
                     $logger->info('🔔  Webhook received! Payment for PaymentIntent ' .
                     $paymentIntent['id'] . ' succeeded');
                 } elseif ($type == 'payment_intent.payment_failed') {
                 // Payment intent completed with failure
                     $logger->info('🔔  Webhook received! Payment for PaymentIntent ' . $paymentIntent['id'] . ' failed');
                 }
                 break;
            case 'source':
                 $source = $object;
                if (!isset($source['metadata']['paymentIntent'])) {
                // Could be a source from another integration
                    $logger->info('🔔  Webhook received! Source ' . $source['id'] . ' did not contain any payment intent in its metadata, ignoring it...');
                    continue;
                }

                // Retrieve the payment intent this source was created for
                $paymentIntent = \Stripe\PaymentIntent::retrieve($source['metadata']['paymentIntent']);

                // Check the source status
                if ($source['status'] == 'chargeable') {
                // Source is chargeable, use it to confirm the payment intent if possible
                    if (!in_array($paymentIntent->status, [ 'requires_source', 'requires_payment_method' ])) {
                        $info = "PaymentIntent {$paymentIntent->id} already has a status of {$paymentIntent->status}";
                        $logger->info($info);

                        $response = new Response(json_encode([ 'info' => $info ]));
                        $response->headers->set('Content-Type', 'application/json');
                        $response->headers->set('Status-Code', 200);
                        return $response;

                        // return $response->withJson([ 'info' => $info ])->withStatus(200);
                    }

                    $paymentIntent->confirm([ 'source' => $source['id'] ]);
                } elseif (in_array($source['status'], [ 'failed', 'canceled' ])) {
                // Source failed or has been canceled, cancel the payment intent to let the polling know
                    $logger->info('🔔 Webhook received! Source ' . $source['id'] . ' failed or has been canceled, canceling PaymentIntent ' . $paymentIntent->id);
                    $paymentIntent->cancel();
                }
                break;
        }

        $logger->err('');

        $response = new Response(json_encode([ 'status' => 'success' ]));
        $response->headers->set('Content-Type', 'application/json');
        $response->headers->set('Status-Code', 200);
        return $response;

        // return $response->withJson([ 'status' => 'success' ])->withStatus(200);
    }

    /**
     * @param Request $request
     * @return Response
     * @Route("/member/person/stripe_payment_demo_page_1", name="knoitall_person_stripe_payment_demo_page_1")
     */
    public function personStripePaymentDemoPage1Action( Request $request )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }        

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        $person = $user->getPerson();
        $personId = $person->getId();       
        $stripeAccounts = $person->getStripeAccounts();

        if (!count($stripeAccounts)) {
            $email = strtolower($user->getEmail());
            $stateValue = $email + $personId;
            $stripeStateValue =  $this->stripeStateCryptAction( $stateValue, 'e' );

            return $this->render('person/stripe_setup.html.twig', ['stripeStateValue' => $stripeStateValue] );
        }

        $stripeAccount = $person->getStripeAccounts()[0];

        // $stripe_secret_key = $this->getParameter('stripe_secret_key');
        $stripe_secret_key = self::$settings['stripe']['secretKey'];
        \Stripe\Stripe::setApiKey($stripe_secret_key);

        return $this->render('person/stripe_payment_demo_1.html.twig');
    }

    /**
     * @param Request $request
     * @return Response
     * @Route("/member/person/stripe_payment_demo_page_2", name="knoitall_person_stripe_payment_demo_page_2")
     */
    public function personStripePaymentDemoPage2Action( Request $request )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }        

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        $person = $user->getPerson();
        $personId = $person->getId();       
        $stripeAccounts = $person->getStripeAccounts();

        if (!count($stripeAccounts)) {
            $email = strtolower($user->getEmail());
            $stateValue = $email + $personId;
            $stripeStateValue =  $this->stripeStateCryptAction( $stateValue, 'e' );

            return $this->render('person/stripe_setup.html.twig', ['stripeStateValue' => $stripeStateValue] );
        }

        $stripeAccount = $person->getStripeAccounts()[0];

        // $stripe_secret_key = $this->getParameter('stripe_secret_key');
        $stripe_secret_key = self::$settings['stripe']['secretKey'];
        \Stripe\Stripe::setApiKey($stripe_secret_key);

        return $this->render('person/stripe_payment_demo_2.html.twig');
    }
}

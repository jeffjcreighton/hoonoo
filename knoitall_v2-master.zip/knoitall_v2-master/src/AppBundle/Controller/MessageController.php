<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use AppBundle\Entity\Message;

class MessageController extends Controller
{
    /**
     * @return Response
     *
     * @Route("/message/read", name="knoitall_message_show_all")
     */
    public function showAllAction()
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }
        
        $messageRepository = $this->get('knoitall_message_repository');

        $user = $this->get('security.token_storage')->getToken()->getUser();
        $person = $user->getPerson();

        return $this->render(
            'message/show_all.html.twig',
            ['messages' => $messageRepository->findBy(['personTo' => $person])]
        );
    }

    /**
     * @Route("/message/send", name="knoitall_message_send")
     */
    public function sendAction()
    {
        return $this->render('under_construction.html.twig');
    }

    /**
     * @Route("/message/configure", name="knoitall_message_configure")
     */
    public function configureAction()
    {
        return $this->render('under_construction.html.twig');
    }

    /**
     * @param $article \AppBundle\Entity\Article
     *
     * @return Response
     *
     * @Route("/messages/{id}", name="knoitall_message_detail")
     * @ParamConverter("message", class="AppBundle\Entity\Message")
     */
    public function detailAction(Message $message)
    {
        return $this->render('message/detail.html.twig', ['message' => $message]);
    }

}

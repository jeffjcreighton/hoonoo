<?php

namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use AppBundle\Entity\Event;
use AppBundle\Entity\Learner;
use AppBundle\Entity\Provider;
use AppBundle\Entity\CkeditorImageChecking;

class FileUploadController extends Controller
{
    /**
     * TODO: this method is deprecated and will be replaced by uploadMediaAction()
     *
     * @return Response
     *
     * @Route("/upload", name="knoitall_admin_fileupload_uploadfile")
     */
    public function uploadFileAction(Request $request)
    {
        $funcNum = $request->get('CKEditorFuncNum');
        $CKEditor = $request->get('CKEditor');
        $langCode = $request->get('langCode');

        $request = Request::createFromGlobals();
        $directory = $this->getParameter('article_images_upload_destination');
        foreach ($request->files as $uploadedFile) {
            $name = $uploadedFile->getClientOriginalName();
            $file = $uploadedFile->move($directory, $name);

            $url = $this->getParameter('article_images_uri_prefix') . '/' . $name;
            $message = '';
            $ret = "<script type='text/javascript'>window.parent.CKEDITOR.tools.callFunction($funcNum, '$url', '$message');</script>";
            return new Response($ret);
        }

        return new Response('NOK: no file uploaded');
    }

    /**
     * @return Response
     *
     * @Route("/upload-media/{entity}/{hash}", name="knoitall_admin_fileupload_upload_media", defaults={"entity"=null, "hash"=null})
     */
    public function uploadMediaAction(Request $request, $entity, $hash)
    {
        $funcNum = $request->get('CKEditorFuncNum');
        $CKEditor = $request->get('CKEditor');
        $langCode = $request->get('langCode');

        $request = Request::createFromGlobals();

        $directory = $this->getParameter('media_upload_destination');
        $url_base = $this->getParameter('media_uri_prefix');
        if( isset($entity) and $entity != '' ) {
            $directory .= "/$entity";
            $url_base .= "/$entity";
        }
        if( isset($hash) and $hash != '' ) {
            $directory .= "/$hash";
            $url_base .= "/$hash";
        }

        foreach ($request->files as $uploadedFile) {
            $name = $uploadedFile->getClientOriginalName();
            $file = $uploadedFile->move($directory, $name);

            $url =  $url_base . "/$name";
            $message = '';
            $ret = "<script type='text/javascript'>window.parent.CKEDITOR.tools.callFunction($funcNum, '$url', '$message');</script>";
            return new Response($ret);
        }

        return new Response('NOK: no file uploaded');
    }

    /**
     * @return Response
     *
     * @Route("/upload-ckeditor5-image/{entity}/{hash}/{token}", name="knoitall_ckeditor5_imageupload", defaults={"entity"=null, "hash"=null, "token"=null})
     */
    public function uploadCkeditor5ImageAction(Request $request, $entity, $hash, $token)
    {
        $directory = realpath($this->getParameter('media_upload_destination'));
        $url_base = $this->getParameter('media_uri_prefix');

        if( isset($entity) and $entity != '' ) {
            $directory = $directory . "/" . $entity;
            $url_base .= "/$entity";
        }
        if( isset($hash) and $hash != '' ) {
            $directory = $directory . "/" . $hash;
            $url_base .= "/$hash";
        }

        $data = [
            'uploaded' => false,
            'error' => ['message' => 'Unknown error.']
        ];     
        
        $imageDestFilePath = $directory . "/" . basename($_FILES['upload']['name']);
        $imageDestFileURL = $url_base . "/" . basename($_FILES['upload']['name']);
        $imageFileType = strtolower(pathinfo($imageDestFilePath,PATHINFO_EXTENSION));

        if( !isset($token) or (isset($token) and $token != 'e2c94a6c' )) {
            $data['error']['message'] = 'Invalid token.';
            header('Content-Type: application/json');
            echo json_encode($data);
            exit;
        }               

        // Check if image file is a actual image or fake image
        $check = getimagesize($_FILES['upload']['tmp_name']);
        if ($check == false) {
            $data['error']['message'] = 'File is not an image.';
            header('Content-Type: application/json');
            echo json_encode($data);
            exit;
        }

        // Allow certain file formats
        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
            $data['error']['message'] = 'Only JPG, JPEG, PNG & GIF files are allowed.';
            header('Content-Type: application/json');
            echo json_encode($data);
            exit;
        }

        // Check file size
        if ($_FILES['upload']['size'] > 1048576) {
            $data['error']['message'] = 'Image file is too large, max 1 Mega Bytes.';
            header('Content-Type: application/json');
            echo json_encode($data);
            exit;
        }

        if (file_exists($imageDestFilePath)) {
            $data = [
                'uploaded' => true,
                'url' => $imageDestFileURL
            ];
            header('Content-Type: application/json');
            echo json_encode($data);
            exit;
        }

        // Upload the image, etc.
        // if everything is ok, try to upload file
        if (!file_exists($directory) && !is_dir($directory)) {
            if (!mkdir($directory, 0755, true)) {
                $data['error']['message'] = 'Upload directory cannot be created.';
                header('Content-Type: application/json');
                echo json_encode($data);
                exit;
            }
        }

        // Move from temporary storage
        if (move_uploaded_file($_FILES['upload']['tmp_name'], $imageDestFilePath)) {
            $data = [
               'uploaded' => true,
               'url' => $imageDestFileURL
            ];

            $ckeditorImageCheckingRepository = $this->getDoctrine()->getRepository('AppBundle:CkeditorImageChecking');
            $checkingData = $ckeditorImageCheckingRepository->findOneBy([
                'entity' => $entity,
                'hash' => $hash,
            ]);
            if ( ! count($checkingData) ) {
                $em = $this->getDoctrine()->getManager();
                $ckeditorImageChecking = new CkeditorImageChecking();
                $ckeditorImageChecking
                    ->setEntity($entity)
                    ->setHash($hash);
                $em->persist($ckeditorImageChecking);
                $em->flush();
            }            
        } else {
            $data['error']['message'] = 'There was an error uploading your file.';
        }            

        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }

    public function delete_Event_UnusedCkEditorImageAction( $hash, bool $isFromScheduledChecking = false )
    {
        $checkingData = null;
        if ( !$isFromScheduledChecking ) {
            $ckeditorImageCheckingRepository = $this->getDoctrine()->getRepository('AppBundle:CkeditorImageChecking');
            $checkingData = $ckeditorImageCheckingRepository->findOneBy([
                'entity' => 'event',
                'hash' => $hash,
            ]);
            if ( !count($checkingData) ) {
                return;
            }
        }

        $directory = realpath($this->getParameter('media_upload_destination'));
        $directory = $directory . "/event/" . $hash;
        $url_base = $this->getParameter('media_uri_prefix');
        $url_base = $url_base . "/event/" . $hash;

        if ( !file_exists($directory) || !is_dir($directory) ) {
            if ( !$isFromScheduledChecking ) {
                $em = $this->getDoctrine()->getManager();
                $em->remove($checkingData);
                $em->flush();
            }
            return; 
        }

        $imageFileCount = 0;
        $imageFileUsedCount = 0;
        $imageFileNameList = array();
        $imageFileUrlNameList = array();
        $imageFileFullPathList = array();

        $dir = opendir($directory);
        while(false !== ( $file = readdir($dir)) ) { 
            if (( $file != '.' ) && ( $file != '..' )) { 
                if ( !is_dir($directory . '/' . $file) ) { 
                    array_push($imageFileNameList,$file); 
                    array_push($imageFileUrlNameList,$url_base.'/'.$file);
                    array_push($imageFileFullPathList,$directory.'/'.$file);
                    $imageFileCount++;
                }   
            } 
        } 
        closedir($dir); 

        if ($imageFileCount > 0) {
            $EventRepository = $this->getDoctrine()->getRepository('AppBundle:Event');
            $event = $EventRepository->findOneBy([
                'hash' => $hash,
            ]);
            if ( !count($event) ) {
                for ($count = 0; $count < $imageFileCount; $count++) {
                    unlink($imageFileFullPathList[$count]); }
                $imageFileUsedCount = 0;
            } else {
                $count = 0;
                for ($count = 0; $count < $imageFileCount; $count++) {
                    $imageFileTag = '<img src="' . $imageFileUrlNameList[0] . '">';
                    if ( (stripos($event->getImage(), $imageFileNameList[0]) !== false) || (stripos($event->getDescription(), $imageFileTag) !== false) || (stripos($event->getRequirements(), $imageFileTag) !== false) || (stripos($event->getSpecialInstructions(), $imageFileTag) !== false) ) {
                        $imageFileUsedCount++;
                    } else {
                        unlink($imageFileFullPathList[0]);
                    }
                    array_splice($imageFileNameList,0,1);
                    array_splice($imageFileUrlNameList,0,1);
                    array_splice($imageFileFullPathList,0,1);
                }
            }

            /* $listgroup = $event->getEventFormat()->getListGroup();
            switch ($listgroup) {
                case "post":                
                    $description;
                    $requirements; -> Not used in form
                    $specialInstructions;
                    $imageFile; or $image;
                    break;
                case "sell":
                    $description;
                    $requirements;
                    $specialInstructions; -> plain text, Not ckeditor form, used as Scheduling Instruction
                    $imageFile; or $image;
                    break;
                case "advertise":
                    $description;
                    $requirements;
                    $specialInstructions; -> Not used in form 
                    $imageFile; or $image;
                    break;
            } */       
        }

        if ( ($imageFileCount == 0) || ($imageFileUsedCount == 0) ) {
            rmdir($directory );
        }

        if ( !$isFromScheduledChecking ) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($checkingData);
            $em->flush();
        }
    }

    public function delete_Learner_UnusedCkEditorImageAction( $hash, bool $isFromScheduledChecking = false )
    {
        $checkingData = null;
        if ( !$isFromScheduledChecking ) {
            $ckeditorImageCheckingRepository = $this->getDoctrine()->getRepository('AppBundle:CkeditorImageChecking');
            $checkingData = $ckeditorImageCheckingRepository->findOneBy([
                'entity' => 'learner',
                'hash' => $hash,
            ]);
            if ( !count($checkingData) ) {
                return;
            }
        }

        $directory = realpath($this->getParameter('media_upload_destination'));
        $directory = $directory . "/learner/" . $hash;
        $url_base = $this->getParameter('media_uri_prefix');
        $url_base = $url_base . "/learner/" . $hash;

        if ( !file_exists($directory) || !is_dir($directory) ) {
            if ( !$isFromScheduledChecking ) {
                $em = $this->getDoctrine()->getManager();
                $em->remove($checkingData);
                $em->flush();
            }
            return; 
        }

        $imageFileCount = 0;
        $imageFileUsedCount = 0;
        $imageFileNameList = array();
        $imageFileUrlNameList = array();
        $imageFileFullPathList = array();

        $dir = opendir($directory);
        while(false !== ( $file = readdir($dir)) ) { 
            if (( $file != '.' ) && ( $file != '..' )) { 
                if ( !is_dir($directory . '/' . $file) ) { 
                    array_push($imageFileNameList,$file); 
                    array_push($imageFileUrlNameList,$url_base.'/'.$file);
                    array_push($imageFileFullPathList,$directory.'/'.$file);
                    $imageFileCount++;
                }   
            } 
        } 
        closedir($dir); 

        if ($imageFileCount > 0) {
            $LearnerRepository = $this->getDoctrine()->getRepository('AppBundle:Learner');
            $learner = $LearnerRepository->findOneBy([
                'hash' => $hash,
            ]);
            if ( !count($learner) ) {
                for ($count = 0; $count < $imageFileCount; $count++) {
                    unlink($imageFileFullPathList[$count]); }
                $imageFileUsedCount = 0;
            } else {
                $count = 0;
                for ($count = 0; $count < $imageFileCount; $count++) {
                    $imageFileTag = '<img src="' . $imageFileUrlNameList[0] . '">';
                    if ( (stripos($learner->getImage(), $imageFileNameList[0]) !== false) || (stripos($learner->getProfile(), $imageFileTag) !== false) || (stripos($learner->getSpecialNeeds(), $imageFileTag) !== false) || (stripos($learner->getAdditionalInformation(), $imageFileTag) !== false) ) {
                        $imageFileUsedCount++;
                    } else {
                        unlink($imageFileFullPathList[0]);
                    }
                    array_splice($imageFileNameList,0,1);
                    array_splice($imageFileUrlNameList,0,1);
                    array_splice($imageFileFullPathList,0,1);
                }
            }
        }

        if ( ($imageFileCount == 0) || ($imageFileUsedCount == 0) ) {
            rmdir($directory );
        }

        if ( !$isFromScheduledChecking ) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($checkingData);
            $em->flush();
        }
    }

    public function delete_Provider_UnusedCkEditorImageAction( $hash, bool $isFromScheduledChecking = false )
    {
        $checkingData = null;
        if ( !$isFromScheduledChecking ) {
            $ckeditorImageCheckingRepository = $this->getDoctrine()->getRepository('AppBundle:CkeditorImageChecking');
            $checkingData = $ckeditorImageCheckingRepository->findOneBy([
                'entity' => 'provider',
                'hash' => $hash,
            ]);
            if ( !count($checkingData) ) {
                return;
            }
        }

        $directory = realpath($this->getParameter('media_upload_destination'));
        $directory = $directory . "/provider/" . $hash;
        $url_base = $this->getParameter('media_uri_prefix');
        $url_base = $url_base . "/provider/" . $hash;

        if ( !file_exists($directory) || !is_dir($directory) ) {
            if ( !$isFromScheduledChecking ) {
                $em = $this->getDoctrine()->getManager();
                $em->remove($checkingData);
                $em->flush();
            }
            return; 
        }

        $imageFileCount = 0;
        $imageFileUsedCount = 0;
        $imageFileNameList = array();
        $imageFileUrlNameList = array();
        $imageFileFullPathList = array();

        $dir = opendir($directory);
        while(false !== ( $file = readdir($dir)) ) { 
            if (( $file != '.' ) && ( $file != '..' )) { 
                if ( !is_dir($directory . '/' . $file) ) { 
                    array_push($imageFileNameList,$file); 
                    array_push($imageFileUrlNameList,$url_base.'/'.$file);
                    array_push($imageFileFullPathList,$directory.'/'.$file);
                    $imageFileCount++;
                }   
            } 
        } 
        closedir($dir); 

        if ($imageFileCount > 0) {
            $ProviderRepository = $this->getDoctrine()->getRepository('AppBundle:Provider');
            $provider = $ProviderRepository->findOneBy([
                'hash' => $hash,
            ]);
            if ( !count($provider) ) {
                for ($count = 0; $count < $imageFileCount; $count++) {
                    unlink($imageFileFullPathList[$count]); }
                $imageFileUsedCount = 0;
            } else {
                $count = 0;
                for ($count = 0; $count < $imageFileCount; $count++) {
                    $imageFileTag = '<img src="' . $imageFileUrlNameList[0] . '">';
                    if ( (stripos($provider->getImage(), $imageFileNameList[0]) !== false) || (stripos($provider->getProfile(), $imageFileTag) !== false) || (stripos($provider->getAdditionalInformation(), $imageFileTag) !== false) ) {
                        $imageFileUsedCount++;
                    } else {
                        unlink($imageFileFullPathList[0]);
                    }
                    array_splice($imageFileNameList,0,1);
                    array_splice($imageFileUrlNameList,0,1);
                    array_splice($imageFileFullPathList,0,1);
                }
            }            
        }

        if ( ($imageFileCount == 0) || ($imageFileUsedCount == 0) ) {
            rmdir($directory );
        }

        if ( !$isFromScheduledChecking ) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($checkingData);
            $em->flush();
        }
    }

    public function add_CkEditorImageCheckingDataAction( $entity, $hash )
    {
        $ckeditorImageCheckingRepository = $this->getDoctrine()->getRepository('AppBundle:CkeditorImageChecking');
        $checkingData = $ckeditorImageCheckingRepository->findOneBy([
            'entity' => $entity,
            'hash' => $hash,
        ]);
        if ( !count($checkingData) ) {                
            $ckeditorImageChecking = new CkeditorImageChecking();
            $ckeditorImageChecking
                ->setEntity($entity)
                ->setHash($hash);
            $em = $this->getDoctrine()->getManager();    
            $em->persist($ckeditorImageChecking);
            $em->flush();
        }
    }

    /**
     * @Route("/member/checking/delete-unused-ckeditor-image-files", name="knoitall_delete_unused_ckeditor_image_files")
     */
    public function deleteUnusedCkeditorImageFilesAction( Request $request )
    {   
        $em = $this->getDoctrine()->getManager();
        $ckeditorImageCheckingRepository = $this->getDoctrine()->getRepository('AppBundle:CkeditorImageChecking');
        $checkingDatas = $ckeditorImageCheckingRepository->findAll();
        foreach( $checkingDatas as $checkingData ) {
            $entity = $checkingData->getEntity();
            $hash = $checkingData->getHash();
            switch ($entity) {
                case "event":
                    $this->delete_Event_UnusedCkEditorImageAction( $hash, true );
                    break;
                case "learner":
                    $this->delete_Learner_UnusedCkEditorImageAction( $hash, true );
                    break;
                case "provider":
                    $this->delete_Provider_UnusedCkEditorImageAction( $hash, true );
                    break;
            }            
            $em->remove($checkingData);
            $em->flush(); 
        }
        
        $logger = $this->get('logger');        
        $logger->err('🔔 Delete unused Ckeditor image files: ');

        return $this->render( ':default:empty.html.twig' );
    }
}
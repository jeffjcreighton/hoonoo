<?php

namespace AppBundle\Controller;

use AppBundle\Entity\User;
use AppBundle\Entity\Person;
use AppBundle\Entity\Learner;
use AppBundle\Entity\Provider;
use AppBundle\Form\LocationType;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use AppBundle\Entity\Location;

class LocationController extends Controller
{
    /**
     * Location - public view
     *
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @param $location \AppBundle\Entity\Location
     *
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/location/{id}", name="knoitall_location_public_view")
     * @ParamConverter("location", class="AppBundle:Location", isOptional="true")
     */
    public function publicViewAction( Request $request, Location $location = null )
    {
        /*
         * if the instructor profile is not published, then the proper hash (as querystring parameter) must be specified:
         */
        $hash = $request->get('hash');
        if ($hash != $location->getHash()) {
            throw $this->createNotFoundException('The location data does not exist');
        }

        /*
         * get a list of coordinates/labels for the google map api:
         * TODO: eliminate duplication locations (several events may possibly refer to the same location)
         */
        $geoLocations = [];
        if( $location ) {
            if( $location->getPublished() ) { 
                $geoLocations[] = [
                    'latitude' => $location->getLatitude(),
                    'longitude' => $location->getLongitude(),
                    'label' => $location->getName(),
                ];
            }
        }

        return $this->render( 'location/public_view.html.twig', [
            'location' => $location,
            'geoLocations' => $geoLocations,
        ] );
    }

    /**
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @param $provider \AppBundle\Entity\Provider
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/member/location/list", name="knoitall_location_list")
     */
    public function locationListAction( Request $request, Provider $provider = null )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();

        if( ! $provider ) {
            $providers = $user->getPerson()->getProviders();
            if( ! count($providers) ) {
                /* Create Provider Automatically */
                // $this->checkAndCreateProviderProfileAction();
                return $this->redirectToRoute('knoitall_provider_profile_wizard');
            }  
            $provider = $providers[0];
        }
   
        if( ! count($user->getPerson()->getLearners()) ) {
            return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
        }  

        $locationRepository = $this->getDoctrine()->getRepository('AppBundle:Location');
        $locationList = $locationRepository->findBy(array('provider' => $provider));        
        /*if ($this->isGranted('ROLE_ADMIN')) {
            $locations = $locationRepository->findAll(); 
        }
        else {*/
        return $this->render( ':location:list.html.twig', ['locationList' => $locationList] );
    }

    /**
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @param $Location \AppBundle\Entity\Location
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/member/location/{id}", name="knoitall_add_edit_location", defaults={"id" = null})
     * @ParamConverter("location", class="AppBundle\Entity\Location", isOptional="true")
     */
    public function locationAddEditAction( Request $request, Location $location = null )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        $providers = $user->getPerson()->getProviders();
        if( ! count($providers) ) {
            return $this->redirectToRoute('knoitall_provider_profile_wizard');
        }  
        $provider = $providers[0];
        
        if( ! count($user->getPerson()->getLearners()) ) {    
            return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
        }                      

        if( $location ) {
            if ($provider != $location->getProvider()) {
               return $this->render( ':custom_exception:error403.html.twig' ); 
            }
        }

        $isAddingLocation = false;
        if( ! $location ) {
            $location = new Location();
            $location->setProvider( $provider );

            $isAddingLocation = true;
        }

        if ($location->getLatitude() == null) {
            $location->setLatitude('32.7157331');
        }
        if ($location->getLongitude() == null) {
            $location->setLongitude('-117.1611485');
        }

        $locationRepository = $this->getDoctrine()->getRepository('AppBundle:Location');
        $locationList = $locationRepository->findBy(array('provider' => $provider));        
        $form = $this->createForm( LocationType::class, $location );

        $form->handleRequest($request);

        if( $form->isSubmitted() and $form->isValid() ) {
            /** @var Location $location */
            $location = $form->getData();
            $em = $this->getDoctrine()->getManager();
            $em->persist( $location );
            $em->flush();     
            $em->refresh( $location );       
            return $this->redirectToRoute('knoitall_add_edit_location', ['id' => $location->getId()]);
        }

        return $this->render( 'location/add_edit_location.html.twig', ['form' => $form->createView(), 'location' => $location, 'isAddingLocation' => $isAddingLocation, 'locationList' => $locationList
        ] );
    }

    /**
     * @Route("/member/location/remove/location", name="knoitall_location_remove_location")     
     */
    public function removeLocationAction(Request $request)
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        $data = null;
        if( $content = $request->getContent() ) {
            $data = json_decode( $content, true );
        }

        if( $data ) {
            $locationId = ( isset($data['location_id']) ? $data['location_id'] : null );         

            $locationRepository = $this->getDoctrine()->getRepository(Location::class);
            $location = ( isset($locationId) ? $locationRepository->find($locationId) : null );

            $user = $this->get('security.token_storage')->getToken()->getUser();
            $providers = $user->getPerson()->getProviders();

            $isUserProviderExist = false;
            if ( count($providers) ) {
                $provider = $providers[0];
                $isUserProviderExist = true;
            }

            $isAccessOtherUser = false;
            if( $location && $isUserProviderExist) {
                if ($provider != $location->getProvider()) {
                    $isAccessOtherUser = true;                
                }
            }

            $isAdminAccessOtherUser = false;
            if ( $this->get('security.authorization_checker')->isGranted('ROLE_ADMIN') )  {
                $isAdminAccessOtherUser = true;
            } 

            $isRemovePermitted = false;
            if (($isUserProviderExist && !$isAccessOtherUser) || 
                (!$isUserProviderExist && $isAdminAccessOtherUser) ||
                ($isAccessOtherUser && $isAdminAccessOtherUser)) {
               $isRemovePermitted = true;
            } 

            if ($location && $isRemovePermitted) {     
                if (count($location->getEvents())) {
                    $returnValues['locationIsUsed'] = 'true';
                } else {
                    $em = $this->getDoctrine()->getManager();
                    $em->remove($location);
                    $em->flush(); 
                    $returnValues['locationIsUsed'] = 'false';
                }
                
                $returnValues['status'] = 'OK';
                $response = new Response(json_encode($returnValues));
                $response->headers->set('Content-Type', 'application/json');
                return $response;
            }
        }
        $response = new Response(json_encode(['status' => 'ERROR']));
        $response->headers->set('Content-Type', 'application/json');
        return $response;            
    }
}

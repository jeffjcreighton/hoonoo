<?php

namespace AppBundle\Controller;

require_once __DIR__ . '/../../../vendor/autoload.php';

use AppBundle\Entity\Event;
use AppBundle\Entity\EventFormat;
use AppBundle\Entity\EventFormatSection;
use AppBundle\Entity\Provider;
use AppBundle\Entity\Taxonomy;
use AppBundle\Entity\Age;
use AppBundle\Entity\CkeditorImageChecking;
use AppBundle\Form\EventPostType;
use AppBundle\Form\EventType;
use AppBundle\Form\LearnerProfileWizardStep1Type;
use AppBundle\Form\LearnerProfileWizardStep2Type;
use AppBundle\Form\LearnerFindOtherProvidersWizardStep1Type;
use Doctrine\Common\Collections\ArrayCollection;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Form\Extension\Core\Type\ButtonType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Form;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\FormBuilderInterface;
use AppBundle\Entity\Learner;
use AppBundle\Form\LearnerType;
use AppBundle\Entity\User;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class LearnerController extends Controller
{
    /**
     * Learner profile - public view
     *
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @param $learner \AppBundle\Entity\Learner
     *
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/learner/{nickname}", name="knoitall_learner_public_profile")
     * @ParamConverter("learner", class="AppBundle:Learner", isOptional="true")
     */
    public function publicProfileAction( Request $request, Learner $learner = null )
    {
        /*
         * if the instructor profile is not published, then the proper hash (as querystring parameter) must be specified:
         */
        if ($learner) {
            if( ! $learner->getPublished() ) {
                $hash = $request->get('hash');
                if ($hash != $learner->getHash()) {
                    throw $this->createNotFoundException('The learner profile does not exist');
                }
            }
        }

        return $this->render( 'learner/public_profile.html.twig', ['learner' => $learner] );
    }

    /**
     * @Route("/member/learner/check/nickname", name="knoitall_learner_check_nickname")
     */
    public function learnerCheckNicknameAction( Request $request )
    {
        $data = null;
        if( $content = $request->getContent() ) {
            $data = json_decode( $content, true );
        }

        /** @var User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        $user_id = $user->getId();
        /** @var Learner $learner */
        $learner = $user->getPerson()->getLearners()[0];
        /** @var Provider $provider */

        $learner_id = ( isset($data['learner_id']) ? $data['learner_id'] : null );
        $nickname_input = ( isset($data['nickname_input']) ? $data['nickname_input'] : null );

        $learnerRepository = $this->getDoctrine()->getRepository(Learner::class);       
        //$otherLearner = strtolower($learnerRepository->findOneBy(['nickname' => $nickname_input]));
        $otherLearner = $learnerRepository->findOneBy(['nickname' => $nickname_input]);

        if( $otherLearner ) {
            $otherLearnerId = $otherLearner->getId();
            if ($otherLearnerId !== $learner_id) {
                $response = new Response(json_encode(['isExist' => true]));
                $response->headers->set('Content-Type', 'application/json');
                return $response;
            }
        }
        $response = new Response(json_encode(['isExist' => false]));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    public function createLearnerProfileAction()
    {
        /*$user = $this->get('security.token_storage')->getToken()->getUser(); 
        $person = $user->getPerson();
        if (($person->getFirstName()!="") || ($person->getLastName()!="")) {
            if ($person->getFirstName()!="") {
                $Title = $person->getFirstName();
                $Nickname = strtolower($person->getFirstName());
            }
            if ($person->getLastName()!="") {
                if ($person->getFirstName()!="") {
                    $Title = $Title . " " . $person->getLastName();    
                    $Nickname = $Nickname . "-" . strtolower($person->getLastName());
                }
                else {
                    $Title = $person->getLastName();
                    $Nickname = strtolower($person->getLastName());
                }
            }
        }
        else {
            $Title = $user->getEmail();
            $Nickname = strtolower($user->getEmail());
        }*/

        $user = $this->get('security.token_storage')->getToken()->getUser();
        $learner = new Learner();
        $person = $user->getPerson();
        $learner->setPerson( $person );
        $learner->SetTitle( $person->getFirstName() . " " . $person->getLastName() );
        $Nickname = strtolower($person->getFirstName()) . "-" . strtolower($person->getLastName());

        $suffix = 1;
        $NewNickname = $Nickname;
        $learnerRepository = $this->getDoctrine()->getRepository('AppBundle:Learner');
        $otherLearner = $learnerRepository->findOneBy(['nickname' => $Nickname]);
        while( $otherLearner ) {
            $NewNickname = $Nickname . "-" . $suffix;
            $otherLearner = $learnerRepository->findOneBy(['nickname' => $NewNickname]);
            $suffix++;
        }
        $learner->setNickname( $NewNickname ); 
        $learner->setPublished(true);
        
        $taxonomyRepository = $this->getDoctrine()->getRepository(Taxonomy::class);        
        $knoitallTaxonomy = $taxonomyRepository->find(4908); // Education:Knoitall
        $learner->addTaxonomy($knoitallTaxonomy);
        
        $ageRepository = $this->getDoctrine()->getRepository(Age::class);
        $defaultAges = $ageRepository->findBy(array('description' => array('Pre-teen','Teen','Adult')));
        foreach( $defaultAges as $age ) {
            $learner->addAge($age);
        }

        $em = $this->getDoctrine()->getManager();
        $em->persist($learner);
        $em->flush();
        $em->refresh($learner);

        $providerRepository = $this->getDoctrine()->getRepository(Provider::class);        
        $JeffCreightonClass = $providerRepository->findOneBy(['id' => 12858]);
        $requestContent = [
            'learner_id' => $learner->getId(),
            'provider_id' => $JeffCreightonClass->getId()
        ];

        $jsonRequest = json_encode($requestContent);

        $tempRequest = new Request(
            $_GET,
            $_POST,
            array(),
            $_COOKIE,
            $_FILES,
            $_SERVER,
            $jsonRequest
        );

        $this->forward('AppBundle:Feed:memberFeed', array(
            'request'  => $tempRequest,
            'action' => 'follow-provider',
        ));    

        $em->refresh($learner);
        return $learner;
    }


    public function checkAndCreateProviderProfileAction()
    {
        $user = $this->get('security.token_storage')->getToken()->getUser();

        $providers = $user->getPerson()->getProviders();        
        if( ! count($providers) ) {
            $provider = $this->forward('AppBundle:Provider:createProviderProfile');            
        } else {
            $provider = $providers[0];     
        }
        return $provider;
    }

    /**
     * @Route("/member/learner/profile", name="knoitall_learner_profile")
     */
    public function profileAction( Request $request, Learner $learner = null )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        
        $providers = $user->getPerson()->getProviders();
        if( ! count($providers) ) {
            /* Create Provider Automatically */
            // $this->checkAndCreateProviderProfileAction();
            return $this->redirectToRoute('knoitall_provider_profile_wizard');
        }  
        $provider = $providers[0];
        
        if( ! $learner ) {
            $learners = $user->getPerson()->getLearners();
            if( ! count($learners) ) {
                /* Create Learner Automatically */
                // $learner = $this->createLearnerProfileAction();
                return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
            }  
            $learner = $learners[0];
            // $this->forward('AppBundle:FileUpload:delete_Learner_UnusedCkEditorImage', [ 'hash' => $learner->getHash() ]);
        }
        $this->CheckAndFollow_SelfFollowerAction( $learner );        

        $form = $this->createForm( LearnerType::class, $learner );

        $form->handleRequest($request);

        if( $form->isSubmitted() and $form->isValid() ) {
            $learner = $form->getData();
            
            $validator = $this->get('validator');
            $errors = $validator->validate($learner);

            if (count($errors) == 0) {
                $em = $this->getDoctrine()->getEntityManager();
                $em->persist( $learner );
                $em->flush();

                $this->forward('AppBundle:FileUpload:add_CkEditorImageCheckingData', [ 'entity' => 'learner', 'hash' => $learner->getHash() ]);

                return $this->redirectToRoute('knoitall_learner_profile');
            }

            $data['errors'] = $errors;
        }
        
        $data['form'] = $form->createView();
        $data['learner'] = $learner;

        return $this->render( 'learner/profile.html.twig', $data );
    }

    /**
     * @param Provider $provider
     * @return boolean
     */
    public function checkIfProviderCanHaveLearner(Provider $provider)
    { 
        $canHaveLearner = false;
        $persons = $provider->getPersons();
        if (count($persons)) {
            $person = $persons[0];
            $learners = $person->getLearners();
            if (count($learners)) {
                $canHaveLearner = true;
            }
            else {
                if (($person->getFirstName()!="") || ($person->getLastName()!="") || ($person->getEmail()!="")) {
                    $canHaveLearner = true;
                }
            }
        }
        return $canHaveLearner;
    }

    /**
     * @param Learner $learner
     * @return Response
     *
     * @Route("/member/learner/self-follower", name="knoitall_learner_self_follower")
     */
    public function CheckAndFollow_SelfFollowerAction( Learner $learner )
    {
        if ($learner->getSelfFollower()) { 
            $em = $this->getDoctrine()->getManager();
            $learner_id = $learner->getId();

            $getstream_key = $this->getParameter('getstream_key');
            $getstream_secret = $this->getParameter('getstream_secret');
            $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );
            $learnerFeed = $client->feed('learner_feed', strval($learner_id));
            $learnerFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));            
            $learnerFeed->unfollowFeed('activity', strval($learner_id));
            $learner->setSelfFollower(false);
            $em->persist($learner);
            $em->flush();
            $em->refresh($learner);
        }
        return true;

        /*if (!$learner->getSelfFollower()) {
            $em = $this->getDoctrine()->getManager();
            $learner_id = $learner->getId();

            $getstream_key = $this->getParameter('getstream_key');
            $getstream_secret = $this->getParameter('getstream_secret');
            $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );
            $learnerFeed = $client->feed('learner_feed', strval($learner_id));
            $learnerFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));
            $learnerFeed->followFeed('activity', strval($learner_id));
            $learner->setSelfFollower(true);
            $em->persist($learner);
            $em->flush();
            $em->refresh($learner);
        }
        return true;*/
    }

    /**
     * @param Request $request
     * @return Response
     *
     * @Route("/member/learner/profile-wizard-step-1", name="knoitall_learner_profile_wizard_step_1")
     */
    public function learnerProfileWizardStep1Action( Request $request, Learner $learner = null )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();

        $providers = $user->getPerson()->getProviders();
        if( ! count($providers) ) {
            /* Create Provider Automatically */
            // $this->checkAndCreateProviderProfileAction();
            return $this->redirectToRoute('knoitall_provider_profile_wizard');
        }  
        $provider = $providers[0];

        if( ! $learner ) {
            $learners = $user->getPerson()->getLearners();
            if( ! count($learners) ) {
                $learner = new Learner();
                $person = $user->getPerson();
                $learner->setPerson( $person );
                $learner->SetTitle( $person->getFirstName() . " " . $person->getLastName() );
            } else {
                return $this->redirectToRoute('knoitall_learner_profile');
            } 
        }        

        /* Store Previous Followees data */
        /* $prevTaxonomies = null;        
        $_SESSION["prev_taxonomies_count"] = "";
        $prevTaxonomies = $learner->getTaxonomies();        
        if ($prevTaxonomies) {
            $_SESSION["prev_taxonomies_count"] = strval(count($prevTaxonomies)); 
            $tempCount = 0;
            foreach( $prevTaxonomies as $Taxonomy ) {
                $tempCount++;
                $_SESSION["prev_taxonomy_".strval($tempCount)] = strval($Taxonomy->getId());
            }
        } */       

        $taxonomyRepository = $this->getDoctrine()->getRepository(Taxonomy::class);
        $taxonomies = $taxonomyRepository->findBy(['inShortList' => true], ['level1' => 'ASC', 'level2' => 'ASC', 'level3' => 'ASC']);

        $form = $this->createForm( LearnerProfileWizardStep1Type::class, $learner );

        $form->handleRequest($request);

        if( $form->isSubmitted() and $form->isValid() ) {
            /** @var Learner $learner */
            $learner = $form->getData();

            $validator = $this->get('validator');
            $errors = $validator->validate($learner);

            if (count($errors) == 0) {  
                $taxonomyRepository = $this->getDoctrine()->getRepository(Taxonomy::class);

                $_SESSION["new_taxonomies_count"] = "";
                $taxonomyIds = $request->request->get('taxonomy');
                if( $taxonomyIds ) {                
                    $tempCount = 0;
                    $_SESSION["new_taxonomies_count"] = strval(count($taxonomyIds)); 
                    foreach( $taxonomyIds as $taxonomyId ) {
                    /* Store New Selected Taxonomies data */                
                        $tempCount++;
                        $_SESSION["new_taxonomy_".strval($tempCount)] = strval($taxonomyId);
                        // $taxonomy = $taxonomyRepository->find($taxonomyId);
                        // $learner->addTaxonomy($taxonomy);
                    }
                }            

                /* Get Previous Taxonomies & Followees data */
                /* $prevTaxonomies = new ArrayCollection();
                if ($_SESSION["prev_taxonomies_count"] != "") {
                    $countPrevTaxonomies = intval($_SESSION["prev_taxonomies_count"]);
                    for ($tempCount=1; $tempCount <= $countPrevTaxonomies; $tempCount++) {
                        $taxonomyId = $_SESSION["prev_taxonomy_".strval($tempCount)];
                        $prevTaxonomies->add($taxonomyRepository->find($taxonomyId));
                    }
                } 

                $currentTaxonomies = $learner->getTaxonomies();
                if (count($prevTaxonomies)) {
                    foreach( $prevTaxonomies as $Taxonomy ) {
                        if( ! $currentTaxonomies->contains($Taxonomy) ) {
                            $learner->addTaxonomy($Taxonomy);
                        }
                    }
                } */

                $Nickname = "";
                $string = strtolower($learner->getTitle());
                $tempNickname = strtok($string, " ");
                while ($tempNickname !== false) {
                    if ($Nickname !== "") {
                        $Nickname = $Nickname . "-";
                    }
                    $Nickname = $Nickname . $tempNickname;
                    $tempNickname = strtok(" ");
                }

                $suffix = 1;
                $NewNickname = $Nickname;
                $learnerRepository = $this->getDoctrine()->getRepository('AppBundle:Learner');
                $otherLearner = $learnerRepository->findOneBy(['nickname' => $Nickname]);
                while( $otherLearner ) {
                    $NewNickname = $Nickname . "-" . $suffix;
                    $otherLearner = $learnerRepository->findOneBy(['nickname' => $NewNickname]);
                    $suffix++;
                }
                $learner->setNickname( $NewNickname ); 
                $learner->setPublished(true);     

                $currentTaxonomies = $learner->getTaxonomies();
                $knoitallTaxonomy = $taxonomyRepository->find(4908); // Education:Knoitall
                if( ! $currentTaxonomies->contains($knoitallTaxonomy) ) {
                    $learner->addTaxonomy($knoitallTaxonomy);
                }

                $currentAges = $learner->getAges();
                if ( ! count($currentAges) ) {
                    $ageRepository = $this->getDoctrine()->getRepository(Age::class);
                    $defaultAges = $ageRepository->findBy(array('description' => array('Pre-teen','Teen','Adult')));
                    foreach( $defaultAges as $age ) {
                        if ( ! $currentAges->contains($age) ) {
                            $learner->addAge($age);
                        }                    
                    }
                }

                $em = $this->getDoctrine()->getManager();
                $em->persist($learner);
                $em->flush();
                $em->refresh($learner);

                $providerRepository = $this->getDoctrine()->getRepository(Provider::class);        
                $JeffCreightonClass = $providerRepository->findOneBy(['id' => 12858]);
                $requestContent = [
                    'learner_id' => $learner->getId(),
                    'provider_id' => $JeffCreightonClass->getId()
                ];

                $jsonRequest = json_encode($requestContent);
     
                $tempRequest = new Request(
                    $_GET,
                    $_POST,
                    array(),
                    $_COOKIE,
                    $_FILES,
                    $_SERVER,
                    $jsonRequest
                );

                $this->forward('AppBundle:Feed:memberFeed', array(
                    'request'  => $tempRequest,
                    'action' => 'follow-provider',
                ));    

                $em->refresh($learner);

                $this->CheckAndFollow_SelfFollowerAction( $learner );
 
                return $this->redirectToRoute('knoitall_learner_profile_wizard_step_2');
            }
            $data['errors'] = $errors;
        }

        $data['form'] = $form->createView();
        $data['learner'] = $learner;
        $data['taxonomies'] = $taxonomies;
        return $this->render( 'learner/profile_wizard_step_1.html.twig', $data );
    }

    /**
     * @param Request $request
     * @return Response
     *
     * @Route("/member/learner/find-other-providers-wizard-step-1", name="knoitall_learner_find_other_providers_wizard_step_1")
     */
    public function learnerFindOtherProvidersWizardStep1Action( Request $request, Learner $learner = null )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();

        $providers = $user->getPerson()->getProviders();
        if( ! count($providers) ) {
            /* Create Provider Automatically */
            // $this->checkAndCreateProviderProfileAction();
            return $this->redirectToRoute('knoitall_provider_profile_wizard');
        }  
        $provider = $providers[0];

        if( ! $learner ) {
            $learners = $user->getPerson()->getLearners();
            if( ! count($learners) ) {
                /* Create Learner Automatically */
                // $learner = $this->createLearnerProfileAction();
                return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
            }  
            $learner = $learners[0];
        }
        $this->CheckAndFollow_SelfFollowerAction( $learner );

        /* Store Previous Followees data */
        $prevTaxonomies = null;        
        $_SESSION["prev_taxonomies_count"] = "";
        $prevTaxonomies = $learner->getTaxonomies();        
        if ($prevTaxonomies) {
            $_SESSION["prev_taxonomies_count"] = strval(count($prevTaxonomies)); 
            $tempCount = 0;
            foreach( $prevTaxonomies as $Taxonomy ) {
                $tempCount++;
                $_SESSION["prev_taxonomy_".strval($tempCount)] = strval($Taxonomy->getId());
                $learner->removeTaxonomy($Taxonomy);
            }
        }        

        $taxonomyRepository = $this->getDoctrine()->getRepository(Taxonomy::class);
        $taxonomies = $taxonomyRepository->findBy(['inShortList' => true], ['level1' => 'ASC', 'level2' => 'ASC', 'level3' => 'ASC']);

        $form = $this->createForm( LearnerFindOtherProvidersWizardStep1Type::class, $learner );

        $form->handleRequest($request);

        if( $form->isSubmitted() and $form->isValid() ) {
            /** @var Learner $learner */
            $learner = $form->getData();
            $taxonomyRepository = $this->getDoctrine()->getRepository(Taxonomy::class);

            $_SESSION["new_taxonomies_count"] = "";
            $taxonomyIds = $request->request->get('taxonomy');
            if( $taxonomyIds ) {                
                $tempCount = 0;
                $_SESSION["new_taxonomies_count"] = strval(count($taxonomyIds)); 
                foreach( $taxonomyIds as $taxonomyId ) {
                /* Store New Selected Taxonomies data */                
                    $tempCount++;
                    $_SESSION["new_taxonomy_".strval($tempCount)] = strval($taxonomyId);
                    // $taxonomy = $taxonomyRepository->find($taxonomyId);
                    // $learner->addTaxonomy($taxonomy);
                }
            }            

            /* Get Previous Taxonomies & Followees data */
            $prevTaxonomies = new ArrayCollection();
            if ($_SESSION["prev_taxonomies_count"] != "") {
                $countPrevTaxonomies = intval($_SESSION["prev_taxonomies_count"]);
                for ($tempCount=1; $tempCount <= $countPrevTaxonomies; $tempCount++) {
                    $taxonomyId = $_SESSION["prev_taxonomy_".strval($tempCount)];
                    $prevTaxonomies->add($taxonomyRepository->find($taxonomyId));
                }
            }

            $currentTaxonomies = $learner->getTaxonomies();
            if (count($prevTaxonomies)) {
                foreach( $prevTaxonomies as $Taxonomy ) {
                    if( ! $currentTaxonomies->contains($Taxonomy) ) {
                        $learner->addTaxonomy($Taxonomy);
                    }
                }
            }

            $em = $this->getDoctrine()->getManager();
            $em->persist($learner);
            $em->flush();

            return $this->redirectToRoute('knoitall_learner_profile_wizard_step_2');
        }

        return $this->render('learner/find_other_providers_wizard_step_1.html.twig', [
            'form' => $form->createView(),
            'learner' => $learner,
            'taxonomies' => $taxonomies,
            'user' => $user,
        ]);
    }

    /**
     * @param Request $request
     * @return Response
     *
     * @Route("/member/learner/profile-wizard-step-2", name="knoitall_learner_profile_wizard_step_2")
     */
    public function learnerProfileWizardStep2Action( Request $request, Learner $learner = null )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();

        $providers = $user->getPerson()->getProviders();
        if( ! count($providers) ) {
            /* Create Provider Automatically */
            // $this->checkAndCreateProviderProfileAction();
            return $this->redirectToRoute('knoitall_provider_profile_wizard');
        }  
        $provider = $providers[0];

        if( ! $learner ) {
            $learners = $user->getPerson()->getLearners();
            if( ! count($learners) ) {
                /* Create Learner Automatically */
                // $learner = $this->createLearnerProfileAction();
                return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
            }  
            $learner = $learners[0];
        }
        $this->CheckAndFollow_SelfFollowerAction( $learner );

        $learner_Provider = $provider;
        
        $prevFollowees = null;
        $_SESSION["prev_followees_count"] = "";
        $prevFollowees = $learner->getFollowees();
        if ($prevFollowees) {
            $_SESSION["prev_followees_count"] = strval(count($prevFollowees)); 
            $tempCount = 0;
            foreach( $prevFollowees as $Followee ) {
                $tempCount++;
                $_SESSION["prev_followee_".strval($tempCount)] = strval($Followee->getId());
            }
        }

        $providers = new ArrayCollection();        
        $taxonomyRepository = $this->getDoctrine()->getRepository(Taxonomy::class);

        /* Get New Taxonomies data */
        $newTaxonomies = new ArrayCollection();
        if ( isset ($_SESSION["new_taxonomies_count"]) ) {
            if ($_SESSION["new_taxonomies_count"] != "") {
                $countNewTaxonomies = intval($_SESSION["new_taxonomies_count"]);
                for ($tempCount=1; $tempCount <= $countNewTaxonomies; $tempCount++) {
                    $taxonomyId = $_SESSION["new_taxonomy_".strval($tempCount)];
                    $newTaxonomies->add($taxonomyRepository->find($taxonomyId));
                }
            }
        }

        /** @var Taxonomy $taxonomy */
        foreach( $newTaxonomies as $taxonomy ) {
            $providersWithSpecifiedTaxonomy = $taxonomy->getProviders();
            foreach( $providersWithSpecifiedTaxonomy as $provider ) {
                if ( (!$providers->contains($provider)) && ($provider != $learner_Provider) ) {
                    if ($this->checkIfProviderCanHaveLearner($provider)) {
                        $providers->add($provider);
                    }
                }
            }
        }

        $form = $this->createForm( LearnerProfileWizardStep2Type::class, $learner );

        $form->handleRequest($request);

        if( $form->isSubmitted() and $form->isValid() ) {
            $learner = $form->getData();

            $providerRepository = $this->getDoctrine()->getRepository('AppBundle:Provider');
       
            $prevFollowees = new ArrayCollection();
            if ($_SESSION["prev_followees_count"] != "") {
                $countPrevFollowees = intval($_SESSION["prev_followees_count"]);
                for ($tempCount=1; $tempCount <= $countPrevFollowees; $tempCount++) {
                    $followeeId = $_SESSION["prev_followee_".strval($tempCount)];
                    $prevFollowees->add($providerRepository->find($followeeId));
                }
            }
            
            $providerIds = $request->request->get('providers');
            if( $providerIds ) {
                foreach( $providerIds as $providerId ) {
                    $provider = $providerRepository->find($providerId); 
                    $canFollowed = $this->checkIfProviderCanHaveLearner($provider);
                    
                    $needConnected = false;
                    if (count($prevFollowees)) {
                        if( ! $prevFollowees->contains($provider) ) {
                            //$learner->addFollowee($provider);
                            $needConnected = true;
                        }
                    } 
                    else {
                        //$learner->addFollowee($provider);
                        $needConnected = true;
                    }

                    $requestContent = [
                        'learner_id' => $learner->getId(),
                        'provider_id' => $provider->getId()
                    ];

                    $jsonRequest = json_encode($requestContent);

                    $tempRequest = new Request(
                        $_GET,
                        $_POST,
                        array(),
                        $_COOKIE,
                        $_FILES,
                        $_SERVER,
                        $jsonRequest
                    );

                    if (($canFollowed) && ($needConnected)) {
                        $this->forward('AppBundle:Feed:memberFeed', array(
                            'request'  => $tempRequest,
                            'action' => 'follow-provider',
                        ));        
                    }
                }
            }
          
            if ( $providerIds) {
                $currentTaxonomies = $learner->getTaxonomies();
                if (count($newTaxonomies)) {
                    foreach( $newTaxonomies as $Taxonomy ) {
                        if( ! $currentTaxonomies->contains($Taxonomy) ) {
                            $learner->addTaxonomy($Taxonomy);
                        }
                    }
                }
            }

            $currentFollowees = $learner->getFollowees();
            if (count($prevFollowees)) {
                foreach( $prevFollowees as $Followee ) {
                    if( ! $currentFollowees->contains($Followee) ) {
                        $learner->addFollowee($Followee);
                    }
                }
            }

            $em = $this->getDoctrine()->getManager();
            $em->persist($learner);
            $em->flush();

            $_SESSION["prev_taxonomies_count"] = "";
            $_SESSION["prev_followees_count"] = "";
            $_SESSION["new_taxonomies_count"] = "";

            return $this->redirectToRoute('knoitall_learner_profile_wizard_step_3');
            //return $this->redirectToRoute('knoitall_learner_profile');
        }

        return $this->render( 'learner/profile_wizard_step_2.html.twig', [
            'form' => $form->createView(),
            'learner' => $learner,
            'providers' => $providers,
        ] );
    }

    /**
     * @param Request $request
     * @return Response
     *
     * @Route("/member/learner/profile-wizard-step-3", name="knoitall_learner_profile_wizard_step_3")
     */
    public function learnerProfileWizardStep3Action( Request $request, Learner $learner = null )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        
        $providers = $user->getPerson()->getProviders();
        if( ! count($providers) ) {
            /* Create Provider Automatically */
            // $this->checkAndCreateProviderProfileAction();
            return $this->redirectToRoute('knoitall_provider_profile_wizard');
        }  
        $provider = $providers[0];

        if( ! $learner ) {
            $learners = $user->getPerson()->getLearners();
            if( ! count($learners) ) {
                /* Create Learner Automatically */
                // $learner = $this->createLearnerProfileAction();
                return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
            }  
            $learner = $learners[0];
        }
        $this->CheckAndFollow_SelfFollowerAction( $learner );

        $form = $this->get('form.factory')->createBuilder()
            ->add('email1', TextType::class, [
                'required' => false,
                'attr' => ['class' => 'form-control', 'placeholder' => 'Email'],
            ] )
            ->add('email2', TextType::class, [
                'required' => false,
                'attr' => ['class' => 'form-control', 'placeholder' => 'Email'],
            ] )
            ->add('email3', TextType::class, [
                'required' => false,
                'attr' => ['class' => 'form-control', 'placeholder' => 'Email'],
            ] )
            ->add('email4', TextType::class, [
                'required' => false,
                'attr' => ['class' => 'form-control', 'placeholder' => 'Email'],
            ] )
            ->add('submit', SubmitType::class, [
                'label' => 'Invite',
                'attr' => ['class' => 'btn btn-success'],
            ] )
            ->add('skip', ButtonType::class, [
                'label' => 'Skip',
                'attr' => ['class' => 'btn btn-default'],
            ])
            ->getForm()
        ;

        $form->handleRequest($request);

        if( $form->isSubmitted() and $form->isValid() ) {
            $data = $form->getData();

            //$nickname = $user->getNickname();

            foreach( ['email1', 'email2', 'email3', 'email4'] as $emailNo ) {               
                if (filter_var($data[$emailNo], FILTER_VALIDATE_EMAIL)) {
                /* if( $data[$emailNo] ) {
                    $mailserver_name = strtolower(substr($data[$emailNo],-12));
                    if ( (strtolower($data[$emailNo]) == 'ipdilaksana@yahoo.com') || ($mailserver_name == 'knoitall.com') ) { */
                        $message = \Swift_Message::newInstance()
                            ->setSubject("Knoitall - The World's Knowledge Network")
                            ->setFrom(['info@knoitall.com' => 'Knoitall'])
                            ->setTo($data[$emailNo])
                            ->setBody(
                                $this->renderView('email/invite.html.twig', ['learner' => $learner]) ,'text/html' );
                        $this->get('mailer')->send($message); 
                    // }
                }
            }
            return $this->redirectToRoute('default_security_target');
        }

        return $this->render( 'learner/profile_wizard_step_3.html.twig', [
            'form' => $form->createView(),
        ] );
    }

    /**
     * @param Request $request
     * @return Response
     *
     * @Route("/member/learner/invite-friends", name="knoitall_learner_invite_friends")
     */
    public function learnerProfileInviteFriendsAction( Request $request, Learner $learner = null )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        
        $providers = $user->getPerson()->getProviders();
        if( ! count($providers) ) {
            /* Create Provider Automatically */
            // $this->checkAndCreateProviderProfileAction();
            return $this->redirectToRoute('knoitall_provider_profile_wizard');
        }  
        $provider = $providers[0];

        if( ! $learner ) {
            $learners = $user->getPerson()->getLearners();
            if( ! count($learners) ) {
                /* Create Learner Automatically */
                // $learner = $this->createLearnerProfileAction();
                return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
            }  
            $learner = $learners[0];
        }
        $this->CheckAndFollow_SelfFollowerAction( $learner );

        $form = $this->get('form.factory')->createBuilder()
            ->add('email1', TextType::class, [
                'required' => false,
                'attr' => ['class' => 'form-control', 'placeholder' => 'Email'],
            ] )
            ->add('email2', TextType::class, [
                'required' => false,
                'attr' => ['class' => 'form-control', 'placeholder' => 'Email'],
            ] )
            ->add('email3', TextType::class, [
                'required' => false,
                'attr' => ['class' => 'form-control', 'placeholder' => 'Email'],
            ] )
            ->add('email4', TextType::class, [
                'required' => false,
                'attr' => ['class' => 'form-control', 'placeholder' => 'Email'],
            ] )
            ->add('submit', SubmitType::class, [
                'label' => 'Invite',
                'attr' => ['class' => 'btn btn-success'],
            ] )
            ->add('skip', ButtonType::class, [
                'label' => 'Skip',
                'attr' => ['class' => 'btn btn-default'],
            ])
            ->getForm()
        ;

        $form->handleRequest($request);

        if( $form->isSubmitted() and $form->isValid() ) {
            $data = $form->getData();

            //$nickname = $user->getNickname();

            foreach( ['email1', 'email2', 'email3', 'email4'] as $emailNo ) {               
                if (filter_var($data[$emailNo], FILTER_VALIDATE_EMAIL)) {
                /* if( $data[$emailNo] ) {
                    $mailserver_name = strtolower(substr($data[$emailNo],-12));
                    if ( (strtolower($data[$emailNo]) == 'ipdilaksana@yahoo.com') || ($mailserver_name == 'knoitall.com') ) { */
                        $message = \Swift_Message::newInstance()
                            ->setSubject("Knoitall - The World's Knowledge Network")
                            ->setFrom(['info@knoitall.com' => 'Knoitall'])
                            ->setTo($data[$emailNo])
                            ->setBody(
                                $this->renderView('email/invite.html.twig', ['learner' => $learner]) ,'text/html' );
                        $this->get('mailer')->send($message); 
                    // }
                }
            }
            return $this->redirectToRoute('knoitall_learner_profile');
        }

        return $this->render( 'learner/profile_wizard_step_3.html.twig', [
            'form' => $form->createView(),
        ] );
    }

    /**
     * @Route("/member/learner/interests", name="knoitall_learner_interests")
     */
    public function interestsAction( Learner $learner = null )
    {
        throw $this->createNotFoundException('The page does not exist');
    }

    /**
     * @Route("/member/learner/providers", name="knoitall_learner_providers")
     */
    public function providersAction( Learner $learner = null )
    {
        throw $this->createNotFoundException('The page does not exist');

    }

    /**
     * @Route("/member/learner/transcripts", name="knoitall_learner_transcripts")
     */
    public function transcriptsAction( Learner $learner = null )
    {        
        throw $this->createNotFoundException('The page does not exist');
    }

    /**
     * @param $learner
     * @return \HttpResponse
     */
    public function gridItemAction( $learner )
    {
        return $this->render( ':learner:grid_item.html.twig', ['learner' => $learner]);
    }

    /**
     * @Route("/member/learner/feed", name="knoitall_learner_feed")
     */
    public function learnerFeedAction( Request $request, Learner $learner = null )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();

        $providers = $user->getPerson()->getProviders();
        if( ! count($providers) ) {
            /* Create Provider Automatically */
            // $this->checkAndCreateProviderProfileAction();
            return $this->redirectToRoute('knoitall_provider_profile_wizard');
        }  
        $provider = $providers[0];

        if( ! $learner ) {
            $learners = $user->getPerson()->getLearners();
            if( ! count($learners) ) {
                /* Create Learner Automatically */
                // $learner = $this->createLearnerProfileAction();
                return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
            }  
            $learner = $learners[0];
        }
        $this->CheckAndFollow_SelfFollowerAction( $learner );

        $eventFormatRepository = $this->getDoctrine()->getRepository(EventFormat::class);
        $eventFormatSectionRepository = $this->getDoctrine()->getRepository(EventFormatSection::class);

        $eventFormatSectionResource = $eventFormatSectionRepository->findOneBy(['code' => 'resources']);
        $eventFormatPost = $eventFormatRepository->findOneBy(['code' => 'resources']);

        $eventPost = new Event();
        $eventPostForm = $this->createForm(EventPostType::class, $eventPost, [
            'eventFormatSection' => $eventFormatSectionResource,
            'eventFormats' => [$eventFormatPost],
        ] );

//        $eventItem = new Event();
//        $eventItemForm = $this->createForm(EventType::class, $eventItem );

        $eventPostForm->handleRequest($request);
//        $eventItemForm->handleRequest($request);

        if( $eventPostForm->isSubmitted() ) {
            if( $eventPostForm->isValid() ) {
                /** @var Event $eventPost */
                $eventPost = $eventPostForm->getData();

                $providers = $learner->getPerson()->getProviders();
                if( isset($providers[0]) ) {
                    $provider = $providers[0];
                } else {
                    $provider = new Provider();
                    $provider->addPerson($learner->getPerson());
                    $learner->getPerson()->addProvider($provider);
                    $em->persist($provider);
                    $em->persist($learner);
                }
                $eventPost->setProvider($provider);

                $em = $this->getDoctrine()->getManager();
                $em->persist($eventPost);
                $em->flush();

                return $this->redirectToRoute('knoitall_provider_profile');
            }
        }

        /*
         * get feed items to display:
         */
        $getstream_key = $this->getParameter('getstream_key');
        $getstream_secret = $this->getParameter('getstream_secret');
        $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );

        $learnerFeed = $client->feed("Learners", $learner->getId() );
        $learnerFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));
        $feedActivities = $learnerFeed->getActivities();

        return $this->render( 'learner/learner_feed.html.twig', [
            'learner' => $learner,
            'eventPostForm' => $eventPostForm->createView(),
//            'eventItemForm' => $eventItemForm->createView(),
            'feedActivities' => $feedActivities['results'],
        ] );
    }
}

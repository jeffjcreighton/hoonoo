<?php

namespace AppBundle\Controller;

require_once __DIR__ . '/../../../vendor/autoload.php';

use AppBundle\Entity\Event;
use AppBundle\Entity\EventFormatSection;
use AppBundle\Entity\Location;
use AppBundle\Entity\Learner;
use AppBundle\Form\ProviderType;
use AppBundle\Form\ProviderProfileWizardType;
use Doctrine\Common\Collections\ArrayCollection;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use AppBundle\Entity\Provider;
use AppBundle\Entity\CkeditorImageChecking;

class ProviderController extends Controller
{
    /**
     * Learning center public view
     *
     * @Route("/provider/{nickname}", name="knoitall_provider_public_profile")
     * @ParamConverter("provider", class="AppBundle:Provider", isOptional="true")
     */
    public function publicProfileAction( Request $request, Provider $provider=null )
    {
        /*
         * if the instructor profile is not published, then the proper hash (as querystring parameter) must be specified:
         */
        if ($provider) {
            if( ! $provider->getPublished() ) {
                $hash = $request->get('hash');
                if ($hash != $provider->getHash()) {
                    throw $this->createNotFoundException('The provider profile is not published');
                }
            }
        }

        /*
         * make sure that learner exists, creating it if not:
         */
        $sameProvider = false;
        if( $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            /** @var \AppBundle\Entity\User $user */
            $user = $this->get('security.token_storage')->getToken()->getUser();

            if( ! count($user->getPerson()->getProviders()) ) {    
                return $this->redirectToRoute('knoitall_provider_profile_wizard');
            }
            $userProvider = $user->getPerson()->getProviders()[0];
            if( $userProvider == $provider ) {
                $sameProvider = true; }         

            // if( ! isset($user->getPerson()->getLearners()[0]) ) {
            if( ! count($user->getPerson()->getLearners()) ) {    
                // $learner = $this->forward('AppBundle:Learner:createLearnerProfile');
                return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
            }

            /*$Followees = $learner->getFollowees();
            $AlreadyFollowed = false;
            foreach( $Followees as $followee ) {
                if ( $followee == $provider ) {
                    $alreadyFollowed = true;
                }
            }*/
        }

        $allProviderEvents = $provider->getEvents();

        /*
         * get a list of event format sections:
         */
        $eventFormatSections = [];
        /** @var Event $event */
        foreach( $allProviderEvents as $event ) {
            if( ! in_array($event->getEventFormat()->getEventFormatSection(), $eventFormatSections) ) {
                $eventFormatSections[] = $event->getEventFormat()->getEventFormatSection();
            }
        }

        /*
         * in addition to the taxonomies explicitly declared for this provider, also include the taxonomies
         * referenced by events in the learning center:
         */
        $taxonomies = $provider->getTaxonomies();
        /** @var Event $event */
        foreach( $allProviderEvents as $event ) {
            foreach( $event->getTaxonomies() as $eventTaxonomy ) {
                if( !$taxonomies->contains($eventTaxonomy) ) {
                    $taxonomies->add($eventTaxonomy);
                }
            }
        }

        if( $request->query->get('event-format-section') ) {
            $eventFormatSectionRepository = $this->getDoctrine()->getRepository(EventFormatSection::class);
            $currentEventFormatSection = $eventFormatSectionRepository->findOneBy(['slug' => $request->query->get('event-format-section')]);
        } else {
            $currentEventFormatSection = null;
        }

        $eventRepository = $this->getDoctrine()->getRepository(Event::class);
        $eventsQuery = $eventRepository->findAllHavingProviderQuery($provider, $currentEventFormatSection);

        $paginator = $this->get('knp_paginator');
        $pagination = $paginator->paginate(
            $eventsQuery,
            $request->get('page', 1),
            10
        );

        /*
         * get a list of coordinates/labels for the google map api:
         * TODO: eliminate duplication locations (several events may possibly refer to the same location)
         */
        $geoLocations = [];
        /** @var Location $location */
        foreach( $provider->getLocations() as $location ) {
            if( $location->getLatitude() != 0 and $location->getLongitude() != 0 ) {
                $geoLocations[] = [
                    'latitude' => $location->getLatitude(),
                    'longitude' => $location->getLongitude(),
                    'label' => $location->getName(),
                ];
            }
        }
        /** @var Event $event */
        foreach( $allProviderEvents as $event ) {
            $location = $event->getLocation(); 
            if( $location ) {
                /* Doing Nothing */
            } else {
                if( $event->getLocationLatitude() != 0 and $event->getLocationLongitude() != 0 ) {
                    $geoLocations[] = [
                        'latitude' => $event->getLocationLatitude(),
                        'longitude' => $event->getLocationLongitude(),
                        'label' => ( $event->getLocationName() ? $event->getLocationName() : $event->getTitle() ),
                    ];
                }
            }
        }

        /*
         * get followers:
         */
        /*$getstream_key = $this->getParameter('getstream_key');
        $getstream_secret = $this->getParameter('getstream_secret');
        $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );*/
        /*$providerFeed = $client->feed('Providers', $provider->getId());
        $providerFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));
        $followers = $providerFeed->followers();

        $xFollowers = [];
        $learnerRepository = $this->getDoctrine()->getRepository(Learner::class);
        foreach( $followers['results'] as $follower ) {
            $matches = [];
            if( preg_match("/^Learners:(\d+)$/", $follower['feed_id'], $matches) ) {
                $learnerId = $matches[1];
                $xFollower = $learnerRepository->find($learnerId);
                $xFollowers[] = $xFollower;
            }
        }*/

        $canFollowed = "false";
        $persons = $provider->getPersons();               
        if (count($persons)) {
            $person = $persons[0];
            $learners = $person->getLearners();
            if (count($learners)) {
                $canFollowed = "true";
            }
            else {
                if (($person->getFirstName()!="") || ($person->getLastName()!="") ||
                    ($person->getEmail()!="")) {
                    $canFollowed = "true";
                }
            }
        }

        return $this->render( 'provider/public_profile.html.twig', [
            'provider' => $provider,
            'events' => $pagination, // $events,
            'eventFormatSections' => $eventFormatSections,
            'currentEventFormatSection' => $currentEventFormatSection,
            'taxonomies' => $taxonomies,
            'geoLocations' => $geoLocations,
            //'followers' => $xFollowers,
            'sameProvider' => $sameProvider,
            'canFollowed' => $canFollowed,
            //'alreadyFollowed' => $alreadyFollowed,
        ] );
    }

    /**
     * @Route("/member/provider/send_share_email", name="knoitall_provider_send_share_email")
     */
    public function providerSendShareEmailAction( Request $request )
    {
        $data = null;
        if( $content = $request->getContent() ) {
            $data = json_decode( $content, true );
        }

        $provider_id = ( isset($data['provider_id']) ? $data['provider_id'] : null );
        $nickname_input = ( isset($data['nickname_input']) ? $data['nickname_input'] : null );

        $sendTo = ( isset($data['send_To']) ? $data['send_To'] : null );
        $sendFrom = ( isset($data['send_From']) ? $data['send_From'] : null );
        $emailSubject = ( isset($data['email_Subject']) ? $data['email_Subject'] : null );
        $emailText = ( isset($data['email_Text']) ? $data['email_Text'] : null );

        $isSuccess = false;
        $isRecipientValid = true;
        $isSenderValid = true;
        if (!filter_var($sendTo, FILTER_VALIDATE_EMAIL)) {
            $isRecipientValid = false;
        }
        if (!filter_var($sendFrom, FILTER_VALIDATE_EMAIL)) {
            $isSenderValid = false;
        }
        if ((filter_var($sendTo, FILTER_VALIDATE_EMAIL)) && (filter_var($sendFrom, FILTER_VALIDATE_EMAIL))) {
            $message = \Swift_Message::newInstance()
                ->setSubject($emailSubject)
                ->setFrom($sendFrom)
                ->setTo($sendTo)
                ->setBody($emailText);
            $this->get('mailer')->send($message); 

            $isSuccess = true;
            $isSenderValid = true;
            $isRecipientValid = true;
        }

        $returnValues = [                    
            'isSenderValid' => $isSenderValid,
            'isRecipientValid' => $isRecipientValid,
            'isSuccess' => $isSuccess
        ]; 

        $returnValues['status'] = 'OK';
        $response = new Response(json_encode($returnValues));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    /**
     * @Route("/member/provider/check/nickname", name="knoitall_provider_check_nickname")
     */
    public function providerCheckNicknameAction( Request $request )
    {
        $data = null;
        if( $content = $request->getContent() ) {
            $data = json_decode( $content, true );
        }

        /** @var User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        $user_id = $user->getId();
        /** @var Provider $provider */
        $provider = $user->getPerson()->getProviders()[0];
        /** @var Learner $learner */

        $provider_id = ( isset($data['provider_id']) ? $data['provider_id'] : null );
        $nickname_input = ( isset($data['nickname_input']) ? $data['nickname_input'] : null );

        $providerRepository = $this->getDoctrine()->getRepository(Provider::class);
        //$otherProvider = strtolower($providerRepository->findOneBy(['nickname' => $nickname_input]));
        $otherProvider = $providerRepository->findOneBy(['nickname' => $nickname_input]);

        if( $otherProvider ) {
            $otherProviderId = $otherProvider->getId();
            if ($otherProviderId !== $provider_id) {
                $response = new Response(json_encode(['isExist' => true]));
                $response->headers->set('Content-Type', 'application/json');
                return $response;
            }
        }
        $response = new Response(json_encode(['isExist' => false]));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    public function createProviderProfileAction()
    {
        $user = $this->get('security.token_storage')->getToken()->getUser();
        $provider = new Provider();
        $person = $user->getPerson();
        $provider->addPerson( $person );

        $em = $this->getDoctrine()->getEntityManager();
        
        // Old user data don't have nickname, create from user name
        if ($user->getNickname() == "") {
            $tempNickname = $person->getFirstName() . " " . $person->getLastName() . " Classroom";
            $user->setNickname($tempNickname);
            $em->persist($user);
            $em->flush();
            $em->refresh($user);
        } 

        $Nickname = "";
        $string = strtolower($user->getNickname());
        $tempNickname = strtok($string, " ");
        while ($tempNickname !== false) {
            if ($Nickname !== "") {
                $Nickname = $Nickname . "-";
            }
            $Nickname = $Nickname . $tempNickname;
            $tempNickname = strtok(" ");
        }

        $suffix = 1;
        $NewNickname = $Nickname;                
        $providerRepository = $this->getDoctrine()->getRepository('AppBundle:Provider');
        $otherProvider = $providerRepository->findOneBy(['nickname' => $Nickname]);
        while( $otherProvider ) {
            $NewNickname = $Nickname . "-" . $suffix;
            $otherProvider = $providerRepository->findOneBy(['nickname' => $NewNickname]);
            $suffix++;
        }
        $provider->setNickname( $NewNickname ); 
        $provider->SetTitle( $user->getNickname() );
        $provider->setPublished(true);

        $em->persist($provider);
        $em->flush();
        $em->refresh($provider);
        return $provider;
    }

    /**
     * Show/edit the learning center profile
     *
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @param $provider \AppBundle\Entity\Provider
     *
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/member/provider/profile", name="knoitall_provider_profile")
     */
    public function profileAction( Request $request, Provider $provider = null )
    {        
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();

        if( ! $provider ) {
            /* TODO: either allow the user to select which learning center to edit or get the current learning center from the session */
            $providers = $user->getPerson()->getProviders();
            if( ! count($providers) ) {
                /* Create Provider Automatically */
                // $this->checkAndCreateProviderProfileAction();
                return $this->redirectToRoute('knoitall_provider_profile_wizard');
            }  
            $provider = $providers[0];
            // $this->forward('AppBundle:FileUpload:delete_Provider_UnusedCkEditorImage', [ 'hash' => $provider->getHash() ]);
        }

        /* Get Learner Name */
        $learners = $user->getPerson()->getLearners();
        if( ! count($learners) ) {
            /* Create Learner Automatically */
            // $learner = $this->createLearnerProfileAction();
            return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
        }  
        $learner = $learners[0];
        $learnerName = $learner->getTitle();        

        $form = $this->createForm( ProviderType::class, $provider );

        $form->handleRequest($request);

        if( $form->isSubmitted() and $form->isValid() ) {
            $provider = $form->getData();

            $validator = $this->get('validator');
            $errors = $validator->validate($provider);

            if (count($errors) == 0) {
                $em = $this->getDoctrine()->getEntityManager();
                $em->persist( $provider );
                $em->flush();

                $this->forward('AppBundle:FileUpload:add_CkEditorImageCheckingData', [ 'entity' => 'provider', 'hash' => $provider->getHash() ]); 

                return $this->redirectToRoute( 'knoitall_provider_profile', ['nickname' => $provider->getNickname()] );    
            }
            $data['errors'] = $errors;
        }

        $data['form'] = $form->createView();
        $data['provider'] = $provider;
        $data['learnerName'] = $learnerName;
        return $this->render( 'provider/profile.html.twig', $data);

        /*$nickname1 = 'aaa' . $user->getFirstname();
        return $this->render( 'provider/profile.html.twig', [
            'form' => $form->createView(),
            'provider' => $provider,
            'nickname1' => $nickname1,
        ]);*/
    }

    /**
     * @param Request $request
     * @return Response
     *
     * @Route("/member/provider/profile-wizard", name="knoitall_provider_profile_wizard")
     */
    public function providerProfileWizardAction( Request $request, Provider $provider = null )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();        
        if( ! $provider ) {
            $providers = $user->getPerson()->getProviders();            
            if( ! count($providers) ) {
                $provider = new Provider();
                $person = $user->getPerson();
                $provider->addPerson( $person );                
                $provider->setTitle($user->getNickname());
            } else {
                return $this->redirectToRoute('knoitall_provider_profile');
            } 
        }

        $taxonomyRepository = $this->getDoctrine()->getRepository('AppBundle:Taxonomy');
        $taxonomies = $taxonomyRepository->findBy(['inShortList' => true], ['level1' => 'ASC', 'level2' => 'ASC', 'level3' => 'ASC']);

        $form = $this->createForm( ProviderProfileWizardType::class, $provider );

        $form->handleRequest($request);

        if( $form->isSubmitted() and $form->isValid() ) {
            /** @var Learner $learner */
            $provider = $form->getData();

            $validator = $this->get('validator');
            $errors = $validator->validate($provider);

            if (count($errors) == 0) {
                $em = $this->getDoctrine()->getManager(); 
                if ($user->getNickname() == "") {
                    $user->setNickname($provider->getTitle());
                    $em->persist($user);
                    $em->flush();
                    $em->refresh($user);
                }
                $Nickname = "";
                $string = strtolower($provider->getTitle());
                $tempNickname = strtok($string, " ");
                while ($tempNickname !== false) {
                    if ($Nickname !== "") {
                        $Nickname = $Nickname . "-";
                    }
                    $Nickname = $Nickname . $tempNickname;
                    $tempNickname = strtok(" ");
                }

                $suffix = 1;
                $NewNickname = $Nickname;                
                $providerRepository = $this->getDoctrine()->getRepository('AppBundle:Provider');
                $otherProvider = $providerRepository->findOneBy(['nickname' => $Nickname]);
                while( $otherProvider ) {
                    $NewNickname = $Nickname . "-" . $suffix;
                    $otherProvider = $providerRepository->findOneBy(['nickname' => $NewNickname]);
                    $suffix++;
                }
                $provider->setNickname( $NewNickname ); 
                // $provider->SetTitle( $user->getNickname() );
                $provider->setPublished(true);

                $em->persist($provider);
                $em->flush();
                $em->refresh($provider);

                return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
            }
            $data['errors'] = $errors;
        }

        $data['form'] = $form->createView();
        $data['provider'] = $provider;
        $data['taxonomies'] = $taxonomies;
        return $this->render( 'provider/profile_wizard.html.twig', $data);
    }

    /**
     * Show/edit consumers associated with a learning center
     *
     * @param Request $request
     * @return Response
     * @Route("/member/provider/consumers", name="knoitall_provider_consumers")
     */
    public function consumersAction(Request $request)
    {
        return $this->render('under_construction.html.twig');
    }

    /**
     * Show/edit the learning center profile
     *
     * @param Request $request
     * @return Response
     * @Route("/member/provider/suppliers", name="knoitall_provider_suppliers")
     */
    public function suppliersAction(Request $request)
    {
        return $this->render('under_construction.html.twig');
    }

    /**
     * Show/edit locations associated with a learning center
     *
     * @param Request $request
     * @return Response
     * @Route("/member/provider/locations", name="knoitall_provider_locations")
     */
    public function locationsAction(Request $request)
    {
        return $this->render('under_construction.html.twig');
    }

    /**
     * Show/edit advisors associated with a learning center
     *
     * @param Request $request
     * @return Response
     * @Route("/member/provider/advisors", name="knoitall_provider_advisors")
     */
    public function advisorsAction(Request $request)
    {
        return $this->render('under_construction.html.twig');
    }

    /**
     * Show/edit instructors associated with a learning center
     *
     * @param Request $request
     * @return Response
     * @Route("/member/provider/instructors", name="knoitall_provider_instructors")
     */
    public function instructorsAction(Request $request)
    {
        return $this->render('under_construction.html.twig');
    }

    /**
     * Show/edit existing listings
     *
     * @param Request $request
     * @param Provider $provider
     *
     * @return Response
     *
     * @Route("/member/provider/listings", name="knoitall_provider_listings")
     */
    public function listingsAction(Request $request, Provider $provider = null )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();

        if( ! $provider ) {
            $providers = $user->getPerson()->getProviders();
            if( ! count($providers) ) {
                /* Create Provider Automatically */
                // $this->checkAndCreateProviderProfileAction();
                return $this->redirectToRoute('knoitall_provider_profile_wizard');
            }
        }  
        $provider = $providers[0];

        $events = $provider->getEvents();

        return $this->render('provider/listings.html.twig', ['events' => $events]);
    }

    /**
     * @param $provider
     * @return \HttpResponse
     */
    public function gridItemAction( $provider )
    {
        return $this->render( ':provider:grid_item.html.twig', ['provider' => $provider]);
    }

    /**
     * @Route("/member/provider/feed/activities", name="knoitall_provider_feed_activities")
     */
    public function providerFeedActivitiesAction()
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        $providers = $user->getPerson()->getProviders();
        if( ! count($providers) ) {
            /* Create Provider Automatically */
            // $this->checkAndCreateProviderProfileAction();
            return $this->redirectToRoute('knoitall_provider_profile_wizard');
        }  
        $provider = $providers[0];

        $getstream_key = $this->getParameter('getstream_key');
        $getstream_secret = $this->getParameter('getstream_secret');
        $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );

        /*$providerFeed = $client->feed('Providers', $provider->getId());
        $providerFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));
        $activities = $providerFeed->getActivities();

        return $this->render('provider/feed_activities.html.twig', ['activities' => $activities]);*/
    }

    /**
     * @Route("/member/provider/feed/followers", name="knoitall_provider_feed_followers")
     */
    public function providerFollowersAction()
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        $providers = $user->getPerson()->getProviders();
        if( ! count($providers) ) {
            /* Create Provider Automatically */
            // $this->checkAndCreateProviderProfileAction();
            return $this->redirectToRoute('knoitall_provider_profile_wizard');
        }  
        $provider = $providers[0];

        $getstream_key = $this->getParameter('getstream_key');
        $getstream_secret = $this->getParameter('getstream_secret');
        $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );

        /*$providerFeed = $client->feed('Providers', $provider->getId());
        $providerFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));
        $followers = $providerFeed->followers();

        return $this->render('provider/feed_followers.html.twig', ['followers' => $followers]);*/
    }
}

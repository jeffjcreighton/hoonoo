<?php

namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use AppBundle\Entity\Tag;

class TagController extends Controller
{
    /**
     * @return Response
     *
     * @Route("/admin/tag-store", name="knoitall_tag_store")
     */
    public function storeAction(Request $request)
    {
        $action = $request->get('action');
        $text = $request->get('text');

        if ($action == 'add') {
            $tag = new Tag();
            $tag->set($text);

            $em = $this->getDoctrine()->getEntityManager();
            $em->persist($tag);
            $em->flush();
        }

        return new Response('OK');
    }
}

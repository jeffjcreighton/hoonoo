<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use AppBundle\Entity\Instructor;
use AppBundle\Form\InstructorType;

class InstructorController extends Controller
{
    /**
     * Instructor profile: public view
     *
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @param $instructor \AppBundle\Entity\Instructor
     *
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/instructor/{nickname}", name="knoitall_instructor_public_profile")
     * @ParamConverter("instructor", class="AppBundle:Instructor", isOptional="true")
     */
    public function publicProfileAction( Request $request, Instructor $instructor = null )
    {
        /*
         * if the instructor profile is not published, then the proper hash (as querystring parameter) must be specified:
         */
        if ($instructor) {
            if( ! $instructor->getPublished() ) {
                $hash = $request->get('hash');
                if ($hash != $instructor->getHash()) {
                    throw $this->createNotFoundException('The instructor profile does not exist');
                }
            }
        }

        return $this->render( 'instructor/public_profile.html.twig', ['instructor' => $instructor] );
    }

    /**
     * Instructor profile: user admin
     *
     * @Route("/member/instructor/profile", name="knoitall_instructor_profile")
     */
    public function profileAction( Request $request, Instructor $instructor = null )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }
        
        /** @var \AppBundle\Entity\User $user */
        /* $user = $this->get('security.token_storage')->getToken()->getUser();

        if( ! $instructor ) {
            $instructorRepository = $this->getDoctrine()->getRepository('AppBundle:Instructor');
            $instructor = $instructorRepository->findOneBy( ['person' => $user->getPerson()] );
            if( ! $instructor ) {
                $instructor = new Instructor();
                $instructor->setPerson( $user->getPerson() );
            }
        }

        $form = $this->createForm( InstructorType::class, $instructor );

        $form->handleRequest($request);

        if( $form->isSubmitted() and $form->isValid() ) {
            $learner = $form->getData();
            $em = $this->getDoctrine()->getEntityManager();
            $em->persist( $learner );
            $em->flush();
            return $this->redirectToRoute('knoitall_instructor_profile');
        }

        return $this->render( 'instructor/profile.html.twig', ['form' => $form->createView(), 'instructor' => $instructor] ); */
    }

    /**
     * @param $instructor
     * @return \HttpResponse
     */
    public function gridItemAction( $instructor )
    {
        return $this->render( ':instructor:grid_item.html.twig', ['instructor' => $instructor]);
    }
}

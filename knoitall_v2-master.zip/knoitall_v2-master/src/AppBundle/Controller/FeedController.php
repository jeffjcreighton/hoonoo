<?php

namespace AppBundle\Controller;

require_once __DIR__ . '/../../../vendor/autoload.php';

use AppBundle\Entity\FeedCommentEvent;
use AppBundle\Entity\FeedFollowProvider;
use AppBundle\Entity\FeedLikeEvent;
use AppBundle\Entity\FeedShareEvent;
use AppBundle\Entity\FeedAddPostEvent;
use AppBundle\Entity\CkeditorImageChecking;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use AppBundle\Entity\User;
use AppBundle\Entity\Person;
use AppBundle\Entity\Learner;
use AppBundle\Entity\Provider;
use AppBundle\Entity\Event;
use AppBundle\Form\EventTypeForPost;
use AppBundle\Form\EventTypeForList;
use AppBundle\Form\EventTypeForAd;
use \DateTime;

class FeedController extends Controller
{
    /**
     * @return Response
     *
     * @Route("/sitemap.xml", name="knoitall_sitemap")
     */
    public function sitemapAction()
    {
        $learnerRepository = $this->getDoctrine()->getRepository('AppBundle:Learner');
        $learners = $learnerRepository->findAll();

        $advisorRepository = $this ->getDoctrine()->getRepository('AppBundle:Advisor');
        $advisors = $advisorRepository->findAll();

        $instructorRepository = $this->getDoctrine()->getRepository('AppBundle:Instructor');
        $instructors = $instructorRepository->findAll();

        $providerRepository = $this->getDoctrine()->getRepository('AppBundle:Provider');
        $providers = $providerRepository->findAll();

        $eventRepository = $this->getDoctrine()->getRepository('AppBundle:Event');
        $events = $eventRepository->findAll();

        $articleRepository = $this->getDoctrine()->getRepository('AppBundle:Article');
        $articles = $articleRepository->findAll();

        $content = $this->renderView( ':feed:sitemap.xml.twig', [
            'learners' => $learners,
            'advisors' => $advisors,
            'instructors' => $instructors,
            'providers' => $providers,
            'events' => $events,
            'articles' => $articles,
        ] );

        return $this->createXmlResponse( $content );
    }

    /**
     * @return Response
     *
     * @route("/rssfeed.xml", name="knoitall_rssfeed")
     */
    public function rssFeedAction()
    {
        $articles = $this
            ->getDoctrine()
            ->getRepository('AppBundle:Article')
            ->findBy(['published' => true], ['id' => 'ASC'])
        ;

        $content = $this->renderView(':feed:rssfeed.xml.twig', ['articles' => $articles]);

        return $this->createXmlResponse($content);
    }

    private function createXmlResponse( $content )
    {
        $response = new Response( $content );
        $response->headers->set( 'Content-Type', 'application/xml' );
        return $response;
    }

   /**
     * @param Learner $learner
     * @return Provider
     */
    public function getProviderFromLearner(Learner $learner)
    {        
        $person = $learner->getPerson(); 
        $provider = $person->getProviders()[0];
        return $provider;
    }

   /**
     * @param Provider $provider
     * @return boolean
     */
    public function checkIfProviderCanHaveLearner(Provider $provider)
    { 
        $canHaveLearner = false;
        $persons = $provider->getPersons();
        if (count($persons)) {
            $person = $persons[0];
            $learners = $person->getLearners();
            if (count($learners)) {
                $canHaveLearner = true;
            }
            else {
                if (($person->getFirstName()!="") || ($person->getLastName()!="") || ($person->getEmail()!="")) {
                    $canHaveLearner = true;
                }
            }
        }
        return $canHaveLearner;
    }

    /**
     * @param Provider $provider
     * @return Learner $learner
     */
    public function createLearnerProfileFromProviderAction( Provider $provider )
    {
        $person = $provider->getPersons()[0];
        $learner = new Learner();
        $learner->setPerson( $person );
        $learner->SetTitle( $person->getFirstName() . " " . $person->getLastName() );
        $Nickname = strtolower($person->getFirstName()) . "-" . strtolower($person->getLastName());

        $suffix = 1;
        $NewNickname = $Nickname;
        $learnerRepository = $this->getDoctrine()->getRepository('AppBundle:Learner');
        $otherLearner = $learnerRepository->findOneBy(['nickname' => $Nickname]);
        while( $otherLearner ) {
            $NewNickname = $Nickname . "-" . $suffix;
            $otherLearner = $learnerRepository->findOneBy(['nickname' => $NewNickname]);
            $suffix++;
        }
        $learner->setNickname( $NewNickname ); 
        $learner->setPublished(true);
        
        $taxonomyRepository = $this->getDoctrine()->getRepository(Taxonomy::class);        
        $knoitallTaxonomy = $taxonomyRepository->find(4908); // Education:Knoitall
        $learner->addTaxonomy($knoitallTaxonomy);
        
        $ageRepository = $this->getDoctrine()->getRepository(Age::class);
        $defaultAges = $ageRepository->findBy(array('description' => array('Pre-teen','Teen','Adult')));
        foreach( $defaultAges as $age ) {
            $learner->addAge($age);
        }

        $em = $this->getDoctrine()->getManager();
        $em->persist($learner);
        $em->flush();
        $em->refresh($learner);

        $providerRepository = $this->getDoctrine()->getRepository(Provider::class);        
        $JeffCreightonClass = $providerRepository->findOneBy(['id' => 12858]);
        $requestContent = [
            'learner_id' => $learner->getId(),
            'provider_id' => $JeffCreightonClass->getId()
        ];

        $jsonRequest = json_encode($requestContent);

        $tempRequest = new Request(
            $_GET,
            $_POST,
            array(),
            $_COOKIE,
            $_FILES,
            $_SERVER,
            $jsonRequest
        );

        $this->forward('AppBundle:Feed:memberFeed', array(
            'request'  => $tempRequest,
            'action' => 'follow-provider',
        ));    

        $em->refresh($learner);
        return $learner;
    }

   /**
     * @param Provider $provider
     * @return Learner
     */
    public function getLearnerFromProvider(Provider $provider)
    {
        /* Check if Provider connected with valid Person ( Provider from Old Database ) */
        if (!$this->checkIfProviderCanHaveLearner($provider)) {
            return NULL;
        }
        /* Person availability has already been checked */
        $person = $provider->getPersons()[0];
        $learners = $person->getLearners();
        if (count($learners)) {
            $learner = $learners[0];
            return $learner;
        }

        /* Create Learner, in case Learner not available */        
        $learner = $this->createLearnerProfileFromProviderAction($provider);
        return $learner;
    }

    public function FollowUnfollow_PushToGetStreamAction( FeedFollowProvider $feedFollowProvider )
    {
        $getstream_key = $this->getParameter('getstream_key');
        $getstream_secret = $this->getParameter('getstream_secret');
        $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );

        $em = $this->getDoctrine()->getManager();
        $actorProvider = $this->getProviderFromLearner($feedFollowProvider->getLearner());
        $learner_id = $feedFollowProvider->getLearner()->getId();
        $provider_id = $feedFollowProvider->getProvider()->getId();

        // get followee's Learner id
        $followee_Learner = $this->getLearnerFromProvider($feedFollowProvider->getProvider());  
        $followee_LearnerId = null;
        if ($followee_Learner) {
            $followee_LearnerId = $followee_Learner->getId();
        }
        // get learner's Provider id
        $learner_ProviderId = $this->getProviderFromLearner($feedFollowProvider->getLearner())->getId(); 

        //$learnerRepository = $this->getDoctrine()->getRepository(Learner::class);
        //$followee_id = $learnerRepository->findOneBy(['person' => $person[0]])->getId();
        $learnerFeed = $client->feed('learner_feed', strval($learner_id));
        $learnerFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));

        /*if (!$followee_id) {
            $followee_id = 0;
        }*/
        if( $feedFollowProvider->getFollow() ) {
            $verb = "follow";
            $learnerFeed->followFeed('activity', strval($followee_LearnerId));
        } else {
            $verb = "unfollow";  
            $learnerFeed->unfollowFeed('activity', strval($followee_LearnerId));
        }                
        $followSuccess = true;
        
        if ($followSuccess) {    
            $activityFeed = $client->feed('activity', strval($learner_id));
            $activityFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));

            /* Notification to Event Owner and Actor's Followers */
            /* maximum of 100 targets per API request. */        
            $NeedNewArray = false;
            $notificationCount = 0;
            $notificationTotalCount = 0;
            $notificationArrayCount = 0;
            $notificationList = array();
            $notificationArrayList = array();

            if (($followee_LearnerId != NULL) && ($followee_LearnerId != $learner_id)) {
                array_push($notificationList,'notification:'.strval($followee_LearnerId)); 
                $notificationCount++;
                $notificationTotalCount++;
            }
            /* Code for send notification to Follower */        
            /*$Followers = $actorProvider->getFollowers();
            foreach($Followers as $follower) {
                if ($NeedNewArray) {
                    array_push($notificationArrayList, $notificationList);
                    $notificationArrayCount++;
                    array_splice($notificationList, 0, 100);
                    //$notificationList = array();
                    $notificationCount = 0;
                    $NeedNewArray = false;
                }
                if ($followee_LearnerId != $follower->getId()) {
                    array_push($notificationList,'notification:'.strval($follower->getId())); 
                    $notificationCount++;
                    $notificationTotalCount++;
                    if ($notificationCount == 100) {
                        $NeedNewArray = true;
                    }
                }            
            }*/
            if ($notificationCount > 0) {
                array_push($notificationArrayList, $notificationList);
                $notificationArrayCount++;
                array_splice($notificationList, 0, $notificationCount);
            }

            $timeTag = $feedFollowProvider->getTimestampAdded();
            $activity = [
                'actor' => 'learner:'.strval($learner_id),
                'verb' => $verb,
                'object' => 'provider:'.strval($provider_id),
                //'to' => ['notification:'.strval($followee_LearnerId)], 
                'foreign_id' => "follow:".strval($feedFollowProvider->getId()),
                'time' => $timeTag->format(DateTime::ISO8601),
            ];

            if ($notificationTotalCount > 0) {
                $activity['to'] = $notificationArrayList[0];
            }
        
            $activityFeed->addActivity($activity);
            $pushSuccess = true;        
            /*    .then(onSuccess)
                .catch(onError) */

            /*function onSuccess(data) {
                // Unique Id will be returned:
                var activityId = data; 
                $pushSuccess = true; 
            }*/

            /* try {
                $response = $feed->addActivity($activity);
            } catch (StreamFeedException $exception) {
                // Something went wrong on your end.
            } catch (ServerException $exception) {
                // Something went wrong on Stream's end.
            } */

            if ($notificationArrayCount > 1) {
                for ($ArrayNo = 1; $ArrayNo < $notificationArrayCount; $ArrayNo++) {                
                    $currentNotificationList = $notificationArrayList[$ArrayNo];
                    $notificationFeedIdString = $currentNotificationList[0];
                    array_splice($currentNotificationList,0,1);
                    $matches = [];
                    if( preg_match("/^notification:(\d+)$/", $notificationFeedIdString, $matches ) ) {
                        $notificationFeedId = $matches[1];
                    }                
                    $activity['to'] = $currentNotificationList;
    
                    /* Push this Activity to Notification Channel */
                    $notificationFeed = $client->feed('notification', strval($notificationFeedId));
                    $notificationFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));
                    $notificationFeed->addActivity($activity);
                    $pushSuccess = true;
                }
            }
        }

        if ($pushSuccess) {            
            $feedFollowProvider->setPushedToGetstream(true); 
            $em->persist($feedFollowProvider);
            $em->flush();
        }
    }

    public function Like_PushToGetStreamAction( FeedLikeEvent $feedLikeEvent )
    {
        $getstream_key = $this->getParameter('getstream_key');
        $getstream_secret = $this->getParameter('getstream_secret');
        $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );

        $em = $this->getDoctrine()->getManager();
        $actorProvider = $this->getProviderFromLearner($feedLikeEvent->getLearner());
        $learner_id = $feedLikeEvent->getLearner()->getId();
        $event_id = $feedLikeEvent->getEvent()->getId();
        $event_provider_id = $feedLikeEvent->getEvent()->getProvider()->getId();
        // get event's Learner id
        $eventLearner = $this->getLearnerFromProvider($feedLikeEvent->getEvent()->getProvider());
        $eventLearnerId = null;
        if ($eventLearner) {
            $eventLearnerId = $eventLearner->getId();
        }
        //$learner_ProviderId = $this->getProviderFromLearner($feedCommentEvent->getLearner())->getId();

        $activityFeed = $client->feed('activity', strval($learner_id));
        $activityFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));

        /* Notification to Event Owner and Actor's Followers */
        /* maximum of 100 targets per API request. */        
        $NeedNewArray = false;
        $notificationCount = 0;
        $notificationTotalCount = 0;
        $notificationArrayCount = 0;
        $notificationList = array();
        $notificationArrayList = array();

        if (($eventLearnerId != NULL) && ($eventLearnerId != $learner_id)) {
            array_push($notificationList,'notification:'.strval($eventLearnerId)); 
            $notificationCount++;
            $notificationTotalCount++;
        }        
        /* Code for send notification to Follower */        
        /*$Followers = $actorProvider->getFollowers();
        foreach($Followers as $follower) {
            if ($NeedNewArray) {
                array_push($notificationArrayList, $notificationList);
                $notificationArrayCount++;
                array_splice($notificationList, 0, 100);
                //$notificationList = array();
                $notificationCount = 0;
                $NeedNewArray = false;
            }
            if ($eventLearnerId != $follower->getId()) {
                array_push($notificationList,'notification:'.strval($follower->getId())); 
                $notificationCount++;
                $notificationTotalCount++;
                if ($notificationCount == 100) {
                    $NeedNewArray = true;
                }
            }            
        }*/        
        if ($notificationCount > 0) {
            array_push($notificationArrayList, $notificationList);
            $notificationArrayCount++;
            array_splice($notificationList, 0, $notificationCount);
        }

        $timeTag = $feedLikeEvent->getTimestampAdded();
        $activity = [
            'actor' => 'learner:'.strval($learner_id),
            'verb' => 'like',
            'object' => 'event:'.strval($event_id),
            //'to' => ['notification:'.strval($event_provider_id)], 
            'foreign_id' => 'like:'.strval($feedLikeEvent->getId()),
            'time' => $timeTag->format(DateTime::ISO8601)
        ];

        if ($notificationTotalCount > 0) {
            $activity['to'] = $notificationArrayList[0];
        }
        
        $activityFeed->addActivity($activity);
        $pushSuccess = true;        
        /*    .then(onSuccess)
            .catch(onError) */

        /*function onSuccess(data) {
            // Unique Id will be returned:
            var activityId = data; 
            $pushSuccess = true; 
        }*/

        /* try {
            $response = $feed->addActivity($activity);
        } catch (StreamFeedException $exception) {
            // Something went wrong on your end.
        } catch (ServerException $exception) {
            // Something went wrong on Stream's end.
        } */

        if ($notificationArrayCount > 1) {
            for ($ArrayNo = 1; $ArrayNo < $notificationArrayCount; $ArrayNo++) {                
                $currentNotificationList = $notificationArrayList[$ArrayNo];
                $notificationFeedIdString = $currentNotificationList[0];
                array_splice($currentNotificationList,0,1);
                $matches = [];
                if( preg_match("/^notification:(\d+)$/", $notificationFeedIdString, $matches ) ) {
                    $notificationFeedId = $matches[1];
                }                
                $activity['to'] = $currentNotificationList;

                /* Push this Activity to Notification Channel */
                $notificationFeed = $client->feed('notification', strval($notificationFeedId));
                $notificationFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));
                $notificationFeed->addActivity($activity);
                $pushSuccess = true;
            }
        }

        if ($pushSuccess) {
            $feedLikeEvent->setPushedToGetstream(true);
            $em->persist($feedLikeEvent);
            $em->flush();
        }
    }

    public function Comment_PushToGetStreamAction( FeedCommentEvent $feedCommentEvent )
    {
        $getstream_key = $this->getParameter('getstream_key');
        $getstream_secret = $this->getParameter('getstream_secret');
        $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );

        $em = $this->getDoctrine()->getManager();
        $actorProvider = $this->getProviderFromLearner($feedCommentEvent->getLearner());
        $learner_id = $feedCommentEvent->getLearner()->getId();
        $event_id = $feedCommentEvent->getEvent()->getId();
        $event_provider_id = $feedCommentEvent->getEvent()->getProvider()->getId();
        // get event's Learner id
        $eventLearner = $this->getLearnerFromProvider($feedCommentEvent->getEvent()->getProvider());
        $eventLearnerId = null;
        if ($eventLearner) {
            $eventLearnerId = $eventLearner->getId();
        }
        //$learner_ProviderId = $this->getProviderFromLearner($feedCommentEvent->getLearner())->getId();

        $activityFeed = $client->feed('activity', strval($learner_id));
        $activityFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));

        /* Notification to Event Owner and Actor's Followers */
        /* maximum of 100 targets per API request. */        
        $NeedNewArray = false;
        $notificationCount = 0;
        $notificationTotalCount = 0;
        $notificationArrayCount = 0;
        $notificationList = array();
        $notificationArrayList = array();

        if (($eventLearnerId != NULL) && ($eventLearnerId != $learner_id)) {
            array_push($notificationList,'notification:'.strval($eventLearnerId)); 
            $notificationCount++;
            $notificationTotalCount++;
        }        
        /* Code for send notification to Follower */        
        /*$Followers = $actorProvider->getFollowers();
        foreach($Followers as $follower) {
            if ($NeedNewArray) {
                array_push($notificationArrayList, $notificationList);
                $notificationArrayCount++;
                array_splice($notificationList, 0, 100);
                //$notificationList = array();
                $notificationCount = 0;
                $NeedNewArray = false;
            }
            if ($eventLearnerId != $follower->getId()) {
                array_push($notificationList,'notification:'.strval($follower->getId())); 
                $notificationCount++;
                $notificationTotalCount++;
                if ($notificationCount == 100) {
                    $NeedNewArray = true;
                }
            }            
        } */       
        if ($notificationCount > 0) {
            array_push($notificationArrayList, $notificationList);
            $notificationArrayCount++;
            array_splice($notificationList, 0, $notificationCount);
        }

        $comment = $feedCommentEvent->getCommentText();
        $timeTag = $feedCommentEvent->getTimestampAdded();        
        $activity = [
            'actor' => 'learner:'.strval($learner_id),
            'verb' => 'comment',
            'object' => 'event:'.strval($event_id),
            'comment' => $comment,
            //'to' => ['notification:'.strval($event_provider_id)], 
            'foreign_id' => 'comment:'.strval($feedCommentEvent->getId()),
            'time' => $timeTag->format(DateTime::ISO8601),
        ];
        
        if ($notificationTotalCount > 0) {
            $activity['to'] = $notificationArrayList[0];
        }
        
        $activityFeed->addActivity($activity);
        $pushSuccess = true;        
        /*    .then(onSuccess)
            .catch(onError) */

        /*function onSuccess(data) {
            // Unique Id will be returned:
            var activityId = data; 
            $pushSuccess = true; 
        }*/

        /* try {
            $response = $feed->addActivity($activity);
        } catch (StreamFeedException $exception) {
            // Something went wrong on your end.
        } catch (ServerException $exception) {
            // Something went wrong on Stream's end.
        } */

        if ($notificationArrayCount > 1) {
            for ($ArrayNo = 1; $ArrayNo < $notificationArrayCount; $ArrayNo++) {                
                $currentNotificationList = $notificationArrayList[$ArrayNo];
                $notificationFeedIdString = $currentNotificationList[0];
                array_splice($currentNotificationList,0,1);
                $matches = [];
                if( preg_match("/^notification:(\d+)$/", $notificationFeedIdString, $matches ) ) {
                    $notificationFeedId = $matches[1];
                }                
                $activity['to'] = $currentNotificationList;

                /* Push this Activity to Notification Channel */
                $notificationFeed = $client->feed('notification', strval($notificationFeedId));
                $notificationFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));
                $notificationFeed->addActivity($activity);
                $pushSuccess = true;
            }
        }

        if ($pushSuccess) {
            $feedCommentEvent->setPushedToGetstream(true);
            $em->persist($feedCommentEvent);
            $em->flush();
        }
    }

    public function ReplyComment_PushToGetStreamAction( FeedCommentEvent $feedCommentEvent )
    {
        $getstream_key = $this->getParameter('getstream_key');
        $getstream_secret = $this->getParameter('getstream_secret');
        $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );

        $em = $this->getDoctrine()->getManager();
        $actorProvider = $this->getProviderFromLearner($feedCommentEvent->getLearner());
        $learner_id = $feedCommentEvent->getLearner()->getId();
        $event_id = $feedCommentEvent->getEvent()->getId();
        $event_provider_id = $feedCommentEvent->getEvent()->getProvider()->getId();
        // get event's Learner id
        $eventLearner = $this->getLearnerFromProvider($feedCommentEvent->getEvent()->getProvider());
        $eventLearnerId = null;
        if ($eventLearner) {
            $eventLearnerId = $eventLearner->getId();
        }
        //$learner_ProviderId = $this->getProviderFromLearner($feedCommentEvent->getLearner())->getId();

        /*$activityFeed = $client->feed('activity', strval($learner_id));
        $activityFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem')); */

        $primaryFeedCommentEvent = $feedCommentEvent->getReplyFromComment();
        $destFeedCommentEvent = $feedCommentEvent->getReplyToComment();
        
        $destCommentId = 0;       
        $primaryCommentId = $primaryFeedCommentEvent->getId();
        if ( $primaryFeedCommentEvent && !$destFeedCommentEvent ) {
            $replyToId = $primaryFeedCommentEvent->getLearner()->getId();
        } 
        if ( $primaryFeedCommentEvent && $destFeedCommentEvent ) {
            $destCommentId = $destFeedCommentEvent->getId();
            $replyToId = $destFeedCommentEvent->getLearner()->getId();
        }

        if ($replyToId == $learner_id) {
            $feedCommentEvent->setPushedToGetstream(true);
            $em->persist($feedCommentEvent);
            $em->flush();
            return;
        }

        $learnerFeed = $client->feed('learner_feed', strval($replyToId));
        $learnerFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));
        
        $comment = $feedCommentEvent->getCommentText();
        $timeTag = $feedCommentEvent->getTimestampAdded();        
        $activity = [
            'actor' => 'learner:'.strval($learner_id),
            'verb' => 'reply',
            'object' => 'replyTo:'.strval($replyToId),
            'event' => 'event:'.strval($event_id),
            'comment' => $comment,
            'reply_from' => strval($primaryCommentId),        
            'reply_to' => strval($destCommentId),
            //'to' => ['notification:'.strval($event_provider_id)], 
            'foreign_id' => 'comment:'.strval($feedCommentEvent->getId()),
            'time' => $timeTag->format(DateTime::ISO8601),
        ];        

        /* Notification to Event Owner and Actor's Followers */
        /* maximum of 100 targets per API request. */        
        $NeedNewArray = false;
        $notificationCount = 0;
        $notificationTotalCount = 0;
        $notificationArrayCount = 0;
        $notificationList = array();
        $notificationArrayList = array();

        array_push($notificationList,'notification:'.strval($replyToId)); 
        $notificationCount++;
        $notificationTotalCount++;
        
        /* Code for send notification to Follower */        
        /*$Followers = $actorProvider->getFollowers();
        foreach($Followers as $follower) {
            if ($NeedNewArray) {
                array_push($notificationArrayList, $notificationList);
                $notificationArrayCount++;
                array_splice($notificationList, 0, 100);
                //$notificationList = array();
                $notificationCount = 0;
                $NeedNewArray = false;
            }
            if ($eventLearnerId != $follower->getId()) {
                array_push($notificationList,'notification:'.strval($follower->getId())); 
                $notificationCount++;
                $notificationTotalCount++;
                if ($notificationCount == 100) {
                    $NeedNewArray = true;
                }
            }            
        } */       
        if ($notificationCount > 0) {
            array_push($notificationArrayList, $notificationList);
            $notificationArrayCount++;
            array_splice($notificationList, 0, $notificationCount);
        }
        
        if ($notificationTotalCount > 0) {
            $activity['to'] = $notificationArrayList[0];
        }
        
        //$activityFeed->addActivity($activity);
        $learnerFeed->addActivity($activity);
        $pushSuccess = true;        
        /*    .then(onSuccess)
            .catch(onError) */

        /*function onSuccess(data) {
            // Unique Id will be returned:
            var activityId = data; 
            $pushSuccess = true; 
        }*/

        /* try {
            $response = $feed->addActivity($activity);
        } catch (StreamFeedException $exception) {
            // Something went wrong on your end.
        } catch (ServerException $exception) {
            // Something went wrong on Stream's end.
        } */

        if ($notificationArrayCount > 1) {
            for ($ArrayNo = 1; $ArrayNo < $notificationArrayCount; $ArrayNo++) {                
                $currentNotificationList = $notificationArrayList[$ArrayNo];
                $notificationFeedIdString = $currentNotificationList[0];
                array_splice($currentNotificationList,0,1);
                $matches = [];
                if( preg_match("/^notification:(\d+)$/", $notificationFeedIdString, $matches ) ) {
                    $notificationFeedId = $matches[1];
                }                
                $activity['to'] = $currentNotificationList;

                /* Push this Activity to Notification Channel */
                $notificationFeed = $client->feed('notification', strval($notificationFeedId));
                $notificationFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));
                $notificationFeed->addActivity($activity);
                $pushSuccess = true;
            }
        }

        if ($pushSuccess) {
            $feedCommentEvent->setPushedToGetstream(true);
            $em->persist($feedCommentEvent);
            $em->flush();
        }
    }

    public function Share_PushToGetStreamAction( FeedShareEvent $feedShareEvent )
    {
        $getstream_key = $this->getParameter('getstream_key');
        $getstream_secret = $this->getParameter('getstream_secret');
        $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );

        $em = $this->getDoctrine()->getManager();
        $actorProvider = $this->getProviderFromLearner($feedShareEvent->getLearner());
        $learner_id = $feedShareEvent->getLearner()->getId();
        $event_id = $feedShareEvent->getEvent()->getId();
        $event_provider_id = $feedShareEvent->getEvent()->getProvider()->getId();
        // get event's Learner id
        $eventLearner = $this->getLearnerFromProvider($feedShareEvent->getEvent()->getProvider());
        $eventLearnerId = null;
        if ($eventLearner) {
            $eventLearnerId = $eventLearner->getId();
        }
        //$learner_ProviderId = $this->getProviderFromLearner($feedShareEvent->getLearner())->getId();

        $activityFeed = $client->feed('activity', strval($learner_id));
        $activityFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));

        /* Notification to Event Owner and Actor's Followers */
        /* maximum of 100 targets per API request. */        
        $NeedNewArray = false;
        $notificationCount = 0;
        $notificationTotalCount = 0;
        $notificationArrayCount = 0;
        $notificationList = array();
        $notificationArrayList = array();

        if (($eventLearnerId != NULL) && ($eventLearnerId != $learner_id)) {
            array_push($notificationList,'notification:'.strval($eventLearnerId)); 
            $notificationCount++;
            $notificationTotalCount++;
        }        
        /* Code for send notification to Follower */        
        /*$Followers = $actorProvider->getFollowers();
        foreach($Followers as $follower) {
            if ($NeedNewArray) {
                array_push($notificationArrayList, $notificationList);
                $notificationArrayCount++;
                array_splice($notificationList, 0, 100);
                //$notificationList = array();
                $notificationCount = 0;
                $NeedNewArray = false;
            }
            if ($eventLearnerId != $follower->getId()) {
                array_push($notificationList,'notification:'.strval($follower->getId())); 
                $notificationCount++;
                $notificationTotalCount++;
                if ($notificationCount == 100) {
                    $NeedNewArray = true;
                }
            }            
        }*/
        if ($notificationCount > 0) {
            array_push($notificationArrayList, $notificationList);
            $notificationArrayCount++;
            array_splice($notificationList, 0, $notificationCount);
        }

        $timeTag = $feedShareEvent->getTimestampAdded();
        $activity = [
            'actor' => 'learner:'.strval($learner_id),
            'verb' => 'share',
            'object' => 'event:'.strval($event_id),
            //'to' => ['notification:'.strval($event_provider_id)], 
            'foreign_id' => 'share:'.strval($feedShareEvent->getId()),
            'time' => $timeTag->format(DateTime::ISO8601)
        ];

        if ($notificationTotalCount > 0) {
            $activity['to'] = $notificationArrayList[0];
        }
        
        $activityFeed->addActivity($activity);
        $pushSuccess = true;        
        /*    .then(onSuccess)
            .catch(onError) */

        /*function onSuccess(data) {
            // Unique Id will be returned:
            var activityId = data; 
            $pushSuccess = true; 
        }*/

        /* try {
            $response = $feed->addActivity($activity);
        } catch (StreamFeedException $exception) {
            // Something went wrong on your end.
        } catch (ServerException $exception) {
            // Something went wrong on Stream's end.
        } */

        if ($notificationArrayCount > 1) {
            for ($ArrayNo = 1; $ArrayNo < $notificationArrayCount; $ArrayNo++) {                
                $currentNotificationList = $notificationArrayList[$ArrayNo];
                $notificationFeedIdString = $currentNotificationList[0];
                array_splice($currentNotificationList,0,1);
                $matches = [];
                if( preg_match("/^notification:(\d+)$/", $notificationFeedIdString, $matches ) ) {
                    $notificationFeedId = $matches[1];
                }                
                $activity['to'] = $currentNotificationList;

                /* Push this Activity to Notification Channel */
                $notificationFeed = $client->feed('notification', strval($notificationFeedId));
                $notificationFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));
                $notificationFeed->addActivity($activity);
                $pushSuccess = true;
            }
        }
        
        if ($pushSuccess) {
            $feedShareEvent->setPushedToGetstream(true);
            $em->persist($feedShareEvent);
            $em->flush();
        }
    }    

    public function addPost_PushToGetStreamAction( FeedAddPostEvent $feedAddPostEvent )
    {
        $getstream_key = $this->getParameter('getstream_key');
        $getstream_secret = $this->getParameter('getstream_secret');
        $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );

        $em = $this->getDoctrine()->getManager();
        $actorProvider = $feedAddPostEvent->getProvider();
        $provider_id = $feedAddPostEvent->getProvider()->getId();
        $event_id = $feedAddPostEvent->getEvent()->getId();
        $event_provider_id = $feedAddPostEvent->getEvent()->getProvider()->getId();
        // get provider's Learner id
        $provider_Learner = $this->getLearnerFromProvider($feedAddPostEvent->getProvider());
        $provider_LearnerId = null;
        if ($provider_Learner) {
            $provider_LearnerId = $provider_Learner->getId();
        }

        $activityFeed = $client->feed('activity', strval($provider_LearnerId));
        $activityFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));

        /* Notification to Event Owner and Actor's Followers */
        /* maximum of 100 targets per API request. */        
        $NeedNewArray = false;
        $notificationCount = 0;
        $notificationTotalCount = 0;
        $notificationArrayCount = 0;
        $notificationList = array();
        $notificationArrayList = array();

        $Followers = $actorProvider->getFollowers();
        foreach($Followers as $follower) {
            if ($NeedNewArray) {
                array_push($notificationArrayList, $notificationList);
                $notificationArrayCount++;
                array_splice($notificationList, 0, 100);
                //$notificationList = array();
                $notificationCount = 0;
                $NeedNewArray = false;
            }
            if ($provider_LearnerId != $follower->getId()) {
                array_push($notificationList,'notification:'.strval($follower->getId())); 
                $notificationCount++;
                $notificationTotalCount++;
                if ($notificationCount == 100) {
                    $NeedNewArray = true;
                }
            }            
        }        
        if ($notificationCount > 0) {
            array_push($notificationArrayList, $notificationList);
            $notificationArrayCount++;
            array_splice($notificationList, 0, $notificationCount);
        }

        $timeTag = $feedAddPostEvent->getTimestampAdded();
        $activity = [
            'actor' => 'provider:'.strval($provider_id),
            'verb' => 'addPost',
            'object' => 'event:'.strval($event_id),
            //'to' => ['notification:'.strval($event_provider_id)], 
            'foreign_id' => 'post:'.strval($feedAddPostEvent->getId()),
            'time' => $timeTag->format(DateTime::ISO8601)
        ];

        if ($notificationTotalCount > 0) {
            $activity['to'] = $notificationArrayList[0];
        }

        $activityFeed->addActivity($activity);
        $pushSuccess = true;        
        /*    .then(onSuccess)
            .catch(onError) */

        /*function onSuccess(data) {
            // Unique Id will be returned:
            var activityId = data; 
            $pushSuccess = true; 
        }*/

        /* try {
            $response = $feed->addActivity($activity);
        } catch (StreamFeedException $exception) {
            // Something went wrong on your end.
        } catch (ServerException $exception) {
            // Something went wrong on Stream's end.
        } */

        if ($notificationArrayCount > 1) {
            for ($ArrayNo = 1; $ArrayNo < $notificationArrayCount; $ArrayNo++) {                
                $currentNotificationList = $notificationArrayList[$ArrayNo];
                $notificationFeedIdString = $currentNotificationList[0];
                array_splice($currentNotificationList,0,1);
                $matches = [];
                if( preg_match("/^notification:(\d+)$/", $notificationFeedIdString, $matches ) ) {
                    $notificationFeedId = $matches[1];
                }                
                $activity['to'] = $currentNotificationList;

                /* Push this Activity to Notification Channel */
                $notificationFeed = $client->feed('notification', strval($notificationFeedId));
                $notificationFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));
                $notificationFeed->addActivity($activity);
                $pushSuccess = true;
            }
        }

        if ($pushSuccess) {
            $feedAddPostEvent->setPushedToGetstream(true);
            $em->persist($feedAddPostEvent);
            $em->flush();
        }
    }    

    /**
     * @Route("/member/feed/{action}", name="knoitall_feed")
     */
    public function memberFeedAction(Request $request, $action = null)
    {
        $data = null;
        if( $content = $request->getContent() ) {
            $data = json_decode( $content, true );
        }

        if( $data ) {
            /** @var User $user */
            $user = $this->get('security.token_storage')->getToken()->getUser();
            $user_id = $user->getId();
            /** @var Learner $learner */
            $userLearner = $user->getPerson()->getLearners()[0];
            /** @var Provider $provider */

            $learner_id = ( isset($data['learner_id']) ? $data['learner_id'] : null );
            $provider_id = ( isset($data['provider_id']) ? $data['provider_id'] : null );
            $event_id = ( isset($data['event_id']) ? $data['event_id'] : null );
            $activity_id = ( isset($data['activity_id']) ? $data['activity_id'] : null );
            $comment_place_id = ( isset($data['comment_place_id']) ? $data['comment_place_id'] : null ); 
            $comment_text = ( isset($data['comment_text']) ? $data['comment_text'] : null );
            $primary_comment_id = ( isset($data['primary_comment_id']) ? $data['primary_comment_id'] : null ); 
            $destination_comment_id = ( isset($data['destination_comment_id']) ? $data['destination_comment_id'] : null );             
            $reply_text = ( isset($data['reply_text']) ? $data['reply_text'] : null ); 
            $client_timezone = ( isset($data['client_timezone']) ? $data['client_timezone'] : null );

            $learnerRepository = $this->getDoctrine()->getRepository(Learner::class);
            $providerRepository = $this->getDoctrine()->getRepository(Provider::class);
            $eventRepository = $this->getDoctrine()->getRepository(Event::class);

            $user_Provider = $user->getPerson()->getProviders()[0];

            $learner = ( isset($learner_id) ? $learnerRepository->find($learner_id) : null );
            $provider = ( isset($provider_id) ? $providerRepository->find($provider_id) : null );
            $event = ( isset($event_id) ? $eventRepository->find($event_id) : null );

            $em = $this->getDoctrine()->getManager();
           
            if( $action == 'follow-provider' ) {
                $alreadyFollow = false;
                $Followers = $provider->getFollowers();
                foreach( $Followers as $Follower ) {
                    if ($Follower == $learner) {
                        $alreadyFollow = true;    
                    }
                }
                $selfProvider = false;
                if ($provider == $user_Provider) {
                   $selfProvider = true;
                }
                $followerCount = 0;
                $FollowerListLink = "";

                if ((!$alreadyFollow) && (!$selfProvider)) {
                    $learner->addFollowee($provider);
                    $em->persist($learner);
                    $em->flush();
    
                    $feedFollowProvider = new FeedFollowProvider();
                    $feedFollowProvider
                        ->setLearner($learner)
                        ->setProvider($provider)
                        ->setFollow(true)
                        ->setPushedToGetstream(false);
                    $em->persist($feedFollowProvider);
                    $em->flush();

                    if (!$feedFollowProvider->getPushedToGetstream()) {
                        $this->FollowUnfollow_PushToGetStreamAction($feedFollowProvider);
                    }

                    $em->refresh($provider);
                    $Followers = $provider->getFollowers();
                    $followerCount = count($Followers);
                    foreach( $Followers as $Follower ) {
                        $tempLink = $this->renderView( ':learner:learner_popover_profile.html.twig', ['learner' => $Follower] );

                        /*if ($Follower->getTitle()) {
                            $tempLink = "<a href=" . $this->generateUrl('knoitall_learner_public_profile', array('nickname' => $Follower->getNickname() )) . ">" . $Follower->getTitle() . "</a>";
                        }*/
                        $FollowerListLink = $FollowerListLink . $tempLink;
                    }
                }                
                $returnValues = [
                    'selfProvider' => $selfProvider,
                    'alreadyFollow' => $alreadyFollow,
                    'followerCount' => $followerCount,
                    'followerList' => $FollowerListLink,
                ];

                /*$feedFollowProviderRepository = $this->getDoctrine()->getRepository(FeedFollowProvider::class);  
                $feedFollowProvider = null;
                $feedFollowProvider = $feedFollowProviderRepository->findOneBy([
                    'learner' => $learner,
                    'provider' => $provider,
                ]);                

                if ($feedFollowProvider) {
                    $alreadyFollow = $feedFollowProvider->getFollow();
                    if (!$feedFollowProvider->getFollow() && !$feedFollowProvider->getPushedToGetstream()) {
                        $feedFollowProvider->setFollow(true);
                        $feedFollowProvider->setPushedToGetstream(true);
                        $em->persist($feedFollowProvider);
                        $em->flush();
                    }
                }
                else {
                    $alreadyFollow = false;*/

                    //$learner->addFollowee($provider);
                    //$em->persist($learner);

                    /*
                     * data to be pushed to getstream.io:
                     */
                    /*$feedFollowProvider = new FeedFollowProvider();
                    $feedFollowProvider
                        ->setLearner($learner)
                        ->setProvider($provider)
                        ->setFollow(true)
                        ->setPushedToGetstream(false);
                    $em->persist($feedFollowProvider);
                    $em->flush();
                }
                if (!$feedFollowProvider->getPushedToGetstream()) {
                    $this->FollowUnfollow_PushToGetStreamAction($feedFollowProvider);
                }

                $feedFollowProviders = $feedFollowProviderRepository->findBy([
                    'provider' => $provider,
                    'follow' => true
                ]);

                $FollowerListLink = "";
                foreach( $feedFollowProviders as $feedFollowProvider ) {
                    $tempLearner = $feedFollowProvider->getLearner();
                    if ($tempLearner->getTitle()) {
                        $tempLink = "<a href=" . $this->generateUrl('knoitall_learner_public_profile', array('nickname' => $tempLearner->getNickname() )) . ">" . $tempLearner->getTitle() . "</a>";
                    }
                    $FollowerListLink = $FollowerListLink . $tempLink . " ";
                }

                $returnValues = [
                    'alreadyFollow' => $alreadyFollow,
                    'followerCount' => count($feedFollowProviders),
                    'followerList' => $FollowerListLink,
                ];    */            
            } elseif( $action == 'unfollow-provider' ) {
                $alreadyUnfollow = true;
                $Followers = $provider->getFollowers();
                foreach( $Followers as $Follower ) {
                    if ($Follower == $learner) {
                        $alreadyUnfollow = false;    
                    }
                }
                $selfProvider = false;
                if ($provider == $user_Provider) {
                   $selfProvider = true;
                }
                $followerCount = 0;
                $FollowerListLink = "";

                if ((!$alreadyUnfollow) && (!$selfProvider)) {
                    $learner->removeFollowee($provider);
                    $em->persist($learner);
                    $em->flush();
    
                    $feedFollowProvider = new FeedFollowProvider();
                    $feedFollowProvider
                        ->setLearner($learner)
                        ->setProvider($provider)
                        ->setFollow(false)
                        ->setPushedToGetstream(false);
                    $em->persist($feedFollowProvider);
                    $em->flush();

                    if (!$feedFollowProvider->getPushedToGetstream()) {
                        $this->FollowUnfollow_PushToGetStreamAction($feedFollowProvider);
                    }
                    
                    $em->refresh($provider);
                    $Followers = $provider->getFollowers();
                    $followerCount = count($Followers);
                    foreach( $Followers as $Follower ) {
                        $tempLink = $this->renderView( ':learner:learner_popover_profile.html.twig', ['learner' => $Follower] );

                        /*if ($Follower->getTitle()) {
                            $tempLink = "<a href=" . $this->generateUrl('knoitall_learner_public_profile', array('nickname' => $Follower->getNickname() )) . ">" . $Follower->getTitle() . "</a>";
                        }*/
                        $FollowerListLink = $FollowerListLink . $tempLink;
                    }
                }
                $returnValues = [
                    'selfProvider' => $selfProvider,
                    'alreadyUnfollow' => $alreadyUnfollow,
                    'followerCount' => $followerCount,
                    'followerList' => $FollowerListLink,
                ];

                /*$feedFollowProviderRepository = $this->getDoctrine()->getRepository(FeedFollowProvider::class);
                $UnfollowFeedProvider = null;
                $UnfollowFeedProvider = $feedFollowProviderRepository->findOneBy([
                    'learner' => $learner,
                    'provider' => $provider,
                ]);

                if ($UnfollowFeedProvider == null) {
                    $alreadyUnfollow = true;                    
                }
                else {
                    $alreadyUnfollow = !$UnfollowFeedProvider->getFollow();

                    if ($UnfollowFeedProvider->getFollow() && !$UnfollowFeedProvider->getPushedToGetstream()) {
                        $em->remove($UnfollowFeedProvider);
                        $em->flush();
                        $UnfollowFeedProvider = null;
                    } else if ($UnfollowFeedProvider->getFollow() && $UnfollowFeedProvider->getPushedToGetstream()) {
                             $UnfollowFeedProvider->setFollow(false);
                             $UnfollowFeedProvider->setPushedToGetstream(false);
                             $em->persist($UnfollowFeedProvider);
                             $em->flush();
                    }
                }
                if ($UnfollowFeedProvider) {
                    if (!$UnfollowFeedProvider->getPushedToGetstream()) {
                        $this->FollowUnfollow_PushToGetStreamAction($UnfollowFeedProvider);
                    }
                }

                $feedFollowProviders = $feedFollowProviderRepository->findBy([
                    'provider' => $provider,
                    'follow' => true
                ]); 

                $FollowerListLink = "";
                foreach( $feedFollowProviders as $feedFollowProvider ) {
                    $tempLearner = $feedFollowProvider->getLearner();
                    if ($tempLearner->getTitle()) {
                        $tempLink = "<a href=" . $this->generateUrl('knoitall_learner_public_profile', array('nickname' => $tempLearner->getNickname() )) . ">" . $tempLearner->getTitle() . "</a>";
                    }
                    $FollowerListLink = $FollowerListLink . $tempLink . " ";
                }
  
                $returnValues = [
                    'alreadyUnfollow' => $alreadyUnfollow,
                    'followerCount' => count($feedFollowProviders),
                    'followerList' => $FollowerListLink,
                ];*/
            } elseif( $action == 'like-event' ) {
                $likeCount = (int) $this->forward('AppBundle:Event:getRealFeedLikeAmount', ['event' => $event])->getContent();
                $eventProvider = $event->getProvider();
                
                if ($user_Provider == $eventProvider) {
                    $selfProvider = true;
                    $returnValues = [
                        'selfProvider' => $selfProvider,
                        'likeCount' => $likeCount,
                        'alreadyLike' => false,
                    ];
                } else {
                    $selfProvider = false;
                    $feedLikeEventRepository = $this->getDoctrine()->getRepository(FeedLikeEvent::class);                  
                    $feedLikeEvent = null;
                    $feedLikeEvent = $feedLikeEventRepository->findOneBy([
                        'learner' => $learner,
                        'event' => $event,
                    ]);

                    if ($feedLikeEvent) {
                        $returnValues = [
                            'selfProvider' => $selfProvider,
                            'likeCount' => $likeCount,
                            'alreadyLike' => true,
                        ];
                    } else {                        
                        $feedLikeEvent = new FeedLikeEvent();
                        $feedLikeEvent
                            ->setLearner($learner)
                            ->setEvent($event)
                            ->setPushedToGetstream(false);
                        $em->persist($feedLikeEvent);
                        $event->setLikeAmount($likeCount+1);
                        $em->persist($event);
                        $em->flush();
                   
                        $returnValues = [
                            'selfProvider' => $selfProvider,
                            'likeCount' => $likeCount,
                            'alreadyLike' => false,
                        ];
                    }
                    if (!$feedLikeEvent->getPushedToGetstream()) {
                        $this->Like_PushToGetStreamAction($feedLikeEvent);
                    }
                }                
            } elseif( $action == 'comment-event' ) {
                $replyAmount = 0;
                $addedText ="";
                $commentCount = (int) $this->forward('AppBundle:Event:getRealFeedCommentAmount', ['event' => $event])->getContent();
                $feedCommentEvent = new FeedCommentEvent();
                $feedCommentEvent
                    ->setLearner($learner)
                    ->setEvent($event)
                    ->setCommentText($comment_text)
                    ->setPushedToGetstream(false);
                $em->persist($feedCommentEvent);
                $event->setCommentAmount($commentCount+1);
                $em->persist($event);
                $em->flush();
                $em->refresh($feedCommentEvent);
                
                $timeTag = $feedCommentEvent->getTimestampAdded();
                $temp_timezone = date_default_timezone_get();
                date_default_timezone_set($client_timezone);
                $timezoneName = date('T');
                date_default_timezone_set($temp_timezone);

                $eventLearner = $event->getProvider()->getPersons()[0]->getLearners()[0];
                $eventLearnerId = $eventLearner->getId();

                $isEventOwner = false;  
                if ($eventLearnerId == $learner->getId()) {
                    $isEventOwner = true;
                }

                $ElapsedTimeText = $this->forward('AppBundle:Event:getElapsedTimeText', ['timestamp' => $timeTag])->getContent();

                if ($activity_id) {
                    $isForEventPage = false;
                    $activityID = $activity_id; 
                } else {
                    $isForEventPage = true;
                    $activityID = ""; 
                }

                /* $activityID = "";
                $isForEventPage = true;
                if ($comment_place_id) {                    
                    $isForEventPage = false;
                    $activityID = $activity_id; 
                }  */              

                $newComment = $this->renderView( ':feed:feed_show_comment.html.twig', [
                    'userLearner' => $userLearner,
                    'learner' => $learner,
                    'event' => $event,
                    'comment_text' => $comment_text,
                    'reply_amount' => $replyAmount,
                    'added_text' => $addedText,
                    'isEventOwner' => $isEventOwner,
                    'commentID' => strval($feedCommentEvent->getId()),
                    'activityID' => $activityID,
                    'elapsedTimeText' => $ElapsedTimeText,
                    'timetag' => $timeTag->format(DateTime::ISO8601),
                    'client_timezone' => $client_timezone,
                    'timezone_name' => $timezoneName,
                    'comment_place_id' => $comment_place_id,
                    'isForEventPage' => $isForEventPage
                ] );

                $returnValues = [
                    'commentCount' => $commentCount,
                    'newComment' => $newComment,
                    'newCommentID' => strval($feedCommentEvent->getId())
                ];

                if (!$feedCommentEvent->getPushedToGetstream()) {
                    $this->Comment_PushToGetStreamAction($feedCommentEvent);
                }
            } elseif( $action == 'reply-comment-event' ) { 
                $feedCommentEventRepository = $this->getDoctrine()->getRepository(FeedCommentEvent::class);
                $primaryFeedCommentEvent = $feedCommentEventRepository->find($primary_comment_id);
                $destFeedCommentEvent = null;
                if ($destination_comment_id) {
                    $destFeedCommentEvent = $feedCommentEventRepository->find($destination_comment_id);
                }
                $commentCount = (int) $this->forward('AppBundle:Event:getRealFeedCommentAmount', ['event' => $event])->getContent();                
                $replyCount = (int) $this->forward('AppBundle:Event:getRealFeedReplyAmount', ['primaryFeedCommentEvent' => $primaryFeedCommentEvent])->getContent();
                
                $feedCommentEvent = new FeedCommentEvent();
                $feedCommentEvent
                    ->setLearner($learner)
                    ->setEvent($event)                    
                    ->setReplyFromComment($primaryFeedCommentEvent)
                    // when reply to other reply, default null
                    ->setCommentText($reply_text)
                    ->setPushedToGetstream(false);
                if ($destFeedCommentEvent) {
                    $feedCommentEvent ->setReplyToComment($destFeedCommentEvent);  
                }                    
                $em->persist($feedCommentEvent);
                $event->setCommentAmount($commentCount+1);                
                $em->persist($event);
                $primaryFeedCommentEvent->setReplyAmount($replyCount+1);
                $em->persist($primaryFeedCommentEvent);
                $em->flush();
                $em->refresh($feedCommentEvent);
                
                $timeTag = $feedCommentEvent->getTimestampAdded();
                $temp_timezone = date_default_timezone_get();
                date_default_timezone_set($client_timezone);
                $timezoneName = date('T');
                date_default_timezone_set($temp_timezone); 

                $eventLearner = $event->getProvider()->getPersons()[0]->getLearners()[0];
                $eventLearnerId = $eventLearner->getId();

                $isEventOwner = false;  
                if ($eventLearnerId == $learner->getId()) {
                    $isEventOwner = true;
                }

                $ElapsedTimeText = $this->forward('AppBundle:Event:getElapsedTimeText', ['timestamp' => $timeTag])->getContent();

                if ($activity_id) {
                    $isForEventPage = false;
                    $activityID = $activity_id; 
                } else {
                    $isForEventPage = true;
                    $activityID = ""; 
                }

                /* $activityID = "";
                $isForEventPage = true;
                if ($comment_place_id) {                    
                    $isForEventPage = false;
                    $activityID = $activity_id; 
                } */              

                $newComment = $this->renderView( ':feed:feed_show_reply.html.twig', [
                    'userLearner' => $userLearner,
                    'learner' => $learner,
                    'event' => $event,
                    'reply_text' => $reply_text,
                    'isEventOwner' => $isEventOwner,
                    'commentID' => strval($feedCommentEvent->getId()),
                    'activityID' => $activityID,
                    'primaryCommentID' => $primary_comment_id,
                    'elapsedTimeText' => $ElapsedTimeText,
                    'timetag' => $timeTag->format(DateTime::ISO8601),
                    'client_timezone' => $client_timezone,
                    'timezone_name' => $timezoneName,
                    'isForEventPage' => $isForEventPage
                ] );

                $returnValues = [                    
                    //'replyCount' => $replyCount,
                    'commentCount' => $commentCount,
                    'newComment' => $newComment,
                    'newCommentID' => strval($feedCommentEvent->getId())
                ];

                if (!$feedCommentEvent->getPushedToGetstream()) {
                    $this->ReplyComment_PushToGetStreamAction($feedCommentEvent);
                }    

                /*
                 * get all user_id's for this event's provider:
                 */
                /** @var Provider $event_provider */
                //$event_provider = $event->getProvider();
                //$event_persons = $event_provider->getPersons();
                //$event_user_ids = [];
                /** @var Person $event_person */
                //foreach( $event_persons as $event_person ) {
                //    $event_users = $event_person->getUsers();
                    /** @var User $event_user */
                //    foreach( $event_users as $event_user) {
                //        $event_user_ids[] = $event_user->getId();
                //    }
                //}
                //$event_user_ids = array_unique($event_user_ids);

            } elseif( $action == 'share-event' ) {                
                $eventProvider = $event->getProvider();
                if ($user_Provider == $eventProvider) {
                    $selfProvider = true;
                    $returnValues = [
                        'selfProvider' => $selfProvider,
                        'alreadyShare' => false,
                    ];
                } else {
                    $selfProvider = false;
                    $feedShareEventRepository = $this->getDoctrine()->getRepository(FeedShareEvent::class);                  
                    $feedShareEvents = null;
                    $feedShareEvents = $feedShareEventRepository->findBy(
                        ['learner' => $learner, 'event' => $event],
                        ['timestampAdded' => 'DESC']
                    );
                    $feedShareEvent = null;
                    if (count($feedShareEvents)) {
                        $feedShareEvent = $feedShareEvents[0];
                    }

                    $alreadyShare = false;
                    if ($feedShareEvent) {
                        $currentTime = new DateTime();                    
                        $lastSharedTime = $feedShareEvent->getTimestampAdded();
                        $interval = $lastSharedTime->diff($currentTime);
                        $difference_in_seconds = ($interval->format('%y') * 365 * 86400) + 
                        ($interval->format('%m') * 30 * 86400) + ($interval->format('%d') * 86400) + ($interval->format('%h') * 3600) + ($interval->format('%i') * 60) + $interval->format('%s'); 
                        if ( $difference_in_seconds < (20*86400) ) {
                            $alreadyShare = true;
                            $returnValues = [ 
                                'selfProvider' => $selfProvider,         
                                'alreadyShare' => true,
                                'elapsedTime' => $difference_in_seconds,
                            ];
                        }
                    }

                    if (!$alreadyShare) {
                        $feedShareEvent = new FeedShareEvent();
                        $feedShareEvent
                            ->setLearner($learner)
                            ->setEvent($event)
                            ->setPushedToGetstream(false);
                        $em->persist($feedShareEvent);
                        $em->flush();
                       
                        $returnValues = [
                            'selfProvider' => $selfProvider,
                            'alreadyShare' => false,
                        ];
                    }
                    if (!$feedShareEvent->getPushedToGetstream()) {
                        $this->Share_PushToGetStreamAction($feedShareEvent);
                    }
                }
            } elseif( $action == 'addPost-event' ) {
                $feedAddPostEventRepository = $this->getDoctrine()->getRepository(FeedAddPostEvent::class);                  
                $feedAddPostEvent = null;
                $feedAddPostEvent = $feedAddPostEventRepository->findOneBy([
                    'provider' => $provider,
                    'event' => $event,
                ]);

                if ($feedAddPostEvent) {
                    $returnValues = [                        
                        'alreadyAddPost' => true,
                    ];
                }
                else {
                    $feedAddPostEvent = new FeedAddPostEvent();
                    $feedAddPostEvent
                        ->setProvider($provider)
                        ->setEvent($event)
                        ->setPushedToGetstream(false);
                    $em->persist($feedAddPostEvent);
                    $em->flush();
                   
                    $returnValues = [
                        'alreadyAddPost' => false,
                    ];
                }

                if (!$feedAddPostEvent->getPushedToGetstream()) {
                    $this->addPost_PushToGetStreamAction($feedAddPostEvent);
                }
            } else {
                $response = new Response(json_encode(['status' => "ERROR: unknown action='$action'"]));
                $response->headers->set('Content-Type', 'application/json');
                return $response;
            }

            $returnValues['status'] = 'OK';
            $response = new Response(json_encode($returnValues));
            $response->headers->set('Content-Type', 'application/json');
            return $response;
        }

        $response = new Response(json_encode(['status' => 'ERROR']));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    /**
     * @param $feedActivity
     * @return Response
     */
    public function feedShowPerActivityAction( $feedActivity, $client_timezone, $isActivityChannel = false, &$mapCanvasId, &$latitude, &$longitude, &$mapLabel )
    {
        /** @var User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        $person = $user->getPerson();
        $userLearner = $person->getLearners()[0];
        $userProvider = $user->getPerson()->getProviders()[0];

        $providerRepository = $this->getDoctrine()->getRepository(Provider::class);
        $learnerRepository = $this->getDoctrine()->getRepository(Learner::class);
        $eventRepository = $this->getDoctrine()->getRepository(Event::class);        

        /** @var Provider $provider */
        $provider = null;
        /** @var Event $event */
        $event = null;

        $temp_timezone = date_default_timezone_get();
        date_default_timezone_set($client_timezone);
        $timezoneName = date('T');
        date_default_timezone_set($temp_timezone);
        //date_default_timezone_set('Europe/London');

        $timeTag = date_create($feedActivity['time'], timezone_open('UTC'));
        $ElapsedTimeText = $this->forward('AppBundle:Event:getElapsedTimeText', ['timestamp' => $timeTag])->getContent();

        if( ( $feedActivity['verb'] == 'follow' ) || ( $feedActivity['verb'] == 'unfollow' ) ) {
            $matches = [];
            if( preg_match("/^learner:(\d+)$/", $feedActivity['actor'], $matches ) ) {
                $learner_id = $matches[1];
                $learner = $learnerRepository->find($learner_id);
            }

            $matches = [];
            if( preg_match("/^provider:(\d+)$/", $feedActivity['object'], $matches ) ) {
                $provider_id = $matches[1];
                $provider = $providerRepository->find($provider_id);
            }

            /*if ((!$isActivityChannel) && ($userProvider != $provider)) {
                return "Not User Interest";
            }*/
            $tagMatch = false;            
            $taxonomies = $userLearner->getTaxonomies();
            foreach( $provider->getTaxonomies() as $providerTaxonomy ) {
                if( $taxonomies->contains($providerTaxonomy) ) {
                    $tagMatch = true;
                    break;
                }
            }
            if ( (!$isActivityChannel) && ($userProvider != $provider) && (!$tagMatch) ) {
                return "Not User Interest";
            }

            return $this->renderView( ':feed:feed_activity_follow_unfollow.html.twig', [
                'verb' => $feedActivity['verb'],
                'learner' => $learner,
                'provider' => $provider,
                'elapsedTimeText' => $ElapsedTimeText,
                'timetag' => $timeTag->format(DateTime::ISO8601),
                'client_timezone' => $client_timezone,
                'timezone_name' => $timezoneName
            ] );

        } elseif( $feedActivity['verb'] == 'like' ) {

            $matches = [];
            if( preg_match("/^learner:(\d+)$/", $feedActivity['actor'], $matches ) ) {
                $learner_id = $matches[1];
                $learner = $learnerRepository->find($learner_id);
            }

            $matches = [];
            if( preg_match("/^event:(\d+)$/", $feedActivity['object'], $matches ) ) {
                $event_id = $matches[1];
                $event = $eventRepository->find($event_id);
            }

            if ($event == null) {
                return "";
            }

            if ((!$isActivityChannel) && ($userLearner == $learner)) {
                return "Learner Activity";
            }

            $tagMatch = false;
            $ageMatch = false;   
            $taxonomies = $userLearner->getTaxonomies();
            foreach( $event->getTaxonomies() as $eventTaxonomy ) {
                if( $taxonomies->contains($eventTaxonomy) ) {
                    $tagMatch = true;
                    break;
                }
            }
            $ages = $userLearner->getAges();
            foreach( $event->getAges() as $eventAge ) {
                if( $ages->contains($eventAge) ) {
                    $ageMatch = true;
                    break;
                }
            }
            if ( (!$isActivityChannel) && ($event->getProvider() != $userProvider) && ((!$tagMatch) || (!$ageMatch)) ) {
                return "Not User Interest";
            }

            $UserIsEventOwner = false;   
            $LearnerIsEventOwner = false; 
            $eventProviderId = $event->getProvider()->getId();
            if ($userProvider->getId() == $eventProviderId) {
                $UserIsEventOwner = true;   
            }

            $learnerProvider = $this->getProviderFromLearner($learner);
            if ($learnerProvider) {
                $learnerProviderId = $learnerProvider->getId();
                if ($eventProviderId == $learnerProviderId) {
                    $LearnerIsEventOwner = true;
                }
            }            
            
            return $this->renderView( ':feed:feed_activity_like.html.twig', [
                'verb' => $feedActivity['verb'],
                'learner' => $learner,
                'event' => $event,
                'elapsedTimeText' => $ElapsedTimeText,
                'timetag' => $timeTag->format(DateTime::ISO8601),
                'client_timezone' => $client_timezone,
                'timezone_name' => $timezoneName,
                'UserIsEventOwner' => $UserIsEventOwner,
                'LearnerIsEventOwner' => $LearnerIsEventOwner,
            ]);

        } elseif( $feedActivity['verb'] == 'comment' ) {

            $matches = [];
            if( preg_match("/^learner:(\d+)$/", $feedActivity['actor'], $matches ) ) {
                $learner_id = $matches[1];
                $learner = $learnerRepository->find($learner_id);
            }

            $matches = [];
            if( preg_match("/^event:(\d+)$/", $feedActivity['object'], $matches ) ) {
                $event_id = $matches[1];
                $event = $eventRepository->find($event_id);
            }

            $matches = [];
            if( preg_match("/^comment:(\d+)$/", $feedActivity['foreign_id'], $matches ) ) {
                $comment_id = $matches[1];
            }

            if ($event == null) {
                return "";
            }

            if ((!$isActivityChannel) && ($userLearner == $learner)) {
                return "Learner Activity";
            }

            if ((!$isActivityChannel) && ($event->getProvider() != $userProvider)) {
                return "Not User Interest";
            }

            $UserIsEventOwner = false;   
            $LearnerIsEventOwner = false; 
            $eventProviderId = $event->getProvider()->getId();
            if ($userProvider->getId() == $eventProviderId) {
                $UserIsEventOwner = true;   
            }

            $learnerProvider = $this->getProviderFromLearner($learner);
            if ($learnerProvider) {
                $learnerProviderId = $learnerProvider->getId();
                if ($eventProviderId == $learnerProviderId) {
                    $LearnerIsEventOwner = true;
                }
            }         

            $commentLink = "#Main_CommentTopPlace-" . strval($comment_id);
            
            return $this->renderView( ':feed:feed_activity_comment.html.twig', [
                'verb' => $feedActivity['verb'],
                'learner' => $learner,
                'event' => $event,
                'comment' => $feedActivity['comment'],
                'commentLink' => $commentLink,
                'elapsedTimeText' => $ElapsedTimeText,
                'timetag' => $timeTag->format(DateTime::ISO8601),
                'client_timezone' => $client_timezone,
                'timezone_name' => $timezoneName,
                'UserIsEventOwner' => $UserIsEventOwner,
                'LearnerIsEventOwner' => $LearnerIsEventOwner,
            ]);        

        } elseif( $feedActivity['verb'] == 'reply' ) {

            /* 'actor' => 'learner:'.strval($learner_id),
            'verb' => 'reply',
            'object' => 'replyTo:'.strval($replyToId),
            'event' => 'event:'.strval($event_id),
            'comment' => $comment,
            'reply_from' => strval($primaryCommentId),        
            'reply_to' => strval($destCommentId),
            //'to' => ['notification:'.strval($event_provider_id)], 
            'foreign_id' => 'comment:'.strval($feedCommentEvent->getId()),
            'time' => $timeTag->format(DateTime::ISO8601), */

            $matches = [];
            if( preg_match("/^learner:(\d+)$/", $feedActivity['actor'], $matches ) ) {
                $learner_id = $matches[1];
                $learner = $learnerRepository->find($learner_id);
            }

            $matches = [];
            if( preg_match("/^replyTo:(\d+)$/", $feedActivity['object'], $matches ) ) {
                $replyTo_id = $matches[1];
                $replyToLearner = $learnerRepository->find($replyTo_id);
            }

            $matches = [];
            if( preg_match("/^event:(\d+)$/", $feedActivity['event'], $matches ) ) {
                $event_id = $matches[1];
                $event = $eventRepository->find($event_id);
            }

            $matches = [];
            if( preg_match("/^comment:(\d+)$/", $feedActivity['foreign_id'], $matches ) ) {
                $reply_id = $matches[1];
            }

            if ($event == null) {
                return "";
            }

            if ((!$isActivityChannel) && ($userLearner == $learner)) {
                return "Learner Activity";
            }            

            $UserIsReplyToLearner = false;               
            if ($userLearner == $replyToLearner) {
                $UserIsReplyToLearner = true;   
            }
            
            $primaryCommentId = intval($feedActivity['reply_from']);
            $destCommentId = intval($feedActivity['reply_to']); 

            $feedCommentEventRepository = $this->getDoctrine()->getRepository(FeedCommentEvent::class);
            $primaryFeedCommentEvent = $feedCommentEventRepository->find($primaryCommentId);
            $destFeedCommentEvent = null;
            if ($destCommentId) {
                $destFeedCommentEvent = $feedCommentEventRepository->find($destCommentId);
            }

            if ( $primaryFeedCommentEvent && !$destFeedCommentEvent ) {
                $prevComment = $primaryFeedCommentEvent->getCommentText();
                $prevCommentLink = "#Main_CommentTopPlace-" . strval($primaryCommentId);
            } 
            if ( $primaryFeedCommentEvent && $destFeedCommentEvent ) {
                $prevComment = $destFeedCommentEvent->getCommentText();
                $prevCommentLink = "#Reply_CommentTopPlace-" . strval($destCommentId);
            }

            $UserIsEventOwner = false;   
            $LearnerIsEventOwner = false; 
            $eventProviderId = $event->getProvider()->getId();
            if ($userProvider->getId() == $eventProviderId) {
                $UserIsEventOwner = true;   
            }

            $learnerProvider = $this->getProviderFromLearner($learner);
            if ($learnerProvider) {
                $learnerProviderId = $learnerProvider->getId();
                if ($eventProviderId == $learnerProviderId) {
                    $LearnerIsEventOwner = true;
                }
            }  
            
            $LearnerIsReplyToLearner = false;
            if ($learner_id == $replyTo_id) {
                $LearnerIsReplyToLearner = true;
            }

            $replyLink = "#Reply_CommentTopPlace-" . strval($reply_id);

            return $this->renderView( ':feed:feed_activity_reply.html.twig', [
                'verb' => $feedActivity['verb'],
                'learner' => $learner,
                'replyToLearner' => $replyToLearner,
                'event' => $event,
                'reply' => $feedActivity['comment'],
                'prev_comment' => $prevComment,
                'replyLink' => $replyLink,
                'prevCommentLink' => $prevCommentLink,
                'elapsedTimeText' => $ElapsedTimeText,
                'timetag' => $timeTag->format(DateTime::ISO8601),
                'client_timezone' => $client_timezone,
                'timezone_name' => $timezoneName,
                'UserIsReplyToLearner' => $UserIsReplyToLearner,
                'UserIsEventOwner' => $UserIsEventOwner,
                'LearnerIsReplyToLearner' => $LearnerIsReplyToLearner,
                'LearnerIsEventOwner' => $LearnerIsEventOwner,
            ]);    

        } elseif( $feedActivity['verb'] == 'share' ) {

            $matches = [];
            if( preg_match("/^learner:(\d+)$/", $feedActivity['actor'], $matches ) ) {
                $learner_id = $matches[1];
                $learner = $learnerRepository->find($learner_id);
            }

            $matches = [];
            if( preg_match("/^event:(\d+)$/", $feedActivity['object'], $matches ) ) {
                $event_id = $matches[1];
                $event = $eventRepository->find($event_id);
            }

            if ($event == null) {
                return "";
            }

            if ((!$isActivityChannel) && ($userLearner == $learner)) {
                return "Learner Activity";
            }

            $tagMatch = false;
            $ageMatch = false;   
            $taxonomies = $userLearner->getTaxonomies();
            foreach( $event->getTaxonomies() as $eventTaxonomy ) {
                if( $taxonomies->contains($eventTaxonomy) ) {
                    $tagMatch = true;
                    break;
                }
            }
            $ages = $userLearner->getAges();
            foreach( $event->getAges() as $eventAge ) {
                if( $ages->contains($eventAge) ) {
                    $ageMatch = true;
                    break;
                }
            }
            if ( (!$isActivityChannel) && ($event->getProvider() != $userProvider) && ((!$tagMatch) || (!$ageMatch)) ) {
                return "Not User Interest";
            }

            $UserIsEventOwner = false;   
            $LearnerIsEventOwner = false; 
            $eventProviderId = $event->getProvider()->getId();
            if ($userProvider->getId() == $eventProviderId) {
                $UserIsEventOwner = true;   
            }

            $learnerProvider = $this->getProviderFromLearner($learner);
            if ($learnerProvider) {
                $learnerProviderId = $learnerProvider->getId();
                if ($eventProviderId == $learnerProviderId) {
                    $LearnerIsEventOwner = true;
                }
            }            

            if ((!$isActivityChannel) && ($event->getProvider() == $userProvider)) {
                return $this->renderView( ':feed:feed_activity_shorter_share.html.twig', [
                    'verb' => $feedActivity['verb'],
                    'learner' => $learner,
                    'event' => $event,
                    'elapsedTimeText' => $ElapsedTimeText,
                    'timetag' => $timeTag->format(DateTime::ISO8601),
                    'client_timezone' => $client_timezone,
                    'timezone_name' => $timezoneName,
                    'UserIsEventOwner' => $UserIsEventOwner,
                    'LearnerIsEventOwner' => $LearnerIsEventOwner,
                ]);             
            }

            $dow = "";
            if( $event->getMonday() ) { $dow = $dow . "Mon"; }
            if( $event->getTuesday() ) { 
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Tue"; }
            if( $event->getWednesday() ) {
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Wed"; }
            if( $event->getThursday() ) {
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Thu"; }
            if( $event->getFriday() ) {
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Fri"; }
            if( $event->getSaturday() ) {
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Sat"; }
            if( $event->getSunday() ) {
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Sun"; }

            $latitude = 0;
            $longitude = 0;
            $mapLabel = "";
            $isShowLocation = "false";
            $location = $event->getLocation();        
            if( $location ) {
                if( $location->getPublished() ) { 
                    $isShowLocation = "true";
                    $mapCanvasId = "MapCanvas-" . $feedActivity['id'];                    
                    $latitude = $location->getLatitude();
                    $longitude = $location->getLongitude();
                    $mapLabel = ( $location->getName() ? $location->getName() : $event->getTitle() );
                } 
            } elseif( $event->getLocationLatitude() != 0 and $event->getLocationLongitude() != 0 ) {
                $isShowLocation = "true";
                $mapCanvasId = "MapCanvas-" . $feedActivity['id'];                    
                $latitude = $event->getLocationLatitude();
                $longitude = $event->getLocationLongitude();
                $mapLabel = ( $event->getLocationName() ? $event->getLocationName() : $event->getTitle() );
            }        

            return $this->renderView( ':feed:feed_activity_share.html.twig', [
                'verb' => $feedActivity['verb'],
                'learner' => $learner,
                'event' => $event,
                'dow' => $dow,
                'elapsedTimeText' => $ElapsedTimeText,
                'timetag' => $timeTag->format(DateTime::ISO8601),
                'client_timezone' => $client_timezone,
                'timezone_name' => $timezoneName,
                'UserIsEventOwner' => $UserIsEventOwner,
                'LearnerIsEventOwner' => $LearnerIsEventOwner,
                'userLearner' => $userLearner,
                'activityID' => $feedActivity['id'],
                'latitude' => $latitude,
                'longitude' => $longitude,
                'mapLabel' => $mapLabel,
                'isShowLocation' => $isShowLocation,
                'isActivityChannel' => $isActivityChannel
            ]);

        } elseif( $feedActivity['verb'] == 'addPost' ) {

            $matches = [];
            if( preg_match("/^provider:(\d+)$/", $feedActivity['actor'], $matches ) ) {
                $provider_id = $matches[1];
                $provider = $providerRepository->find($provider_id);
            }

            $matches = [];
            if( preg_match("/^event:(\d+)$/", $feedActivity['object'], $matches ) ) {
                $event_id = $matches[1];
                $event = $eventRepository->find($event_id);
            }

            if ($event == null) {
                return "";
            }

            if ((!$isActivityChannel) && ($userProvider == $provider)) {
                return "Learner Activity";
            }       

            $tagMatch = false;
            $ageMatch = false;   
            $taxonomies = $userLearner->getTaxonomies();
            foreach( $event->getTaxonomies() as $eventTaxonomy ) {
                if( $taxonomies->contains($eventTaxonomy) ) {
                    $tagMatch = true;
                    break;
                }
            }
            $ages = $userLearner->getAges();
            foreach( $event->getAges() as $eventAge ) {
                if( $ages->contains($eventAge) ) {
                    $ageMatch = true;
                    break;
                }
            }            
            if ((!$isActivityChannel) && ((!$tagMatch) || (!$ageMatch))) {
                return "Not User Interest";
            }

            /*$providerIsEventOwner = false; 
            $eventProviderId = $event->getProvider()->getId();            
            if ($eventProviderId == $provider_id) {
                $ProviderIsEventOwner = true;
            }*/

            $isUpdate = "false";
            /*if ($event->getTimestampAdded() != $event->getTimestampUpdated()) {
                $isUpdate = "true";
            }*/

            $dow = "";
            if( $event->getMonday() ) { $dow = $dow . "Mon"; }
            if( $event->getTuesday() ) { 
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Tue"; }
            if( $event->getWednesday() ) {
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Wed"; }
            if( $event->getThursday() ) {
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Thu"; }
            if( $event->getFriday() ) {
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Fri"; }
            if( $event->getSaturday() ) {
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Sat"; }
            if( $event->getSunday() ) {
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Sun"; }        

            $latitude = 1;
            $longitude = 1;
            $mapLabel = ""; 
            $isShowLocation = "false";
            $location = $event->getLocation();        
            if( $location ) {                
                if( $location->getPublished() ) { 
                    $isShowLocation = "true";
                    $mapCanvasId = "MapCanvas-" . $feedActivity['id'];                    
                    $latitude = $location->getLatitude();
                    $longitude = $location->getLongitude();
                    $mapLabel = ( $location->getName() ? $location->getName() : $event->getTitle() );
                } 
            } elseif( $event->getLocationLatitude() != 0 and $event->getLocationLongitude() != 0 ) {
                $isShowLocation = "true";
                $mapCanvasId = "MapCanvas-" . $feedActivity['id'];                    
                $latitude = $event->getLocationLatitude();
                $longitude = $event->getLocationLongitude();
                $mapLabel = ( $event->getLocationName() ? $event->getLocationName() : $event->getTitle() );
            }                

            return $this->renderView( ':feed:feed_activity_addpost.html.twig', [
                'verb' => $feedActivity['verb'],
                'provider' => $provider,
                'event' => $event,
                'dow' => $dow,
                'elapsedTimeText' => $ElapsedTimeText,
                'timetag' => $timeTag->format(DateTime::ISO8601),
                'client_timezone' => $client_timezone,
                'timezone_name' => $timezoneName,
                'isUpdate' => $isUpdate,
                'userLearner' => $userLearner,
                'activityID' => $feedActivity['id'],                
                'latitude' => $latitude,
                'longitude' => $longitude,
                'mapLabel' => $mapLabel,
                'isShowLocation' => $isShowLocation,
                'isActivityChannel' => $isActivityChannel
                //'ProviderIsEventOwner' => $ProviderIsEventOwner
            ] );

        } else {

            return "ERROR";

        }        
    }

    /**
     * @Route("/member/feed/show/activities/{feed_channel}", name="knoitall_feed_show_activities")
     */
    public function showActivitiesAction(Request $request, $feed_channel = null)
    {
        $data = null;
        if( $content = $request->getContent() ) {
            $data = json_decode( $content, true );
        }

        if( $data ) {
            // $feed_channel = ( isset($data['feed_channel']) ? $data['feed_channel'] : null );            
            $feed_id = ( isset($data['feed_id']) ? $data['feed_id'] : null );
            $is_update = ( isset($data['is_update']) ? $data['is_update'] : null );
            $first_activity_id = ( isset($data['first_activity_id']) ? $data['first_activity_id'] : null );
            $last_activity_id = ( isset($data['last_activity_id']) ? $data['last_activity_id'] : null );
            $client_timezone = ( isset($data['client_timezone']) ? $data['client_timezone'] : null );
            
            $getstream_key = $this->getParameter('getstream_key');
            $getstream_secret = $this->getParameter('getstream_secret');
            $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );
            $activityFeed = $client->feed($feed_channel, strval($feed_id));
            $activityFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));

            if ($first_activity_id == 'first') {
                $minimalShowedFeed = 7;
            } else {
                $minimalShowedFeed = 5;
            }         

            $TotalFeedShown = 0;
            $activitiesCount = 0;            
            $activitiesContent = "";
            $isEndOfActivities = false;
            $MapCanvasIdList = array();
            $LatitudeList = array();
            $LongitudeList = array();
            $MapLabelList = array();
            $mapCanvasCount = 0;

            $ActivitiesPerRequest = 20;
            $TestRequest = $ActivitiesPerRequest + 1;

    GetActivitiesLoop:

            if ($is_update) { 
                if ($first_activity_id != 'first') {
                    $options = ['id_gt' => $first_activity_id];
                    $results = $activityFeed->getActivities(0, $TestRequest, $options);
                } else {
                    $results = $activityFeed->getActivities(0, $TestRequest);
                }
            } else {
                if ($last_activity_id != 'end') {
                    $options = ['id_lt' => $last_activity_id];
                    $results = $activityFeed->getActivities(0, $TestRequest, $options);
                } else {
                    $results = $activityFeed->getActivities(0, $TestRequest);
                }                                
            }
            
            $APIcallSuccess = false; 
            if (count($results)) {
                $activities = &$results['results'];
                $activitiesCount = count($activities);
                $APIcallSuccess = true; 
            }

            if ($activitiesCount <= $ActivitiesPerRequest) {
                $isEndOfActivities = true;
            }
            if ($activitiesCount == $TestRequest) {
                array_splice($activities, ($TestRequest-1), 1);
                $activitiesCount = $activitiesCount -1;    
                $isEndOfActivities = false;
            }
            
            if ($activitiesCount > 0) {
                if ($is_update) { 
                    if ($last_activity_id == 'end') {
                        $last_activity_id = $activities[$activitiesCount-1]['id'];
                    }                
                    $first_activity_id = $activities[0]['id'];
                } else {
                    if ($first_activity_id == 'first') {
                        $first_activity_id = $activities[0]['id'];
                    }                
                    $last_activity_id = $activities[$activitiesCount-1]['id'];
                }

            /* $activity = &$activities[3];
            $activitiesContent = $this->feedShowPerActivityAction( $activity, $client_timezone );*/

            /* For Tracking */            
            /*if ($is_update) {$isup="true";} else {$isup="false";}
            $activityContent = "<h6>isUpdate: ".$isup.", Activities Content: <br/>".$activitiesContent.", Activity Count: ".count($activities).", First activity id: ".$first_activity_id.", Last activity id: ".$last_activity_id.", Third time: ".$activity['time'].", feed channel: ".$feed_channel.", feed_id: ".$feed_id.", clinet time zone: ".$client_timezone."</h6>";
            $returnValues = [                    
                    'activitiesCount' => $activitiesCount,
                    'activitiesContent' => $activityContent,
                    'firstActivityId' => $first_activity_id,
                    'lastActivityId' => $last_activity_id ];
            $returnValues['status'] = 'OK';
            $response = new Response(json_encode($returnValues));
            $response->headers->set('Content-Type', 'application/json');
            return $response;*/
            /* End Tracking */ 
             
                $isActivityChannel = false;
                if ($feed_channel == "activity") {
                    $isActivityChannel = true;
                }
                foreach ( $activities as $activity ) { 
                    $mapCanvasId = "";
                    $latitude = 0;
                    $longitude = 0;
                    $mapLabel = "";
                    $feedShown = $this->feedShowPerActivityAction( $activity, $client_timezone, $isActivityChannel, $mapCanvasId, $latitude, $longitude, $mapLabel );
                    if (($feedShown != "Learner Activity") && ($feedShown != "Not User Interest")) {
                        if ($feedShown != "") {
                            $activitiesContent = $activitiesContent . $feedShown;
                            $TotalFeedShown = $TotalFeedShown + 1;
                        }
                        if ($mapCanvasId != "")  {
                            array_push($MapCanvasIdList, $mapCanvasId);
                            array_push($LatitudeList, $latitude);
                            array_push($LongitudeList, $longitude);
                            array_push($MapLabelList, $mapLabel);
                            $mapCanvasCount++;
                        }
                    }
                }

                if (($TotalFeedShown < $minimalShowedFeed) && (!$isEndOfActivities)) {
                   $activitiesCount = 0;
                   goto GetActivitiesLoop;   
                }

                $returnValues = [
                    'activitiesCount' => $activitiesCount,
                    'activitiesContent' => $activitiesContent,
                    'firstActivityId' => $first_activity_id,
                    'lastActivityId' => $last_activity_id,
                    'isEndOfActivities' => $isEndOfActivities,
                    'MapCanvasIdList' => $MapCanvasIdList,
                    'LatitudeList' => $LatitudeList,
                    'LongitudeList' => $LongitudeList,
                    'MapLabelList' => $MapLabelList,
                    'mapCanvasCount' =>$mapCanvasCount
                ];
            } else {
                $activitiesCount = 0;                

                $returnValues = [                    
                    'activitiesCount' => $activitiesCount,
                    'activitiesContent' => $activitiesContent,
                    'firstActivityId' => $first_activity_id,
                    'lastActivityId' => $last_activity_id,
                    'isEndOfActivities' => $isEndOfActivities,
                    'MapCanvasIdList' => $MapCanvasIdList,
                    'LatitudeList' => $LatitudeList,
                    'LongitudeList' => $LongitudeList,
                    'MapLabelList' => $MapLabelList,
                    'mapCanvasCount' =>$mapCanvasCount
                ];
            }

            $returnValues['status'] = 'OK';
            $response = new Response(json_encode($returnValues));
            $response->headers->set('Content-Type', 'application/json');
            return $response;
        }

        $response = new Response(json_encode(['status' => 'ERROR']));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    /**
     * @Route("/member/feed/show/comment", name="knoitall_feed_show_comment")
     */
    public function feedShowCommentAction(Request $request)
    {
        $data = null;
        if( $content = $request->getContent() ) {
            $data = json_decode( $content, true );
        }

        if( $data ) {
            $event_id = ( isset($data['event_id']) ? $data['event_id'] : null );
            $activity_id = ( isset($data['activity_id']) ? $data['activity_id'] : null );
            $comment_place_id = ( isset($data['comment_place_id']) ? $data['comment_place_id'] : null );
            $commentOffsetId = ( isset($data['comment_offset_id']) ? $data['comment_offset_id'] : null );
            $client_timezone = ( isset($data['client_timezone']) ? $data['client_timezone'] : null );
            
            $eventRepository = $this->getDoctrine()->getRepository(Event::class);
            $event = ( isset($event_id) ? $eventRepository->find($event_id) : null );
            $em = $this->getDoctrine()->getManager();
            
            $totalComment = $event->getCommentAmount();

            $feedCommentEventRepository = $this->getDoctrine()->getRepository(FeedCommentEvent::class);

            $feedCommentEventIds = null;

            if ($totalComment) {
                if ($commentOffsetId == 'first') {
                    $commentPerRequest = 5;
                    $feedCommentEvents = $feedCommentEventRepository->findBy(
                        ['event' => $event, 'replyFromComment' => NULL],
                        ['timestampAdded' => 'DESC'],  // ASC = Ascending  DESC = Descending
                        1,                   // limit
                        0                    // offset
                    );
                    $commentOffsetId = $feedCommentEvents[0]->getId();
                } else {
                    $commentPerRequest = 10;
                }

                $testRequest = $commentPerRequest + 1;

                $qb = $em->createQueryBuilder();
                $qb->select('feed_comment_event.id');
                $qb->from('AppBundle:FeedCommentEvent','feed_comment_event');
                $qb->where($qb->expr()->andX($qb->expr()->eq('feed_comment_event.event', $event->getId()),$qb->expr()->isNull('feed_comment_event.replyFromComment'),$qb->expr()->lte('feed_comment_event.id', $commentOffsetId) ));
                $qb->orderBy('feed_comment_event.timestampAdded', 'DESC');
                $qb->setMaxResults( $testRequest );            
                $feedCommentEventIds = $qb->getQuery()->getResult();
            }

            if( $feedCommentEventIds ) {                
                //$Comments = "";
                $CommentList = array();
                $CommentIdList = array();
                $ReplyAmountList = array();
                $commentCount = 0; 
                $commentShownCount = 0;
                foreach ( $feedCommentEventIds as $feedCommentEventId ) {
                    $commentCount++;
                    $feedCommentEvent = $feedCommentEventRepository->find($feedCommentEventId);
                    $commentOffsetId = $feedCommentEvent->getId();

                    if ( $commentCount <= $commentPerRequest ) {
                        $learner = $feedCommentEvent->getLearner();
                        $comment_text = $feedCommentEvent->getCommentText();
                        $replyAmount = $feedCommentEvent->getReplyAmount();
                        $timeTag = $feedCommentEvent->getTimestampAdded();
                        $temp_timezone = date_default_timezone_get();
                        date_default_timezone_set($client_timezone);
                        $timezoneName = date('T');
                        date_default_timezone_set($temp_timezone);

                        $eventLearner = $event->getProvider()->getPersons()[0]->getLearners()[0];
                        $eventLearnerId = $eventLearner->getId();

                        $qb = $em->createQueryBuilder();
                        $qb->select('count(feed_comment_event.id)');
                        $qb->from('AppBundle:FeedCommentEvent','feed_comment_event');
                        $qb->where($qb->expr()->andX($qb->expr()->eq('feed_comment_event.learner',$eventLearnerId), $qb->expr()->eq('feed_comment_event.replyFromComment',$feedCommentEvent->getId()) ));
                        $TotalEventOwnerComment = $qb->getQuery()->getSingleScalarResult();

                        $addedText = "";
                        if ($TotalEventOwnerComment) {
                            $addedText = " from " . $eventLearner->getTitle();
                            if ($replyAmount > $TotalEventOwnerComment) {
                                $addedText = $addedText . " and others";
                            }
                        }

                        $user = $this->get('security.token_storage')->getToken()->getUser();
                        $userLearner = $user->getPerson()->getLearners()[0];

                        $isEventOwner = false;  
                        if ($eventLearnerId == $learner->getId()) {
                            $isEventOwner = true;
                        }

                        $ElapsedTimeText = $this->forward('AppBundle:Event:getElapsedTimeText', ['timestamp' => $timeTag])->getContent();

                        $isForEventPage = false;
                                   
                        $Comment = $this->renderView( ':feed:feed_show_comment.html.twig', [
                            'userLearner' => $userLearner,
                            'learner' => $learner,
                            'event' => $event,
                            'comment_text' => $comment_text,
                            'reply_amount' => $replyAmount,
                            'added_text' => $addedText,
                            'isEventOwner' => $isEventOwner,
                            'commentID' => strval($feedCommentEvent->getId()),
                            'activityID' => $activity_id,
                            'comment_place_id' => $comment_place_id,
                            'elapsedTimeText' => $ElapsedTimeText,
                            'timetag' => $timeTag->format(DateTime::ISO8601),
                            'client_timezone' => $client_timezone,
                            'timezone_name' => $timezoneName,
                            'isForEventPage' => $isForEventPage
                        ] );
                        $commentShownCount++;
                        array_push($CommentList, $Comment);
                        array_push($CommentIdList, strval($feedCommentEvent->getId()));
                        array_push($ReplyAmountList, $replyAmount);
                    }                     
                }   

                $isEndOfComment = false;
                if ( $commentCount <= $commentPerRequest ) {
                    $isEndOfComment = true;                    
                } 

                $remainingCommentAmount = 0;
                if ((!$isForEventPage) && (!$isEndOfComment)) {
                    $qb = $em->createQueryBuilder();
                    $qb->select('count(feed_comment_event.id)');
                    $qb->from('AppBundle:FeedCommentEvent','feed_comment_event');
                    $qb->where($qb->expr()->andX($qb->expr()->eq('feed_comment_event.event', $event->getId()),$qb->expr()->isNull('feed_comment_event.replyFromComment'),$qb->expr()->lte('feed_comment_event.id', $commentOffsetId) ));
                    $qb->orderBy('feed_comment_event.timestampAdded', 'DESC');
                    $remainingCommentAmount = $qb->getQuery()->getSingleScalarResult();
                }

                $returnValues = [
                    'commentOffsetId' => $commentOffsetId,
                    //'Comments' => $Comments,
                    'CommentList' => $CommentList,
                    'CommentIdList' => $CommentIdList,
                    'ReplyAmountList' => $ReplyAmountList,
                    'commentShownCount' => $commentShownCount,
                    'isEndOfComment' => $isEndOfComment,
                    'remainingCommentAmount' => $remainingCommentAmount,
                ];
            } else {
                $returnValues = [
                    'commentOffsetId' => $commentOffsetId,
                    //'Comments' => '',
                    'CommentList' => null,
                    'CommentIdList' => null,
                    'ReplyAmountList' => null,
                    'commentShownCount' => 0,
                    'isEndOfComment' => true,
                    'remainingCommentAmount' => 0,
                ];
            }

            $returnValues['status'] = 'OK';
            $response = new Response(json_encode($returnValues));
            $response->headers->set('Content-Type', 'application/json');
            return $response;
        }

        $response = new Response(json_encode(['status' => 'ERROR']));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    /**
     * @Route("/member/feed/show/reply", name="knoitall_feed_show_reply")
     */
    public function feedShowReplyAction(Request $request)
    {
        $data = null;
        if( $content = $request->getContent() ) {
            $data = json_decode( $content, true );
        }

        if( $data ) {
            $event_id = ( isset($data['event_id']) ? $data['event_id'] : null );
            $activity_id = ( isset($data['activity_id']) ? $data['activity_id'] : null );
            $primary_comment_id = ( isset($data['primary_comment_id']) ? $data['primary_comment_id'] : null );
            $replyOffsetId = ( isset($data['reply_offset_id']) ? $data['reply_offset_id'] : null );
            $client_timezone = ( isset($data['client_timezone']) ? $data['client_timezone'] : null );
            
            $eventRepository = $this->getDoctrine()->getRepository(Event::class);
            $event = ( isset($event_id) ? $eventRepository->find($event_id) : null );
            $em = $this->getDoctrine()->getManager();
            
            $feedCommentEventRepository = $this->getDoctrine()->getRepository(FeedCommentEvent::class);

            $primaryCommentEvent = $feedCommentEventRepository->find($primary_comment_id);

            if ($replyOffsetId == 'first') {
                $feedReplyEvents = $feedCommentEventRepository->findBy(
                    ['event' => $event, 'replyFromComment' => $primaryCommentEvent],
                    ['timestampAdded' => 'ASC'],  // ASC = Ascending  DESC = Descending
                    1,                   // limit
                    0                    // offset
                );
                $replyOffsetId = $feedReplyEvents[0]->getId();
                $replyPerRequest = 10;
            } else {
                $replyPerRequest = 50;
            }

            $testRequest = $replyPerRequest + 1;

            $qb = $em->createQueryBuilder();
            $qb->select('feed_comment_event.id');
            $qb->from('AppBundle:FeedCommentEvent','feed_comment_event');
            $qb->where($qb->expr()->andX($qb->expr()->eq('feed_comment_event.event', $event->getId()),$qb->expr()->eq('feed_comment_event.replyFromComment', $primary_comment_id),$qb->expr()->gte('feed_comment_event.id', $replyOffsetId) ));
            $qb->orderBy('feed_comment_event.timestampAdded', 'ASC');
            $qb->setMaxResults( $testRequest );            
            $feedReplyEventIds = $qb->getQuery()->getResult();

            if( $feedReplyEventIds ) {                
                //$Comments = "";
                $ReplyList = array();
                $ReplyIdList = array();
                // $ReplyAmountList = array();
                $replyCount = 0; 
                $replyShownCount = 0;
                foreach ( $feedReplyEventIds as $feedReplyEventId ) {
                    $replyCount++;
                    $feedReplyEvent = $feedCommentEventRepository->find($feedReplyEventId);
                    $replyOffsetId = $feedReplyEvent->getId();

                    if ( $replyCount <= $replyPerRequest ) {
                        $learner = $feedReplyEvent->getLearner();
                        $reply_text = $feedReplyEvent->getCommentText();
                        // $replyAmount = $feedCommentEvent->getReplyAmount();
                        $timeTag = $feedReplyEvent->getTimestampAdded();
                        $temp_timezone = date_default_timezone_get();
                        date_default_timezone_set($client_timezone);
                        $timezoneName = date('T');
                        date_default_timezone_set($temp_timezone);

                        $eventLearner = $event->getProvider()->getPersons()[0]->getLearners()[0];
                        $eventLearnerId = $eventLearner->getId();

                        $user = $this->get('security.token_storage')->getToken()->getUser();
                        $userLearner = $user->getPerson()->getLearners()[0];

                        $isEventOwner = false;  
                        if ($eventLearnerId == $learner->getId()) {
                            $isEventOwner = true;
                        }

                        $ElapsedTimeText = $this->forward('AppBundle:Event:getElapsedTimeText', ['timestamp' => $timeTag])->getContent();

                        $isForEventPage = false;

                        $Reply = $this->renderView( ':feed:feed_show_reply.html.twig', [
                            'userLearner' => $userLearner,
                            'learner' => $learner,
                            'event' => $event,
                            'reply_text' => $reply_text,
                            'isEventOwner' => $isEventOwner,
                            'commentID' => strval($feedReplyEvent->getId()),
                            'activityID' => $activity_id,
                            'primaryCommentID' => $primary_comment_id,
                            'elapsedTimeText' => $ElapsedTimeText,
                            'timetag' => $timeTag->format(DateTime::ISO8601),
                            'client_timezone' => $client_timezone,
                            'timezone_name' => $timezoneName,
                            'isForEventPage' => $isForEventPage
                        ] );
                        $replyShownCount++;
                        array_push($ReplyList, $Reply);
                        array_push($ReplyIdList, strval($feedReplyEvent->getId()));
                    }                     
                }   

                $isEndOfReply = false;
                if ( $replyCount <= $replyPerRequest ) {
                    $isEndOfReply = true;                    
                } 

                $returnValues = [
                    'replyOffsetId' => $replyOffsetId,
                    //'Comments' => $Comments,
                    'ReplyList' => $ReplyList,
                    'ReplyIdList' => $ReplyIdList,
                    'replyShownCount' => $replyShownCount,
                    'isEndOfReply' => $isEndOfReply,
                ];
            } else {
                $returnValues = [
                    'replyOffsetId' => $replyOffsetId,
                    //'Comments' => '',
                    'ReplyList' => null,
                    'ReplyIdList' => null,
                    'replyShownCount' => 0,
                    'isEndOfReply' => true,
                ];
            }

            $returnValues['status'] = 'OK';
            $response = new Response(json_encode($returnValues));
            $response->headers->set('Content-Type', 'application/json');
            return $response;
        }

        $response = new Response(json_encode(['status' => 'ERROR']));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    /**
     * @return boolean
     */
    public function feedAddPostToStreamAction(  Provider $provider,  Event $event, bool $isUpdate = false )
    {
        $feedAddPostEventRepository = $this->getDoctrine()->getRepository(FeedAddPostEvent::class);
        $feedAddPostEvent = $feedAddPostEventRepository->findOneBy([
            'provider' => $provider,
            'event' => $event,
        ]);

        $isNewPost = false;
        if ( (!count($feedAddPostEvent)) || ($isUpdate) ) {
            $isNewPost = true;
            $em = $this->getDoctrine()->getManager();
            $feedAddPostEvent = new FeedAddPostEvent();
            $feedAddPostEvent
                ->setProvider($provider)
                ->setEvent($event)
                ->setPushedToGetstream(false);
            $em->persist($feedAddPostEvent);
            $em->flush();
            $em->refresh($feedAddPostEvent);
        } /*else {
            if ($isUpdate) {
                $em = $this->getDoctrine()->getManager();
                $feedAddPostEvent->setPushedToGetstream(false);
                $em->persist($feedAddPostEvent);
                $em->flush();
                $em->refresh($feedAddPostEvent);
            }
        }*/

        if (!$feedAddPostEvent->getPushedToGetstream()) {
            $this->addPost_PushToGetStreamAction($feedAddPostEvent);
        }
        return $isNewPost;
    }

    /**
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @param $event \AppBundle\Entity\Event
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/member/feed/show/page", name="knoitall_show_feed_page")
     * @ParamConverter("event", class="AppBundle\Entity\Event", isOptional="true")
     */
    public function feedPageAction( Request $request, Event $event = null )
    {   
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        $providers = $user->getPerson()->getProviders();
        if( ! count($providers) ) {
            /* Create Provider Automatically */
            // $this->checkAndCreateProviderProfileAction();
            return $this->redirectToRoute('knoitall_provider_profile_wizard');
        }  
        $provider = $providers[0];

        $learners = $user->getPerson()->getLearners();
        if( ! count($learners) ) {
            /* Create Learner Automatically */
            // $learner = $this->createLearnerProfileAction();
            return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
        }  
        $learner = $learners[0];
        
        $event2 = $event;
        if( ! $event ) {
            /* TODO: get the current profile (from session) */
            $event = new Event();
            $event->setProvider( $provider );

            $event2 = new Event();
            $event2->setProvider( $provider );
        }        
        //$event2 = $event;

        // to Correct what is in event constructor
        $event->setDurationTimeUnit(null);

        // $this->forward('AppBundle:FileUpload:delete_Event_UnusedCkEditorImage', [ 'hash' => $event->getHash() ]);            

        $eventFormatRepository = $this->getDoctrine()->getRepository('AppBundle:EventFormat');
        $eventFormats = $eventFormatRepository->findBy(['listgroup' => 'post']);
        $form = $this->createForm(
            EventTypeForPost::class,
            $event,
            ['eventFormatSection' => 'Generic', 'eventFormats' => $eventFormats]
        );

        // if ($request->request->has("form")) { 
        $form->handleRequest($request);

        // if ($form->get('save')->isClicked() and $form->isValid()) {
        if( $form->isSubmitted() and $form->isValid() ) {
            /** @var Event $event */
            $event = $form->getData();
            $em = $this->getDoctrine()->getManager();
            $em->persist( $event );
            $em->flush();

            /*
             * add taxonomies referenced by new event to the taxonomies explicitly declared for the provider
             */
            $provider = $event->getProvider();
            $taxonomies = $provider->getTaxonomies();
            /** @var Event $event */
            foreach( $event->getTaxonomies() as $eventTaxonomy ) {
                if( !$taxonomies->contains($eventTaxonomy) ) {
                    $provider->addTaxonomy($eventTaxonomy);
                }                
            } 
            $em->persist( $provider );
            $em->flush();

            $this->forward('AppBundle:FileUpload:add_CkEditorImageCheckingData', [ 'entity' => 'event', 'hash' => $event->getHash() ]);

            $this->feedAddPostToStreamAction( $provider, $event );
            return $this->redirectToRoute('knoitall_show_feed_page'); //, ['id' => $event->getId()]);
        }

        // List Generic Section

        $eventFormatToSectionList2 = array();
        $eventFormatRepository2 = $this->getDoctrine()->getRepository('AppBundle:EventFormat');
        //$eventFormats2 = $eventFormatRepository2->findBy(['listgroup' => 'sell']);
        $eventFormats2 = $eventFormatRepository2->findBy(array('id' => array(318,320,327,329)));        
        foreach($eventFormats2 as $eventFormatItem2) {
            array_push($eventFormatToSectionList2,$eventFormatItem2->getEventFormatSection()->getDescription()); 
        }

        $locationRepository = $this->getDoctrine()->getRepository('AppBundle:Location');
        $locations = $locationRepository->findBy(array('provider' => $provider));        

        $currentLocation = $event2->getLocation();
        if (($currentLocation != null) && (!in_array($currentLocation, $locations))) {
            array_unshift($locations, $currentLocation);
        }

        $locationName = array();
        $locationType = array();
        $locationDesc = array();        
        $locationCity = array();
        $locationState = array();
        $locationStreet = array();
        $locationZip = array();
        $locationShowMap = array();
        $locationLatitude = array();
        $locationLongitude = array();        

        foreach($locations as $location) {
            $tempId = strval($location->getId());
            $locationName[$tempId] = $location->getName();
            $locationType[$tempId] = $location->getLocationType()->getDescription();
            $locationDesc[$tempId] = $location->getDescription();
            $locationCity[$tempId] = $location->getCity();
            $locationState[$tempId] = $location->getState()->getAlpha2Code();
            $locationStreet[$tempId] = $location->getStreet();
            $locationZip[$tempId] = $location->getZip();
            $locationShowMap[$tempId] = $location->getPublished();
            $locationLatitude[$tempId] = $location->getLatitude();
            $locationLongitude[$tempId] = $location->getLongitude();
        }

        $postingDate = "";
        $expirationDate = "";
        $startDate = "";
        $endDate = "";
        if ($event2->getPostingDate()) {
            $postingDate = $event2->getPostingDate()->format("Y-m-d"); }  // format("F d, Y"); }        
        if ($event2->getExpirationDate()) {    
            $expirationDate = $event2->getExpirationDate()->format("Y-m-d"); }  // format("F d, Y"); }
        if ($event2->getStartDate()) {
            $startDate = $event2->getStartDate()->format("Y-m-d"); }  // format("F d, Y"); }
        if ($event2->getEndDate()) {
            $endDate = $event2->getEndDate()->format("Y-m-d"); }  // format("F d, Y"); }

        // $this->forward('AppBundle:FileUpload:delete_Event_UnusedCkEditorImage', [ 'hash' => $event2->getHash() ]);            
       
        $form2 = $this->createForm(
            EventTypeForList::class,
            $event2,
            ['eventFormatSection' => 'Generic', 'eventFormats' => $eventFormats2, 'locations' => $locations]
        );

        // if ($request->request->has("form2")) {
        $form2->handleRequest($request);

        // if ($form2->get('save')->isClicked() and $form2->isValid()) {
        if( $form2->isSubmitted() and $form2->isValid() ) {        
            /** @var Event $event */            
            $event2 = $form2->getData();
            $em = $this->getDoctrine()->getManager();
            $em->persist( $event2 );
            $em->flush();

            /*
             * add taxonomies referenced by new event to the taxonomies explicitly declared for the provider
             */
            $provider = $event2->getProvider();
            $taxonomies = $provider->getTaxonomies();
            /** @var Event $event */
            foreach( $event2->getTaxonomies() as $eventTaxonomy ) {
                if( !$taxonomies->contains($eventTaxonomy) ) {
                    $provider->addTaxonomy($eventTaxonomy);
                }                
            } 
            $em->persist( $provider );
            $em->flush();

            $this->forward('AppBundle:FileUpload:add_CkEditorImageCheckingData', [ 'entity' => 'event', 'hash' => $event2->getHash() ]);
            
            $this->feedAddPostToStreamAction( $provider, $event2 ); 
            return $this->redirectToRoute('knoitall_show_feed_page'); //, ['id' => $event2->getId()]); 
        }

        //$learner = $learnerRepository->findOneBy( ['person' => $user->getPerson()] );
        $feedChannel = "learner_feed";
        $feedId = $learner->getId();

        /*$getstream_key = $this->getParameter('getstream_key');
        $getstream_secret = $this->getParameter('getstream_secret');
        $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );
        $activityFeed = $client->feed($feedChannel, strval($feedId));
        $activityFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));
        $activities = $activityFeed->getActivities(0,20);*/

        return $this->render( 'feed/feed_page.html.twig', ['form' => $form->createView(), 'form2' => $form2->createView(), 'event' => $event, 'event2' => $event2,
            'eventFormatToSectionList2' => $eventFormatToSectionList2,
            'postingDate' => $postingDate, 'expirationDate' => $expirationDate, 
            'startDate' => $startDate, 'endDate' => $endDate, 
            'feedChannel' => $feedChannel, 'feedId' => $feedId, 'learner' => $learner, 
            'locationName' => $locationName, 'locationType' => $locationType, 
            'locationDesc' => $locationDesc, 'locationCity' => $locationCity, 
            'locationState' => $locationState, 'locationStreet' => $locationStreet, 
            'locationZip' => $locationZip, 'locationShowMap' => $locationShowMap, 
            'locationLatitude' => $locationLatitude, 'locationLongitude' => $locationLongitude,
            //, 'activities' => $activities
        ] );
    }


    /**
     * @Route("/member/feed/erase_all_feed_database", name="knoitall_feed_erase_database")
     */
    public function eraseAllFeedDatabaseAction(Request $request)
    {
        // $em = $this->getDoctrine()->getManager();

        // Delete Follow Table (Follower-Followee data) in database

        /* $learnerRepository = $this->getDoctrine()->getRepository(Learner::class);
        $learners = $learnerRepository->findAll();
        foreach( $learners as $learner ) {
            $followees = $learner->getFollowees();
            foreach( $followees as $followee ) {
                $learner->removeFollowee($followee);
                $em->persist($learner);
            }
        }
        $em->flush();

        $feedFollowProviderRepository = $this->getDoctrine()->getRepository(FeedFollowProvider::class);
        $feedFollowProviders = $feedFollowProviderRepository->findAll();
        foreach ( $feedFollowProviders as $feedFollowProvider ) { 
            $em->remove($feedFollowProvider);
        }
        $em->flush();

        $feedLikeEventRepository = $this->getDoctrine()->getRepository(FeedLikeEvent::class);
        $feedLikeEvents = $feedLikeEventRepository->findAll();
        foreach ( $feedLikeEvents as $feedLikeEvent ) { 
            $em->remove($feedLikeEvent);
        }
        $em->flush();

        $feedCommentEventRepository = $this->getDoctrine()->getRepository(FeedCommentEvent::class);
        $feedCommentEvents = $feedCommentEventRepository->findAll();
        foreach ( $feedCommentEvents as $feedCommentEvent ) { 
            $em->remove($feedCommentEvent);
        }
        $em->flush();

        $feedShareEventRepository = $this->getDoctrine()->getRepository(FeedShareEvent::class);
        $feedShareEvents = $feedShareEventRepository->findAll();
        foreach ( $feedShareEvents as $feedShareEvent ) { 
            $em->remove($feedShareEvent);
        }
        $em->flush();        

        $feedAddPostEventRepository = $this->getDoctrine()->getRepository(FeedAddPostEvent::class);
        $feedAddPostEvents = $feedAddPostEventRepository->findAll();
        foreach ( $feedAddPostEvents as $$feedAddPostEvent ) { 
            $em->remove($feedAddPostEvent);
        }
        $em->flush(); */
    }

    /**
     * @Route("/member/feed/delete_learner_feed_data/{learner}", name="knoitall_delete_feed_data")
     */
    public function deleteLearnerFeedDataAction(Request $request, $learner = null)
    {
    }
}
<?php

namespace AppBundle\Controller;

require_once __DIR__ . '/../../../vendor/autoload.php';

use AppBundle\Entity\FeedCommentEvent;
use AppBundle\Entity\FeedFollowProvider;
use AppBundle\Entity\FeedLikeEvent;
use AppBundle\Entity\FeedShareEvent;
use AppBundle\Entity\FeedAddPostEvent;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use AppBundle\Entity\User;
use AppBundle\Entity\Person;
use AppBundle\Entity\Learner;
use AppBundle\Entity\Provider;
use AppBundle\Entity\Event;
use AppBundle\Form\EventTypeForPost;
use AppBundle\Form\EventTypeForList;
use AppBundle\Form\EventTypeForAd;
use \DateTime;

class NotificationController extends Controller
{
    /**
     * @param $activityGroup
     * @return Response
     */
    public function showPerActivityGroupAction( $activityGroup, $client_timezone, $isForSeeAllPage)
    {
        /** @var User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        $person = $user->getPerson();
        $userLearner = $person->getLearners()[0];
        $userProvider = $user->getPerson()->getProviders()[0];

        $providerRepository = $this->getDoctrine()->getRepository(Provider::class);
        $learnerRepository = $this->getDoctrine()->getRepository(Learner::class);
        $eventRepository = $this->getDoctrine()->getRepository(Event::class);

        /** @var Learner $learner */
        $learner = null;
        $firstLearner = null;
        /** @var Provider $provider */
        $provider = null;
        /** @var Event $event */
        $event = null;        

        $temp_timezone = date_default_timezone_get();
        date_default_timezone_set($client_timezone);
        $timezoneName = date('T');
        date_default_timezone_set($temp_timezone);        
        //date_default_timezone_set('Europe/London');

        /* Prepare Notification Data */
        $timeTag = date_create($activityGroup['updated_at'], timezone_open('UTC'));
        $verb = $activityGroup['verb'];
        $activityCount = $activityGroup['activity_count'];
        $actorCount = $activityGroup['actor_count'];        
        $notificationText = "";
        $eventName = "";

        if (($verb != "follow") && ($verb != "unfollow")) {
            $matches = [];
            if( preg_match("/^event:(\d+)$/", $activityGroup['activities'][0]['object'], $matches ) ) {
                $event_id = $matches[1];
                $event = $eventRepository->find($event_id);
                if ($event != null) {
                    $eventName = $event->getTitle();
                } else {
                    return "";
                }
            }
        }        

        if ($verb == 'addPost') {
            $matches = [];
            if( preg_match("/^provider:(\d+)$/", $activityGroup['activities'][0]['actor'], $matches ) ) {
                $provider_id = $matches[1];
                $provider = $providerRepository->find($provider_id);
                $providerName = $provider->getTitle();
            }            

            if ($activityCount == 1) {
                $notificationText = "<strong>" . $providerName . "</strong> published a post: <strong>" . $eventName . "</strong>";
            } else {
                $notificationText = "<strong>" . $providerName . "</strong> published " . strval($activityCount) . " posts: <strong>" . $eventName . "</strong>" . " and " . strval($activityCount - 1)  . " other ";
                if (($activityCount - 1) > 1) {
                    $notificationText = $notificationText . "events.";
                } else {
                    $notificationText = $notificationText . "event.";
                } 
            }
        } else {
            $matches = [];
            if( preg_match("/^learner:(\d+)$/", $activityGroup['activities'][0]['actor'], $matches ) ) {
                $learner_id = $matches[1];
                $learner = $learnerRepository->find($learner_id);
                $firstLearner = $learner;
                $actorName1 = $learner->getTitle();                
                $actorLearnerId_1 = $learner_id;
            }
            $notificationText = "<strong>" . $actorName1 . "</strong>";

            if ($actorCount > 1) {
                for ($count = 1; $count < $activityCount; $count++) {
                    $matches = [];
                    if( preg_match("/^learner:(\d+)$/", $activityGroup['activities'][$count]['actor'], $matches ) ) {
                        $learner_id = $matches[1];
                        $learner = $learnerRepository->find($learner_id);
                        $tempName = $learner->getTitle();
                        if ($learner_id != $actorLearnerId_1) {
                            $actorName2 = $tempName;
                            $actorLearnerId_2 = $learner_id;
                            $count = $activityCount;
                        }
                    }
                }
                if ($actorCount == 2) {
                    $notificationText = $notificationText . " and <strong>" . $actorName2 . "</strong>";
                } else {
                    $notificationText = $notificationText . ", <strong>" . $actorName2 . "</strong>";
                }
            }
            if ($actorCount > 2) {
                for ($count = 2; $count < $activityCount; $count++) {
                    $matches = [];
                    if( preg_match("/^learner:(\d+)$/", $activityGroup['activities'][$count]['actor'], $matches ) ) {
                        $learner_id = $matches[1];
                        $learner = $learnerRepository->find($learner_id);
                        $tempName = $learner->getTitle();
                        if (($learner_id != $actorLearnerId_1) && ($learner_id != $actorLearnerId_2)) {
                            $actorName3 = $tempName;
                            $count = $activityCount;
                        }
                    }
                }
                if ($actorCount == 3) {
                    $notificationText = $notificationText . ", and <strong>" . $actorName3 . "</strong>";
                } else {
                    $notificationText = $notificationText . ", and " . strval($actorCount - 2) . " others";
                }
            }
            switch ($verb) {
                case 'like': $pastVerb = " liked "; break;
                case 'comment': $pastVerb = " commented on "; break;
                case 'reply': $pastVerb = " replied to "; break;
                case 'share': $pastVerb = " shared "; break;
                case 'follow': $pastVerb = " followed "; break;
                case 'unfollow': $pastVerb = " unfollowed "; break;
            }            
            if (($verb == "follow") || ($verb == "unfollow")) {
                $notificationText = $notificationText . $pastVerb . "<strong>You</strong>.";                
            } else {
                if ($verb == "reply") {
                    if ($activityCount == 1) {
                        $notificationText = $notificationText . $pastVerb . "your comment.";
                    } else {
                        $notificationText = $notificationText . $pastVerb . "your comments.";
                    }
                } else {
                    $notificationText = $notificationText . $pastVerb . "your event: <strong>" . $eventName . "</strong>.";
                }
            }
        }

        $ElapsedTimeText = $this->forward('AppBundle:Event:getElapsedTimeText', ['timestamp' => $timeTag])->getContent();

        if ($isForSeeAllPage) {
            return $this->renderView( ':notification:notification_activity_list_group_in_page.html.twig', [
                'verb' => $verb,
                'learner' => $firstLearner,
                'provider' => $provider,
                'event' => $event,
                'elapsedTimeText' => $ElapsedTimeText,
                'timetag' => $timeTag->format(DateTime::ISO8601),
                'timezone_name' => $timezoneName,
                'client_timezone' => $client_timezone,
                'notification_text' => $notificationText,
                'isRead' => $activityGroup['is_read'],
                'completeActivityGroupID' => $activityGroup['id'],
                'activityGroupID' => substr($activityGroup['id'],0,36), // Only use Number
            ]);
        } else {
            return $this->renderView( ':notification:notification_activity_list_group_in_popover.html.twig', [
                'verb' => $verb,
                'learner' => $firstLearner,
                'provider' => $provider,
                'event' => $event,
                'elapsedTimeText' => $ElapsedTimeText,
                'timetag' => $timeTag->format(DateTime::ISO8601),
                'timezone_name' => $timezoneName,
                'client_timezone' => $client_timezone,
                'notification_text' => $notificationText,
                'isRead' => $activityGroup['is_read'],
                'completeActivityGroupID' => $activityGroup['id'],
                'activityGroupID' => substr($activityGroup['id'],0,36), // Only use Number
            ]);
        }
    }

    /**
     * @Route("/member/notification/show/activities_group", name="knoitall_notification_show_activities_group")
     */
    public function showActivitiesGroupAction(Request $request)
    {
        $data = null;
        if( $content = $request->getContent() ) {
            $data = json_decode( $content, true );
        }

        $user = $this->get('security.token_storage')->getToken()->getUser();
        $learner = $user->getPerson()->getLearners()[0];
        $feed_id = $learner->getId();

        if( $data ) {
            // $feed_channel = ( isset($data['feed_channel']) ? $data['feed_channel'] : null );
            $is_update = ( isset($data['is_update']) ? $data['is_update'] : null );
            $is_in_see_all_page = ( isset($data['is_in_see_all_page']) ? $data['is_in_see_all_page'] : null );
            $is_popover_request = ( isset($data['is_popover_request']) ? $data['is_popover_request'] : null );            
            $first_notification_id = ( isset($data['first_notification_id']) ? $data['first_notification_id'] : null );
            $last_notification_id = ( isset($data['last_notification_id']) ? $data['last_notification_id'] : null );
            $client_timezone = ( isset($data['client_timezone']) ? $data['client_timezone'] : null );
            
            $getstream_key = $this->getParameter('getstream_key');
            $getstream_secret = $this->getParameter('getstream_secret');
            $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );
            $notificationFeed = $client->feed('notification', strval($feed_id));
            $notificationFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));
            $results = null;
            $isEndOfNotification = false;
            $activityGroupIDList = null;
            $unseenCount = 0;
            $TotalFeedShown = 0;
            $notificationCount = 0;
            $notificationContentInPage = "";
            $notificationContentInPopover = "";

            if ($is_popover_request) {
                $ActivitiesPerRequest = 12;
            } else {
                $ActivitiesPerRequest = 22;
            }
            $TestRequest = $ActivitiesPerRequest + 1;

    GetActivitiesGroupLoop:

            if ($is_update) { 
                if ($first_notification_id != 'first') {
                    $options = ['id_gt' => $first_notification_id];
                    $results = $notificationFeed->getActivities(0, $TestRequest, $options);
                } else {
                    $options = ['mark_seen' => true];
                    $results = $notificationFeed->getActivities(0, $TestRequest, $options);
                }
            } else {
                if ($last_notification_id != 'end') {
                    $options = ['id_lt' => $last_notification_id];
                    $results = $notificationFeed->getActivities(0, $TestRequest, $options);
                } else {
                    $options = ['mark_seen' => true];
                    $results = $notificationFeed->getActivities(0, $TestRequest, $options);
                }                                
            }
            
            $APIcallSuccess = false; 
            if (count($results)) {
                $activitiesGroup = &$results['results'];
                //$unseenCount = $results['unseen'];
                $notificationCount = count($activitiesGroup);

                $APIcallSuccess = true; 
            }

            if ($notificationCount <= $ActivitiesPerRequest) {
                $isEndOfNotification = true;
            }
            if ($notificationCount == $TestRequest) {
                array_splice($activitiesGroup, ($TestRequest-1), 1);
                $notificationCount = $notificationCount -1;    
                $isEndOfNotification = false;
            }
            
            if ($notificationCount > 0) {                
                if ($is_update) { 
                    if ($last_notification_id == 'end') {
                        $last_notification_id = $activitiesGroup[$notificationCount-1]['id'];
                    }                
                    $first_notification_id = $activitiesGroup[0]['id'];
                } else {
                    if ($first_notification_id == 'first') {
                        $first_notification_id = $activitiesGroup[0]['id'];
                    }                
                    $last_notification_id = $activitiesGroup[$notificationCount-1]['id'];
                }                

                $activityGroupIDList = array();
                foreach ( $activitiesGroup as $activityGroup ) { 
                    $feedShownInPopover = $this->showPerActivityGroupAction( $activityGroup, $client_timezone, false );
                    if ($is_in_see_all_page) {
                        $feedShownInPage = $this->showPerActivityGroupAction( $activityGroup, $client_timezone, true );
                    }
                    if ($feedShownInPopover != "Hidden Notification") {
                        $notificationContentInPopover = $notificationContentInPopover . $feedShownInPopover;
                        if ($is_in_see_all_page) {
                            $notificationContentInPage = $notificationContentInPage . $feedShownInPage;
                        }
                        $activityGroupID = substr($activityGroup['id'],0,36); // Only use Number
                        array_push($activityGroupIDList,$activityGroupID);
                        $TotalFeedShown = $TotalFeedShown + 1;
                    }
                }

                if (($TotalFeedShown < 4) && (!$isEndOfNotification)) {
                   $notificationCount = 0;
                   goto GetActivitiesGroupLoop;   
                }

                $returnValues = [
                    //'unseenCount' => $unseenCount,
                    'notificationCount' => $notificationCount,
                    'lastFeedShownCount' => $TotalFeedShown,
                    'notificationContentInPopover' => $notificationContentInPopover,
                    'notificationContentInPage' => $notificationContentInPage,
                    'activityGroupIDList' => $activityGroupIDList,
                    'firstNotificationId' => $first_notification_id,
                    'lastNotificationId' => $last_notification_id,
                    'isEndOfNotification' => $isEndOfNotification
                ];
            } else {
                $notificationCount = 0;

                $returnValues = [ 
                    //'unseenCount' => $unseenCount,                
                    'notificationCount' => $notificationCount,
                    'lastFeedShownCount' => $TotalFeedShown,
                    'notificationContentInPopover' => $notificationContentInPopover,
                    'notificationContentInPage' => $notificationContentInPage,
                    'activityGroupIDList' => $activityGroupIDList,
                    'firstNotificationId' => $first_notification_id,
                    'lastNotificationId' => $last_notification_id,
                    'isEndOfNotification' => $isEndOfNotification
                ];
            }

            $returnValues['status'] = 'OK';
            $response = new Response(json_encode($returnValues));
            $response->headers->set('Content-Type', 'application/json');
            return $response;
        }

        $response = new Response(json_encode(['status' => 'ERROR']));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    /**
     * @Route("/notification/get_unseen_count", name="knoitall_notification_get_unseen_count")
     */
    public function getUnseenCountNotificationAction(Request $request)
    {        
        $user = $this->get('security.token_storage')->getToken()->getUser();
        $learner = $user->getPerson()->getLearners()[0];
        $feed_id = $learner->getId();

        $getstream_key = $this->getParameter('getstream_key');
        $getstream_secret = $this->getParameter('getstream_secret');
        $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );
        $notificationFeed = $client->feed('notification', strval($feed_id));
        $notificationFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));

        $unseenCount = $notificationFeed->getActivities(0,1)['unseen'];

        $returnValues = [
            'unseenCount' => $unseenCount,
        ];

        $returnValues['status'] = 'OK';
        $response = new Response(json_encode($returnValues));
        $response->headers->set('Content-Type', 'application/json');        
        return $response;            
        
        /*$response = new Response(json_encode(['status' => 'ERROR']));
        $response->headers->set('Content-Type', 'application/json');
        return $response;*/
    }

    /**
     * @Route("/notification/mark_all_as_read_or_unread", name="knoitall_notification_mark_as_read_or_unread")
     */
    public function markAllAsReadOrUnreadNotificationAction(Request $request)
    {        
        $data = null;
        if( $content = $request->getContent() ) {
            $data = json_decode( $content, true );
        }

        if( $data ) {
            $isMarkAsRead = ( isset($data['is_mark_as_read']) ? $data['is_mark_as_read'] : null );
            $activityGroupID = ( isset($data['activity_group_id']) ? $data['activity_group_id'] : null );
         
            $user = $this->get('security.token_storage')->getToken()->getUser();
            $learner = $user->getPerson()->getLearners()[0];
            $feed_id = $learner->getId();
 
            $getstream_key = $this->getParameter('getstream_key');
            $getstream_secret = $this->getParameter('getstream_secret');
            $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );
            $notificationFeed = $client->feed('notification', strval($feed_id));
            $notificationFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));

            $options = [ 'id_gte' => $activityGroupID, 'mark_read' => $activityGroupID ];        
            $isRead = $notificationFeed->getActivities(0,1,$options)['results'][0]['is_read'];

            if ($isRead == $isMarkAsRead) {
                $returnValues['status'] = 'OK';
                $response = new Response(json_encode($returnValues));
                $response->headers->set('Content-Type', 'application/json');
                return $response;            
            } 
        }

        $response = new Response(json_encode(['status' => 'ERROR']));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }    

    /**
     * @Route("/notification/mark_all_as_read", name="knoitall_notification_mark_all_as_read")
     */
    public function markAllAsReadNotificationAction(Request $request)
    {        
        $user = $this->get('security.token_storage')->getToken()->getUser();
        $learner = $user->getPerson()->getLearners()[0];
        $feed_id = $learner->getId();

        $getstream_key = $this->getParameter('getstream_key');
        $getstream_secret = $this->getParameter('getstream_secret');
        $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );
        $notificationFeed = $client->feed('notification', strval($feed_id));
        $notificationFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));

        $options = ['mark_read' => true ];
        $unreadCount = $notificationFeed->getActivities(0,1,$options)['unread'];

        /*$returnValues = [
            'unseenCount' => $unseenCount,
        ];*/

        if ($unreadCount == 0) {
            $returnValues['status'] = 'OK';
            $response = new Response(json_encode($returnValues));
            $response->headers->set('Content-Type', 'application/json');        
            return $response;            
        } 

        $response = new Response(json_encode(['status' => 'ERROR']));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }    

    /**
     * @Route("/notification/see/all", name="knoitall_notification_see_all_page")
     */
    public function seeAllNotificationPageAction()
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        $user = $this->get('security.token_storage')->getToken()->getUser();

        $learners = $user->getPerson()->getLearners();
        if( ! count($learners) ) {
            return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
        }  
        $learner = $learners[0];
        $feed_id = $learner->getId();

        $getstream_key = $this->getParameter('getstream_key');
        $getstream_secret = $this->getParameter('getstream_secret');
        $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );
        $notificationFeed = $client->feed('notification', strval($feed_id));
        $notificationFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));

        $activitiesGroup = $notificationFeed->getActivities(0,1);

        return $this->render('notification/notification_see_all_page.html.twig', ['activitiesGroup' => $activitiesGroup]
        );
    }

    /**
     * @param Learner $learner
     * @return Provider
     */
    public function getProviderFromLearner(Learner $learner)
    {        
        $person = $learner->getPerson(); 
        $provider = $person->getProviders()[0];
        return $provider;
    }

    /**
     * @param $individualFeed
     * @return Response
     */
    public function showPerIndividualFeedAction( $feedActivity, $client_timezone, &$mapCanvasId, &$latitude, &$longitude, &$mapLabel )
    {
        /** @var User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        $person = $user->getPerson();
        $userLearner = $person->getLearners()[0];
        $userProvider = $user->getPerson()->getProviders()[0];

        $providerRepository = $this->getDoctrine()->getRepository(Provider::class);
        $learnerRepository = $this->getDoctrine()->getRepository(Learner::class);
        $eventRepository = $this->getDoctrine()->getRepository(Event::class);

        /** @var Provider $provider */
        $provider = null;
        /** @var Event $event */
        $event = null;

        $temp_timezone = date_default_timezone_get();
        date_default_timezone_set($client_timezone);
        $timezoneName = date('T');
        date_default_timezone_set($temp_timezone);
        //date_default_timezone_set('Europe/London');

        $timeTag = date_create($feedActivity['time'], timezone_open('UTC'));
        $ElapsedTimeText = $this->forward('AppBundle:Event:getElapsedTimeText', ['timestamp' => $timeTag])->getContent();

        if( ( $feedActivity['verb'] == 'follow' ) || ( $feedActivity['verb'] == 'unfollow' ) ) {
            $matches = [];
            if( preg_match("/^learner:(\d+)$/", $feedActivity['actor'], $matches ) ) {
                $learner_id = $matches[1];
                $learner = $learnerRepository->find($learner_id);
            }

            $matches = [];
            if( preg_match("/^provider:(\d+)$/", $feedActivity['object'], $matches ) ) {
                $provider_id = $matches[1];
                $provider = $providerRepository->find($provider_id);
            }

            return $this->renderView( ':feed:feed_activity_follow_unfollow.html.twig', [
                'verb' => $feedActivity['verb'],
                'learner' => $learner,
                'provider' => $provider,
                'elapsedTimeText' => $ElapsedTimeText,
                'timetag' => $timeTag->format(DateTime::ISO8601),
                'client_timezone' => $client_timezone,
                'timezone_name' => $timezoneName
            ] );

        } elseif( $feedActivity['verb'] == 'like' ) {

            $matches = [];
            if( preg_match("/^learner:(\d+)$/", $feedActivity['actor'], $matches ) ) {
                $learner_id = $matches[1];
                $learner = $learnerRepository->find($learner_id);
            }

            $matches = [];
            if( preg_match("/^event:(\d+)$/", $feedActivity['object'], $matches ) ) {
                $event_id = $matches[1];
                $event = $eventRepository->find($event_id);
            }

            if ($event == null) {
                return "";
            }

            $UserIsEventOwner = false;   
            $LearnerIsEventOwner = false; 
            $eventProviderId = $event->getProvider()->getId();
            if ($userProvider->getId() == $eventProviderId) {
                $UserIsEventOwner = true;   
            }

            $learnerProvider = $this->getProviderFromLearner($learner);
            if ($learnerProvider) {
                $learnerProviderId = $learnerProvider->getId();
                if ($eventProviderId == $learnerProviderId) {
                    $LearnerIsEventOwner = true;
                }
            }            
            
            return $this->renderView( ':feed:feed_activity_like.html.twig', [
                'verb' => $feedActivity['verb'],
                'learner' => $learner,
                'event' => $event,
                'elapsedTimeText' => $ElapsedTimeText,
                'timetag' => $timeTag->format(DateTime::ISO8601),
                'client_timezone' => $client_timezone,
                'timezone_name' => $timezoneName,
                'UserIsEventOwner' => $UserIsEventOwner,
                'LearnerIsEventOwner' => $LearnerIsEventOwner,
            ]);

        } elseif( $feedActivity['verb'] == 'comment' ) {

            $matches = [];
            if( preg_match("/^learner:(\d+)$/", $feedActivity['actor'], $matches ) ) {
                $learner_id = $matches[1];
                $learner = $learnerRepository->find($learner_id);
            }

            $matches = [];
            if( preg_match("/^event:(\d+)$/", $feedActivity['object'], $matches ) ) {
                $event_id = $matches[1];
                $event = $eventRepository->find($event_id);
            }

            $matches = [];
            if( preg_match("/^comment:(\d+)$/", $feedActivity['foreign_id'], $matches ) ) {
                $comment_id = $matches[1];
            }

            if ($event == null) {
                return "";
            }

            $UserIsEventOwner = false;   
            $LearnerIsEventOwner = false; 
            $eventProviderId = $event->getProvider()->getId();
            if ($userProvider->getId() == $eventProviderId) {
                $UserIsEventOwner = true;   
            }

            $learnerProvider = $this->getProviderFromLearner($learner);
            if ($learnerProvider) {
                $learnerProviderId = $learnerProvider->getId();
                if ($eventProviderId == $learnerProviderId) {
                    $LearnerIsEventOwner = true;
                }
            } 

            $commentLink = "#Main_CommentTopPlace-" . strval($comment_id);

            return $this->renderView( ':feed:feed_activity_comment.html.twig', [
                'verb' => $feedActivity['verb'],
                'learner' => $learner,
                'event' => $event,
                'comment' => $feedActivity['comment'],
                'commentLink' => $commentLink,
                'elapsedTimeText' => $ElapsedTimeText,
                'timetag' => $timeTag->format(DateTime::ISO8601),
                'client_timezone' => $client_timezone,
                'timezone_name' => $timezoneName,
                'UserIsEventOwner' => $UserIsEventOwner,
                'LearnerIsEventOwner' => $LearnerIsEventOwner,
            ]);

        } elseif( $feedActivity['verb'] == 'reply' ) {

            /* 'actor' => 'learner:'.strval($learner_id),
            'verb' => 'reply',
            'object' => 'replyTo:'.strval($replyToId),
            'event' => 'event:'.strval($event_id),
            'comment' => $comment,
            'reply_from' => strval($primaryCommentId),        
            'reply_to' => strval($destCommentId),
            //'to' => ['notification:'.strval($event_provider_id)], 
            'foreign_id' => 'comment:'.strval($feedCommentEvent->getId()),
            'time' => $timeTag->format(DateTime::ISO8601), */
            
            $matches = [];
            if( preg_match("/^learner:(\d+)$/", $feedActivity['actor'], $matches ) ) {
                $learner_id = $matches[1];
                $learner = $learnerRepository->find($learner_id);
            }

            $matches = [];
            if( preg_match("/^replyTo:(\d+)$/", $feedActivity['object'], $matches ) ) {
                $replyTo_id = $matches[1];
                $replyToLearner = $learnerRepository->find($replyTo_id);
            }

            $matches = [];
            if( preg_match("/^event:(\d+)$/", $feedActivity['event'], $matches ) ) {
                $event_id = $matches[1];
                $event = $eventRepository->find($event_id);
            }

            $matches = [];
            if( preg_match("/^comment:(\d+)$/", $feedActivity['foreign_id'], $matches ) ) {
                $reply_id = $matches[1];
            }

            if ($event == null) {
                return "";
            }
            
            $UserIsReplyToLearner = false;               
            if ($userLearner == $replyToLearner) {
                $UserIsReplyToLearner = true;   
            }
            
            $primaryCommentId = intval($feedActivity['reply_from']);
            $destCommentId = intval($feedActivity['reply_to']); 

            $feedCommentEventRepository = $this->getDoctrine()->getRepository(FeedCommentEvent::class);
            $primaryFeedCommentEvent = $feedCommentEventRepository->find($primaryCommentId);
            $destFeedCommentEvent = null;
            if ($destCommentId) {
                $destFeedCommentEvent = $feedCommentEventRepository->find($destCommentId);
            }

            if ( $primaryFeedCommentEvent && !$destFeedCommentEvent ) {
                $prevComment = $primaryFeedCommentEvent->getCommentText();
                $prevCommentLink = "#Main_CommentTopPlace-" . strval($primaryCommentId);
            } 
            if ( $primaryFeedCommentEvent && $destFeedCommentEvent ) {
                $prevComment = $destFeedCommentEvent->getCommentText();
                $prevCommentLink = "#Reply_CommentTopPlace-" . strval($destCommentId);
            }

            $UserIsEventOwner = false;   
            $LearnerIsEventOwner = false; 
            $eventProviderId = $event->getProvider()->getId();
            if ($userProvider->getId() == $eventProviderId) {
                $UserIsEventOwner = true;   
            }

            $learnerProvider = $this->getProviderFromLearner($learner);
            if ($learnerProvider) {
                $learnerProviderId = $learnerProvider->getId();
                if ($eventProviderId == $learnerProviderId) {
                    $LearnerIsEventOwner = true;
                }
            }  
            
            $LearnerIsReplyToLearner = false;
            if ($learner_id == $replyTo_id) {
                $LearnerIsReplyToLearner = true;
            }

            $replyLink = "#Reply_CommentTopPlace-" . strval($reply_id);
            
            return $this->renderView( ':feed:feed_activity_reply.html.twig', [
                'verb' => $feedActivity['verb'],
                'learner' => $learner,
                'replyToLearner' => $replyToLearner,
                'event' => $event,
                'reply' => $feedActivity['comment'],                
                'prev_comment' => $prevComment,
                'replyLink' => $replyLink,
                'prevCommentLink' => $prevCommentLink,
                'elapsedTimeText' => $ElapsedTimeText,
                'timetag' => $timeTag->format(DateTime::ISO8601),
                'client_timezone' => $client_timezone,
                'timezone_name' => $timezoneName,
                'UserIsReplyToLearner' => $UserIsReplyToLearner,
                'UserIsEventOwner' => $UserIsEventOwner,
                'LearnerIsReplyToLearner' => $LearnerIsReplyToLearner,
                'LearnerIsEventOwner' => $LearnerIsEventOwner,
            ]);        

        } elseif( $feedActivity['verb'] == 'share' ) {

            $matches = [];
            if( preg_match("/^learner:(\d+)$/", $feedActivity['actor'], $matches ) ) {
                $learner_id = $matches[1];
                $learner = $learnerRepository->find($learner_id);
            }

            $matches = [];
            if( preg_match("/^event:(\d+)$/", $feedActivity['object'], $matches ) ) {
                $event_id = $matches[1];
                $event = $eventRepository->find($event_id);
            }

            if ($event == null) {
                return "";
            }

            $UserIsEventOwner = false;   
            $LearnerIsEventOwner = false; 
            $eventProviderId = $event->getProvider()->getId();
            if ($userProvider->getId() == $eventProviderId) {
                $UserIsEventOwner = true;   
            }

            $learnerProvider = $this->getProviderFromLearner($learner);
            if ($learnerProvider) {
                $learnerProviderId = $learnerProvider->getId();
                if ($eventProviderId == $learnerProviderId) {
                    $LearnerIsEventOwner = true;
                }
            }     

            if ($event->getProvider() == $userProvider) {
                return $this->renderView( ':feed:feed_activity_shorter_share.html.twig', [
                    'verb' => $feedActivity['verb'],
                    'learner' => $learner,
                    'event' => $event,
                    'elapsedTimeText' => $ElapsedTimeText,
                    'timetag' => $timeTag->format(DateTime::ISO8601),
                    'client_timezone' => $client_timezone,
                    'timezone_name' => $timezoneName,
                    'UserIsEventOwner' => $UserIsEventOwner,
                    'LearnerIsEventOwner' => $LearnerIsEventOwner,
                ]);             
            } 

            $dow = "";
            if( $event->getMonday() ) { $dow = $dow . "Mon"; }
            if( $event->getTuesday() ) { 
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Tue"; }
            if( $event->getWednesday() ) {
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Wed"; }
            if( $event->getThursday() ) {
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Thu"; }
            if( $event->getFriday() ) {
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Fri"; }
            if( $event->getSaturday() ) {
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Sat"; }
            if( $event->getSunday() ) {
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Sun"; } 
            
            $latitude = 0;
            $longitude = 0;
            $mapLabel = "";
            $isShowLocation = "false";  
            $location = $event->getLocation();        
            if( $location ) {
                if( $location->getPublished() ) { 
                    $isShowLocation = "true";
                    $mapCanvasId = "MapCanvas-" . $feedActivity['id'];                    
                    $latitude = $location->getLatitude();
                    $longitude = $location->getLongitude();
                    $maplabel = ( $location->getName() ? $location->getName() : $event->getTitle() );
                } 
            } elseif( $event->getLocationLatitude() != 0 and $event->getLocationLongitude() != 0 ) {
                $isShowLocation = "true";
                $mapCanvasId = "MapCanvas-" . $feedActivity['id'];                    
                $latitude = $event->getLocationLatitude();
                $longitude = $event->getLocationLongitude();
                $maplabel = ( $event->getLocationName() ? $event->getLocationName() : $event->getTitle() );
            }  

            $isActivityChannel = false;
            return $this->renderView( ':feed:feed_activity_share.html.twig', [
                'verb' => $feedActivity['verb'],
                'learner' => $learner,
                'event' => $event,
                'dow' => $dow,
                'elapsedTimeText' => $ElapsedTimeText,
                'timetag' => $timeTag->format(DateTime::ISO8601),
                'client_timezone' => $client_timezone,
                'timezone_name' => $timezoneName,
                'UserIsEventOwner' => $UserIsEventOwner,
                'LearnerIsEventOwner' => $LearnerIsEventOwner,
                'userLearner' => $userLearner,
                'activityID' => $feedActivity['id'],
                'latitude' => $latitude,
                'longitude' => $longitude,
                'mapLabel' => $mapLabel,
                'isShowLocation' => $isShowLocation,
                'isActivityChannel' => $isActivityChannel
            ]);

        } elseif( $feedActivity['verb'] == 'addPost' ) {

            $matches = [];
            if( preg_match("/^provider:(\d+)$/", $feedActivity['actor'], $matches ) ) {
                $provider_id = $matches[1];
                $provider = $providerRepository->find($provider_id);
            }

            $matches = [];
            if( preg_match("/^event:(\d+)$/", $feedActivity['object'], $matches ) ) {
                $event_id = $matches[1];
                $event = $eventRepository->find($event_id);
            }

            if ($event == null) {
                return "";
            }

            $isUpdate = "false";
            /*if ($event->getTimestampAdded() != $event->getTimestampUpdated()) {
                $isUpdate = "true";
            }*/

            $dow = "";
            if( $event->getMonday() ) { $dow = $dow . "Mon"; }
            if( $event->getTuesday() ) { 
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Tue"; }
            if( $event->getWednesday() ) {
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Wed"; }
            if( $event->getThursday() ) {
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Thu"; }
            if( $event->getFriday() ) {
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Fri"; }
            if( $event->getSaturday() ) {
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Sat"; }
            if( $event->getSunday() ) {
                if($dow !== "") { $dow = $dow . ", "; }
                    $dow = $dow . "Sun"; }        

            $latitude = 0;
            $longitude = 0;
            $mapLabel = "";
            $isShowLocation = "false";
            $location = $event->getLocation();        
            if( $location ) {
                if( $location->getPublished() ) { 
                    $isShowLocation = "true";
                    $mapCanvasId = "MapCanvas-" . $feedActivity['id'];                    
                    $latitude = $location->getLatitude();
                    $longitude = $location->getLongitude();
                    $mapLabel = ( $location->getName() ? $location->getName() : $event->getTitle() );
                } 
            } elseif( $event->getLocationLatitude() != 0 and $event->getLocationLongitude() != 0 ) {
                $isShowLocation = "true";
                $mapCanvasId = "MapCanvas-" . $feedActivity['id'];                    
                $latitude = $event->getLocationLatitude();
                $longitude = $event->getLocationLongitude();
                $mapLabel = ( $event->getLocationName() ? $event->getLocationName() : $event->getTitle() );
            }                

            $isActivityChannel = false;
            return $this->renderView( ':feed:feed_activity_addpost.html.twig', [
                'verb' => $feedActivity['verb'],
                'provider' => $provider,
                'event' => $event,
                'dow' => $dow,
                'elapsedTimeText' => $ElapsedTimeText,
                'timetag' => $timeTag->format(DateTime::ISO8601),
                'client_timezone' => $client_timezone,
                'timezone_name' => $timezoneName,
                'isUpdate' => $isUpdate,
                'userLearner' => $userLearner,
                'activityID' => $feedActivity['id'],
                'latitude' => $latitude,
                'longitude' => $longitude,
                'mapLabel' => $mapLabel,
                'isShowLocation' => $isShowLocation,
                'isActivityChannel' => $isActivityChannel
            ] );

        } else {

            return "ERROR";

        }        
    }

   /**
    * @Route("member/notification/show/individual/Feed", name="knoitall_notification_show_individual_feed")
    */
    public function showIndividualFeedAction(Request $request)
    {
        $data = null;
        if( $content = $request->getContent() ) {
            $data = json_decode( $content, true );
        }

        if( $data ) {
            $group_id = ( isset($data['group_id']) ? $data['group_id'] : null );
            $client_timezone = ( isset($data['client_timezone']) ? $data['client_timezone'] : null );
            
            $user = $this->get('security.token_storage')->getToken()->getUser();
            $learner = $user->getPerson()->getLearners()[0];
            $feed_id = $learner->getId();

            $getstream_key = $this->getParameter('getstream_key');
            $getstream_secret = $this->getParameter('getstream_secret');
            $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );
            $notificationFeed = $client->feed('notification', strval($feed_id));
            $notificationFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));

            $options = [ 'id_gte' => $group_id, 'mark_read' => $group_id ];
            $results = $notificationFeed->getActivities(0,1,$options);

            $APIcallSuccess = false; 
            $individualFeedCount = 0;
            $individualFeedContent = "";
            $MapCanvasIdList = array();
            $LatitudeList = array();
            $LongitudeList = array();
            $MapLabelList = array();
            $mapCanvasCount = 0;

            if (count($results)) {                
                $individualFeedGroup = &$results['results'][0]['activities'];
                $individualFeedCount = count($individualFeedGroup);
  
                foreach ( $individualFeedGroup as $individualFeed ) { 
                    $mapCanvasId = "";
                    $latitude = 0;
                    $longitude = 0;
                    $mapLabel = "";
                    $feedShown = $this->showPerIndividualFeedAction( $individualFeed, $client_timezone, $mapCanvasId, $latitude, $longitude, $mapLabel );
                    $individualFeedContent = $individualFeedContent . $feedShown;
                    if ($mapCanvasId != "") {
                        array_push($MapCanvasIdList, $mapCanvasId);
                        array_push($LatitudeList, $latitude);
                        array_push($LongitudeList, $longitude);
                        array_push($MapLabelList, $mapLabel);
                        $mapCanvasCount++;
                    }
                }

                /*$TempContent = var_export($results, true);
                $individualFeedContent = "<h3>".$TempContent."</h3>";*/

                $returnValues = [
                    'individualFeedCount' => $individualFeedCount,
                    'individualFeedContent' => $individualFeedContent,
                    'MapCanvasIdList' => $MapCanvasIdList,
                    'LatitudeList' => $LatitudeList,
                    'LongitudeList' => $LongitudeList,
                    'MapLabelList' => $MapLabelList,
                    'mapCanvasCount' =>$mapCanvasCount
                ];

                $returnValues['status'] = 'OK';
                $response = new Response(json_encode($returnValues));
                $response->headers->set('Content-Type', 'application/json');
                return $response;
            }
        }
        $response = new Response(json_encode(['status' => 'ERROR']));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    /**
     * @Route("/notification/show/individual/{group_id}", name="knoitall_notification_show_individual_page")
     */
    public function showIndividualFeedPageAction( Request $request, $group_id = null )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }
        
        $user = $this->get('security.token_storage')->getToken()->getUser();
        $learners = $user->getPerson()->getLearners();
        if( ! count($learners) ) {
            return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
        }  
        $learner = $learners[0];
        
        return $this->render( 'notification/notification_individual_feed_page.html.twig', ['group_id' => $group_id, 'learner' => $learner
        ] );
    }

    /**
     * @Route("/member/notification/send_notification_email", name="knoitall_send_notification_email")
     */
    public function sendNotificationEmailAction( Request $request )
    {
        $date = new DateTime();                    
        $currentTime = date_create($date->format('Y-m-d H:i:s')); //, timezone_open('UTC'));

        $getstream_key = $this->getParameter('getstream_key');
        $getstream_secret = $this->getParameter('getstream_secret');
        $client = new \GetStream\Stream\Client( $getstream_key, $getstream_secret );

        $learnerRepository = $this->getDoctrine()->getRepository('AppBundle:Learner');        
        //$learnerTest = $learnerRepository->findOneBy( ['title' => 'Jeff Creighton'] );
        $learners = $learnerRepository->findAll();
        foreach ( $learners as $learner ) {
            $person = $learner->getPerson();
            $user = $person->getUsers()[0];
            $email = strtolower($user->getEmail());
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            // if ($email == 'jeff@inquisic.com') {
                $feed_id = $learner->getId();                
                $name = $learner->getTitle(); 
                //$person->getFirstName() . $person->getLastName();;

                $notificationFeed = $client->feed('notification', strval($feed_id));
                $notificationFeed->setGuzzleDefaultOption('verify', realpath($this->getParameter('app_root_dir') . '/cacert.pem'));

                $results = $notificationFeed->getActivities(0,1);
                $unseenCount = $results['unseen'];               

                $difference_in_seconds = 1000000;
                if ($unseenCount >= 1) {
                    $lastUpdated = $results['results'][0]['updated_at'];
                    $timeTag = date_create($lastUpdated, timezone_open('UTC'));
                    /* currentTime is defined at the top */
                    $interval = $timeTag->diff($currentTime);
                    $difference_in_seconds = ($interval->format('%y') * 365 * 86400) + ($interval->format('%m') * 30 * 86400) + ($interval->format('%d') * 86400) + ($interval->format('%h') * 3600) + ($interval->format('%i') * 60) + $interval->format('%s'); 
                }               

                if (($difference_in_seconds <= 86405) && ($difference_in_seconds > 5) && ($unseenCount >= 1)) {
                    $message = \Swift_Message::newInstance()
                        ->setSubject("Hi " . $person->getFirstName() . ", you have " . strval($unseenCount) . " notification(s) at Knoitall")
                        ->setFrom(['info@knoitall.com' => 'Knoitall'])
                        ->setTo([                            
                            $email => $name]) 
                            // 'ipdilaksana@gmail.com',
                            // 'ipdilaksana@yahoo.com' => 'Ipdi Laksana',
                        // ->setCc()
                        ->setBody(
                            $this->renderView('email/notification.html.twig', ['name' => $name, 'unseenCount' => strval($unseenCount)]), 'text/html' );
                    $this->get('mailer')->send($message); 
                    //$echoes =  'email address: ' . $email . ' - unseen count = ' . $unseenCount . ' - difference in second = ' . $difference_in_seconds;
                    //echo $echoes;
                }
            }    
        }
        //return $this->render( 'learner/public_profile.html.twig', ['learner' => $learner] );
        return $this->render( ':notification:empty.html.twig' );
    }
}
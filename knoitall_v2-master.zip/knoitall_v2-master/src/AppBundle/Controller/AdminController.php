<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Learner;
use AppBundle\Entity\Advisor;
use AppBundle\Entity\Instructor;
use AppBundle\Entity\Provider;
use AppBundle\Entity\Event;
use AppBundle\Entity\Person;
use AppBundle\Entity\User;
use AppBundle\Entity\Article;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use JavierEguiluz\Bundle\EasyAdminBundle\Controller\AdminController as BaseController;
use Ivory\CKEditorBundle\Form\Type\CKEditorType;

class AdminController extends BaseController
{
    /**
     * called from EasyAdmin for previewing learners
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function learnerPreviewAction()
    {
        $id = $this->request->query->get('id');
        $learnerRepository = $this->getDoctrine()->getRepository('AppBundle:Learner');
        /** @var Learner $learner */
        $learner = $learnerRepository->find($id);

        return $this->redirectToRoute('knoitall_learner_public_profile', ['nickname' => $learner->getNickname(), 'hash' => $learner->getHash()]);
    }

    /**
     * called from EasyAdmin for previewing advisors
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function advisorPreviewAction()
    {
        $id = $this->request->query->get('id');
        $advisorRepository = $this->getDoctrine()->getRepository('AppBundle:Advisor');
        /** @var Advisor $advisor */
        $advisor = $advisorRepository->find($id);

        return $this->redirectToRoute('knoitall_advisor_public_profile', ['nickname' => $advisor->getNickname(), 'hash' => $advisor->getHash()]);
    }

    /**
     * called from EasyAdmin for previewing instructors
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function instructorPreviewAction()
    {
        $id = $this->request->query->get('id');
        $instructorRepository = $this->getDoctrine()->getRepository('AppBundle:Instructor');
        /** @var Instructor $instructor */
        $instructor = $instructorRepository->find($id);

        return $this->redirectToRoute('knoitall_instructor_public_profile', ['nickname' => $instructor->getNickname(), 'hash' => $instructor->getHash()]);
    }

    /**
     * called from EasyAdmin for previewing providers
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function providerPreviewAction()
    {
        $id = $this->request->query->get('id');
        $providerRepository = $this->getDoctrine()->getRepository('AppBundle:Provider');
        /** @var Provider $provider */
        $provider = $providerRepository->find($id);

        return $this->redirectToRoute('knoitall_provider_public_profile', ['nickname' => $provider->getNickname(), 'hash' => $provider->getHash()]);
    }

    /**
     * called from EasyAdmin for previewing events
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function eventPreviewAction()
    {
        $id = $this->request->query->get('id');
        $eventRepository = $this->getDoctrine()->getRepository('AppBundle:Event');
        /** @var Event $event */
        $event = $eventRepository->find($id);

        return $this->redirectToRoute('knoitall_event_public_view', ['slug' => $event->getSlug(), 'hash' => $event->getHash()]);
    }

    /**
     * called from EasyAdmin for previewing articles
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function articlePreviewAction()
    {
        $id = $this->request->query->get('id');
        $repository = $this->getDoctrine()->getRepository('AppBundle:Article');
        /** @var Article $article */
        $article = $repository->find($id);

        return $this->redirectToRoute('knoitall_article_detail', ['slug' => $article->getSlug(), 'hash' => $article->getHash()]);
    }

    /**
     * Customize the form created in admin: in particular
     *  - specify the proper fmelfinder properties for the ckeditor object
     *
     * @param object $entity
     * @param array $entityProperties
     * @return \Symfony\Component\Form\Form
     */
    public function createEditForm($entity, array $entityProperties)
    {
        $editForm = parent::createEditForm($entity, $entityProperties);

        if( $entity instanceof Learner ) {
            $editForm->remove('profile');
            $editForm->add( 'profile', CKEditorType::class, [
                'label' => 'Profile',
                'config_name' => 'custom',
                'config' => [
                    'uiColor' => '#ffe0c0',
                    'filebrowserBrowseRoute' => 'elfinder',
                    'filebrowserBrowseRouteParameters' => ['instance' => 'learner', 'homeFolder' => $entity->getHash()],
                    'filebrowserUploadRoute' => 'knoitall_admin_fileupload_upload_media',
                    'filebrowserUploadRouteParameters' => ['entity' => 'learner', 'hash' => $entity->getHash()],
                ],
                'required' => true,
            ] );
        }

        if( $entity instanceof Advisor ) {
            $editForm->remove('profile');
            $editForm->add( 'profile', CKEditorType::class, [
                'label' => 'Profile',
                'config_name' => 'custom',
                'config' => [
                    'uiColor' => '#ffe0c0',
                    'filebrowserBrowseRoute' => 'elfinder',
                    'filebrowserBrowseRouteParameters' => ['instance' => 'advisor', 'homeFolder' => $entity->getHash()],
                    'filebrowserUploadRoute' => 'knoitall_admin_fileupload_upload_media',
                    'filebrowserUploadRouteParameters' => ['entity' => 'advisor', 'hash' => $entity->getHash()],
                ],
                'required' => true,
            ] );
        }
        if( $entity instanceof Instructor ) {
            $editForm->remove('profile');
            $editForm->add( 'profile', CKEditorType::class, [
                'label' => 'Profile',
                'config_name' => 'custom',
                'config' => [
                    'uiColor' => '#ffe0c0',
                    'filebrowserBrowseRoute' => 'elfinder',
                    'filebrowserBrowseRouteParameters' => ['instance' => 'instructor', 'homeFolder' => $entity->getHash()],
                    'filebrowserUploadRoute' => 'knoitall_admin_fileupload_upload_media',
                    'filebrowserUploadRouteParameters' => ['entity' => 'instructor', 'hash' => $entity->getHash()],
                ],
                'required' => true,
            ] );
        }
        if( $entity instanceof Provider ) {
            $editForm->remove('profile');
            $editForm->add( 'profile', CKEditorType::class, [
                'label' => 'Profile',
                'config_name' => 'custom',
                'config' => [
                    'uiColor' => '#ffe0c0',
                    'filebrowserBrowseRoute' => 'elfinder',
                    'filebrowserBrowseRouteParameters' => ['instance' => 'provider', 'homeFolder' => $entity->getHash()],
                    'filebrowserUploadRoute' => 'knoitall_admin_fileupload_upload_media',
                    'filebrowserUploadRouteParameters' => ['entity' => 'provider', 'hash' => $entity->getHash()],
                ],
                'required' => true,
            ] );
        }

        if( $entity instanceof Event ) {
            $editForm->remove('description');
            $editForm->add( 'description', CKEditorType::class, [
                'label' => 'Description',
                'config_name' => 'custom',
                'config' => [
                    'uiColor' => '#ffe0c0',
                    'filebrowserBrowseRoute' => 'elfinder',
                    'filebrowserBrowseRouteParameters' => ['instance' => 'event', 'homeFolder' => $entity->getHash()],
                    'filebrowserUploadRoute' => 'knoitall_admin_fileupload_upload_media',
                    'filebrowserUploadRouteParameters' => ['entity' => 'event', 'hash' => $entity->getHash()],
                ],
                'required' => true,
            ] );
        }

        if( $entity instanceof Article ) {
            $editForm->remove('content');
            $editForm->add( 'content', CKEditorType::class, [
                'label' => 'Content',
                'config_name' => 'custom',
                'config' => [
                    'uiColor' => '#ffe0c0',
                    'filebrowserBrowseRoute' => 'elfinder',
                    'filebrowserBrowseRouteParameters' => ['instance' => 'article', 'homeFolder' => $entity->getHash()],
                    'filebrowserUploadRoute' => 'knoitall_admin_fileupload_upload_media',
                    'filebrowserUploadRouteParameters' => ['entity' => 'article', 'hash' => $entity->getHash()],
                ],
                'required' => true,
            ] );
        }

        return $editForm;
    }

    /**
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/member/admin/user-list/{page}", name="knoitall_admin_user_list", defaults={"page" = 1})
     */
    public function userListAction( Request $request, $page = 1)
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        if(! $this->get('security.authorization_checker')->isGranted('ROLE_ADMIN') ) {
            return $this->render( ':custom_exception:error403.html.twig' ); 
        }

        if ($page < 1) {
            $page = 1;
        }
        $userRepository = $this->getDoctrine()->getRepository('AppBundle:User');
        //$allUserList = $userRepository->findBy( [], ['id' => 'ASC'] );
        //$userTotalAmount = count($allUserList);

        $em = $this->getDoctrine()->getManager();
        $qb = $em->createQueryBuilder();
        $qb->select('count(user.id)');
        $qb->from('AppBundle:User','user');
        $userTotalAmount = $qb->getQuery()->getSingleScalarResult();

        $totalPage = ceil($userTotalAmount/25);
        if ($page > $totalPage) {
            $page = $totalPage;
        }
        $userStartPos = ($page-1)*25;
        $userEndPos = $userStartPos + 25;  // Not included the end pos
        $totalViewed = 25;
        if ($userEndPos > $userTotalAmount) {            
            $totalViewed = $userTotalAmount - $userStartPos;
            $userEndPos = $userStartPos + $totalViewed;
        }

        $userViewedList = $userRepository->findBy(
            array(),
            ['id' => 'ASC'],     // ASC = Ascending  DESC = Descending
            $totalViewed,        // limit or result amount
            $userStartPos        // offset
        );

        return $this->render( ':admin:user_list.html.twig', ['page' => $page, 'totalPage' => $totalPage, 'userStartPos' => $userStartPos+1, 'userEndPos' => $userEndPos, 'userTotalAmount' => $userTotalAmount, 'userViewedList' => $userViewedList] );
    }

    /**
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/member/admin/person-list/{page}", name="knoitall_admin_person_list", defaults={"page" = 1})
     */
    public function personListAction( Request $request, $page = 1)
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        if(! $this->get('security.authorization_checker')->isGranted('ROLE_ADMIN') ) {
            return $this->render( ':custom_exception:error403.html.twig' ); 
        }

        if ($page < 1) {
            $page = 1;
        }
        $personRepository = $this->getDoctrine()->getRepository('AppBundle:Person');
        //$allPersonList = $personRepository->findBy( [], ['id' => 'ASC'] );
        //$personTotalAmount = count($allPersonList);

        $em = $this->getDoctrine()->getManager();
        $qb = $em->createQueryBuilder();
        $qb->select('count(person.id)');
        $qb->from('AppBundle:Person','person');
        $personTotalAmount = $qb->getQuery()->getSingleScalarResult();

        $totalPage = ceil($personTotalAmount/25);
        if ($page > $totalPage) {
            $page = $totalPage;
        }
        $personStartPos = ($page-1)*25;
        $personEndPos = $personStartPos + 25;  // Not included the end pos
        $totalViewed = 25;
        if ($personEndPos > $personTotalAmount) {            
            $totalViewed = $personTotalAmount - $personStartPos;
            $personEndPos = $personStartPos + $totalViewed;
        }

        $personViewedList = $personRepository->findBy(
            array(),
            ['id' => 'ASC'],     // ASC = Ascending  DESC = Descending
            $totalViewed,        // limit or result amount
            $personStartPos        // offset
        );

        $userListFromViewedPersons = [];
        $userRepository = $this->getDoctrine()->getRepository('AppBundle:User');
        foreach( $personViewedList as $person ) {
            $userListFromViewedPersons[$person->getId()] = $userRepository->findBy( ['person' => $person], ['id' => 'ASC'] );
        }

        return $this->render( ':admin:person_list.html.twig', ['page' => $page, 'totalPage' => $totalPage, 'personStartPos' => $personStartPos+1, 'personEndPos' => $personEndPos, 'personTotalAmount' => $personTotalAmount, 'personViewedList' => $personViewedList, 'userListFromViewedPersons' => $userListFromViewedPersons] );
    }

    /**
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/member/admin/provider-list/{page}", name="knoitall_admin_provider_list", defaults={"page" = 1})
     */
    public function providerListAction( Request $request, $page = 1)
    {

        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        if(! $this->get('security.authorization_checker')->isGranted('ROLE_ADMIN') ) {
            return $this->render( ':custom_exception:error403.html.twig' ); 
        }

        if ($page < 1) {
            $page = 1;
        }
        $providerRepository = $this->getDoctrine()->getRepository('AppBundle:Provider');
        //$allProviderList = $providerRepository->findBy( [], ['id' => 'ASC'] );
        //$providerTotalAmount = count($allProviderList);

        $em = $this->getDoctrine()->getManager();
        $qb = $em->createQueryBuilder();
        $qb->select('count(provider.id)');
        $qb->from('AppBundle:Provider','provider');
        $providerTotalAmount = $qb->getQuery()->getSingleScalarResult();

        $totalPage = ceil($providerTotalAmount/25);
        if ($page > $totalPage) {
            $page = $totalPage;
        }
        $providerStartPos = ($page-1)*25;
        $providerEndPos = $providerStartPos + 25;  // Not included the end pos
        $totalViewed = 25;
        if ($providerEndPos > $providerTotalAmount) {            
            $totalViewed = $providerTotalAmount - $providerStartPos;
            $providerEndPos = $providerStartPos + $totalViewed;
        }

        $providerViewedList = $providerRepository->findBy(
            array(),
            ['id' => 'ASC'],     // ASC = Ascending  DESC = Descending
            $totalViewed,        // limit or result amount
            $providerStartPos        // offset
        );

        return $this->render( ':admin:provider_list.html.twig', ['page' => $page, 'totalPage' => $totalPage, 'providerStartPos' => $providerStartPos+1, 'providerEndPos' => $providerEndPos, 'providerTotalAmount' => $providerTotalAmount, 'providerViewedList' => $providerViewedList] );
    }

    /**
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/member/admin/event-list/{page}", name="knoitall_admin_event_list", defaults={"page" = 1})
     */
    public function eventListAction( Request $request, $page = 1)
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }
        
        if(! $this->get('security.authorization_checker')->isGranted('ROLE_ADMIN') ) {
            return $this->render( ':custom_exception:error403.html.twig' ); 
        }

        $user = $this->get('security.token_storage')->getToken()->getUser();
        $providers = $user->getPerson()->getProviders();
        $provider = $providers[0];
        $adminProviderId = $provider->getId();

        if ($page < 1) {
            $page = 1;
        }
        $eventRepository = $this->getDoctrine()->getRepository('AppBundle:Event');
        /*$allEventList = $eventRepository->findBy( [], ['id' => 'ASC'] );
        $eventTotalAmount = count($allEventList);*/

        $em = $this->getDoctrine()->getManager();
        $qb = $em->createQueryBuilder();
        $qb->select('count(event.id)');
        $qb->from('AppBundle:Event','event');
        $eventTotalAmount = $qb->getQuery()->getSingleScalarResult();
        
        $totalPage = ceil($eventTotalAmount/25);
        if ($page > $totalPage) {
            $page = $totalPage;
        }
        $eventStartPos = ($page-1)*25;
        $eventEndPos = $eventStartPos + 25;  // Not included the end pos
        $totalViewed = 25;
        if ($eventEndPos > $eventTotalAmount) {            
            $totalViewed = $eventTotalAmount - $eventStartPos;
            $eventEndPos = $eventStartPos + $totalViewed;
        }

        $eventViewedList = $eventRepository->findBy(
            array(),
            ['id' => 'ASC'],     // ASC = Ascending  DESC = Descending
            $totalViewed,        // limit or result amount
            $eventStartPos        // offset
        );        

        return $this->render( ':admin:event_list.html.twig', ['page' => $page, 'totalPage' => $totalPage, 'eventStartPos' => $eventStartPos+1, 'eventEndPos' => $eventEndPos, 'eventTotalAmount' => $eventTotalAmount, 'eventViewedList' => $eventViewedList, 'adminProviderId' => $adminProviderId] );
    }
}

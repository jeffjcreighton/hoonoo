<?php

namespace AppBundle\Controller;

use AppBundle\Entity\User;
use AppBundle\Entity\Person;
use AppBundle\Entity\Learner;
use AppBundle\Entity\Provider;
use AppBundle\Entity\Event;
use AppBundle\Entity\PathwayEvent;
use AppBundle\Entity\PathwayFeedPos;
use AppBundle\Entity\Taxonomy;
use AppBundle\Form\PathwayType;
use Doctrine\Common\Collections\ArrayCollection;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Form\Form;
use Symfony\Component\Form\FormBuilderInterface;
use AppBundle\Entity\Pathway;

class PathwayController extends Controller
{
    /**
     * Pathway - public view
     *
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @param $pathway \AppBundle\Entity\Pathway
     *
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/pathway/{id}/{page}", name="knoitall_pathway_public_view", defaults={"page" = 1})
     * @ParamConverter("pathway", class="AppBundle:Pathway", isOptional="true")
     */
    public function publicViewAction( Request $request, Pathway $pathway = null, $page = 1)
    {        
        /*
         * if the pathway is not published, then the proper hash (as querystring parameter) must be specified:
         */
        if ($pathway) {
            if( ! $pathway->getPublished() ) {
                $hash = $request->get('hash');
                if ($hash != $pathway->getHash()) {
                    throw $this->createNotFoundException('The pathway is not published');
                }
            }
        }

        $hash = $request->get('hash');
        if ($hash != $pathway->getHash()) {
            throw $this->createNotFoundException('The pathway is not published');
        }

        $provider = $pathway->getProvider();
        $allPathwayEvents = $pathway->getPathwayEvents();
        $pathwayEventTotalAmount = count($allPathwayEvents);

        if( array_key_exists( 'page', $_GET ) ) {
            $page = $_GET["page"];
        }

        if ($page < 1) {
            $page = 1;
        }
        $totalPage = ceil($pathwayEventTotalAmount/10);
        if ($page > $totalPage) {
            $page = $totalPage;
        }
        $eventStartPos = ($page-1)*10;
        $eventEndPos = $eventStartPos + 10;  // Not included the end pos
        $totalViewed = 10;        
        if ($eventEndPos > $pathwayEventTotalAmount) {            
            $totalViewed = $pathwayEventTotalAmount - $eventStartPos;
            $eventEndPos = $eventStartPos + $totalViewed;
        }

        /*$pathwayShownEvents = new ArrayCollection();
        $eventList = $provider->getEvents();
        $pathwayEventRepository = $this->getDoctrine()->getRepository(PathwayEvent::class);
        $pathwayShownEvents = $pathwayEventRepository->findBy(
            ['pathway' => $pathway],
            ['sequence' => 'ASC'],
        );*/
        // $pathwayEvents = $pathway->getPathwayEvents();
        
        /*foreach($pathwayEvents as $pathwayEvent) {
            $includedEvents->add($pathwayEvent->getEvent()); 
        }*/

        return $this->render( 'pathway/public_view.html.twig', [
            'pathway' => $pathway,
            'provider' => $provider,
            'pageNo' => $page,
            'totalPage' => $totalPage,
            'totalViewed' => $totalViewed,
            'eventStartPos' => $eventStartPos,
            'eventEndPos' => $eventEndPos,
            'allPathwayEvents' => $allPathwayEvents,
            'pathwayEventTotalAmount' => $pathwayEventTotalAmount
        ] );
    }

    /**
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @param $provider \AppBundle\Entity\Provider
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/member/pathway/list", name="knoitall_pathway_list")
     */
    public function pathwayListAction( Request $request, Provider $provider = null )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();

        if( ! $provider ) {
            $providers = $user->getPerson()->getProviders();
            if( ! count($providers) ) {
                // return $this->render( 'event/no_learning_center.html.twig' );
                return $this->redirectToRoute('knoitall_provider_profile_wizard');
            }  
            $provider = $providers[0];                
        }

        if( ! count($user->getPerson()->getLearners()) ) {
            return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
        }          

        $pathwayRepository = $this->getDoctrine()->getRepository('AppBundle:Pathway');
        $pathwayList = $pathwayRepository->findBy(array('provider' => $provider));        

        return $this->render( ':pathway:list.html.twig', ['pathwayList' => $pathwayList] );
    }

    /**
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @param $pathway \AppBundle\Entity\Pathway
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @Route("/member/pathway/{id}", name="knoitall_add_edit_pathway", defaults={"id" = null})
     * @ParamConverter("pathway", class="AppBundle\Entity\Pathway", isOptional="true")
     */
    public function pathwayAddEditAction( Request $request, Pathway $pathway = null )
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        /** @var \AppBundle\Entity\User $user */
        $user = $this->get('security.token_storage')->getToken()->getUser();
        $providers = $user->getPerson()->getProviders();
        if( ! count($providers) ) {            
            return $this->redirectToRoute('knoitall_provider_profile_wizard');
        }  
        $provider = $providers[0];
        
        if( ! count($user->getPerson()->getLearners()) ) {    
            return $this->redirectToRoute('knoitall_learner_profile_wizard_step_1');
        }                      

        if( $pathway ) {
            if ($provider != $pathway->getProvider()) {
               return $this->render( ':custom_exception:error403.html.twig' ); 
            }
        }

        $isAddingPathway = false;
        if( ! $pathway ) {
            $pathway = new Pathway();
            $pathway->setProvider( $provider );

            $isAddingPathway = true;
        }

        $includedEvents = new ArrayCollection();
        $excludedEvents = new ArrayCollection();
        $eventList = $provider->getEvents();
        $pathwayEventRepository = $this->getDoctrine()->getRepository(PathwayEvent::class);
        $pathwayEvents = $pathwayEventRepository->findBy(
            ['pathway' => $pathway],
            ['sequence' => 'ASC'] 
        );
        // $pathwayEvents = $pathway->getPathwayEvents();
        
        foreach($pathwayEvents as $pathwayEvent) {
            $includedEvents->add($pathwayEvent->getEvent()); 
        }
        foreach($eventList as $event) {
            if( ! $includedEvents->contains($event) ) {
                $excludedEvents->add($event); 
            }
        }

        $form = $this->createForm( PathwayType::class, $pathway );

        $form->handleRequest($request); 

        if( $form->isSubmitted() and $form->isValid() ) {
            $em = $this->getDoctrine()->getManager();
            $eventRepository = $this->getDoctrine()->getRepository(Event::class);                      

            /** @var Pathway $pathway */
            $pathway = $form->getData();
            $em->persist( $pathway );
            $em->flush();     
            $em->refresh( $pathway );

            /*$pathwayEventRepository = $this->getDoctrine()->getRepository(PathwayEvent::class);
            $pathwayEvents = $pathwayEventRepository->findBy(['pathway' => $pathway]);*/
            $pathwayEvents = $pathway->getPathwayEvents();
            foreach ($pathwayEvents as $pathwayEvent) {
                $em->remove($pathwayEvent);
                $em->flush();
            }

            $eventIdLists = $_POST["event_lists"];
            $isIncludedEvents = $_POST["is_included_events"];
            $orderNoEvents = $_POST["order_no_events"];

            $pointer = 0;
            foreach ($eventIdLists as $eventId) {
                if ($isIncludedEvents[$pointer] == "YES") {
                    $pathwayEvent = new PathwayEvent();
                    $pathwayEvent->setPathway($pathway);

                    $event = $eventRepository->find($eventId);
                    $pathwayEvent->setEvent($event);

                    $sequence = $orderNoEvents[$pointer];
                    $pathwayEvent->setSequence($sequence);                 

                    $em->persist( $pathwayEvent );
                    $em->flush();              
                }
                $pointer++;
            }
            
            $em->persist( $pathway );
            $em->flush();     
            return $this->redirectToRoute('knoitall_add_edit_pathway', ['id' => $pathway->getId()]);
        }

        return $this->render( 'pathway/add_edit_pathway.html.twig', ['form' => $form->createView(), 'pathway' => $pathway, 'includedEvents' => $includedEvents, 'excludedEvents' => $excludedEvents, 'isAddingPathway' => $isAddingPathway
        ] ); 
    }

    /**
     * @Route("/member/pathway/remove/pathway", name="knoitall_pathway_remove_pathway")     
     */
    public function removePathwayAction(Request $request)
    {
        if(! $this->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_REMEMBERED') ) {
            return $this->redirectToRoute('knoitall_homepage');
        }

        $data = null;
        if( $content = $request->getContent() ) {
            $data = json_decode( $content, true );
        }

        if( $data ) {
            $pathwayId = ( isset($data['pathway_id']) ? $data['pathway_id'] : null );         

            $pathwayRepository = $this->getDoctrine()->getRepository(Pathway::class);
            $pathway = ( isset($pathwayId) ? $pathwayRepository->find($pathwayId) : null );            

            $user = $this->get('security.token_storage')->getToken()->getUser();
            $providers = $user->getPerson()->getProviders();

            $isUserProviderExist = false;
            if ( count($providers) ) {
                $provider = $providers[0];
                $isUserProviderExist = true;
            }

            $isAccessOtherUser = false;
            if( $pathway && $isUserProviderExist) {
                if ($provider != $pathway->getProvider()) {
                    $isAccessOtherUser = true;                
                }
            }

            $isAdminAccessOtherUser = false;
            if ( $this->get('security.authorization_checker')->isGranted('ROLE_ADMIN') )  {
                $isAdminAccessOtherUser = true;
            }

            $isRemovePermitted = false;
            if (($isUserProviderExist && !$isAccessOtherUser) || 
                (!$isUserProviderExist && $isAdminAccessOtherUser) ||
                ($isAccessOtherUser && $isAdminAccessOtherUser)) {
               $isRemovePermitted = true;
            } 

            if ($pathway && $isRemovePermitted) {     
                /* $pathwayFeedPosRepository = $this->getDoctrine()->getRepository(PathwayFeedPos::class);           
                $pathwayFeedPoss = $pathwayFeedPosRepository->findBy(['pathway' => $pathway]); */
                $pathwayFeedPoss = $pathway->getPathwayFeedPoss();
                if (count($pathwayFeedPoss)) {
                    $returnValues['pathwayIsUsed'] = 'true';
                } else {
                    $em = $this->getDoctrine()->getManager();
                    $pathwayEvents = $pathway->getPathwayEvents();
                    foreach ($pathwayEvents as $pathwayEvent) {
                        $em->remove($pathwayEvent);                        
                    }
                    $em->flush();
                    $em->remove($pathway);
                    $em->flush();  

                    $returnValues['pathwayIsUsed'] = 'false';
                } 

                $returnValues['status'] = 'OK';
                $response = new Response(json_encode($returnValues));
                $response->headers->set('Content-Type', 'application/json');
                return $response;
            }
        }
        $response = new Response(json_encode(['status' => 'ERROR']));
        $response->headers->set('Content-Type', 'application/json');
        return $response;            
    }
}
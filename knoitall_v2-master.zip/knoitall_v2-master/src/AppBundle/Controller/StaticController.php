<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class StaticController extends Controller
{
    /**
     * @param $page string
     *
     * @return Response
     *
     * @Route("/static/{page}", name="knoitall_static")
     */
    public function defaultAction( $page )
    {
        /*function my_delete_directory($src) { 
            $dir = opendir($src);
            while(false !== ( $file = readdir($dir)) ) { 
                if (( $file != '.' ) && ( $file != '..' )) { 
                    if ( is_dir($src . '/' . $file) ) { 
                        my_delete_directory($src . '/' . $file); 
                    } 
                    else { 
                        unlink($src . '/' . $file); 
                    }   
                } 
            } 
            closedir($dir); 
            rmdir($src);
        }
        
        my_delete_directory('E:/knoitall_Feed_Work/var/cache/dev');*/
        //my_delete_directory('/var/www/html/knoitall_v2/var/cache/dev');
        return $this->render( 'static/' . $page . '.html.twig' );
    }
}

<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\RequestStack;
use AppBundle\Entity\Article;

class ArticleController extends Controller
{
    /**
     * @return Response
     *
     * @Route("/news/latest", name="knoitall_article_latest")
     */
    public function latestAction()
    {
        $articleRepository = $this->get('knoitall_article_repository');

        return $this->render(
            'article/latest.html.twig',
            ['articles' => $articleRepository->findLatest()]
        );
    }

    /**
     * @return Response
     *
     * @Route("/news/archive", name="knoitall_article_archive")
     */
    public function archiveAction()
    {
        $articleRepository = $this->get('knoitall_article_repository');

        return $this->render(
            'article/archive.html.twig',
            ['articles' => $articleRepository->findBy(['published' => true], ['id' => 'ASC'])]
        );
    }

    /**
     * @param $request \Symfony\Component\HttpFoundation\Request
     * @param $article \AppBundle\Entity\Article
     *
     * @return Response
     *
     * @Route("/article/{slug}", name="knoitall_article_detail")
     * @ParamConverter("article", class="AppBundle\Entity\Article")
     */
    public function detailAction( Request $request, Article $article)
    {
        /*
         * if the article is not published, then the proper hash (as querystring parameter) must be specified:
         */
        if ($article) {
            if( ! $article->getPublished() ) {
                $hash = $request->get('hash');
                if ($hash != $article->getHash()) {
                    throw $this->createNotFoundException('The article does not exist');
                }
            }
        }

        return $this->render('article/detail.html.twig', ['article' => $article]);
    }

    /**
     * @param $article
     * @return \HttpResponse
     */
    public function gridItemAction( $article )
    {
        return $this->render( ':article:grid_item.html.twig', ['article' => $article]);
    }
}

<?php

namespace AppBundle\Menu;

use Knp\Menu\FactoryInterface;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use Symfony\Component\DependencyInjection\ContainerAwareTrait;

class Builder implements ContainerAwareInterface
{
    use ContainerAwareTrait;

    public function mainMenu(FactoryInterface $factory, array $options)
    {
        $menu = $factory->createItem('root');

        $menu->addChild( 'Home', ['route' => 'knoitall_homepage'] );
        $menu->addChild( 'Login', ['route' => 'fos_user_security_login'] );

        return $menu;
    }

    public function helpMenu(FactoryInterface $factory, array $options)
    {
        $menu = $factory->createItem('help');

        $menu->addChild( 'Getting Started', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'listing-getting-started'],
            'attributes' => ['class' => 'listing-getting-started']
        ] );
        $menu->addChild( 'Listing Guidelines', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'listing-guidelines'],
            'attributes' => ['class' => 'listing-guidelines']
        ] );
        $menu->addChild( 'Knoitall Advertising and Sales Fees', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'listing-advertising-and-sales-fees'],
            'attributes' => ['class' => 'listing-advertising-and-sales-fees']
        ] );
        $menu->addChild( 'Getting Paid', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'listing-getting-paid'],
            'attributes' => ['class' => 'listing-getting-paid']
        ] );
        $menu->addChild( 'Connecting My Learning Center to Stripe', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'listing-stripe'],
            'attributes' => ['class' => 'listing-stripe']
        ] );
        $menu->addChild( 'How Knoitall Syndicates Your Learning', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'listing-syndication'],
            'attributes' => ['class' => 'listing-syndication']
        ] );
        $menu->addChild( 'Adding Content from Other Learning Providers to My Learning Center', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'listing-provider-affiliate'],
            'attributes' => ['class' => 'listing-provider-affiliate']
        ] );
        $menu->addChild( 'Building Your Learning Center', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'listing-building-your-learning-center'],
            'attributes' => ['class' => 'listing-building-your-learning-center']
        ] );
        $menu->addChild( 'Listing a Class', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'listing-class'],
            'attributes' => ['class' => 'listing-class']
        ] );
        $menu->addChild( 'Listing a YouTube Video', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'listing-youtube'],
            'attributes' => ['class' => 'listing-youtube']
        ] );
        $menu->addChild( 'Listing a SlideShare Presentation', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'listing-slideshare'],
            'attributes' => ['class' => 'listing-slideshare']
        ] );
        $menu->addChild( 'Listing Lessons or Tutoring', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'listing-lessons-or-tutoring'],
            'attributes' => ['class' => 'listing-lessons-or-tutoring']
        ] );
        $menu->addChild( 'Listing Consulting or Advising Services', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'listing-consulting-or-advising-services'],
            'attributes' => ['class' => 'listing-consulting-or-advising-services']
        ] );
        $menu->addChild( 'Listing a Product that is Shipped', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'listing-a-product-that-is-shipped'],
            'attributes' => ['class' => 'listing-a-product-that-is-shipped']
        ] );
        $menu->addChild( 'Listing a Certificate or Degree', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'listing-certificate-or-degree'],
            'attributes' => ['class' => 'listing-certificate-or-degree']
        ] );
        $menu->addChild( 'Creating Effective Listings', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'listing-creating-effective-listings'],
            'attributes' => ['class' => 'listing-creating-effective-listings']
        ] );
        $menu->addChild( 'Managing Your Listings', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'listing-managing-your-listings'],
            'attributes' => ['class' => 'listing-managing-your-listings']
        ] );
        $menu->addChild( 'Managing Your Audience', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'listing-managing-your-audience'],
            'attributes' => ['class' => 'listing-managing-your-audience']
        ] );
        $menu->addChild( 'How to Become a Better Seller', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'listing-how-to-become-a-better-seller'],
            'attributes' => ['class' => 'listing-how-to-become-a-better-seller']
        ] );
        $menu->addChild( 'Using Knoitall to Connect to Other Learning Resources', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'listing-connect-to-other-learning-resources'],
            'attributes' => ['class' => 'listing-connect-to-other-learning-resources']
        ] );

        return $menu;
    }

    public function learningHelpMenu(FactoryInterface $factory, array $options)
    {
        $menu = $factory->createItem('help');

        $menu->addChild('Join Our Community', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'learning-join-our-community'],
            'attributes' => ['class' => 'learning-join-our-community']
        ]);
        $menu->addChild('Knoitall Buyer Protections', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'learning-buyer-protection'],
            'attributes' => ['class' => 'learning-buyer-protection']
        ]);
        $menu->addChild('How We Secure Your Payments', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'learning-secure-payment'],
            'attributes' => ['class' => 'learning-secure-payment']
        ]);
        $menu->addChild('Our Learning Categories', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'learning-categories'],
            'attributes' => ['class' => 'learning-categories']
        ]);
        $menu->addChild('Certification of Learning Providers Within Knoitall', [
            'route' => 'knoitall_help',
            'routeParameters' => ['page' => 'learning-certification-policy'],
            'attributes' => ['class' => 'learning-certification-policy']
        ]);

        return $menu;
    }
}
<?php

namespace AppBundle\Twig;

use AppBundle\Entity\Advisor;
use AppBundle\Entity\Article;
use AppBundle\Entity\Event;
use AppBundle\Entity\Instructor;
use AppBundle\Entity\Learner;
use AppBundle\Entity\Provider;

class KnoitallTwigExtension extends \Twig_Extension
{
    public function getTests()
    {
        return [
            new \Twig_SimpleTest('learner', function($object) { return $object instanceof Learner; } ),
            new \Twig_SimpleTest('advisor', function($object) { return $object instanceof Advisor; } ),
            new \Twig_SimpleTest('instructor', function($object) { return $object instanceof Instructor; } ),
            new \Twig_SimpleTest('provider', function($object) { return $object instanceof Provider; } ),
            new \Twig_SimpleTest('event', function($object) { return $object instanceof Event; } ),
            new \Twig_SimpleTest('article', function($object) { return $object instanceof Article; } ),
        ];
    }

    public function getName()
    {
        return 'knoitall_twig_extension';
    }
}

<?php

namespace AppBundle\Namer;

use Vich\UploaderBundle\Naming\DirectoryNamerInterface;
use Vich\UploaderBundle\Mapping\PropertyMapping;
use AppBundle\Entity\Pathway;

class PathwayMediaDirectoryNamer implements DirectoryNamerInterface
{
    /**
     * @param Pathway $pathway
     * @param PropertyMapping $mapping
     * @return mixed
     */
    public function directoryName($pathway, PropertyMapping $mapping)
    {
        /**
         * This is appended to the upload_destination/uri_prefix configuration values,
         * so we'll end up with something like /media/pathway/57b6ecaf55bf01.47055012
         */
        return $pathway->getHash();
    }
}

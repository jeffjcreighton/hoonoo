<?php

namespace AppBundle\Namer;

use Vich\UploaderBundle\Naming\DirectoryNamerInterface;
use Vich\UploaderBundle\Mapping\PropertyMapping;
use AppBundle\Entity\Location;

class LocationMediaDirectoryNamer implements DirectoryNamerInterface
{
    /**
     * @param Location $location
     * @param PropertyMapping $mapping
     * @return mixed
     */
    public function directoryName($location, PropertyMapping $mapping)
    {
        /**
         * This is appended to the upload_destination/uri_prefix configuration values,
         * so we'll end up with something like /media/location/57b6ecaf55bf01.47055012
         */
        return $location->getHash();
    }
}
